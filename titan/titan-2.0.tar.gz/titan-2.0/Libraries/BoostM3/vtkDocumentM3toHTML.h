/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkDocumentM3toHTML vtkDocumentM3toHTML.h <TextAnalysis/vtkDocumentM3toHTML.h>
/// \brief Adds a new column to a vtkTable that has html tags for entities

#ifndef __vtkDocumentM3toHTML_h
#define __vtkDocumentM3toHTML_h

#include "titanBoostM3.h"
#include "vtkTableAlgorithm.h"

class vtkStringArray;
class vtkStdString;

class TITAN_BOOST_M3_EXPORT vtkDocumentM3toHTML : public vtkTableAlgorithm
{
public:
  static vtkDocumentM3toHTML* New();
  vtkTypeMacro(vtkDocumentM3toHTML, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  vtkGetStringMacro(ArrayName);
  vtkSetStringMacro(ArrayName);

//BTX
protected:
  vtkDocumentM3toHTML();
  ~vtkDocumentM3toHTML();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(vtkInformation*,vtkInformationVector**,vtkInformationVector*);

  char* ArrayName;

private:

  void HTMLEncoding(std::ostream& stream,
                    const vtkStdString& source,
                    const vtkIdType begin,
                    const vtkIdType end);

  vtkDocumentM3toHTML(const vtkDocumentM3toHTML&); // Not implemented
  void operator=(const vtkDocumentM3toHTML&);   // Not implemented
//ETX
};

#endif
