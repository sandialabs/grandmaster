/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkCommand.h>
#include <vtkDocumentM3MetaData.h>
#include <vtkIdTypeArray.h>
#include <vtkInformation.h>
#include <vtkObjectFactory.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkUnicodeStringArray.h>

#include <stdexcept>

// Boost stuff for M3MetaData
#include <boost/regex.hpp>
#include <boost/xpressive/xpressive.hpp>
#include <boost/xpressive/regex_actions.hpp>

using namespace boost::xpressive;

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#define DEBUG_TOKENS       0
#define DEBUG_PRINT_BINS   0
#define TOKENIZE_LINES     0
#define TRY_UNICODESTRINGS 0   // TURN ON UNICODESTRINGS--CURRENTLY B0RKED


vtkStandardNewMacro(vtkDocumentM3MetaData);


vtkDocumentM3MetaData::vtkDocumentM3MetaData()
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");
  this->SetNumberOfInputPorts(1);
}



vtkDocumentM3MetaData::~vtkDocumentM3MetaData()
{
}



void vtkDocumentM3MetaData::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "TextColumnName: "
     << (this->TextColumnName ? this->TextColumnName : "(none)") << "\n";
}



int vtkDocumentM3MetaData::RequestData(
  vtkInformation* request,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{

  // CREATE A TAG TYPE ENUM TO HELP KEEP TRACK OF WHERE WE ARE.
  enum iirTagTypes { TAG_UNKNOWN, TAG_ACQ, TAG_CONTROLS, TAG_COUNTRY, TAG_BT,
                     TAG_CLASSIFICATION, TAG_DIST, TAG_DISSEM, TAG_DOCNO,
                     TAG_DOI, TAG_DTG, TAG_FROM, TAG_IIR, TAG_INSTR, TAG_IPSP,
                     TAG_PREC, TAG_PREP, TAG_REQS, TAG_SERIAL, TAG_SOURCE,
                     TAG_SUBJ, TAG_SUMMARY, TAG_TEXT, TAG_TO, TAG_WARNING,
                     TAG_ENDOFADDRS, TAG_ENDOFMSG, TAG_NONE };

  iirTagTypes tag_type = TAG_UNKNOWN;

  // -------------------------------------------------------------------------
  //  B E G I N   I I R   R E G E X   G R A M M A R
  // -------------------------------------------------------------------------

  // MATCHES A FULL LINE OF TEXT
  sregex rex_line = *~_n >> _n;

  // MATCH A DTG TAG (STORES DATE/TIME INFO)
  sregex iir_dtg = ((s1=(( as_xpr('O') | as_xpr('P') | as_xpr('R') |
                     as_xpr('W') | as_xpr('Y') | as_xpr('Z') )))
                   >> +_s >> (s2=(repeat<6>(_d) >> "Z"
                   >> +_s >> repeat<3>(alpha)
                   >> +_s >> repeat<2>(_d))))
                   [ref((int&)tag_type)=(int)TAG_DTG];

  // IIR SECTION TAGS
  sregex iir_bt       = as_xpr("BT")                              // TAG: BT
                        [ref((int&)tag_type)=(int)TAG_BT];
  sregex iir_acq      = as_xpr("ACQ:")                             // TAG: ACQ
                        [ref((int&)tag_type)=(int)TAG_ACQ];
  sregex iir_controls = as_xpr("CONTROLS:")                        // TAG: CONTROLS
                        [ref((int&)tag_type)=(int)TAG_CONTROLS];
  sregex iir_country  = as_xpr("COUNTRY:")                         // TAG: COUNTRY
                        [ref((int&)tag_type)=(int)TAG_COUNTRY];
  sregex iir_dist     = as_xpr("DIST:")                            // TAG: DIST
                        [ref((int&)tag_type)=(int)TAG_DIST];
  sregex iir_dissem   = as_xpr("DISSEM:")                          // TAG: DISSEM
                        [ref((int&)tag_type)=(int)TAG_DISSEM];
  sregex iir_docno    = as_xpr("DOCNO:")                           // TAG: DOCNO
                        [ref((int&)tag_type)=(int)TAG_DOCNO];
  sregex iir_doi      = as_xpr("DOI")                             // TAG: DOI
                        [ref((int&)tag_type)=(int)TAG_DOI];
  sregex iir_from     = (as_xpr("FROM") | as_xpr("FM") |          // TAG: FROM
                        as_xpr("<REASFROM>"))
                        [ref((int&)tag_type)=(int)TAG_FROM];
  sregex iir_iir      = as_xpr("IIR")                             // TAG: IIR
                        [ref((int&)tag_type)=(int)TAG_IIR];
  sregex iir_instr    = as_xpr("INSTR:")                           // TAG: INSTR
                        [ref((int&)tag_type)=(int)TAG_INSTR];
  sregex iir_ipsp     = as_xpr("IPSP:")                            // TAG: IPSP
                        [ref((int&)tag_type)=(int)TAG_IPSP];
  sregex iir_prec     = as_xpr("PREC:")                            // TAG: PREC
                        [ref((int&)tag_type)=(int)TAG_PREC];
  sregex iir_prep     = as_xpr("PREP:")                            // TAG: PREP
                        [ref((int&)tag_type)=(int)TAG_PREP];
  sregex iir_reqs     = as_xpr("REQS:")                            // TAG: REQS
                        [ref((int&)tag_type)=(int)TAG_REQS];
  sregex iir_serial   = as_xpr("SERIAL:")                          // TAG: SERIAL
                        [ref((int&)tag_type)=(int)TAG_SERIAL];
  sregex iir_source   = as_xpr("SOURCE:")                          // TAG: SOURCE
                        [ref((int&)tag_type)=(int)TAG_SOURCE];
  sregex iir_subj     = as_xpr("SUBJ:")                            // TAG: SUBJ
                        [ref((int&)tag_type)=(int)TAG_SUBJ];
  sregex iir_summary  = as_xpr("SUMMARY:")                         // TAG: SUMMARY
                        [ref((int&)tag_type)=(int)TAG_SUMMARY];
  sregex iir_text     = as_xpr("TEXT")                            // TAG: TEXT
                        [ref((int&)tag_type)=(int)TAG_TEXT];
  sregex iir_to       = as_xpr("TO")                              // TAG: TO
                        [ref((int&)tag_type)=(int)TAG_TO];
  sregex iir_warning  = as_xpr("WARNING:")                         // TAG: WARNING
                        [ref((int&)tag_type)=(int)TAG_WARNING];
  sregex iir_endofmsg = (as_xpr("NNNN"))                          // TAG: ENDOFMSG
                        [ref((int&)tag_type)=(int)TAG_ENDOFMSG];
  sregex iir_endofaddrs = (as_xpr("QQQQ"))                        // TAG: ENDOFADDRS
                        [ref((int&)tag_type)=(int)TAG_ENDOFADDRS];

  sregex iir_classification = (s1=(as_xpr("UNCLAS")
                              | !as_xpr("T O P ") >> as_xpr("S E C R E T")
                              | as_xpr("C O N F I D E N T I A L")))
                              [ref((int&)tag_type)=(int)TAG_CLASSIFICATION];

  sregex data_ipaddr = repeat<1,3>(repeat<1,3>(_d) >> ".") >> repeat<1,3>(_d);

  sregex data_class_short = ("(" >> (s1=(as_xpr("U")|as_xpr("C"))) >> ")");

  sregex data_serial = !("(" >> (s1=(as_xpr("U")|as_xpr("C"))) >> ")" >> *_s)
                        >> "IIR" >> *_s
                        >> (s2=(_d >> +_s >> repeat<3>(_d) >> +_s
                        >> repeat<4>(_d) >> +_s >> repeat<2>(_d) ));

  sregex iir_tags = bos >> (iir_text | iir_bt   | iir_acq     | iir_controls
                    | iir_country    | iir_dist | iir_dissem  | iir_docno
                    | iir_doi        | iir_from | iir_iir     | iir_instr
                    | iir_ipsp       | iir_prec | iir_reqs    | iir_serial
                    | iir_source     | iir_subj | iir_summary | iir_dtg
                    | iir_endofmsg   | iir_endofaddrs | iir_classification);

  // A REGEX FOR PARSING THROUGH LINES TO GET RELEVANT INFO OUT OF THEM
  // (ACTUALLY JUST TOKENIZES THE LINE INTO A STREAM BUT KEEP SOME THINGS
  // TOGETHER IF WE KNOW WHAT TO LOOK FOR)
  sregex iir_data = data_ipaddr
                    | iir_classification
                    | *~_s>>+_s;

  // -------------------------------------------------------------------------
  //  E N D   I I R   R E G E X   G R A M M A R
  // -------------------------------------------------------------------------

  // DOCUMENT SECTIONS, FOR NOW WE WILL JUST SPLIT INTO 3 SECTIONS
  // -- HEADER / BODY TEXT / FOOTER
  enum iir_docSectionType {IIR_HEADER, IIR_BODY, IIR_FOOTER};

  try
    {
    // GET THE INPUT DATA
    vtkTable* const input_table = vtkTable::GetData(inputVector[0]);
    if(!input_table)
      throw std::runtime_error("missing input table");

    vtkUnicodeStringArray * const text_array =
        vtkUnicodeStringArray::SafeDownCast(
            this->GetInputAbstractArrayToProcess(0, 0, inputVector)
        );
    if(!text_array)
      throw std::runtime_error("missing text array");

    // ALLOCATE NEW TABLE COLUMNS TO BE ADDED
    VTK_CREATE(vtkUnicodeStringArray, header_array);
    VTK_CREATE(vtkUnicodeStringArray, body_array);
    VTK_CREATE(vtkUnicodeStringArray, footer_array);
    header_array->SetName("header");
    body_array->SetName("body");
    footer_array->SetName("footer");

    // LOOP OVER DOCUMENTS (i.e., TABLE ROWS)
    for(vtkIdType doci=0; doci < text_array->GetNumberOfTuples(); doci++)
      {
      //cout << "+++++[" << doci << "]++++++++++++++++++++++++++++" << endl;

      int doc_offset = 0;
      iir_docSectionType iir_docSection = IIR_HEADER;
      tag_type = TAG_UNKNOWN;

      // GET THE DOCUMENT AS A STRING (TODO: MAKE THIS A UNICODE STRING)
      vtkStdString text_entry = text_array->GetValue(doci).utf8_str();

      // CREATE STRINGS TO STORE SECTIONAL DATA FROM THE DOCUMENT
      vtkUnicodeString ustr_IIRsec_Header;
      vtkUnicodeString ustr_IIRsec_Body;
      vtkUnicodeString ustr_IIRsec_Footer;

#if TRY_UNICODESTRINGS
      // EXPERIMENTAL, VTKUNICODESTRING NEEDS A BIT MORE CAPABILITY BEFORE IT'LL
      // MAKE BOOST ALGORITHMS HAPPY.
      std::vector<std::string> strs;
      // TODO: Get this working directly on unicode strings
      std::vector<vtkUnicodeString> ucodeStrs;
      boost::split(ucodeStrs, text_array->GetValue(doci), boost::is_any_of("\n"));
#endif

      // SPLIT OUT DOCUMENT BY LINES AND STREAM THROUGH THEM
      sregex_token_iterator iter_line( text_entry.begin(), text_entry.end(), rex_line);
      sregex_token_iterator iter_line_end;

      for(vtkIdType line_no=1;
          iter_line != iter_line_end;
          ++iter_line, ++line_no)
        {
        std::string M3DocumentLine = *iter_line;

        tag_type = TAG_NONE;

#if DEBUG_TOKENS
        cout << std::setw(5) << line_no << " ("
             << std::setw(3) << M3DocumentLine.size() << ") "
             << "-----[" << M3DocumentLine << "]\n";
#endif

        // SEARCH THE LINE FOR ANY IIR TAGS (NOTE: THE REGEX RULES
        // SET THE STATE IF THEY MATCH ANY OF THE IIR TAGS). IF NECESSARY
        // WE CAN DO OTHER SPECIAL STUFF IF OUR LINE MATCHES A TAG.
        if( regex_search(M3DocumentLine, sregex(iir_tags)) )
          {
#if DEBUG_TOKENS
          cout << "\t!!! IIR TAG FOUND ("<< tag_type<<")!!!" << endl;
#endif
          smatch what;
          switch(tag_type)
            {
            case TAG_BT:
              // cout << "\tBT TAG" << endl;
              break;
            case TAG_DTG:
              {
              //cout << "\tDTG TAG" << endl;
              regex_search(M3DocumentLine, what, iir_dtg);
              // what[1] contains the PREC tag
              // what[2] contains the zulu time
              //cout << "\t s:" << what.size() << endl;
              //cout << "\t" << what[0] << endl;
              }
              break;
            case TAG_SERIAL:
              {
              //cout << "\tSERIAL TAG" << endl;
              regex_search(M3DocumentLine, what, data_serial);
              // what[1] contains classification [UC] if any
              // what[2] contains the IIR serial number: N NNN NNNN NN
              }
              break;
            case TAG_FROM:
              //cout << "\tFROM TAG" << endl;
              break;
            case TAG_SOURCE:
              //cout << "\tSOURCE TAG" << endl;
              break;
            case TAG_SUBJ:
              //cout << "\tSUBJ TAG" << endl;
              break;
            case TAG_ENDOFMSG:
              //cout << "\tENDOFMSG TAG" << endl;
              break;
            case TAG_ENDOFADDRS:
              //cout << "\tQQQQ TAG" << endl;
              break;
            case TAG_CLASSIFICATION:
              regex_search(M3DocumentLine, what, iir_classification);
              // what[1] = UNCLAS | T O P S E C R E T | C O N F I D E N T I A L
              //cout << "\tsz=" << what.size();
              //cout << "\t" << what[1] << endl;
              break;
            default:
              if(tag_type != TAG_NONE)
                {
                //cout << "\tTAG (" << tag_type << ")" << endl;
                }
              break;
            };
          }

#if TOKENIZE_LINES
        sregex_token_iterator tok( M3DocumentLine.begin(),
                                   M3DocumentLine.end(),
                                   iir_data);
        sregex_token_iterator tok_end;
        for( ; tok != tok_end; ++tok)
          {
          std::string strToken = *tok;
          cout << std::setw(3) << strToken.size()
               << " {" << strToken << "}" << endl;
          }
#endif

#if DEBUG_TOKENS
        cout << "\ttag = " << tag_type << endl;
#endif

        // DUMP THE STRING INTO THE APPROPRIATE BUCKET, WHEN WE START PARSING
        // THE DOCUMENTS BETTER THIS WILL BECOME MORE SOPHISTICATED.
        if(IIR_HEADER==iir_docSection && TAG_TEXT==tag_type)
          {
          iir_docSection = IIR_BODY;
          }
        else if(IIR_BODY==iir_docSection && TAG_NONE!=tag_type)
          {
          iir_docSection = IIR_FOOTER;
          }

        switch(iir_docSection)
          {
          case IIR_HEADER:
            ustr_IIRsec_Header += vtkUnicodeString::from_utf8(M3DocumentLine);
            break;
          case IIR_BODY:
            ustr_IIRsec_Body += vtkUnicodeString::from_utf8(M3DocumentLine);
            break;
          case IIR_FOOTER:
            ustr_IIRsec_Footer += vtkUnicodeString::from_utf8(M3DocumentLine);
            break;
          default:
            break;
          };

        // UPDATE THE OFFSET WITH THE LENGTH OF THIS LINE
        doc_offset += M3DocumentLine.size();
        }

#if DEBUG_PRINT_BINS
      cout << "=====[ HEADER ]=====\n" << ustr_IIRsec_Header.utf8_str() << endl;
      cout << "=====[ BODY  ]=====\n" << ustr_IIRsec_Body.utf8_str() << endl;
      cout << "=====[ FOOTER ]=====\n" << ustr_IIRsec_Footer.utf8_str() << endl;
#endif

      header_array->InsertNextValue( ustr_IIRsec_Header );
      body_array->InsertNextValue( ustr_IIRsec_Body );
      footer_array->InsertNextValue( ustr_IIRsec_Footer );

      // COMPARE BUFFER SIZES AS A QUICK SANITY CHECK
      vtkIdType output_size = ustr_IIRsec_Header.character_count() +
                              ustr_IIRsec_Body.character_count()   +
                              ustr_IIRsec_Footer.character_count();
      vtkIdType input_size  = text_entry.size();
      if(output_size != input_size)
        {
        vtkErrorMacro(<< "input and output buffers sizes don't match."
                      << " input_size="  << input_size
                      << " output_size=" << output_size);
        return 0;
        }

      // EMIT A PROGRESS EVENT
      double progress = doci / (double)text_array->GetNumberOfTuples();
      this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
      cout << "."; fflush(stdout);
      }  // doci
    cout << endl;

    vtkTable * const output_table = vtkTable::GetData(outputVector);
    output_table->ShallowCopy(input_table);
    output_table->AddColumn(header_array);
    output_table->AddColumn(body_array);
    output_table->AddColumn(footer_array);
    } // end try
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  return 1;
}

// TODO: Use unicode directly... dependent on some new stuff being added to
//       vtkUnicodeString to make Boost happy...
