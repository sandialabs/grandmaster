/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkCommand.h"
#include "vtkDocumentM3toHTML.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkObjectFactory.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"
#include "vtkSmartPointer.h"

#include <set>
#include <string>
#include <algorithm>
#include <iterator>
#include <sstream>
#include <stdexcept>
#include <iomanip>

#include <boost/regex.hpp>

#define DEBUG 0

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkDocumentM3toHTML);


///////////////////////////////////////////////////////////////////////////
// HTMLEncoding
void
vtkDocumentM3toHTML::HTMLEncoding(std::ostream& stream,
                         const vtkStdString& source,
                         const vtkIdType begin,
                         const vtkIdType end)
{
  for(vtkIdType i = begin; i != end; ++i)
    {
    if(source[i] == '<')
      stream << "&lt;";
    else if(source[i] == '>')
      stream << "&gt;";
    else
      stream << source[i];
    }
}


vtkDocumentM3toHTML::vtkDocumentM3toHTML() : ArrayName(0)
{
  this->SetArrayName("html");

  // Set port information
  this->SetNumberOfInputPorts(3);
  this->SetNumberOfOutputPorts(1);

  // From DocumentExtract
  this->SetInputArrayToProcess(0, 0, 0, 6, "document");
  this->SetInputArrayToProcess(1, 0, 0, 6, "text");

  // From M3MetaTagTable
  this->SetInputArrayToProcess(2, 1, 0, 6, "document");
  this->SetInputArrayToProcess(3, 1, 0, 6, "begin");
  this->SetInputArrayToProcess(4, 1, 0, 6, "end");
  this->SetInputArrayToProcess(5, 1, 0, 6, "type");

  // From StanfordNER
  this->SetInputArrayToProcess( 6, 2, 0, 6, "document");
  this->SetInputArrayToProcess( 7, 2, 0, 6, "begin");
  this->SetInputArrayToProcess( 8, 2, 0, 6, "end");
  this->SetInputArrayToProcess( 9, 2, 0, 6, "type");
  this->SetInputArrayToProcess(10, 2, 0, 6, "text");
}


vtkDocumentM3toHTML::~vtkDocumentM3toHTML()
{
  this->SetArrayName(0);
}


void vtkDocumentM3toHTML::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "ArrayName: " << (this->ArrayName ? this->ArrayName : "(none)") << endl;
}


int vtkDocumentM3toHTML::FillInputPortInformation(int port, vtkInformation* information)
{
    switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;

    case 1:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}


int vtkDocumentM3toHTML::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  #if DEBUG
  cout << ">>>>>>>>>> " << __PRETTY_FUNCTION__ << endl;
  #endif

  try
    {

    enum SENSITIVITYLEVEL {UNKNOWN, UNCLASSIFIED, CONFIDENTIAL, SECRET, TOPSECRET };

    // Validate our required inputs ...
    vtkTable * const document_table = vtkTable::GetData(inputVector[0]);
    if(!document_table)
      {
      throw std::runtime_error("Missing vtkTable on input port 0.");
      }

    vtkTable * const m3_tag_table = vtkTable::GetData(inputVector[1]);
    if(!m3_tag_table)
      {
      throw std::runtime_error("Missing vtkTable on input port 1.");
      }

    vtkTable * const sner_tag_table = vtkTable::GetData(inputVector[2]);
    if(!sner_tag_table)
      {
      throw std::runtime_error("Missing vtkTable on input port 2.");
      }

    // Downcast the input arrays into something we can work with...
    // -- documents table --
    vtkIdTypeArray * const document_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!document_array) throw std::runtime_error("Missing document array.");

    vtkUnicodeStringArray * const document_text_array = vtkUnicodeStringArray::SafeDownCast(this->GetInputAbstractArrayToProcess(1, 0, inputVector));
    if(!document_text_array) throw std::runtime_error("Missing document text array.");

    // -- m3 tag table --
    vtkIdTypeArray * const m3_document_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(2, 0, inputVector));
    if(!m3_document_array) throw std::runtime_error("Missing m3 document array.");

    vtkIdTypeArray * const m3_begin_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(3, 0, inputVector));
    if(!m3_begin_array) throw std::runtime_error("Missing m3 begin array.");

    vtkIdTypeArray * const m3_end_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(4, 0, inputVector));
    if(!m3_end_array) throw std::runtime_error("Missing m3 end array.");

    vtkStringArray * const m3_type_array = vtkStringArray::SafeDownCast(this->GetInputAbstractArrayToProcess(5, 0, inputVector));
    if(!m3_type_array) throw std::runtime_error("Missing m3 type array.");

    // -- StanfordNER tag table --
    vtkIdTypeArray * const sner_document_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(6, 0, inputVector));
    if(!sner_document_array) throw std::runtime_error("Missing sner document array.");

    vtkIdTypeArray * const sner_begin_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(7, 0, inputVector));
    if(!sner_begin_array) throw std::runtime_error("Missing sner begin array.");

    vtkIdTypeArray * const sner_end_array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(8, 0, inputVector));
    if(!sner_end_array) throw std::runtime_error("Missing sner end array.");

    vtkStringArray * const sner_type_array = vtkStringArray::SafeDownCast(this->GetInputAbstractArrayToProcess(9, 0, inputVector));
    if(!sner_type_array) throw std::runtime_error("Missing sner type array.");

    vtkUnicodeStringArray * const sner_text_array = vtkUnicodeStringArray::SafeDownCast(this->GetInputAbstractArrayToProcess(10, 0, inputVector));
    if(!sner_text_array) throw std::runtime_error("Missing sner text array.");
#if DEBUG
    cout << " 0: [" << document_array->GetName() << "]" << endl;
    cout << " 1: [" << document_text_array->GetName() << "]" << endl;
    cout << " 2: [" << m3_document_array->GetName() << "]" << endl;
    cout << " 3: [" << m3_begin_array->GetName() << "]" << endl;
    cout << " 4: [" << m3_end_array->GetName() << "]" << endl;
    cout << " 5: [" << m3_type_array->GetName() << "]" << endl;
    cout << " 6: [" << sner_document_array->GetName() << "]" << endl;
    cout << " 7: [" << sner_begin_array->GetName() << "]" << endl;
    cout << " 8: [" << sner_end_array->GetName() << "]" << endl;
    cout << " 9: [" << sner_type_array->GetName() << "]" << endl;
    cout << "10: [" << sner_text_array->GetName() << "]" << endl;
#endif

    const vtkIdType document_count = document_array->GetNumberOfTuples();
    const vtkIdType m3_tag_count   = m3_document_array->GetNumberOfTuples();
    const vtkIdType sner_tag_count = sner_document_array->GetNumberOfTuples();

    // Setup the output...
    vtkTable * const output = vtkTable::GetData(outputVector,0);
    if(!output)
      {
      throw std::runtime_error("Missing vtkTable on output port 0.");
      }
    output->ShallowCopy(document_table);

    VTK_CREATE(vtkStringArray, html_array);
    html_array->SetName(this->GetArrayName());
    html_array->SetNumberOfValues(document_count);
    output->AddColumn(html_array);

    // Only do something if we have documents.
    if(document_count > 0)
      {
      // For every document...
      for(vtkIdType document_index=0; document_index != document_count; ++document_index)
        {
        #if DEBUG
        cout << "=====[ DOCUMENT " << document_index << " ]=================================\n";
        #endif

        // Initialize the HTML div sections for the document
        std::ostringstream html_div_clearing;
        std::ostringstream html_div_header;
        std::ostringstream html_div_documentTitle;
        std::ostringstream html_div_classification;
        std::ostringstream html_div_leftbar;
        std::ostringstream html_div_subj;
        std::ostringstream html_div_source;
        std::ostringstream html_div_meta;
        std::ostringstream html_div_messageText;
        std::ostringstream html_div_fullText;
        std::ostringstream html_body;

        std::multiset<vtkIdType> m3_meta_tags;
        for(vtkIdType m3_index=0; m3_index != m3_tag_count; ++m3_index)
          {
          if(m3_document_array->GetValue(m3_index) == document_index)
            m3_meta_tags.insert( m3_index );
          }   // for(m3_index)

        std::multiset<vtkIdType> sner_meta_tags;
        for(vtkIdType sner_index=0; sner_index != sner_tag_count; ++sner_index)
          {
          if(sner_document_array->GetValue(sner_index) == document_index)
            sner_meta_tags.insert(sner_index);
          }

        const vtkStdString body = document_text_array->GetValue(document_index).utf8_str();

        std::multiset<vtkIdType>::iterator iter_m3 = m3_meta_tags.begin();
        std::multiset<vtkIdType>::iterator iter_sner= sner_meta_tags.begin();

        vtkIdType plain_begin = 0;
        vtkIdType plain_end   = 0;

        bool inTextSection      = false;
        bool haveSerial         = false;
        int  docClassification  = UNKNOWN;

        //cout << "docClassification = " << docClassification << endl;

        // Iterate over tags, always taking the one with the smallest begin index.
        // ** this could get tricky b/c we're merging two multisets.
        while(iter_m3 != m3_meta_tags.end() || iter_sner != sner_meta_tags.end())
          {
          vtkIdType m3_begin   = -1;
          vtkIdType sner_begin = -1;

          if(iter_m3 != m3_meta_tags.end())
            {
            m3_begin = std::min<vtkIdType>(static_cast<vtkIdType>(body.size()), m3_begin_array->GetValue(*iter_m3));
            }
          if(iter_sner != sner_meta_tags.end())
            {
            sner_begin = std::min<vtkIdType>(static_cast<vtkIdType>(body.size()), sner_begin_array->GetValue(*iter_sner));
            }

          if(m3_begin != -1 && (sner_begin==-1 || m3_begin<=sner_begin))
            {
            // Next tag is an M3 Document TAG
            vtkIdType    m3_end  = std::min<vtkIdType>(static_cast<vtkIdType>(body.size()), m3_end_array->GetValue(*iter_m3));
            vtkStdString m3_type = m3_type_array->GetValue(*iter_m3);
            vtkStdString m3_text = vtkStdString(document_text_array->GetValue(document_index).utf8_str(), m3_begin, m3_end-m3_begin);

            #if DEBUG
            cout << ">>  M3  << " << std::setw(2) << *iter_m3 << " | " << m3_type
                 << " [" << m3_begin << "::" << m3_end << "]" << endl;
            //cout << m3_type << endl << m3_text << endl;
            #endif

            if(m3_type=="TEXT")
              {
              inTextSection = true;
              html_div_messageText << "<DIV ID=\"message-text\">\n<H2>Body Text</H2>\n"
                                   << "<SPAN CLASS=\"m3pre\">";
              plain_begin = m3_begin;
              }
            else
              {
              if(inTextSection)
                {
                inTextSection = false;
                HTMLEncoding(html_div_messageText, body, plain_begin, m3_begin);
                html_div_messageText << "</SPAN>\n</DIV>\n";
                }
              if(!haveSerial && m3_type=="SERIAL")
                {
                html_div_documentTitle  << "<DIV ID=\"documentTitle\">" << endl;
                HTMLEncoding(html_div_documentTitle, m3_text, 0, m3_text.size());
                html_div_documentTitle << "\n</DIV>\n";
                haveSerial=true;
                #if DEBUG
                cout << html_div_documentTitle.str();
                #endif
                }
              else if(m3_type=="CLASSIFICATION")
                {
                int          _tmpClassification    = UNKNOWN;
                vtkStdString _tmpClassificationStr = "";
                boost::regex exp_unclas("UNCLAS");
                boost::regex exp_confidential("C O N F I D E N T I A L");
                boost::regex exp_TS("T O P\\s+S E C R E T");
                boost::regex exp_secret("S E C R E T");

                if(boost::regex_search(m3_text, exp_unclas))
                  {
                  _tmpClassificationStr = "unclassified";
                  _tmpClassification    = UNCLASSIFIED;
                  }
                else if(boost::regex_search(m3_text, exp_confidential))
                  {
                  _tmpClassificationStr = "confidential";
                  _tmpClassification    = CONFIDENTIAL;
                  }
                else if(boost::regex_search(m3_text, exp_secret))
                  {
                  _tmpClassificationStr = "secret";
                  _tmpClassification    = SECRET;
                  }
                else if(boost::regex_search(m3_text, exp_TS))
                  {
                  _tmpClassificationStr = "topsecret";
                  _tmpClassification    = TOPSECRET;
                  }

                if(_tmpClassification > docClassification)
                  {
                  // Is this classification line more secret than what we
                  // already found?
                  html_div_classification << "<DIV ID=\"classification\" CLASS=\"";
                  html_div_classification << _tmpClassificationStr;
                  html_div_classification << "\">" << endl;
                  HTMLEncoding(html_div_classification, m3_text, 0, m3_text.size());
                  html_div_classification << "\n</DIV>\n";
                  docClassification = _tmpClassification;
                  }

                #if DEBUG
                cout << html_div_classification.str();
                #endif
                }
              else if(m3_type=="SOURCE")
                {
                html_div_source << "<LI>\n";
                HTMLEncoding(html_div_source, m3_text, 0, m3_text.size());
                html_div_source << "\n</LI>\n";
                }
              else if(m3_type=="SUBJ")
                {
                html_div_subj << "<LI>\n";
                HTMLEncoding(html_div_subj, m3_text, 0, m3_text.size());
                html_div_subj << "\n</LI>\n";
                }
              else if(m3_type=="DTG"  || m3_type=="ACQ"  || m3_type=="INSTR"||
                      m3_type=="COLL" || m3_type=="PROJ" || m3_type=="REQS" ||
                      m3_type=="COUNTRY" || m3_type=="EZ05" || m3_type=="DOI")
                {
                html_div_meta << "<LI>\n";
                HTMLEncoding(html_div_meta, m3_text, 0, m3_text.size());
                html_div_meta << "\n</LI>\n";
                }
              }
            ++iter_m3;
            }

          else if(sner_begin != -1)
            {
            plain_end = sner_begin;

            // Here we have a SNER entity to handle.
            vtkIdType    sner_end  = std::min<vtkIdType>(static_cast<vtkIdType>(body.size()), sner_end_array->GetValue(*iter_sner));
            vtkStdString sner_type = sner_type_array->GetValue(*iter_sner);
            vtkStdString sner_text = vtkStdString(document_text_array->GetValue(document_index).utf8_str(), sner_begin, sner_end-sner_begin);

            #if DEBUG
            cout << ">> SNER << " << std::setw(2) << *iter_sner << " | " << sner_type
                 << " [" << sner_begin << "::" << sner_end << "]" << endl
                 << "\t //" << sner_text << "//" << endl
                 << "\t plain_begin = " << plain_begin << endl
                 << "\t plain_end   = " << plain_end << endl;
            #endif

            HTMLEncoding(html_div_messageText, body, plain_begin, plain_end);

            plain_begin = sner_end;

            html_div_messageText << "<SPAN CLASS='M3Entity " << sner_type << "'>";
            html_div_messageText << "<a href='http://en.wikipedia.org/wiki/Special:Search/" << sner_text << "'>";
            HTMLEncoding(html_div_messageText, body, sner_begin, sner_end);
            html_div_messageText << "</A></SPAN>";

            ++iter_sner;
            }
          }

          // A helper div that fixes problems with some browsers
          html_div_clearing << "\n<DIV CLASS=\"clearing\">&nbsp;</DIV>\n";

          // Assemble the HEADER section
          html_div_header << "\n<DIV ID=\"headers\">"
                          << html_div_documentTitle.str()
                          << html_div_classification.str()
                          << "</DIV>\n";

          // Assemble the LEFTBAR section
          html_div_leftbar << "\n<DIV ID=\"leftbar\">\n<H2>Meta Information</H2>\n";
          if(html_div_subj.str().length())
            html_div_leftbar << "<UL ID=\"meta\">\n" << html_div_subj.str()   << "</UL>\n";
          else
            html_div_leftbar << "<UL ID=\"meta\">(NO SUBJECT ENTRY FOUND)</UL>\n";
          if(html_div_source.str().length())
            html_div_leftbar << "<UL ID=\"meta\">\n" << html_div_source.str() << "</UL>\n";
          else
            html_div_leftbar << "<UL ID=\"meta\">(NO SOURCE ENTRY FOUND)</UL>\n";
          html_div_leftbar << "<UL ID=\"meta\">\n" << html_div_meta.str()   << "</UL>\n";
          html_div_leftbar << "</DIV>\n\n";

          // Assemble the FULLTEXT section
          html_div_fullText << "\n<DIV ID=\"full-message-text\">\n<H2>Full Message Text</H2>\n<SPAN CLASS=\"m3pre\">";
          HTMLEncoding(html_div_fullText, body, 0, body.size());
          html_div_fullText << "</SPAN>\n</DIV>\n";

          // Assemble the full html <body>
          html_body << "<BODY>\n"
                    << "<DIV ID=\"m3wrapper\">\n"
                    << html_div_header.str()
                    << "<DIV ID=\"container\">\n"
                    << html_div_leftbar.str()
                    << html_div_messageText.str()
                    //<< html_div_clearing.str()
                    << "</DIV>\n" // << "<!-- container -->\n"
                    << html_div_fullText.str()
                    << html_div_clearing.str()
                    << "</DIV>\n" // << "<!-- m3wrapper -->\n"
                    << "</BODY>\n";

          #if DEBUG
          cout << html_body.str() << endl;
          #endif

          html_array->SetValue(document_index, html_body.str());

          // EMIT A PROGRESS EVENT
          double progress = (document_index+1) / (double)document_count;
          this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

        }   // for(document_index)
      }   // if(document_count > 0)
    }   // try ...
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  #if DEBUG
  cout << "<<<<<<<<<< " << __PRETTY_FUNCTION__ << endl;
  #endif

  return 1;
}
