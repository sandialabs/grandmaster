/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkCommand.h>
#include <vtkDocumentM3MetaTagTable.h>
#include <vtkIdTypeArray.h>
#include <vtkInformation.h>
#include <vtkObjectFactory.h>
#include <vtkSmartPointer.h>
#include <vtkStdString.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTimerLog.h>
#include <vtkUnicodeStringArray.h>

#include <stdexcept>
#include <iomanip>

// Boost stuff for M3MetaData
#include <boost/regex.hpp>
#include <boost/xpressive/xpressive.hpp>
#include <boost/xpressive/regex_actions.hpp>

using namespace boost::xpressive;

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

// FOR DEBUGGING
#define METRICS_TIMING     1
#define DEBUG_TOKENS       0
#define DEBUG_PRINT_BINS   0
#define TOKENIZE_LINES     0
#define TRY_UNICODESTRINGS 0   // TURN ON UNICODESTRINGS--CURRENTLY B0RKED




vtkStandardNewMacro(vtkDocumentM3MetaTagTable);



vtkDocumentM3MetaTagTable::vtkDocumentM3MetaTagTable()
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "document");
  this->SetInputArrayToProcess(1, 0, 0, 6, "text");
  this->SetInputArrayToProcess(2, 0, 0, 6, "mime_type");
}



vtkDocumentM3MetaTagTable::~vtkDocumentM3MetaTagTable()
{
}



void vtkDocumentM3MetaTagTable::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}



int vtkDocumentM3MetaTagTable::RequestData(
  vtkInformation* request,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{

  vtkStdString iirTagNames[] = { "UNKNOWN", "ACQ",            "CONTROLS", "COUNTRY",
                                 "BT",      "CLASSIFICATION", "DIST",     "DISSEM",
                                 "DOCNO",   "DOI",            "DTG",      "FROM",
                                 "IIR",     "INSTR",          "IPSP",     "PREC",
                                 "PREP",    "REQS",           "SERIAL",   "SOURCE",
                                 "SUBJ",    "SUMMARY",        "TEXT",     "TO",
                                 "WARNING", "ENDOFADDRS",     "ENDOFMSG", "REFS",
                                 "EZ05",    "PROJ",           "COLL",     "PASS",
                                 "NONE" };

  // CREATE A TAG TYPE ENUM TO HELP KEEP TRACK OF WHERE WE ARE.
  enum iirTagTypes { TAG_UNKNOWN, TAG_ACQ,            TAG_CONTROLS, TAG_COUNTRY,
                     TAG_BT,      TAG_CLASSIFICATION, TAG_DIST,     TAG_DISSEM,
                     TAG_DOCNO,   TAG_DOI,            TAG_DTG,      TAG_FROM,
                     TAG_IIR,     TAG_INSTR,          TAG_IPSP,     TAG_PREC,
                     TAG_PREP,    TAG_REQS,           TAG_SERIAL,   TAG_SOURCE,
                     TAG_SUBJ,    TAG_SUMMARY,        TAG_TEXT,     TAG_TO,
                     TAG_WARNING, TAG_ENDOFADDRS,     TAG_ENDOFMSG, TAG_REFS,
                     TAG_EZ05,    TAG_PROJ,           TAG_COLL,     TAG_PASS,
                     TAG_NONE };

  iirTagTypes tag_type = TAG_UNKNOWN;

  // -------------------------------------------------------------------------
  //  B E G I N   I I R   R E G E X   G R A M M A R
  // -------------------------------------------------------------------------

  // MATCHES A FULL LINE OF TEXT
  sregex rex_line = *~_n >> _n;

  // MATCH A DTG TAG (STORES DATE/TIME INFO)
  sregex iir_dtg = ((s1=(( as_xpr('O') | as_xpr('P') | as_xpr('R') |
                     as_xpr('W') | as_xpr('Y') | as_xpr('Z') )))
                   >> +_s >> (s2=(repeat<6>(_d) >> "Z"
                   >> +_s >> repeat<3>(alpha)
                   >> +_s >> repeat<2>(_d))))
                   [ref((int&)tag_type)=(int)TAG_DTG];

  // KNOWN IIR SECTION TAGS
  sregex iir_proj     = as_xpr("PROJ:")                           // TAG: PROJ:
                        [ref((int&)tag_type)=(int)TAG_PROJ];
  sregex iir_coll     = as_xpr("COLL:")                           // TAG: COLL:
                        [ref((int&)tag_type)=(int)TAG_COLL];
  sregex iir_bt       = as_xpr("BT")                              // TAG: BT
                        [ref((int&)tag_type)=(int)TAG_BT];
  sregex iir_acq      = as_xpr("ACQ:")                            // TAG: ACQ
                        [ref((int&)tag_type)=(int)TAG_ACQ];
  sregex iir_controls = as_xpr("CONTROLS:")                       // TAG: CONTROLS
                        [ref((int&)tag_type)=(int)TAG_CONTROLS];
  sregex iir_country  = as_xpr("COUNTRY:")                        // TAG: COUNTRY
                        [ref((int&)tag_type)=(int)TAG_COUNTRY];
  sregex iir_dist     = as_xpr("DIST:")                           // TAG: DIST
                        [ref((int&)tag_type)=(int)TAG_DIST];
  sregex iir_dissem   = as_xpr("DISSEM:")                         // TAG: DISSEM
                        [ref((int&)tag_type)=(int)TAG_DISSEM];
  sregex iir_docno    = as_xpr("DOCNO:")                          // TAG: DOCNO
                        [ref((int&)tag_type)=(int)TAG_DOCNO];
  sregex iir_doi      = as_xpr("DOI")                             // TAG: DOI
                        [ref((int&)tag_type)=(int)TAG_DOI];
  sregex iir_ez05     = as_xpr("EZ05:")                           // TAG: EZ05
                        [ref((int&)tag_type)=(int)TAG_EZ05];
  sregex iir_from     = (as_xpr("FROM") | as_xpr("FM") |          // TAG: FROM
                        as_xpr("<REASFROM>"))
                        [ref((int&)tag_type)=(int)TAG_FROM];
  sregex iir_iir      = as_xpr("IIR")                             // TAG: IIR
                        [ref((int&)tag_type)=(int)TAG_IIR];
  sregex iir_instr    = as_xpr("INSTR:")                          // TAG: INSTR
                        [ref((int&)tag_type)=(int)TAG_INSTR];
  sregex iir_ipsp     = -repeat<0,2>("/") >> as_xpr("IPSP:")      // TAG: IPSP
                        [ref((int&)tag_type)=(int)TAG_IPSP];
  sregex iir_pass     = as_xpr("PASS:")                            // TAG: PASS ?
                        [ref((int&)tag_type)=(int)TAG_PASS];
  sregex iir_prec     = as_xpr("PREC:")                           // TAG: PREC
                        [ref((int&)tag_type)=(int)TAG_PREC];
  sregex iir_prep     = as_xpr("PREP:")                           // TAG: PREP
                        [ref((int&)tag_type)=(int)TAG_PREP];
  sregex iir_reqs     = as_xpr("REQS")                            // TAG: REQS
                        [ref((int&)tag_type)=(int)TAG_REQS];
  sregex iir_serial   = as_xpr("SERIAL:")                         // TAG: SERIAL
                        [ref((int&)tag_type)=(int)TAG_SERIAL];
  sregex iir_source   = (as_xpr("SOURCE:") | as_xpr("SOURCE") )   // TAG: SOURCE
                        [ref((int&)tag_type)=(int)TAG_SOURCE];
  sregex iir_subj     = (as_xpr("SUBJ:") | as_xpr("SUBJECT:"))    // TAG: SUBJ
                        [ref((int&)tag_type)=(int)TAG_SUBJ];
  sregex iir_summary  = as_xpr("SUMMARY:")                        // TAG: SUMMARY
                        [ref((int&)tag_type)=(int)TAG_SUMMARY];
  sregex iir_refs     = as_xpr("REFS:")                           // TAG: SUMMARY
                        [ref((int&)tag_type)=(int)TAG_REFS];
  sregex iir_text     = as_xpr("TEXT")                            // TAG: TEXT
                        [ref((int&)tag_type)=(int)TAG_TEXT];
  sregex iir_to       = as_xpr("TO")                              // TAG: TO
                        [ref((int&)tag_type)=(int)TAG_TO];
  sregex iir_warning  = as_xpr("WARNING:")                        // TAG: WARNING
                        [ref((int&)tag_type)=(int)TAG_WARNING];
  sregex iir_endofmsg = (as_xpr("NNNN"))                          // TAG: ENDOFMSG
                        [ref((int&)tag_type)=(int)TAG_ENDOFMSG];
  sregex iir_endofaddrs = (as_xpr("QQQQ"))                        // TAG: ENDOFADDRS
                        [ref((int&)tag_type)=(int)TAG_ENDOFADDRS];

  sregex iir_classification = (s1=(as_xpr("UNCLAS")
                              | !(as_xpr("T O P")>> +space) >> as_xpr("S E C R E T")
                              | as_xpr("C O N F I D E N T I A L")))
                              [ref((int&)tag_type)=(int)TAG_CLASSIFICATION];

  sregex data_ipnum = ('2'>>range('0','5')>>range('0','5'))    // 200-255
                    | ('1'>>repeat<1,2>(range('0','9')))       // 100-199
                    | *as_xpr('0')>>repeat<1,2>(_d);           // 00-99

  sregex data_ipaddr = (bos|after(~_d)) >> data_ipnum >> repeat<3,3>(".">> data_ipnum);

  sregex data_class_short = ("(" >> (s1=(as_xpr("U")|as_xpr("C"))) >> ")");

  sregex data_serial = !("(" >> (s1=(as_xpr("U")|as_xpr("C"))) >> ")" >> *_s)
                        >> "IIR" >> *_s
                        >> (s2=(_d >> +_s >> repeat<3>(_d) >> +_s
                        >> repeat<4>(_d) >> +_s >> repeat<2>(_d) ));

  sregex iir_tags = bos >> (iir_text | iir_bt      | iir_acq     | iir_controls
                    | iir_country    | iir_dist    | iir_dissem  | iir_docno
                    | iir_doi        | iir_from    | iir_iir     | iir_instr
                    | iir_ipsp       | iir_prec    | iir_reqs    | iir_serial
                    | iir_source     | iir_subj    | iir_summary | iir_dtg
                    | iir_endofmsg   | iir_warning | iir_refs    | iir_coll
                    | iir_ez05       | iir_proj    | iir_pass
                    | iir_endofaddrs | iir_classification);

  // A REGEX FOR PARSING THROUGH LINES TO GET RELEVANT INFO OUT OF THEM
  // (ACTUALLY JUST TOKENIZES THE LINE INTO A STREAM BUT KEEP SOME THINGS
  // TOGETHER IF WE KNOW WHAT TO LOOK FOR)
  sregex iir_data = data_ipaddr
                    | iir_classification
                    | *~_s>>+_s;

  // -------------------------------------------------------------------------
  //  E N D   I I R   R E G E X   G R A M M A R
  // -------------------------------------------------------------------------

  try
    {
    // GET THE INPUT DATA
    vtkTable* const input_table = vtkTable::GetData(inputVector[0]);
    if(!input_table)
      throw std::runtime_error("missing input table");

std::cout << "Input table:\n";
input_table->Dump(20);

    vtkIdTypeArray * const documentid_array =
        vtkIdTypeArray::SafeDownCast(
            this->GetInputAbstractArrayToProcess(0, 0, inputVector)
        );
    if(!documentid_array)
      throw std::runtime_error("missing document ID array");

    vtkUnicodeStringArray * const text_array =
        vtkUnicodeStringArray::SafeDownCast(
            this->GetInputAbstractArrayToProcess(1, 0, inputVector)
        );
    if(!text_array)
      throw std::runtime_error("missing text array");

    vtkStringArray* const mime_type_array =
      vtkStringArray::SafeDownCast(this->GetInputAbstractArrayToProcess(2, 0, inputVector));
    if(!mime_type_array)
      throw std::runtime_error("missing mime_type array");

    // ALLOCATE OUTPUT COLUMNS
    VTK_CREATE(vtkIdTypeArray, document_array);
    document_array->SetName("document");

    VTK_CREATE(vtkIdTypeArray, lineno_array);
    lineno_array->SetName("line");

    VTK_CREATE(vtkIdTypeArray, begin_array);
    begin_array->SetName("begin");

    VTK_CREATE(vtkIdTypeArray, end_array);
    end_array->SetName("end");

    VTK_CREATE(vtkStringArray, type_array);
    type_array->SetName("type");

    #if METRICS_TIMING
    VTK_CREATE(vtkTimerLog, timer);
    const double timeStart = timer->GetUniversalTime();
    #endif

    // ----------------------------------------------------
    // LOOP OVER DOCUMENTS (i.e., TABLE ROWS)
    // ----------------------------------------------------
    for(vtkIdType doci=0; doci < text_array->GetNumberOfTuples(); doci++)
      {
      #if DEBUG_TOKENS
      cout << "+++++[" << doci << "]++++++++++++++++++++++++++++" << endl;
      #endif

      if(mime_type_array->GetValue(doci) != "text/x-iir")
        {
        document_array->InsertNextValue(documentid_array->GetValue(doci));
        lineno_array->InsertNextValue(0);
        begin_array->InsertNextValue(0);
        end_array->InsertNextValue(text_array->GetValue(doci).character_count());
        type_array->InsertNextValue("TEXT");
        continue;
        }

      tag_type = TAG_UNKNOWN;

      vtkIdType doc_offset = 0;
      vtkIdType section_begin_lineno = 0;
      vtkIdType section_begin_offset = 0;
      vtkIdType section_end_offset   = doc_offset;
      vtkIdType section_tag_type     = 0;

      // GET THE DOCUMENT NUMBER FROM DOCUMENT ID COLUMN
      vtkIdType documentId = documentid_array->GetValue(doci);

      // GET THE DOCUMENT TEXT AS A STRING (TODO: MAKE THIS A UNICODE STRING)
      vtkStdString text_entry = text_array->GetValue(doci).utf8_str();

#if TRY_UNICODESTRINGS
      // EXPERIMENTAL, VTKUNICODESTRING NEEDS A BIT MORE CAPABILITY BEFORE IT'LL
      // MAKE BOOST ALGORITHMS HAPPY.
      std::vector<std::string> strs;
      // TODO: Get this working directly on unicode strings
      std::vector<vtkUnicodeString> ucodeStrs;
      boost::split(ucodeStrs, text_array->GetValue(doci), boost::is_any_of("\n"));
#endif

      // SPLIT OUT DOCUMENT BY LINES AND STREAM THROUGH THEM
      sregex_token_iterator iter_line( text_entry.begin(), text_entry.end(), rex_line);
      sregex_token_iterator iter_line_end;

      // Create some helpful flags scoped by document
      bool flagSeen_BT     = false;
      bool flagSeen_TEXT   = false;
      bool flagSeen_SERIAL = false;
      bool flagSeen_SOURCE = false;
      bool flagSeen_SUBJ   = false;

      // ----------------------------------------------------
      // LOOP OVER DOCUMENT LINES
      // ----------------------------------------------------
      for(vtkIdType line_no=1; iter_line != iter_line_end; ++iter_line, ++line_no)
        {
        std::string M3DocumentLine = *iter_line;
        std::string::const_iterator begin_M3DocumentLine;

        tag_type = TAG_NONE;

        #if DEBUG_TOKENS
        cout << std::setw(3) << line_no
             << "\tb=" << std::setw(4) << section_begin_offset
             << "\te=" << std::setw(4) << doc_offset
             << " ---[" << M3DocumentLine << "]\n";
        #endif

        // SEARCH THE LINE FOR ANY IIR TAGS (NOTE: THE REGEX RULES
        // SET THE STATE IF THEY MATCH ANY OF THE IIR TAGS). IF NECESSARY
        // WE CAN DO OTHER SPECIAL STUFF IF OUR LINE MATCHES A TAG.

        bool flagFoundM3Tag = regex_search(M3DocumentLine, sregex(iir_tags));
        bool flag_doAppendTag;

        // Check 1 (pre-insert) :: Some tags are ignored if they occur after
        //                         other tags, this check gets the context
        if( flagFoundM3Tag )
          {
          flag_doAppendTag = true;
          #if DEBUG_TOKENS
          cout << "\t!!! IIR TAG FOUND ("<< iirTagNames[tag_type] <<") !!!" << endl;
          #endif

          switch(tag_type)
            {
            // If we're in a text section, ignore these tags for purposes of
            // creating a section transition.  (we may do something special
            // with these later on).
            case TAG_CLASSIFICATION:
            case TAG_COUNTRY:
            case TAG_PASS:
            case TAG_SERIAL:
              if(TAG_TEXT==section_tag_type)
                {
                flag_doAppendTag = false;
                }
              break;

            case TAG_BT:
              flagSeen_BT = true;
              break;

            case TAG_FROM:
              if(flagSeen_BT)
                {
                // If we're past the real header, don't falsely identify a FROM tag.
                flag_doAppendTag = false;
                }
              break;

            case TAG_SOURCE:
              if(flagSeen_TEXT)
                flag_doAppendTag = false;
              else
                flagSeen_SOURCE = true;
              break;

            case TAG_SUBJ:
              // Don't grab this if we're in the TEXT section or if we already
              // have found a subject line.
              if(TAG_TEXT==section_tag_type || flagSeen_SUBJ)
                {
                flagSeen_SUBJ = true;
                flag_doAppendTag = false;
                }
              break;

            case TAG_TEXT:
              flagSeen_TEXT = true;
              break;

            default:
              ;
            };

          // If this was a section transition and we're appending then do eet
          if(flag_doAppendTag && tag_type != section_tag_type)
            {
            if( section_tag_type != TAG_UNKNOWN )
              {
              #if DEBUG_TOKENS
              cout << "\tSECTION TRANSITION" << endl;
              cout << "\t - Appending [" << iirTagNames[section_tag_type]
                   << "] @ " << section_begin_lineno
                   << "\t" << section_begin_offset
                   << "::" << section_end_offset
                   << endl;
              cout << "\t - current doc_offset = " << doc_offset << endl;
              #endif
              document_array->InsertNextValue(documentId);
              lineno_array->InsertNextValue(section_begin_lineno);
              begin_array->InsertNextValue(section_begin_offset);
              end_array->InsertNextValue(section_end_offset-1);
              type_array->InsertNextValue(iirTagNames[section_tag_type]);
              }
            // Update section offsets since we just inserted.
            section_tag_type = (vtkIdType)tag_type;
            section_begin_offset = doc_offset;
            section_begin_lineno = line_no;
            }  // !if(flag_doAppend....)
          }  // !if(flagFoundM3Tag)    // first!

#if 0
        // TODO:
        // IF WE'RE IN A TEXT BLOCK, LET'S SCAN THE LINES FOR STUFF THAT
        // WE MIGHT WANT TO FLAG. (I.E., IP ADDRESSES, ETC).
        // WOULD BE COOL TO BE ABLE TO INSERT TAGGING INTO THE DOCUMENT
        // FOR FIELDS THAT WE PERHAPS CAN 'FIND'.
        // WOULDN'T THIS MIMIC WHAT SNER DOES--BUT FOR SPECIFIC STUFF LIKE
        // IP ADDRESSES, ETC.
        sregex_iterator _cur( M3DocumentLine.begin(), M3DocumentLine.end(), data_ipaddr),
                        _end;
        for(; _cur != _end; ++_cur)
          {
          smatch const &what = *_cur;
          cout << "---" << endl;
          cout << "\t  [" << what[0] << "]" << endl;
          cout << "\ts :" << what.position(0) << endl;
          cout << "\tl :" << what.length(0) << endl;
          cout << "\tss:" << M3DocumentLine.substr(what.position(0), what.length(0)) << endl;
          cout << "\to1:" << doc_offset + what.position(0) << endl;
          cout << "\to2:" << doc_offset + what.position(0) + what.length(0) << endl;
          }
#endif

        // CERTAIN TAGS HAVE SOME KIND OF IMMEDIATE PROCESSING REQUIREMENTS
        // AND THEIR SECTIONS WON'T SPAN MULTIPLE LINES.  FOR THESE WE
        // NEED TO DO SOMETHING IMMEDIATE ON THE LINE DIRECTLY.
        // TAG WILL BE SET TO UNKNOWN AFTER THIS SO WE DON'T ACCIDENTALLY
        // SUCK UP JUNK BEFORE WE ENCOUNTER ANOTHER M3 TAG.
        if( flagFoundM3Tag && flag_doAppendTag)
          {
          flag_doAppendTag = false;
          vtkIdType _tmpOff = section_begin_offset;
          smatch what;
          switch(tag_type)
            {
            case TAG_CLASSIFICATION:
              regex_search(M3DocumentLine, what, iir_classification);
              if(!what.empty())
                {
                if(what[0].matched)
                  {
                  section_begin_offset = _tmpOff+(what[0].first - M3DocumentLine.begin());
                  section_end_offset   = _tmpOff+(what[0].second- M3DocumentLine.begin());
                  }
                }
              else
                {
                section_end_offset = _tmpOff + M3DocumentLine.length();
                }
              flag_doAppendTag = true;
              break;
            case TAG_DTG:
              regex_search(M3DocumentLine, what, iir_dtg);
              break;
            case TAG_SERIAL:
              {
              // what[1] contains classification [UC] if any
              // what[2] contains the IIR serial number: N NNN NNNN NN
              flagSeen_SERIAL = true;
              regex_search(M3DocumentLine, what, data_serial);
              if(!what.empty())
                {
                //cout << "\twhat[0]: " << what[0] << endl;
                if(what[1].matched)
                  {
                  //cout << "\twhat[1]: " << what[1] << endl;
                  // ** currently we don't do anything with what[1], hanging
                  //    onto this codeblock for future use.
                  }
                if(what[2].matched)
                  {
                  //cout << "\twhat[2]: " << what[2] << endl;
                  section_begin_offset = _tmpOff + (what[2].first - M3DocumentLine.begin());
                  section_end_offset   = _tmpOff + (what[2].second- M3DocumentLine.begin());
                  }
                }
              else
                {
                section_end_offset = _tmpOff + M3DocumentLine.length();
                }
                flag_doAppendTag = true;
              }
              break;
            default: ;
            };

          // If this is a special case that we need to just append the tag
          // then we do it here.
          if(flag_doAppendTag && section_tag_type != TAG_UNKNOWN)
            {
            #if DEBUG_TOKENS
            cout << "\tSPECIAL TAG -- INSERT IMMEDIATE" << endl;
            cout << "\t - Appending [" << iirTagNames[section_tag_type]
                 << "] @ " << section_begin_lineno
                 << "\t" << section_begin_offset
                 << "::" << section_end_offset
                 << endl;
            cout << "\t - current doc_offset = " << doc_offset << endl;
            #endif

            document_array->InsertNextValue( documentId );
            lineno_array->InsertNextValue( section_begin_lineno );
            begin_array->InsertNextValue( section_begin_offset );
            end_array->InsertNextValue( section_end_offset );
            type_array->InsertNextValue( iirTagNames[section_tag_type] );

            // Update section offsets since we inserted, with UNKNOWN
            // section so this stuff doesn't get inserted when the
            // next tag is found.
            section_tag_type = (vtkIdType)TAG_UNKNOWN;
            section_begin_offset = doc_offset;
            section_begin_lineno = line_no;
            }
          } // !if(flagFoundM3Tag)   // second!

        #if TOKENIZE_LINES
        sregex_token_iterator tok( M3DocumentLine.begin(),
                                   M3DocumentLine.end(),
                                   iir_data);
        sregex_token_iterator tok_end;
        for( ; tok != tok_end; ++tok)
          {
          std::string strToken = *tok;
          cout << std::setw(3) << strToken.size()
               << " {" << strToken << "}" << endl;
          }
        #endif

        #if DEBUG_TOKENS
        if(tag_type != TAG_NONE)
          cout << "\ttag = " << tag_type << endl;
        #endif

        // UPDATE THE OFFSET WITH THE LENGTH OF THIS LINE
        doc_offset += M3DocumentLine.length();
        section_end_offset = doc_offset;

        } // << for lineno >>

      // ADD THE LAST BIT INTO THE TABLE
      document_array->InsertNextValue(documentId);
      lineno_array->InsertNextValue(section_begin_lineno);
      begin_array->InsertNextValue(section_begin_offset);
      end_array->InsertNextValue(doc_offset-1);
      type_array->InsertNextValue(iirTagNames[section_tag_type]);


      // EMIT A PROGRESS EVENT
      double progress = (doci+1) / (double)text_array->GetNumberOfTuples();
      this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
      }  // doci

    #if METRICS_TIMING
    // Print out some timing metrics
    const double timeFinish = timer->GetUniversalTime();
    cout << "M3MetaTag Parser: Processed " << text_array->GetNumberOfTuples()
         << " documents in " << timeFinish-timeStart << " seconds";
    if(text_array->GetNumberOfTuples())
      {
      cout << " (" << (timeFinish-timeStart)/text_array->GetNumberOfTuples()
           << " per document)";
      }
    cout << endl;
    #endif

    vtkTable * const output_table = vtkTable::GetData(outputVector);
    output_table->AddColumn(document_array);
    output_table->AddColumn(lineno_array);
    output_table->AddColumn(begin_array);
    output_table->AddColumn(end_array);
    output_table->AddColumn(type_array);

std::cout << "Output table:\n";
output_table->Dump(20);

    #if 0
    output_table->Dump(15);
    #endif
    } // end try
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  // EMIT A PROGRESS EVENT
  double progress = 1.0;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  return 1;
}

// TODO: Use unicode directly... dependent on some new stuff being added to
//       vtkUnicodeString to make Boost happy...
// TODO: Handle tearlines, tighten up the ranges on some tags.
