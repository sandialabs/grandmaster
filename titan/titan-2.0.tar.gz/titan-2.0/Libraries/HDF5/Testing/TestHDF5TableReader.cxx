
#include "vtkHDF5TableReader.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"

int main(int argc, char* argv[])
{
  vtkSmartPointer<vtkHDF5TableReader> reader = vtkSmartPointer<vtkHDF5TableReader>::New();
  reader->SetFileName("/Users/jeff/Work/test.h5");
  //reader->SetDatasetPath("Solar Spectral Irradiance");
  reader->SetDatasetPath("Solar and Geophysical Parameters");
  //reader->SetDatasetPath("XPS XUV Solar Spectrum");
  reader->Update();

  reader->GetOutput()->Dump(10);
  if (reader->GetReadAttributes())
     reader->GetOutput(1)->Dump(10);

  return 0;
}
