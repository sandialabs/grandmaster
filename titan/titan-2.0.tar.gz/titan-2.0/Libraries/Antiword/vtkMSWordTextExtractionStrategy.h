/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef _vtkMSWordTextExtractionStrategy_h
#define _vtkMSWordTextExtractionStrategy_h

#include <titanAntiword.h>
#include <vtkTextExtractionStrategy.h>

/// \class vtkMSWordTextExtractionStrategy vtkMSWordTextExtractionStrategy.h <Antiword/vtkMSWordTextExtractionStrategy.h>
/// \brief text extraction strategy that works with application/msword data.
///
///  Concrete implementation of vtkTextExtractionStrategy that works with application/msword MIME types.
///  vtkMSWordTextExtractionStrategy converts the contents of the given resource into
///  text using a library created from the antiword utility.
///
///  Generates a single "TEXT" tag that incorporates the entire text content.
///
/// \sa
///  vtkTextExtraction, vtkTextExtractionStrategy.
///
///  Developed by Jason Shepherd (jfsheph@sandia.gov) at Sandia National Laboratories.

class TITAN_ANTIWORD_EXPORT vtkMSWordTextExtractionStrategy :
  public vtkTextExtractionStrategy
{
public:
  static vtkMSWordTextExtractionStrategy* New();
  vtkTypeMacro(vtkMSWordTextExtractionStrategy, vtkTextExtractionStrategy);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
  virtual bool Extract(
    const vtkIdType document,
    const vtkStdString& uri,
    const vtkStdString& mime_type,
    const vtkTypeUInt8* content_begin,
    const vtkTypeUInt8* content_end,
    vtkUnicodeString& text,
    vtkIdTypeArray* tag_document,
    vtkIdTypeArray* tag_begin,
    vtkIdTypeArray* tag_end,
    vtkStringArray* tag_type);

protected:
  vtkMSWordTextExtractionStrategy();
  virtual ~vtkMSWordTextExtractionStrategy();

private:
  vtkMSWordTextExtractionStrategy(const vtkMSWordTextExtractionStrategy&); //Not implemented.
  void operator=(const vtkMSWordTextExtractionStrategy&); //Not implemented.

  class Diagram;
  class FileHandle;
//ETX
};

#endif // !_vtkMSWordTextExtractionStrategy_h
