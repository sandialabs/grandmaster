/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkIdTypeArray.h>
#include <vtkMSWordTextExtractionStrategy.h>
#include <vtkMimeTypes.h>
#include <vtkObjectFactory.h>
#include <vtkStringArray.h>
#include <vtkUnicodeStringArray.h>

#include <stdexcept>

#include <antiword.h>
#include <wordtypes.h>

//////////////////////////////////////////////////////////////////////////////////
// vtkMSWordTextExtractionStrategy::Diagram

class vtkMSWordTextExtractionStrategy::Diagram
{
public:
  Diagram(diagram_type* diagram = 0) :
    InternalDiagram(diagram)
  {
  }

  ~Diagram()
  {
    if(this->InternalDiagram)
      vDestroyDiagram(this->InternalDiagram);
  }

  operator diagram_type*()
  {
    return this->InternalDiagram;
  }

private:
  diagram_type* InternalDiagram;
};

//////////////////////////////////////////////////////////////////////////////////
// vtkMSWordTextExtractionStrategy::FileHandle

class vtkMSWordTextExtractionStrategy::FileHandle
{
public:
  FileHandle(FILE* file = 0) :
    File(file)
  {
  }

  ~FileHandle()
  {
    if(this->File)
      fclose(this->File);
  }

  operator FILE*()
  {
    return this->File;
  }

private:
  FILE* File;
};

//////////////////////////////////////////////////////////////////////////////////
// ReceiveText

void ReceiveText(const char* text, size_t length, void* data)
{
  vtkUnicodeString& output = *reinterpret_cast<vtkUnicodeString*>(data);
  output += vtkUnicodeString::from_utf8(text, text + length);
}

//////////////////////////////////////////////////////////////////////////////////
// vtkMSWordTextExtractionStrategy


vtkStandardNewMacro(vtkMSWordTextExtractionStrategy);

vtkMSWordTextExtractionStrategy::vtkMSWordTextExtractionStrategy()
{
}

vtkMSWordTextExtractionStrategy::~vtkMSWordTextExtractionStrategy()
{
}

void vtkMSWordTextExtractionStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

bool vtkMSWordTextExtractionStrategy::Extract(
  const vtkIdType document,
  const vtkStdString& uri,
  const vtkStdString& mime_type,
  const vtkTypeUInt8* content_begin,
  const vtkTypeUInt8* content_end,
  vtkUnicodeString& text,
  vtkIdTypeArray* tag_document,
  vtkIdTypeArray* tag_begin,
  vtkIdTypeArray* tag_end,
  vtkStringArray* tag_type)
{
  // Determine whether we can handle this content or not ...
  if(!vtkMimeTypes::Match("application/msword", mime_type))
    return false;

  try
    {
    // Extract text from the content ...

    // This is a terrible hack, but antiword doesn't provide any way to work with a file that's
    // already in memory ... so we load it again.  Doh!
    if(0 != uri.find("file://"))
      throw std::runtime_error("Cannot extract text from resources outside the filesystem.");

#ifdef WIN32
    const vtkStdString filename = uri.substr(8);
#else // WIN32
    const vtkStdString filename = uri.substr(7);
#endif // !WIN32

    FileHandle file(fopen(filename.c_str(), "rb"));
    if(!file)
      throw std::runtime_error("Error opening MSWord file for reading.");

    fseek(file, 0, SEEK_END);
    const long file_length = ftell(file);
    rewind(file);

    // Ensure that antiword objects are cleaned-up completely before we return ...
      {
      SetAntiwordConversionCallback(ReceiveText, &text);

      Diagram diagram = pCreateDiagram("vtkMSWordTextExtractionStrategy", filename.c_str());
      if(!diagram)
        throw std::runtime_error("Error opening MSWord diagram for reading.");

      if(!bWordDecryptor(file, file_length, diagram))
        throw std::runtime_error("Error extracting MSWord text.");
      }

    // Generate a tag for the content ...
    tag_document->InsertNextValue(document);
    tag_begin->InsertNextValue(0);
    tag_end->InsertNextValue(text.character_count());
    tag_type->InsertNextValue("TEXT");
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "caught unknown exception." << endl);
    }

  return true;
}
