#ifdef BLAS_SURROUND_UNDERSCORE
#  define BLAS_LEADING_UNDERSCORE
#  define BLAS_TRAILING_UNDERSCORE
#endif

#if defined(BLAS_LEADING_UNDERSCORE)
#  define BLAS_PREFIX _
#elif defined(BLAS_LEADING_ATL)
#  define BLAS_PREFIX ATL_
#else
#  define BLAS_PREFIX
#endif
#ifdef BLAS_TRAILING_UNDERSCORE
#  define BLAS_SUFFIX _
#else
#  define BLAS_SUFFIX
#endif

#ifdef BLAS_UPPERCASE_NAMES
#  define BLAS_NAME DGEMV
#else
#  define BLAS_NAME dgemv
#endif

#define BLAS_DGEMVX(a,b,c) a ## b ## c
#define BLAS_DGEMV(a,b,c) BLAS_DGEMVX(a,b,c)

int main()
{
  char cdummy = 'T';
  int idummy=1;
  double ddummy = 1.;

  BLAS_DGEMV(BLAS_PREFIX,BLAS_NAME,BLAS_SUFFIX)
  (
    &cdummy, &idummy, &idummy, &ddummy, &ddummy, &idummy,
    &ddummy, &idummy, &ddummy, &ddummy, &idummy
  );
  return 0;
}
