/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkJVMManagerManager.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/
/// \class vtkJVMManagerManager vtkJVMManagerManager.h <JVMManager/vtkJVMManagerManager.h>
/// \brief Manages the vtkJVMManager singleton.
///
/// vtkJVMManagerManager is included in the header of any
/// subclass of vtkJVMManager.
/// It makes sure that the singleton is created after vtkDebugLeaks singleton,
/// and destroyed before vtkDebugLeaks is cleaned up.

/// \sa vtkJVMManager

#ifndef __vtkJVMManagerManager_h
#define __vtkJVMManagerManager_h

#include "titanJVMManager.h"
#include "vtkSystemIncludes.h"

#include "vtkDebugLeaksManager.h" // DebugLeaks exists longer than info keys.

class TITAN_JVMMANAGER_EXPORT vtkJVMManagerManager
{
public:
  vtkJVMManagerManager();
  ~vtkJVMManagerManager();
private:
  static unsigned int Count;
};

/// This instance will show up in any translation unit that uses
/// vtkJVMManager, or that has a singleton.  It will make sure
/// vtkJVMManager is initialized before it is used, and is one of the last
/// static object destroyed.
static vtkJVMManagerManager vtkJVMManagerManagerInstance;

#endif
