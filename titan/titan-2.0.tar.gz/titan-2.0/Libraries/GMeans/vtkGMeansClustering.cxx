/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkGMeansClustering.h"

#include "IB.h"
#include "Spherical_k_means.h"
#include "Diametric_k_means.h"
#include "Euclidean_k_means.h"
#include "Kullback_leibler_k_means.h"
#include "Matrix.h"

#include "vtkArrayConversions.h"
#include "vtkArrayData.h"
#include "vtkCommand.h"
#include "vtkDenseArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkSparseArray.h"
#include "vtkTable.h"

#include <vtksys/ios/sstream>

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name)                                  \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkGMeansClustering);

vtkGMeansClustering::vtkGMeansClustering()
{
  // default parameters for the k-means algorithm
  this->Algorithm = SPHERICAL_K_MEANS;
  this->NumberOfClusters = 1;
  this->Alpha = DEFAULT_ALPHA;
  this->Epsilon = DEFAULT_EPSILON;
  this->Delta = DEFAULT_DELTA;
  this->Omega = 0.0;
  this->InitializationMethod = WELL_SEPARATED_CENTROID_INIT_MODIFY;
  this->PerturbationMagnitude = DEFAULT_PERTURB;
  this->UpperClusterBound = 0;
  this->NumberOfFirstVariations = 0;
  this->IncrementalKMeansMoves = 0;
  this->Seed = 0;
  this->NumberOfIterations = 5;
  this->MaxIterations = 50;
  this->MaxRuns = 10000;
  this->UseLaplacian = NOLAPLACE;
  this->RandomSeeding = false;
  this->SkipSPKM = false;
  this->VerifyObjectiveFunction = false;
  this->EvaluateOnly = false;
  this->GenerateWordClustering = false;
  this->PriorMethod = UNIFORM_PRIOR;

  this->PriorFileName = 0;
  this->SetPriorFileName( "" );

  this->PatternFileName = 0;
  this->SetPatternFileName( "" );

  this->SetNumberOfInputPorts(3);
  this->SetNumberOfOutputPorts(2);
}

vtkGMeansClustering::~vtkGMeansClustering()
{
  this->SetPriorFileName(0);
  this->SetPatternFileName(0);
}

int vtkGMeansClustering::FillInputPortInformation(int port, vtkInformation* info)
{
  if( port == 0 )
    {
    //port 0 is the frequency matrix...
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    return 1;
    }
  if( port == 1 )
    {
    //port 0 is the frequency matrix...
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
    return 1;
    }
  else if( port == 2 )
    {
    //port 1 is a 'seed' array used to initialize the gmeans algorithm, if desired.
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData" );
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1 );
    return 1;
    }
  return 0;
}

int vtkGMeansClustering::FillOutputPortInformation( int port, vtkInformation* info )
{
  if ( port == 0 )
    {
    //port 0 contains the document dictionary table with a cluster ids column appended.
    info->Set( vtkDataObject::DATA_TYPE_NAME(), "vtkTable" );
    return 1;
    }
  else if( port == 1 )
    {
    //port 1 (optional) contains an array with terms/word clusters.
    //  (WordClustering must be on before port 1 is filled...)
    info->Set( vtkDataObject::DATA_TYPE_NAME(), "vtkArrayData" );
    return 1;
    }
  return 0;
}

int vtkGMeansClustering::RequestData(
  vtkInformation *vtkNotUsed(request),
  vtkInformationVector **inputVector, vtkInformationVector *outputVector)
{
  vtkTable* const input_table = vtkTable::GetData(inputVector[0]);
  if(!input_table)
    {
    vtkErrorMacro( "Missing input table." );
    return 0;
    }

  vtkArrayData* const input_array_data = vtkArrayData::GetData(inputVector[1]);
  if(!input_array_data)
    {
    vtkErrorMacro("Missing input array data.");
    return 0;
    }
  if(input_array_data->GetNumberOfArrays() != 1)
    {
    vtkErrorMacro("Input vtkArrayData must contain exactly one vtkArray.");
    return 0;
    }

  vtkTypedArray<double>* const input_array = vtkTypedArray<double>::SafeDownCast(input_array_data->GetArray(0));
  if(!input_array)
    {
    vtkErrorMacro( "Input array must be a vtkTypedArray<double>." );
    return 0;
    }
  if(input_array->GetDimensions() != 2)
    {
    vtkErrorMacro( "Input array must have two dimensions." );
    return 0;
    }
  if(!input_array->GetExtents().ZeroBased())
    {
    vtkErrorMacro( "Input array must use zero-based indices.");
    return 0;
    }

  double progress = 0.;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  vtkTable* const output_table = vtkTable::GetData(outputVector, 0);
  output_table->ShallowCopy( input_table );

  vtkIdTypeArray* const cluster_id_array = vtkIdTypeArray::New();
  cluster_id_array->SetName( "cluster_id" );
  cluster_id_array->SetNumberOfTuples( input_table->GetNumberOfRows() );
  output_table->AddColumn(cluster_id_array);
  cluster_id_array->Delete();

  // Check for a matrix with size = 0
  if(input_array->GetSize() == 0)
    {
//    vtkWarningMacro( "Input matrix has no entries" );
    return 1;
    }

  int i;
  vtkDenseArray<vtkIdType>* seed_array = NULL;
  vtkIdType* seedingArray = NULL;
  if( this->InitializationMethod == SEEDINGFILE_INIT )
    {
    vtkArrayData* const input_array_data2 = vtkArrayData::GetData(inputVector[2]);
    if(!input_array_data)
      {
      vtkErrorMacro("Missing seeding array data.");
      return 0;
      }

    seed_array = vtkDenseArray<vtkIdType>::SafeDownCast(input_array_data2->GetArray(0));
    if(!seed_array)
      {
      vtkErrorMacro( "Seed array must be a vtkDenseArray<vtkIdType>." );
      return 0;
      }
    if(seed_array->GetDimensions() != 1)
      {
      vtkErrorMacro( "Seed array must have a single dimension." );
      return 0;
      }

    seedingArray = seed_array->GetStorage();
    }

  int n_Empty_Docs;
  int* e_D_ID;
  Matrix* matrix;
  float** val;
  bool val_allocated = false;
  std::vector<int> columns;
  std::vector<int> rows;
  std::vector<float> values;
  vtkSparseArray<double>* const sparse_input_array = vtkSparseArray<double>::SafeDownCast(input_array_data->GetArray(0));
  vtkDenseArray<double>* const dense_input_array = vtkDenseArray<double>::SafeDownCast(input_array_data->GetArray(0));
  if( sparse_input_array )
    {
    vtkConvertToCCS( sparse_input_array, columns, rows, values );
    matrix = new SparseMatrix( sparse_input_array->GetExtents()[0].GetSize(),
                               sparse_input_array->GetExtents()[1].GetSize(),
                               sparse_input_array->GetNonNullSize(),
                               &values[0], &rows[0], &columns[0] );

    //find the number of empty columns (documents) and
    // set up the empty columns map needed by gmeans...
    int pre = -1;
    int *empty_Docs_ID = new int[columns.size()-1];
    n_Empty_Docs = 0;
    for( i = 0; i < static_cast<int>(columns.size()); i++ )
      {
      int curr_col_value = columns[i];
      if( curr_col_value == pre)
        {
        empty_Docs_ID[n_Empty_Docs]= i-1;
        n_Empty_Docs++;
        }
      pre = columns[i];
      }

    e_D_ID = new int [n_Empty_Docs+1];

    for( i = 0; i < n_Empty_Docs; i++ )
      e_D_ID[i] = empty_Docs_ID[i];
    e_D_ID [i] = columns.size()-1;

    delete [] empty_Docs_ID;

    cout<<"Empty docs found: "<<n_Empty_Docs<<endl;
    }
  else if( dense_input_array )
    {
    //need to create the matrix for a dense array....
    int nrows = dense_input_array->GetExtents()[0].GetSize();
    int ncolumns = dense_input_array->GetExtents()[1].GetSize();

    val_allocated = true;
    val = new float * [nrows];
    for( i = 0; i < nrows; i++ )
      {
      val[i] = new float [ncolumns];
      }

    for( i = 0; i < nrows; i++ )
      {
      for( int j = 0; j < ncolumns; j++ )
        {
        val[i][j] = dense_input_array->GetValue( i, j );
        }
      }

    matrix = new DenseMatrix( nrows, ncolumns, val );

    n_Empty_Docs = 0;
    e_D_ID = new int [n_Empty_Docs+1];
    e_D_ID [0] = ncolumns;
    }
  else
    {
    vtkErrorMacro( "Input must be a vtkDenseArray<vtkIdType> or vtkSparseArray<vtkIdType>." );
    return 0;
    }

  progress = 0.25;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  //begin gmeans algorithm...
  switch(this->Algorithm)
    {
    case DIAMETRIC_K_MEANS:
      matrix->normalize_mat_L2();
      break;
    case EUCLIDEAN_K_MEANS:
      matrix->ComputeNorm_2();
      break;
    case KULLBACK_LEIBLER:
      matrix->SetAlpha( this->Alpha, this->UseLaplacian );
      matrix->SetPrior( this->PriorMethod, this->PriorFileName, n_Empty_Docs, e_D_ID );
      matrix->normalize_mat_L1();
      matrix->ComputeNorm_KL(this->UseLaplacian);
      break;
    case INFO_BOTTLENECK:
      matrix->SetPrior( this->PriorMethod, this->PriorFileName, n_Empty_Docs, e_D_ID );
      matrix->normalize_mat_L1();
      matrix->ComputeNorm_KL(NOLAPLACE);
      break;
    case SPHERICAL_K_MEANS:
    default:
      matrix->normalize_mat_L2();
      break;
    }

  if( this->UpperClusterBound <= this->NumberOfClusters )
    this->UpperClusterBound = this->NumberOfClusters;
  if( matrix->GetNumCol()- n_Empty_Docs < this->UpperClusterBound )
    {
    this->UpperClusterBound = matrix->GetNumCol() - n_Empty_Docs;
    cout <<"The number of clusters you asked for is greater than the number of non-empty vectors. We adjust the number of clusters to be the number of data items."<<endl;
    }
  if( matrix->GetNumCol() < this->NumberOfFirstVariations )
    {
    this->SetNumberOfFirstVariations( matrix->GetNumCol() );
    cout <<"The number of first variations you asked for is greater than the number of data items. We adjust the number of clusters to be the number of data items."<<endl;
    }
  vtkIdType* cluster = new vtkIdType[matrix->GetNumCol()];

  Gmeans *K;
  switch (this->Algorithm)
    {
    case DIAMETRIC_K_MEANS:
      K = new Diametric_k_means (matrix, cluster, this->NumberOfClusters, this->NumberOfIterations, this->Omega, this->RandomSeeding, this->Seed, this->Epsilon, this->MaxIterations, this->MaxRuns);
      break;
    case EUCLIDEAN_K_MEANS:
      K = new Euclidean_k_means (matrix, cluster, this->NumberOfClusters, this->NumberOfIterations, this->Omega, this->RandomSeeding, this->Seed, this->Epsilon, this->MaxIterations, this->MaxRuns);
      break;
    case KULLBACK_LEIBLER :
      K = new Kullback_leibler_k_means(matrix, cluster, this->NumberOfClusters, this->NumberOfIterations, this->Omega, this->RandomSeeding, this->Seed, this->Epsilon, this->MaxIterations, this->MaxRuns);
      break;
    case INFO_BOTTLENECK:
      K = new IB(matrix, cluster, this->NumberOfClusters, this->NumberOfIterations, this->Omega, this->RandomSeeding, this->Seed, this->Epsilon, this->MaxIterations, this->MaxRuns);
      break;
    case SPHERICAL_K_MEANS:
    default:
      K = new Spherical_k_means (matrix, cluster, this->NumberOfClusters, this->NumberOfIterations, this->Omega, this->RandomSeeding, this->Seed, this->Epsilon, this->MaxIterations, this->MaxRuns);
      break;
    }

  K->SetAlgorithm( this->Algorithm);
  K->SetEmptyDocs( n_Empty_Docs, e_D_ID);
  K->setDumpinfo( false);
  K->setInitialClustering( this->InitializationMethod);
  K->setSkipSPKM( this->SkipSPKM);
  K->setVerify( this->VerifyObjectiveFunction);
  K->setLaplacian( this->UseLaplacian);
  K->setIncemental_k_means( this->IncrementalKMeansMoves);
  K->SetEpsilon( this->Epsilon);
  K->setDelta( this->Delta);
  K->setEvaluate( this->EvaluateOnly );

  if( this->InitializationMethod == RANDOM_PERTURB_INIT)
    K->SetPerturb( this->PerturbationMagnitude);

  if (this->PatternFileName)
    {
    K->read_cate( this->PatternFileName );
    }
  else
    {
    K->read_cate( "" );
    }

  K->general_means(matrix, this->UpperClusterBound, this->NumberOfFirstVariations, seedingArray );

  float coherence = K->GetResult();
  int final_cluster_num = K->getClusterNum();

  vtkDenseArray<vtkIdType> *outputArray2 = vtkDenseArray<vtkIdType>::New();
  vtkArrayData* const output2 = vtkArrayData::GetData(outputVector, 1);
  output2->ClearArrays();
  output2->AddArray( outputArray2 );
  outputArray2->Delete();

  progress = 0.75;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  if (this->GenerateWordClustering)
    {
    cout << "\nWriting word clusters: ";
    int* word_cluster = new int[matrix->GetNumRow()];
    K->wordCluster( word_cluster );

    outputArray2->Resize( matrix->GetNumRow() );
    for( i = 0; i < matrix->GetNumRow(); i++ )
      {
      outputArray2->SetValue( i, word_cluster[i] );
      }
    delete [] word_cluster;
    }

  for( i = 0; i < matrix->GetNumCol(); i++ )
    {
//    cluster_id_array->InsertNextValue( cluster[i] );
    cluster_id_array->SetValue( i, cluster[i] );
    }

  cout << "\nobjective function value: " << coherence << "\n\n";
  cout << "Final number of clusters : " << final_cluster_num << "\n";
  cout << "Number of documents  : " << matrix->GetNumCol()<< "\n";

  switch (this->Algorithm)
    {
    case SPHERICAL_K_MEANS:
      cout << "Algorithm            : spherical k-means\n";
      break;
    case DIAMETRIC_K_MEANS:
      cout << "Algorithm            : diametric k-means\n";
      break;
    case EUCLIDEAN_K_MEANS:
      cout << "Algorithm            : euclidian k-means\n";
      break;
    case KULLBACK_LEIBLER:
      cout << "Algorithm            : kullback_leibler k-means\n";
      cout<<"The mutual information of the original matrix is : " <<matrix->MutualInfo()<<endl;
      cout<<"The mutual information of the final matrix is    : "<<matrix->MutualInfo()-coherence<<" ("
    <<(matrix->MutualInfo()-coherence)*100.0/matrix->MutualInfo()<<"%)"<<endl;
      switch (this->UseLaplacian)
  {
  case CENTER_LAPLACE:
    cout << "Laplace's rule is applied to the centroids.\n";
    cout<<"The prior used is : "<< this->Alpha << endl;
    break;
  case PRIOR_LAPLACE:
    cout << "Laplace's rule is applied to the input probabilty vectors.\n";
    break;
  }
      break;
    case INFO_BOTTLENECK:
      cout << "Algorithm            : sequential information bottleneck.\n";
      cout<<"The mutual information of the original matrix is : " <<matrix->MutualInfo()<<endl;
      cout<<"The mutual information of the final matrix is    : "<<coherence<<" ("
    <<coherence*100.0/matrix->MutualInfo()<<"%)"<<endl;
      break;
    }

  cout << "Epsilon              : " << this->Epsilon << " (used for Kmeans)\n";
  cout << "Omega                : " << this->Omega <<" (used for fv and split)\n";
  cout << "Delta                : " << this->Delta <<" (used for fv and split)\n";
  cout << "Initialization method: ";
  switch (this->InitializationMethod)
    {
    case RANDOM_PERTURB_INIT:
      cout << "random perturbation\n";
      cout << "perturbation magnitude: " << this->PerturbationMagnitude << "\n";
      break;
    case RANDOM_CLUSTER_ID_INIT:
      cout << "Randomly generated cluster ID for each vector.\n";
      break;
    case SEEDINGFILE_INIT:
      cout << "Initialized with seeding array." << endl;
      break;
    case WELL_SEPARATED_CENTROID_INIT:
      cout << "Cluster centroids are chosen to be well separated from each other, starting with a random chosen vector" << endl;
      break;
    case WELL_SEPARATED_CENTROID_INIT_MODIFY:
      cout << "Cluster centroids are chosen to be well separated from each other, starting with a vector farthest from the centroid of the whole data set" << endl;
      break;
    case CONCEPT_VECTORS_INIT:
      cout << "Randomly chose centroids" << endl;
      break;
    }

  //cleanup memory...
  if( val_allocated )
    {
    int nrows = input_array->GetExtents()[0].GetSize();
    for( i = 0; i < nrows; i++ )
      {
      delete [] val[i];
      }
    delete [] val;
    }
  delete [] e_D_ID;
  delete K;

  progress = 1.;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  return 1;
}

void vtkGMeansClustering::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}

void vtkGMeansClustering::SetAlgorithmToSphericalKMeans()
{
  this->Algorithm = SPHERICAL_K_MEANS;
}
void vtkGMeansClustering::SetAlgorithmToEuclideanKMeans()
{
  this->Algorithm = EUCLIDEAN_K_MEANS;
}
void vtkGMeansClustering::SetAlgorithmToKullbackLeibler()
{
  this->Algorithm = KULLBACK_LEIBLER;
}
void vtkGMeansClustering::SetAlgorithmToDiametricKMeans()
{
  this->Algorithm = DIAMETRIC_K_MEANS;
}
void vtkGMeansClustering::SetAlgorithmToInfoBottleneck()
{
  this->Algorithm = INFO_BOTTLENECK;
}
void vtkGMeansClustering::SetInitializationMethodToRandomPerturbation()
{
  this->InitializationMethod = RANDOM_PERTURB_INIT;
}
void vtkGMeansClustering::SetInitializationMethodToRandomClusterId()
{
  this->InitializationMethod = RANDOM_CLUSTER_ID_INIT;
}
void vtkGMeansClustering::SetInitializationMethodToRandomVectorCentroids()
{
  this->InitializationMethod = CONCEPT_VECTORS_INIT;
}
void vtkGMeansClustering::SetInitializationMethodToRandomFirstCentroid()
{
  this->InitializationMethod = WELL_SEPARATED_CENTROID_INIT;
}
void vtkGMeansClustering::SetInitializationMethodToFarthestFirstCentroid()
{
  this->InitializationMethod = WELL_SEPARATED_CENTROID_INIT_MODIFY;
}
void vtkGMeansClustering::SetInitializationMethodToSeedArray()
{
  this->InitializationMethod = SEEDINGFILE_INIT;
}
void vtkGMeansClustering::UseCenterLaplacian( double alphain )
{
  this->UseLaplacian = CENTER_LAPLACE;
  this->Alpha = alphain;
}
void vtkGMeansClustering::UseNoLaplacian()
{
  this->UseLaplacian = NOLAPLACE;
}
void vtkGMeansClustering::SetPriorMethodToUniform()
{
  this->PriorMethod = UNIFORM_PRIOR;
}
void vtkGMeansClustering::SetPriorMethodToFile( char* filename )
{
  this->PriorMethod = FILE_PRIOR;
  this->SetPriorFileName( filename );
}
void vtkGMeansClustering::SetSkipSphericalKMeans( bool val )
{
  this->SkipSPKM = val;
}
void vtkGMeansClustering::SetPerturbationWithPositiveIntegerSeed( int val )
{
  this->RandomSeeding = false;
  this->Seed = val;
}
void vtkGMeansClustering::SetTrueLabelFile( char* filename)
{
  this->SetPatternFileName( filename );
}
void vtkGMeansClustering::SetVerifyObjectiveFunction( bool val )
{
  this->VerifyObjectiveFunction = val;
}
void vtkGMeansClustering::SetGenerateWordClustering( bool val )
{
  this->GenerateWordClustering = val;
}
