/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkPerceptron.h"

#include "vtkDataArray.h"
#include "vtkDataSetAttributes.h"
#include "vtkDoubleArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkUnsignedIntArray.h"
#include "vtkMath.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"
#include "vtkTable.h"

#include <algorithm>
#include <assert.h>
#include <map>
#include <sstream>
#include <vector>

using namespace std;


vtkStandardNewMacro(vtkPerceptron);

vtkPerceptron::vtkPerceptron()
{
  this->GroundTruthArrayName = 0;
  this->SetGroundTruthArrayName("GroundTruth");
  this->OutputArrayName = 0;
  this->SetOutputArrayName("Classification");
  this->DebugPrintLevel = 0;
  this->TrainingPasses = 1000;
  this->Mode = TRAIN;
  this->Reset();
}

vtkPerceptron::~vtkPerceptron()
{
  this->SetGroundTruthArrayName(0);
  this->GroundTruthArrayName = 0;
  this->SetOutputArrayName(0);
  this->OutputArrayName = 0;
  this->weights.clear();
}


void vtkPerceptron::AddFeatureColumn(const char * column)
{
  string s(column);
  this->FeatureColumns.push_back(s);
  this->Modified();
}


int vtkPerceptron::ValidateInput(vtkTable *input)
{
  // Check for the required columns

  // Ground Truth column
  vtkDataArray* column = vtkDataArray::SafeDownCast(
      input->GetColumnByName(this->GetGroundTruthArrayName()));
  if (!column)
    {
    vtkErrorMacro( "vtkPerceptron cannot find GroundTruth array: " <<
      this->GetGroundTruthArrayName());
    return 0;
    }
  this->GroundTruthArray = column;

  // Load up the possible output labels
  for(int i=0;i<this->GroundTruthArray->GetNumberOfTuples(); ++i)
    {
    this->output_labels.insert(static_cast<int>(this->GroundTruthArray->GetTuple1(i)));
    }


  // Feature columns
  this->FeatureArrays.clear();
  if (this->FeatureColumns.size() == 0)
    {
    vtkErrorMacro( "vtkPerceptron needs at least one feature array: ");
    return 0;
    }
  vector<string>::iterator I;
  for(I=this->FeatureColumns.begin(); I != this->FeatureColumns.end();++I)
    {
    vtkDataArray* column = vtkDataArray::SafeDownCast(input->GetColumnByName((*I).c_str()));
    if (!column)
      {
      vtkErrorMacro( "vtkPerceptron cannot find array: " << (*I).c_str());
      return 0;
      }
    this->FeatureArrays.push_back(column);
    }
    return 1;
}


void vtkPerceptron::UpdateModelAll()
{
  for(int i=0;i<this->FeatureArrays[0]->GetNumberOfTuples(); ++i)
    UpdateModelItem(i);
}

void vtkPerceptron::UpdateModelItem(int index)
{

  // This implements a vanilla perceptron with multiple outputs
  int truth_label = static_cast<int>(this->GroundTruthArray->GetTuple1(index));
  int guess = ClassifyItem(index);
  if(this->DebugPrintLevel >= 1)
    cout << ">>>Observation: "<<index<<" Truth Label: "<<truth_label<< " Guess: "<<guess<< endl;
  if (truth_label == guess) return;

  // Incorrect labeling so make adjustments to the weights
  // Not looping through all output labels (just adjusting guess and truth)

  // Adjust bias (just the -1 index weight)
  this->weights[make_pair(-1,guess)] -= 1;
  this->weights[make_pair(-1,truth_label)] += 1;

  // Update weights for the features in this observation
  int feature_index = 0;
  vector<vtkDataArray*>::iterator I;
  for (I = this->FeatureArrays.begin(); I != this->FeatureArrays.end(); ++I, ++feature_index)
    {
    double x = (*I)->GetTuple1(index);

    // Adjust the feature weight
    weights[make_pair(feature_index,guess)] -= x;
    weights[make_pair(feature_index,truth_label)] += x;
    }


  if(this->DebugPrintLevel >= 2)
    this->PrintWeights();
}

double vtkPerceptron::DotProduct(int index, int target_label)
{
  // Compute the dot product of w and x.
  double dp = 0;

  // Iterate over features
  int feature_index = 0;
  vector<vtkDataArray*>::iterator I;
  for (I = this->FeatureArrays.begin(); I != this->FeatureArrays.end(); ++I, ++feature_index)
    {
    double x = (*I)->GetTuple1(index);
    double w = weights[make_pair(feature_index,target_label)];
    dp += w * x;
  }

  return dp;
}

int vtkPerceptron::ClassifyItem(int index)
{
  // To classify x, compute the score, which is the dot product of w and x
  // against all possible targets and pick the winner
  double max_score=-1e10;
  int max_label=-1;
  set<int>::iterator I;
  for (I = this->output_labels.begin(); I != this->output_labels.end(); ++I)
    {
    int target_label = *I;
    double score = DotProduct(index,target_label) + weights[make_pair(-1,target_label)];
    if (score > max_score) {max_score=score;max_label=target_label;}
    if (this->DebugPrintLevel >= 2)
      cout << "Observation: "<<index<<" Target Label: "<<target_label<< " Score: "<< score<< endl;
    }
  return max_label;
}

void vtkPerceptron::Reset()
{
  this->weights.clear();
  cout << "Reset" << endl;
}

// Debugging function
void vtkPerceptron::PrintWeights()
{
  map<edge,double>::iterator WI;
  for (WI = this->weights.begin(); WI != this->weights.end(); ++WI)
    {
    cout << " weight(" << WI->first.first << "," << WI->first.second << ")"
      << WI->second << endl;
    }
}

int vtkPerceptron::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{

  // Get input table
  vtkInformation* inputInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* input = vtkTable::SafeDownCast(
    inputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get output tables
  vtkInformation* outputInfo = outputVector->GetInformationObject(0);
  vtkTable* output = vtkTable::SafeDownCast(
    outputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Shallow copy the input to the output, we'll add a column to the output later.
  output->ShallowCopy(input);


  // Validate that we have all the required columns
  if (!this->ValidateInput(input))
    {
    vtkErrorMacro("The input table does not have the required columns,\
                     see vtkPerceptron.h for description of input");
    return 0;
    }

  // Create the estimated classification column
  vtkSmartPointer<vtkUnsignedIntArray> classColumn = vtkSmartPointer<vtkUnsignedIntArray>::New();
  classColumn->SetName(this->OutputArrayName);


  // Do cool perceptron stuff

  // Loop around for each training pass
  if (this->Mode == TRAIN)
    {
    for(int i=0; i<this->TrainingPasses; ++i)
      this->UpdateModelAll();
    }

  // Classify the data
  double accuracy = 0;
  for (int i = 0; i < output->GetNumberOfRows(); ++i)
    {
    int estimation = this->ClassifyItem(i);
    classColumn->InsertNextValue(estimation);
    accuracy += static_cast<int>(this->GroundTruthArray->GetTuple1(i)) == estimation;
    }

  // Add the data to the output table
  output->AddColumn(classColumn);

  // Debugging output
  if (this->DebugPrintLevel >= 2)
    this->PrintWeights();

  // Output accuracy
  if (this->Mode == TRAIN)
    cout << "(Training) Accuracy: " << accuracy/output->GetNumberOfRows() << endl;
  else
    cout << "(Classifing) Accuracy: " << accuracy/output->GetNumberOfRows() << endl;

  return 1;

}

void vtkPerceptron::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "TrainingPasses: " << this->TrainingPasses << endl;
  os << indent << "GroundTruth array name: ";
  if (this->GroundTruthArrayName)
    os << this->GroundTruthArrayName << endl;
  else
    os << "(none)" << endl;
  os << indent << "Output array name: ";
  if (this->OutputArrayName)
    os << this->OutputArrayName << endl;
  else
    os << "(none)" << endl;
}
