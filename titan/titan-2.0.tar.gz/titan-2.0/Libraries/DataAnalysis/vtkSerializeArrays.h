/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkSerializeArrays vtkSerializeArrays.h <DataAnalysis/vtkSerializeArrays.h>
/// \brief Helper functions to serialize/unserialize vtkStringArray and vtkVariantArray
///
///
///  Primitive arrays (i.e. vtkDataArray and subclasses) are easy to
///  serialize and unserialize.  Not so vtkVariantArray and
///  vtkStringArray, both of which have variable-length elements.  This
///  file specifies helper functions to make that possible.
///
///  In a perfect world we could use the Boost serialization library to
///  do all this with proper class versioning and everything.  At the
///  moment that's not an option for two reasons.  First, Boost is a
///  pretty heavyweight package with complex version compatibility
///  problems and it's impractical to insist that everyone go and
///  download it.  Second, as of the end of 2008 there are still plenty
///  of compilers out there that are not sophisticated enough in the way
///  they handle templates to be able to compile Boost in the first
///  place.
///
/// \bug
///
///  This class assumes that data type sizes do not change between the
///  place where arrays are saved and the place where they are restored.


#ifndef __vtkSerializeArrays_h
#define __vtkSerializeArrays_h

#include <titanDataAnalysis.h>
#include <vtkObject.h>
#include <vtkStdString.h>

class vtkCharArray;
class vtkStringArray;
class vtkVariantArray;

class TITAN_DATA_ANALYSIS_EXPORT vtkSerializeArrays : public vtkObject
{
public:
  vtkTypeMacro(vtkSerializeArrays, vtkObject);
  static vtkSerializeArrays *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  static void SaveStringArray(vtkStringArray *input, ostream &output);
  static void RestoreStringArray(istream &instream, vtkStringArray *output);
  static void SaveVariantArray(vtkVariantArray *input, ostream &output);
  static void RestoreVariantArray(istream &instream, vtkVariantArray *output);

  static void SaveStringArray(vtkStringArray *input, vtkCharArray *output);
  static void SaveVariantArray(vtkVariantArray *input, vtkCharArray *output);

  static void RestoreStringArray(vtkCharArray *input, vtkStringArray *output);
  static void RestoreVariantArray(vtkCharArray *input, vtkVariantArray *output);

protected:
  vtkSerializeArrays();
  ~vtkSerializeArrays();

private:
  vtkSerializeArrays(const vtkSerializeArrays &);
  void operator=(const vtkSerializeArrays &);
};

#endif
