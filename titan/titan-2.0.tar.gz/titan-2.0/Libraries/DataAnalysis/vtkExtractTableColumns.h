/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkExtractTableColumns vtkExtractTableColumns.h <DataAnalysis/vtkExtractTableColumns.h>
/// \brief Extracts a set of columns from a table.
///
///     names, produces an output table that contains only those columns.
///     This is useful for either a) extracting a subset of columns from a table,
///     b) rearranging the order of the columns in a table, or c) some combination
///     of both.

#ifndef __vtkExtractTableColumns_h
#define __vtkExtractTableColumns_h

#include <titanDataAnalysis.h>
#include <vtkTableAlgorithm.h>

class TITAN_DATA_ANALYSIS_EXPORT vtkExtractTableColumns : public vtkTableAlgorithm
{
public:
  static vtkExtractTableColumns* New();
  vtkTypeMacro(vtkExtractTableColumns,vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Methods for specifying the names of columns to extract
  void AddColumn(const char *colName);
  void RemoveColumn(const char *colName);
  void RemoveAllColumns();
  void SetColumnStatus( const char* namCol, int status );
  ///@}

protected:
  vtkExtractTableColumns();
  ~vtkExtractTableColumns();

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkExtractTableColumns(const vtkExtractTableColumns&); // Not implemented
  void operator=(const vtkExtractTableColumns&);   // Not implemented

//BTX
  class vtkVector;
  vtkVector* Columns;
//ETX
};

#endif
