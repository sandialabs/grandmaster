/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkJensenShannonSimilarityTable_h
#define __vtkJensenShannonSimilarityTable_h

#include "titanDataAnalysis.h"
#include <vtkSimilarityTable.h>

class vtkInformation;

/// \class vtkJensenShannonSimilarityTable vtkJensenShannonSimilarityTable.h <DataAnalysis/vtkJensenShannonSimilarityTable.h>
/// \brief compute similarity metrics using Jensen-Shannon divergence.
///
///
///  Treats matrices as collections of probability distributions and
///  computes the Jensen-Shannon divergence between pairs of
///  distributions.  Similarity is defined as 2 ^ divergence.
///
///  The results are returned as an edge-table that lists the index of each vector
///  and their computed similarity.  The output edge-table is typically used with
///  vtkTableToGraph to create a similarity graph.
///
///  This filter can be used with one or two input matrices.  If you provide a
///  single matrix as input, every vector in the matrix is compared with every
///  other vector. If you provide two matrices, every vector in the first matrix
///  is compared with every vector in the second matrix.
///
///  Inputs:
///    Input port 0: (required) A vtkDenseArray<double> with two dimensions.
///    Input port 1: (optional) A vtkDenseArray<double> with two dimensions.
///
///  Outputs:
///    Output port 0: A vtkTable containing "source", "target", and "similarity"
///      columns.
///
/// \warning
///  Note that the complexity of this filter is quadratic!  It also requires dense
///  arrays as input, in the future it should be generalized to accept sparse
///  arrays.
///
/// \par Thanks :
///
///  Developed by Andy Wilson (atwilso@sandia.gov) at Sandia National
///  Laboratories, starting from code by Timothy M. Shead
///  (tshead@sandia.gov).

class TITAN_DATA_ANALYSIS_EXPORT vtkJensenShannonSimilarityTable : public vtkSimilarityTable
{
public:
  vtkTypeMacro(vtkJensenShannonSimilarityTable, vtkSimilarityTable);
  static vtkJensenShannonSimilarityTable *New();
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
protected:
  vtkJensenShannonSimilarityTable();
  ~vtkJensenShannonSimilarityTable();

private:
  vtkJensenShannonSimilarityTable(const vtkJensenShannonSimilarityTable&); // Not implemented
  void operator=(const vtkJensenShannonSimilarityTable&);   // Not implemented

  void StartIteration(const Context& context);
  double ComputePairwiseScore(const Context& context, vtkIdType vector_a, vtkIdType vector_b);
  void FinishIteration(const Context& context);
//ETX
};

#endif
