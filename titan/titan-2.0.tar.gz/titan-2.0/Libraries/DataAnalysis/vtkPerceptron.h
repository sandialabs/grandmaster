/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkPerceptron vtkPerceptron.h <DataAnalysis/vtkPerceptron.h>
/// \brief vtkPerceptron performs linear classification given a training
/// set and a proceeding test set.
///
///
///  The vtkPerceptron class is a reference implementation of a multi-output
///  perceptron (neural network). Given a vector of features specified by one
///  or more calls to AddFeatureColumn and a ground truth label, specified by
///  SetGroundTruthArrayName, the perceptron adjusts it's internal model of
///  weights.
///
///  The perceptron is trained by calling SetMode(TRAIN) and then you can
///  classify data by calling SetMode(CLASSIFY), during the training phase
///  the 'GroundTruthArray' is used to supervise the training, during the
///  classification phase the 'GroundTruthArray' is compared against for the
///  accuracy calculation.
///
///  Note: This filter is under development...
///
///  Inputs:
///    Input port 0: (required) A vtkTable features table with a ground truth column.
///
///  Outputs:
///    Output port 0: The input table + the specified output array (defaults to
///                   "Classification") with the results of the classification.
///
///
/// \sa
///  vtkStatisticsAlgorithm, vtkClusteringKMeans
///
/// \par Thanks :
///  To Voltron, long live the MegaSword. Also thanks to Art Munson for helpful guidence.

#ifndef __vtkPerceptron_h
#define __vtkPerceptron_h

#include <titanDataAnalysis.h>
#include <vtkTableAlgorithm.h>
#include <map>
#include <set>
#include <string>
#include <vector>

class vtkUnsignedIntArray;
class vtkDataArray;

class TITAN_DATA_ANALYSIS_EXPORT vtkPerceptron : public vtkTableAlgorithm
{
public:
  static vtkPerceptron* New();
  vtkTypeMacro(vtkPerceptron,vtkTableAlgorithm)
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Specifies the mode of the perception: TRAIN or CLASSIFY
  /// Default: TRAIN
  vtkSetMacro(Mode, int)
  vtkGetMacro(Mode, int)
  ///@}

  ///@{
  /// Mode of the perception: TRAIN or CLASSIFY
  enum ModeType
  {
    TRAIN = 0,
    CLASSIFY = 1
  };
  ///@}

  ///@{
  /// Specifies the number of training passes for the  perception
  /// Default: 1000
  vtkSetMacro(TrainingPasses, int)
  vtkGetMacro(TrainingPasses, int)
  ///@}


  ///@{
  /// Add Feature columns, call this for each column to be
  /// included as a feature for the perceptron
  void AddFeatureColumn(const char* column);
  ///@}

  ///@{
  /// Set/Get the name of the ground truth array. Default is "GroundTruth".
  vtkSetStringMacro(GroundTruthArrayName)
  vtkGetStringMacro(GroundTruthArrayName)
  ///@}


  ///@{
  /// Set/Get the name of the output array. Default is "Classification".
  vtkSetStringMacro(OutputArrayName)
  vtkGetStringMacro(OutputArrayName)
  ///@}

  ///@{
  /// Specifies set the debug print level
  /// Default: 0 (nothing)
  vtkSetMacro(DebugPrintLevel, int)
  vtkGetMacro(DebugPrintLevel, int)
  ///@}


protected:
  vtkPerceptron();
  ~vtkPerceptron();

  virtual int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPerceptron(const vtkPerceptron&); // Not implemented
  void operator=(const vtkPerceptron&);   // Not implemented

  int Mode;
  int DebugPrintLevel;
  int TrainingPasses;
  char *OutputArrayName;
  char *GroundTruthArrayName;
  std::vector<std::string> FeatureColumns;
  std::vector<vtkDataArray*> FeatureArrays;
  vtkDataArray* GroundTruthArray;

  // Weights are the internal 'model' for this class
  typedef std::pair<int,int> edge; // Feature to Label edge
  std::map<edge,double> weights;  // Perceptron weights (edge,weight)
  std::set<int> output_labels;


  // Internal methods
  int ValidateInput(vtkTable* const input);
  void UpdateModelAll();
  void UpdateModelItem(int index);
  int ClassifyItem(int index);
  double DotProduct(int index, int target_label);
  void Reset();
  void PrintWeights();
};

#endif
