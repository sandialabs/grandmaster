/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkFrequencyMatrix_h
#define __vtkFrequencyMatrix_h

#include "titanDataAnalysis.h"

#include <vtkArrayDataAlgorithm.h>
#include <vtkMultiProcessController.h>

/// \class vtkFrequencyMatrix vtkFrequencyMatrix.h <DataAnalysis/vtkFrequencyMatrix.h>
/// \brief Creates a frequency matrix based on a document
///  dictionary, a feature dictionary, and a collection of features.
///
///
///  \c vtkFrequencyMatrix combines a document dictionary, a feature dictionary,
///  and a table containing features into a frequency matrix where documents
///  are represented by columns, features are represented by rows, and each
///  matrix value stores the number of times a feature appears in a particular
///  document. If a "count" column is present in the feature table, that column
///  will be used to aggregate the frequency, otherwise each row counts as 1
///  toward the total feature frequency in the document.
///
///  Inputs:
///  \li Input port 0: (required) A \c vtkTable feature table containing "document", "text", and optionally "count" columns.
///  \li Input port 1: (required) A \c vtkTable feature dictionary containing a "text" column.
///  \li Input port 2: (required) A \c vtkTable document dictionary containing a "document" column.
///
///  Outputs:
///  \li Output port 0: A sparse matrix of counts - <tt>vtkSparseArray<double></tt> with two dimensions.
///
///  Input arrays:
///  \li Use <tt>SetInputArrayToProcess(0, 0, ...)</tt> to specify the input feature table "document" array.
///  \li Use <tt>SetInputArrayToProcess(1, 0, ...)</tt> to specify the input feature table "text" array.
///  \li Use <tt>SetInputArrayToProcess(2, 1, ...)</tt> to specify the input feature dictionary "text" array.
///  \li Use <tt>SetInputArrayToProcess(3, 2, ...)</tt> to specify the input document dictionary "document" array.
///  \li Use <tt>SetInputArrayToProcess(4, 0, ...)</tt> to specify the input feature table optional "count" array.
///
/// \sa
///  vtkFeatureDictionary, vtkPTermDictionary
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_DATA_ANALYSIS_EXPORT vtkFrequencyMatrix :
  public vtkArrayDataAlgorithm
{
public:
  static vtkFrequencyMatrix* New();
  vtkTypeMacro(vtkFrequencyMatrix, vtkArrayDataAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  enum LookupType
  {
    GLOBAL_PLUS_LOCAL = 0,
    GLOBAL = 1,
    GLOBAL_PRESORTED = 2,
  };

  ///@{
  /// Specifies the strategy that will be used to insert terms into the matrix.
  /// Default: GLOBAL_PLUS_LOCAL
  vtkSetMacro(Lookup, int);
  vtkGetMacro(Lookup, int);
  ///@}

  ///@{
  /// Get/Set an optional parallel controller, which is used only for profiling.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

  ///@{
  /// Controls behavior when encountering features that aren't listed in the
  /// feature dictionary.  Note that unknown features never affect the output
  /// frequency matrix, this parameter simply controls whether unknown features
  /// are considered an error-condition that generates warning messages.  Ignoring
  /// unknown features will typically be enabled when computing query results,
  /// where a query document can contain features that aren't part of a preexisting
  /// model.  Default: OFF.
  vtkSetMacro(IgnoreUnknownFeatures, int);
  vtkGetMacro(IgnoreUnknownFeatures, int);
  ///@}

//BTX
protected:
  vtkFrequencyMatrix();
  ~vtkFrequencyMatrix();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkFrequencyMatrix(const vtkFrequencyMatrix&); // Not implemented
  void operator=(const vtkFrequencyMatrix&);   // Not implemented

  int Lookup;
  int IgnoreUnknownFeatures;

  vtkMultiProcessController* Controller;
//ETX
};

#endif
