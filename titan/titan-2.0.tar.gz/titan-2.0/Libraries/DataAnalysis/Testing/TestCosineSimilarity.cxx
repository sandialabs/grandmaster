/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkArrayData.h>
#include <vtkArrayPrint.h>
#include <vtkCosineSimilarityTable.h>
#include <vtkDenseArray.h>
#include <vtkSmartPointer.h>
#include <vtkTable.h>
#include <vtkVariant.h>

#include <vtksys/ios/iostream>
#include <vtksys/stl/stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    throw std::runtime_error("Expression failed: " #expression); \
}

static bool close_enough(const double lhs, const double rhs)
{
  return fabs(lhs - rhs) < 1.0e-6;
}

static bool test_tuple(vtkSmartPointer<vtkCosineSimilarityTable>& similarity, int row, int source, int target, double value)
{
  test_expression(similarity->GetOutput()->GetValueByName(row, "source").ToInt() == source);
  test_expression(similarity->GetOutput()->GetValueByName(row, "target").ToInt() == target);
  test_expression(close_enough(similarity->GetOutput()->GetValueByName(row, "similarity").ToDouble(), value));
}

int main(int vtkNotUsed(argc), char *vtkNotUsed(argv)[])
{
  cout << setprecision(17);

  try
    {
    // Create a weighting vector ...
    vtkSmartPointer<vtkDenseArray<double> > weighting_vector = vtkSmartPointer<vtkDenseArray<double> >::New();
    weighting_vector->Resize(2);
    weighting_vector->SetValue(0, 1);
    weighting_vector->SetValue(1, 0.5);

    std::cout << "Weighting vector:" << std::endl;
    vtkPrintVectorFormat(std::cout, weighting_vector.GetPointer());

    vtkSmartPointer<vtkArrayData> weighting_data = vtkSmartPointer<vtkArrayData>::New();
    weighting_data->AddArray(weighting_vector);

    // Run tests on one matrix ...
    vtkSmartPointer<vtkDenseArray<double> > matrix_a = vtkSmartPointer<vtkDenseArray<double> >::New();
    matrix_a->Resize(2, 3);
    matrix_a->SetValue(0, 0, 0);
    matrix_a->SetValue(1, 0, 1);
    matrix_a->SetValue(0, 1, 2);
    matrix_a->SetValue(1, 1, 2);
    matrix_a->SetValue(0, 2, 3);
    matrix_a->SetValue(1, 2, 0);

    std::cout << "Input matrix A:" << std::endl;
    vtkPrintMatrixFormat(std::cout, matrix_a.GetPointer());

    vtkSmartPointer<vtkArrayData> matrix_data_a = vtkSmartPointer<vtkArrayData>::New();
    matrix_data_a->AddArray(matrix_a);

    vtkSmartPointer<vtkCosineSimilarityTable> similarity = vtkSmartPointer<vtkCosineSimilarityTable>::New();
    similarity->SetInputData(0, matrix_data_a);
    similarity->SetInputData(2, weighting_data);
    similarity->SetVectorDimension(1);
    similarity->SetMinimumThreshold(0);
    similarity->SetMinimumCount(0);

    std::cout << "Upper diagonal similarities:" << std::endl;
    similarity->SetUpperDiagonal(true);
    similarity->SetDiagonal(false);
    similarity->SetLowerDiagonal(false);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 0, 1, 0.447214);
    test_tuple(similarity, 1, 0, 2, 0);
    test_tuple(similarity, 2, 1, 2, 0.894427);

    std::cout << "Diagonal similarities:" << std::endl;
    similarity->SetUpperDiagonal(false);
    similarity->SetDiagonal(true);
    similarity->SetLowerDiagonal(false);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 0, 0, 1);
    test_tuple(similarity, 1, 1, 1, 1);

    std::cout << "Lower diagonal similarities:" << std::endl;
    similarity->SetUpperDiagonal(false);
    similarity->SetDiagonal(false);
    similarity->SetLowerDiagonal(true);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 1, 0, 0.447214);
    test_tuple(similarity, 1, 2, 1, 0.894427);
    test_tuple(similarity, 2, 2, 0, 0);

    // Run tests with two matrices ...
    vtkSmartPointer<vtkDenseArray<double> > matrix_b = vtkSmartPointer<vtkDenseArray<double> >::New();
    matrix_b->Resize(2, 2);
    matrix_b->SetValue(0, 0, 1.5);
    matrix_b->SetValue(1, 0, 0);
    matrix_b->SetValue(0, 1, 0);
    matrix_b->SetValue(1, 1, 2);

    std::cout << "Input matrix B:" << std::endl;
    vtkPrintMatrixFormat(std::cout, matrix_b.GetPointer());

    vtkSmartPointer<vtkArrayData> matrix_data_b = vtkSmartPointer<vtkArrayData>::New();
    matrix_data_b->AddArray(matrix_b);

    similarity->SetInputData(1, matrix_data_b);

    std::cout << "First -> Second similarities:" << std::endl;
    similarity->SetFirstSecond(true);
    similarity->SetSecondFirst(false);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 6);
    test_tuple(similarity, 0, 0, 1, 1);
    test_tuple(similarity, 1, 0, 0, 0);
    test_tuple(similarity, 2, 1, 0, 0.894427);
    test_tuple(similarity, 3, 1, 1, 0.447214);
    test_tuple(similarity, 4, 2, 0, 1);
    test_tuple(similarity, 5, 2, 1, 0);

    std::cout << "Second -> First similarities:" << std::endl;
    similarity->SetFirstSecond(false);
    similarity->SetSecondFirst(true);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 6);
    test_tuple(similarity, 0, 2, 0, 1);
    test_tuple(similarity, 1, 1, 0, 0.894427);
    test_tuple(similarity, 2, 0, 0, 0);
    test_tuple(similarity, 3, 0, 1, 1);
    test_tuple(similarity, 4, 1, 1, 0.447214);
    test_tuple(similarity, 5, 2, 1, 0);

    return 0;
    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    return 1;
    }
}
