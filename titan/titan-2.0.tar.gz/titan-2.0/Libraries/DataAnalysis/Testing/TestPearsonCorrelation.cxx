/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkAbstractArray.h"
#include "vtkDenseArray.h"
#include "vtkSmartPointer.h"
#include <vtkArrayPrint.h>

#include <vtksys/stl/stdexcept>
#include <vtksys/ios/sstream>

#include "vtkPearsonCorrelation.h"


#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

static bool close_enough(const double lhs, const double rhs)
{
  return fabs(lhs - rhs) < 1.0e-6;
}


int main(int /*argc*/, char* /*argv*/[])
{
  //Matlab
  // a = rand(4,5);
  double a[]={
              0.8147,    0.6324,    0.9575,    0.9572,    0.4218,
              0.9058,    0.0975,    0.9649,    0.4854,    0.9157,
              0.1270,    0.2785,    0.1576,    0.8003,    0.7922,
              0.9134,    0.5469,    0.9706,    0.1419,    0.9595};

  double b[]={
              0.8147,    0.6324,
              0.9058,    0.0975,
              0.1270,    0.2785,
              0.9134,    0.5469};

  double d[]={
              0.4218,
              0.9157,
              0.7922,
              0.9595};

  int numRows  = 4;
  int numColsA = 5;
  int numColsB = 2;
  int numColsC = 1;


  vtkSmartPointer<vtkDenseArray<double> > A1 = vtkSmartPointer<vtkDenseArray<double> >::New();
  A1->Resize(numRows, numColsA);
  for(int c=0; c<numColsA; c++)
  {
    for(int r=0; r<numRows; r++)
    {
      A1->SetValue(r, c, a[r*numColsA + c]);
    }
  }

  vtkSmartPointer<vtkDenseArray<double> > A2 = vtkSmartPointer<vtkDenseArray<double> >::New();
  A2->Resize(numRows, numColsA);
  for(int c=0; c<numColsA; c++)
  {
    for(int r=0; r<numRows; r++)
    {
      A2->SetValue(r, c, a[r*numColsA + c]);
    }
  }

  vtkSmartPointer<vtkDenseArray<double> > B = vtkSmartPointer<vtkDenseArray<double> >::New();
  B->Resize(numRows, numColsB);
  for(int c=0; c<numColsB; c++)
  {
    for(int r=0; r<numRows; r++)
    {
      B->SetValue(r, c, b[r*numColsB + c]);
    }
  }

  vtkSmartPointer<vtkDenseArray<double> > C1 = vtkSmartPointer<vtkDenseArray<double> >::New();
  C1->Resize(numRows, numColsC);
  for(int c=0; c<numColsC; c++)
  {
    for(int r=0; r<numRows; r++)
    {
      C1->SetValue(r, c, d[r*numColsC + c]);
    }
  }

  vtkSmartPointer<vtkDenseArray<double> > C2 = vtkSmartPointer<vtkDenseArray<double> >::New();
  C2->Resize(numRows, numColsC);
  for(int c=0; c<numColsC; c++)
  {
    for(int r=0; r<numRows; r++)
    {
      C2->SetValue(r, c, d[r*numColsC + c]);
    }
  }

  //Add 2 data arrays and result array
  vtkSmartPointer<vtkArrayData> inBucket = vtkSmartPointer<vtkArrayData>::New();
  inBucket->AddArray(A1);
  inBucket->AddArray(A2);

  //Perform first test:  pcc(A,A)
  VTK_CREATE(vtkPearsonCorrelation, pcc);
  pcc->SetInputData(0, inBucket);
  pcc->Update();

  test_expression(pcc->GetOutput());
  test_expression(pcc->GetOutput()->GetNumberOfArrays() == 1);
  vtkSmartPointer< vtkDenseArray<double> >  result = vtkDenseArray<double>::SafeDownCast(pcc->GetOutput()->GetArray(0));
  test_expression(result);

  std::cerr << "**************************************" << std::endl;
  std::cerr << "Result for pcc(A,A):" << std::endl;
  vtkPrintMatrixFormat(std::cerr, result.GetPointer());
  std::cerr << "**************************************" << std::endl;

  //result should be 5x5
  test_expression(result->GetExtents()[0].GetSize() == 5);
  test_expression(result->GetExtents()[1].GetSize() == 5);

  //diag should be 1's (ea col is perfectly correl to itself)
  test_expression( close_enough(result->GetValue(0,0), 1.0) );
  test_expression( close_enough(result->GetValue(1,1), 1.0) );
  test_expression( close_enough(result->GetValue(2,2), 1.0) );
  test_expression( close_enough(result->GetValue(3,3), 1.0) );
  test_expression( close_enough(result->GetValue(4,4), 1.0) );

  //various values
  test_expression( close_enough(result->GetValue(0,1),  0.232792) );
  test_expression( close_enough(result->GetValue(3,0), -0.477056) );
  test_expression( close_enough(result->GetValue(4,0),  0.064459) );
  test_expression( close_enough(result->GetValue(4,1), -0.55387) );


  //Test B vs. C
  inBucket->ClearArrays();
  inBucket->AddArray(B);
  inBucket->AddArray(C1);
  pcc->SetInputData(0, inBucket);
  pcc->Update();

  result = vtkDenseArray<double>::SafeDownCast(pcc->GetOutput()->GetArray(0));

  std::cerr << "**************************************" << std::endl;
  std::cerr << "Result for pcc(B,C):" << std::endl;
  vtkPrintMatrixFormat(std::cerr, result.GetPointer());
  std::cerr << "**************************************" << std::endl;

  //result should be 2x1
  test_expression(result->GetExtents()[0].GetSize() == 2);
  test_expression(result->GetExtents()[1].GetSize() == 1);

  //2 values
  test_expression( close_enough(result->GetValue(0,0),  0.0644596) );
  test_expression( close_enough(result->GetValue(1,0), -0.55387) );


  //Test C1 vs. C2
  inBucket->ClearArrays();
  inBucket->AddArray(C1);
  inBucket->AddArray(C2);
  pcc->SetInputData(0, inBucket);
  pcc->Update();

  result = vtkDenseArray<double>::SafeDownCast(pcc->GetOutput()->GetArray(0));

  std::cerr << "**************************************" << std::endl;
  std::cerr << "Result for pcc(C,C):" << std::endl;
  vtkPrintMatrixFormat(std::cerr, result.GetPointer());
  std::cerr << "**************************************" << std::endl;

  //result should be 1x1
  test_expression(result->GetExtents()[0].GetSize() == 1);
  test_expression(result->GetExtents()[1].GetSize() == 1);

  //1 value
  test_expression( close_enough(result->GetValue(0,0), 1.0) );


  //Test A vs. B
  inBucket->ClearArrays();
  inBucket->AddArray(A1);
  inBucket->AddArray(B);
  pcc->SetInputData(0, inBucket);
  pcc->Update();

  result = vtkDenseArray<double>::SafeDownCast(pcc->GetOutput()->GetArray(0));

  std::cerr << "**************************************" << std::endl;
  std::cerr << "Result for pcc(A,B):" << std::endl;
  vtkPrintMatrixFormat(std::cerr, result.GetPointer());
  std::cerr << "**************************************" << std::endl;

  //result should be 1x1
  test_expression(result->GetExtents()[0].GetSize() == 5);
  test_expression(result->GetExtents()[1].GetSize() == 2);

  //2 values
  test_expression( close_enough(result->GetValue(4,0), 0.064459) );
  test_expression( close_enough(result->GetValue(3,1), 0.097225) );



  //Giving bad data and verifying errors:
  //inBucket->ClearArrays();
  //result->Resize(0,0);
  //vtkSmartPointer<vtkDenseArray<double> > G = vtkSmartPointer<vtkDenseArray<double> >::New();
  //G->Resize(5,1);
  //G->SetValue(1,0, 0.5);
  //inBucket->AddArray(A1);
  //inBucket->AddArray(A2);
  //inBucket->AddArray(result);
  //pcc->SetInputConnection(0, inBucket->GetProducerPort());
  //pcc->SetUnbiasedVariance(false);
  //pcc->Update();

  //std::cerr << "**************************************" << std::endl;
  //std::cerr << "Result for biased variance pcc(A,A):" << std::endl;
  //vtkPrintMatrixFormat(std::cerr, result.GetPointer());
  //std::cerr << "**************************************" << std::endl;

  cout<<endl;

  return 0;
}
