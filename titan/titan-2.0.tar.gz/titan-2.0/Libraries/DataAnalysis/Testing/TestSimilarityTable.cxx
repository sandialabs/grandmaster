/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkTestSimilarityTable.h"

#include <vtkArrayData.h>
#include <vtkArrayPrint.h>
#include <vtkDenseArray.h>
#include <vtkSmartPointer.h>
#include <vtkTable.h>
#include <vtkVariant.h>

#include <iostream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    throw std::runtime_error("Expression failed: " #expression); \
}

static bool close_enough(const double lhs, const double rhs)
{
  return fabs(lhs - rhs) < 1.0e-6;
}

static bool test_tuple(vtkSmartPointer<vtkTestSimilarityTable>& similarity, int row, int source, int target, double value)
{
  test_expression(similarity->GetOutput()->GetValueByName(row, "source").ToInt() == source);
  test_expression(similarity->GetOutput()->GetValueByName(row, "target").ToInt() == target);
  test_expression(close_enough(similarity->GetOutput()->GetValueByName(row, "similarity").ToDouble(), value));
}

int main(int vtkNotUsed(argc), char *vtkNotUsed(argv)[])
{
  cout << setprecision(17);

  try
    {
    // Run tests on one matrix ...
    vtkSmartPointer<vtkDenseArray<double> > matrix_a = vtkSmartPointer<vtkDenseArray<double> >::New();
    matrix_a->Resize(2, 3);
    matrix_a->SetValue(0, 0, 0);
    matrix_a->SetValue(1, 0, 1);
    matrix_a->SetValue(0, 1, 2);
    matrix_a->SetValue(1, 1, 2);
    matrix_a->SetValue(0, 2, 3);
    matrix_a->SetValue(1, 2, 0);

    std::cout << "Input matrix A:" << std::endl;
    vtkPrintMatrixFormat(std::cout, matrix_a.GetPointer());

    vtkSmartPointer<vtkArrayData> matrix_data_a = vtkSmartPointer<vtkArrayData>::New();
    matrix_data_a->AddArray(matrix_a);

    vtkSmartPointer<vtkTestSimilarityTable> similarity = vtkSmartPointer<vtkTestSimilarityTable>::New();
    similarity->SetInputData(0, matrix_data_a);
    similarity->SetVectorDimension(1);
    similarity->SetMinimumThreshold(0);
    similarity->SetMinimumCount(0);

    std::cout << "All similarities:" << std::endl;
    similarity->SetUpperDiagonal(true);
    similarity->SetDiagonal(true);
    similarity->SetLowerDiagonal(true);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 9);
    test_tuple(similarity, 0, 0, 2, 2);
    test_tuple(similarity, 1, 0, 1, 1);
    test_tuple(similarity, 2, 0, 0, 0);
    test_tuple(similarity, 3, 1, 0, 1);
    test_tuple(similarity, 4, 1, 2, 1);
    test_tuple(similarity, 5, 1, 1, 0);
    test_tuple(similarity, 6, 2, 0, 2);
    test_tuple(similarity, 7, 2, 1, 1);
    test_tuple(similarity, 8, 2, 2, 0);

    std::cout << "Upper diagonal similarities:" << std::endl;
    similarity->SetUpperDiagonal(true);
    similarity->SetDiagonal(false);
    similarity->SetLowerDiagonal(false);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 0, 2, 2);
    test_tuple(similarity, 1, 0, 1, 1);
    test_tuple(similarity, 2, 1, 2, 1);

    std::cout << "Diagonal similarities:" << std::endl;
    similarity->SetUpperDiagonal(false);
    similarity->SetDiagonal(true);
    similarity->SetLowerDiagonal(false);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 0, 0, 0);
    test_tuple(similarity, 1, 1, 1, 0);
    test_tuple(similarity, 2, 2, 2, 0);

    std::cout << "Lower diagonal similarities:" << std::endl;
    similarity->SetUpperDiagonal(false);
    similarity->SetDiagonal(false);
    similarity->SetLowerDiagonal(true);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 1, 0, 1);
    test_tuple(similarity, 1, 2, 0, 2);
    test_tuple(similarity, 2, 2, 1, 1);

    std::cout << "Threshold similarities:" << std::endl;
    similarity->SetUpperDiagonal(true);
    similarity->SetDiagonal(true);
    similarity->SetLowerDiagonal(true);
    similarity->SetMinimumThreshold(2);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 2);
    test_tuple(similarity, 0, 0, 2, 2);
    test_tuple(similarity, 1, 2, 0, 2);

    std::cout << "Minimum count similarities:" << std::endl;
    similarity->SetMinimumCount(1);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 3);
    test_tuple(similarity, 0, 0, 2, 2);
    test_tuple(similarity, 1, 1, 0, 1);
    test_tuple(similarity, 2, 2, 0, 2);

    std::cout << "Maximum count similarities:" << std::endl;
    similarity->SetMinimumThreshold(0);
    similarity->SetMinimumCount(0);
    similarity->SetMaximumCount(2);
    similarity->Update();
    similarity->GetOutput()->Dump(10);

    test_expression(similarity->GetOutput()->GetNumberOfRows() == 6);
    test_tuple(similarity, 0, 0, 2, 2);
    test_tuple(similarity, 1, 0, 1, 1);
    test_tuple(similarity, 2, 1, 0, 1);
    test_tuple(similarity, 3, 1, 2, 1);
    test_tuple(similarity, 4, 2, 0, 2);
    test_tuple(similarity, 5, 2, 1, 1);

    return 0;
    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    return 1;
    }
}
