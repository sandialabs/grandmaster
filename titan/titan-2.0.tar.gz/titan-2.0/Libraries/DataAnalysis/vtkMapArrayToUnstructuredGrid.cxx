/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkMapArrayToUnstructuredGrid.h"

#include <vtkArrayData.h>
#include <vtkArrayToTable.h>
#include <vtkDenseArray.h>
#include <vtkDoubleArray.h>
#include <vtkIdTypeArray.h>
#include <vtkInformation.h>
#include <vtkIntArray.h>
#include <vtkObjectFactory.h>
#include <vtkPointData.h>
#include <vtkSortDataArray.h>
#include <vtkTable.h>
#include <vtkUnstructuredGrid.h>

#include <stdexcept>

#include <vtkSmartPointer.h>
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

vtkStandardNewMacro(vtkMapArrayToUnstructuredGrid);

//----------------------------------------------------------------------------
vtkMapArrayToUnstructuredGrid::vtkMapArrayToUnstructuredGrid()
{
  this->SetNumberOfInputPorts(3);
}

//----------------------------------------------------------------------------
vtkMapArrayToUnstructuredGrid::~vtkMapArrayToUnstructuredGrid()
{
}

//----------------------------------------------------------------------------
int vtkMapArrayToUnstructuredGrid::RequestData(
  vtkInformation* vtkNotUsed(request),
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // get the input and output
  vtkUnstructuredGrid *mesh = vtkUnstructuredGrid::GetData(inputVector[0]);
  if (!mesh)
    throw std::runtime_error("Port 0 requires vtkUnstructuredGrid input");
  vtkArrayData* const BContainer = vtkArrayData::GetData(inputVector[1]);
  if (!BContainer)
    throw std::runtime_error("Missing CCA result matrix.");
  vtkArrayData* const nodeMapContainer = vtkArrayData::GetData(inputVector[2]);
  vtkDenseArray<int>* nodeMap = NULL;
  if (nodeMapContainer != NULL)
    {
    nodeMap = vtkDenseArray<int>::SafeDownCast(nodeMapContainer->GetArray(0));
    }

  VTK_CREATE(vtkArrayToTable, BConvert);
  BConvert->SetInputData(0, BContainer);
  BConvert->Update();

  vtkTable* BOutputTable = BConvert->GetOutput();
  if (BOutputTable == NULL)
    {
    return 0;
    }

  vtkUnstructuredGrid* output = vtkUnstructuredGrid::GetData(outputVector, 0);
  output->ShallowCopy(mesh);

  vtkPointData* points = mesh->GetPointData();

  vtkDataArray* globalIds = points->GetGlobalIds();

  int numPoints = globalIds->GetNumberOfTuples();
  char valueName[20];

  vtkIdTypeArray* gIDs = vtkIdTypeArray::SafeDownCast(globalIds);
  VTK_CREATE(vtkIdTypeArray, indices);
  indices->SetNumberOfValues(numPoints);
  VTK_CREATE(vtkIntArray, keys);
  keys->SetNumberOfValues(numPoints);
  VTK_CREATE(vtkSortDataArray, sorter);

  for(vtkIdType j = 0; j < numPoints; j++)
    {
    indices->SetValue(j, j);
    int g = gIDs->GetValue(j);
    keys->SetValue(j, g);
    }

  sorter->Sort(keys, indices);

  if (nodeMap == NULL) // construct one using the globalIds
    {
    // I'm making the assumption here that the globalIDs are not only
    // zero-based, but also that you can tell by looking at the first
    // ID.  This problem stems from exodus using a 1-based index, that
    // later on we compensate for by subtracting one (so we add one here).
    // Since we are trying to generate a nodeMap, we don't know the source
    // of the grid (probably not exodus), this is an ad hoc effort to fix it.
    int indexingBase = 0;
    if (gIDs->GetValue(0) == 0)
      {
      indexingBase = 1;
      }
    nodeMap = vtkDenseArray<int>::New();
    nodeMap->Resize(numPoints);
    for (int j = 0; j < numPoints; j++)
      {
      int id = gIDs->GetValue(j) + indexingBase; // replicate exodus 1-based indexing
      nodeMap->SetValue(j, id);
      }
    }

  // Create a lookup for the first instance of each gid in the sorted list
  VTK_CREATE(vtkIdTypeArray, gidStart);
  int keyRange[2];
  keys->GetValueRange(keyRange);
  gidStart->SetNumberOfValues(keyRange[1]+1);

  gidStart->SetValue(0, 0);
  vtkIdType next = 1;
  for (vtkIdType j = 1; j < numPoints; j++)
  {
    if(keys->GetValue(j-1) != keys->GetValue(j))
      {
      gidStart->SetValue(next, j);
      next++;
      }
  }

  for (int j = 0; j < BOutputTable->GetNumberOfColumns(); j++)
    {
    vtkDataArray* ccaComponent = vtkDataArray::SafeDownCast(BOutputTable->GetColumn(j));
    int numCCAValues = ccaComponent->GetNumberOfTuples();

    VTK_CREATE(vtkDoubleArray, renderArray);
    renderArray->SetNumberOfTuples(numPoints);
    renderArray->FillComponent(0, 0.0); // init array to zero
    sprintf(valueName, "CCA%1d", j+1); // label is base-1 indexed
    renderArray->SetName(valueName);
    for (int i = 0; i < numCCAValues; i++)
      {
      int gid = nodeMap->GetValue(i) - 1; // 1-based indexing
      double v = ccaComponent->GetTuple1(i);
      int nextKey = gidStart->GetValue(gid); // 0-based indexing
      while (nextKey < numPoints)
        {
        if (keys->GetValue(nextKey) == (gid + 1)) // keys are 1-based indexing
          {
          renderArray->SetTuple1(indices->GetValue(nextKey), v);
          nextKey++;
          }
        else
          {
          break;
          }
        }
      }
    output->GetPointData()->AddArray(renderArray);
    }
  nodeMap->Delete();

  return 1;
}


//----------------------------------------------------------------------------
int vtkMapArrayToUnstructuredGrid::FillInputPortInformation(int port, vtkInformation* info)
{
  switch(port)
    {
    case 0:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkUnstructuredGrid");
      return 1;
    case 1:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;
    case 2:
      info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;
    }

  return 0;
}

//----------------------------------------------------------------------------
void vtkMapArrayToUnstructuredGrid::PrintSelf(ostream& os,
  vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
