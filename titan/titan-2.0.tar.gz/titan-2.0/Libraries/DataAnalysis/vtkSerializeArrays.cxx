/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
**********************************************************************/

#undef COPIOUS_DEBUG_OUTPUT_READ
#undef COPIOUS_DEBUG_OUTPUT_WRITE


#include "vtkSerializeArrays.h"

#include <vtkCharArray.h>
#include <vtkObjectFactory.h>
#include <vtkStringArray.h>
#include <vtkVariantArray.h>

#include <vtksys/ios/sstream>

// 0x1234 = 0001 0010 0011 0100 = 4660 decimal

// 0x3412 = 0011 0100 0001 0010 =

// 2 + 16 + 1024 + 4096 + 8192 = 5140 + 8192 = 13332

#define GUARD_NULL(x) ((x) == 0 ? "(null)" : (x))

static const unsigned short ENDIANNESS_COOKIE = 0x1234;
static const unsigned short BACKWARDS_COOKIE  = 0x3412;


vtkStandardNewMacro(vtkSerializeArrays);

template<typename T>
T flip_bytes(T input)
{
  char flipbuf[sizeof(T)];
  const char *inbuf = reinterpret_cast<const char *>(&input);

  for (unsigned int i = 0; i < sizeof(T); ++i)
    {
      flipbuf[(sizeof(T)-i)-1] = inbuf[i];
    }

  return *(reinterpret_cast<const T *>(flipbuf));
}

template<>
vtkStdString flip_bytes(vtkStdString input)
{
  return input;
}

// ----------------------------------------------------------------------

template<typename T>
void ReadNumber(istream &instream, T *output, bool should_flip)
{
#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "Reading " << sizeof(T) << " bytes from instream\n";
  ios::fmtflags saved_flags = cerr.flags();
  cerr.setf(ios::hex);
#endif

  T tempvar;
  instream.read(reinterpret_cast<istream::char_type *>(&tempvar), sizeof(T));

#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "Raw number: " << static_cast<int>(tempvar) << "\n";
  cerr.setf(saved_flags);
#endif

  if (should_flip)
    {
      *output = flip_bytes(tempvar);
    }
  else
    {
      *output = tempvar;
    }
}

// ----------------------------------------------------------------------

template<typename T>
void WriteNumber(T value, ostream &output)
{
#ifdef COPIOUS_DEBUG_OUTPUT_WRITE
  cerr << "\tWriteNumber: Writing " << sizeof(T) << " bytes to stream\n";
#endif
  output.write(reinterpret_cast<const istream::char_type *>(&value), sizeof(T));
}

// ----------------------------------------------------------------------

// Format for string arrays in the archive:
//
// Bytes 1 and 2: endianness test 1234
//
// Byte 3: length of array name
// Bytes 4-N: array name
//
// Next comes the number of elements in the array (4 bytes)
//
// Then follow the strings one at a time.  Each string is a 4-byte
// size followed by the string data.  Wait... what does std::string do for its own operator<<  and >>?

//
// vtkVariantArray will work much the same way.
//
//

typedef vtksys_ios::ostringstream outstream;

#define MANUAL_STRING_SERIALIZATION

void
SerializeStdString(const vtkStdString &data, ostream &os)
{
#ifdef MANUAL_STRING_SERIALIZATION
#ifdef COPIOUS_DEBUG_OUTPUT_WRITE
  cerr << "Serializing string with length " << data.size() << "\n";
#endif
  WriteNumber(data.size(), os);
  // XXX YOU ARE HERE
  if (data.size())
    {
#ifdef COPIOUS_DEBUG_OUTPUT_WRITE
      cerr << "\tWriting " << data.size() << " bytes of string content\n";
#endif
      os.write(data.c_str(), data.size());
    }
#else
  os << data;
#endif
}

// ----------------------------------------------------------------------

vtkStdString
UnserializeStdString(istream &instream, vtkStdString &output, bool flip_bytes)
{
#ifdef MANUAL_STRING_SERIALIZATION
  vtkStdString::size_type length;
  ReadNumber(instream, &length, flip_bytes);
#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "\tUnserializeStdString about to read " << length << " bytes\n";
#endif
  for (vtkStdString::size_type i = 0; i < length; ++i)
    {
      output += instream.get();
    }

#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "\tUnserializeStdString: size " << length << ", data '" << output << "'\n";
  //  cerr << "\tUnserializeStdString: size " << length << "\n";
#endif

  return output;
#else
  vtkStdString retval;
  instream >> retval;
  return retval;
#endif
}

// ----------------------------------------------------------------------

vtkSerializeArrays::vtkSerializeArrays()
{

}

// ----------------------------------------------------------------------

vtkSerializeArrays::~vtkSerializeArrays()
{

}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::SaveStringArray(vtkStringArray *input, ostream &os)
{
  WriteNumber(ENDIANNESS_COOKIE, os);
  if (input->GetName())
    {
      SerializeStdString(vtkStdString(input->GetName()), os);
    }
  else
    {
      SerializeStdString(vtkStdString("(null)"), os);
    }

  vtkIdType size = input->GetNumberOfTuples();
  WriteNumber(size, os);

  for (int i = 0; i < size; ++i)
    {
      SerializeStdString(input->GetValue(i), os);
    }
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::RestoreStringArray(istream &instream, vtkStringArray *output)
{
  short restored_cookie;
  vtkStdString name;
  vtkIdType size;

  ReadNumber(instream, &restored_cookie, false);
#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "RestoreStringArray: restored cookie " << restored_cookie << "\n";
#endif
  UnserializeStdString(instream, name, (restored_cookie != ENDIANNESS_COOKIE));
  ReadNumber(instream, &size, (restored_cookie != ENDIANNESS_COOKIE));
#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "RestoreStringArray: restored size " << size << "\n";
#endif

  if (name != "(null)")
    {
      output->SetName(name.c_str());
    }
  output->SetNumberOfTuples(size);
  for (vtkIdType i = 0; i < size; ++i)
    {
      vtkStdString newval;
      UnserializeStdString(instream, newval, (restored_cookie != ENDIANNESS_COOKIE));
      output->SetValue(i, newval);
    }
  return;
}

// ----------------------------------------------------------------------

static void
SerializeVariant(const vtkVariant &variant, ostream &os)
{
  if (!variant.IsValid())
    {
#ifdef COPIOUS_DEBUG_OUTPUT_WRITE
      cerr << "Serializing null variant\n";
#endif
      char null = 0;
      WriteNumber(null, os);
      return;
    }

  // Output the type
  char Type = variant.GetType();
#ifdef COPIOUS_DEBUG_OUTPUT_WRITE
  cerr << "Serializing variant with type " << static_cast<int>(Type) << "\n";
#endif
  WriteNumber(Type, os);

  // Output the value
#define VTK_VARIANT_SAVE(Value,Type,Function)   \
  case Value:                                   \
    {                                           \
      Type value = variant.Function();          \
      WriteNumber(value, os);                   \
    }                                           \
  return

  switch (Type)
    {
    case VTK_STRING: SerializeStdString(variant.ToString(), os); return;
      VTK_VARIANT_SAVE(VTK_FLOAT,float,ToFloat);
      VTK_VARIANT_SAVE(VTK_DOUBLE,double,ToDouble);
      VTK_VARIANT_SAVE(VTK_CHAR,char,ToChar);
      VTK_VARIANT_SAVE(VTK_SIGNED_CHAR,signed char,ToSignedChar);
      VTK_VARIANT_SAVE(VTK_UNSIGNED_CHAR,unsigned char,ToUnsignedChar);
      VTK_VARIANT_SAVE(VTK_SHORT,short,ToShort);
      VTK_VARIANT_SAVE(VTK_UNSIGNED_SHORT,unsigned short,ToUnsignedShort);
      VTK_VARIANT_SAVE(VTK_INT,int,ToInt);
      VTK_VARIANT_SAVE(VTK_UNSIGNED_INT,unsigned int,ToUnsignedInt);
      VTK_VARIANT_SAVE(VTK_LONG,long,ToLong);
      VTK_VARIANT_SAVE(VTK_UNSIGNED_LONG,unsigned long,ToUnsignedLong);
#if defined(VTK_TYPE_USE___INT64)
      VTK_VARIANT_SAVE(VTK___INT64,vtkTypeInt64,ToTypeInt64);
      VTK_VARIANT_SAVE(VTK_UNSIGNED___INT64,vtkTypeUInt64,ToTypeUInt64);
#endif
#if defined(VTK_TYPE_USE_LONG_LONG)
      VTK_VARIANT_SAVE(VTK_LONG_LONG,long long,ToLongLong);
      VTK_VARIANT_SAVE(VTK_UNSIGNED_LONG_LONG,unsigned long long,
                       ToUnsignedLongLong);
#endif
    default:
      cerr << "cannot serialize variant with type " << variant.GetType()
           << '\n';
    }
#undef VTK_VARIANT_SAVE
}

// ----------------------------------------------------------------------

static void
UnserializeVariant(istream  &instream, vtkVariant &output, bool should_flip)
{
  char Type;
  ReadNumber(instream, &Type, false);

#ifdef COPIOUS_DEBUG_OUTPUT_READ
  cerr << "UnserializeVariant: Got type " << static_cast<int>(Type) << "\n";
#endif

#define VTK_VARIANT_LOAD(Value,DataType)                \
  case Value:                                           \
    {                                                   \
      DataType value;                                   \
      ReadNumber(instream, &value, should_flip);        \
      output = vtkVariant(value);                       \
    }; return

  switch (Type)
    {
    case 0: output = vtkVariant(); return;
    case VTK_STRING:
      {
        vtkStdString value;
        UnserializeStdString(instream, value, should_flip);
        output = vtkVariant(value);
      }; return;
      VTK_VARIANT_LOAD(VTK_FLOAT,float);
      VTK_VARIANT_LOAD(VTK_DOUBLE,double);
      VTK_VARIANT_LOAD(VTK_CHAR,char);
      VTK_VARIANT_LOAD(VTK_SIGNED_CHAR,signed char);
      VTK_VARIANT_LOAD(VTK_UNSIGNED_CHAR,unsigned char);
      VTK_VARIANT_LOAD(VTK_SHORT,short);
      VTK_VARIANT_LOAD(VTK_UNSIGNED_SHORT,unsigned short);
      VTK_VARIANT_LOAD(VTK_INT,int);
      VTK_VARIANT_LOAD(VTK_UNSIGNED_INT,unsigned int);
      VTK_VARIANT_LOAD(VTK_LONG,long);
      VTK_VARIANT_LOAD(VTK_UNSIGNED_LONG,unsigned long);
#if defined(VTK_TYPE_USE___INT64)
      VTK_VARIANT_LOAD(VTK___INT64,vtkTypeInt64);
      VTK_VARIANT_LOAD(VTK_UNSIGNED___INT64,vtkTypeUInt64);
#endif
#if defined(VTK_TYPE_USE_LONG_LONG)
      VTK_VARIANT_LOAD(VTK_LONG_LONG,long long);
      VTK_VARIANT_LOAD(VTK_UNSIGNED_LONG_LONG,unsigned long long);
#endif
    default:
      cerr << "cannot deserialize variant with type " << Type << '\n';
      output = vtkVariant();
    }
#undef VTK_VARIANT_LOAD

}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::SaveVariantArray(vtkVariantArray *data, ostream &os)
{
  WriteNumber(ENDIANNESS_COOKIE, os);
#ifdef COPIOUS_DEBUG_OUTPUT_WRITE
  cerr << "SaveVariantArray: Serializing variant array '"
       << (data->GetName() ? data->GetName() : "unnamed")
       << "' with "
       << data->GetNumberOfTuples() << " elements\n";
#endif

  if (data->GetName())
    {
      SerializeStdString(vtkStdString(data->GetName()), os);
    }
  else
    {
      SerializeStdString(vtkStdString(), os);
    }

  WriteNumber(data->GetNumberOfTuples(), os);
  for (vtkIdType i = 0; i < data->GetNumberOfTuples(); ++i)
    {
      SerializeVariant(data->GetValue(i), os);
    }
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::RestoreVariantArray(istream &instream, vtkVariantArray *output)
{
  short restored_cookie;
  vtkStdString name;
  vtkIdType size;

  ReadNumber(instream, &restored_cookie, false);
  UnserializeStdString(instream, name, (restored_cookie != ENDIANNESS_COOKIE));

  ReadNumber(instream, &size, (restored_cookie != ENDIANNESS_COOKIE));

  if (name != "(null)")
    {
      output->SetName(name.c_str());
    }

  output->SetNumberOfTuples(size);

  for (int i = 0; i < size; ++i)
    {
      vtkVariant variant;
      UnserializeVariant(instream, variant, (restored_cookie != ENDIANNESS_COOKIE));
      output->SetValue(i, variant);
    }
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::SaveStringArray(vtkStringArray *data,
                                    vtkCharArray *output)
{
  vtksys_ios::ostringstream namebuf;
  namebuf << "Serialized version of vtkStringArray '"
          << GUARD_NULL(data->GetName()) << "'";

  vtksys_ios::ostringstream archive;
  vtkSerializeArrays::SaveStringArray(data, archive);

  vtkIdType item_count = static_cast<vtkIdType>(archive.str().size());
  output->Reset();
  output->SetName(namebuf.str().c_str());
  output->SetNumberOfTuples(item_count);

  char *write_here = reinterpret_cast<char *>(output->WriteVoidPointer(0, item_count));
  memcpy(write_here, archive.str().data(), archive.str().size());
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::SaveVariantArray(vtkVariantArray *data,
                                     vtkCharArray *output)
{

  vtksys_ios::ostringstream namebuf;
  namebuf << "Serialized version of vtkVariantArray '"
          << GUARD_NULL(data->GetName()) << "'";

  vtksys_ios::ostringstream archive;
  vtkSerializeArrays::SaveVariantArray(data, archive);

  vtkIdType item_count = static_cast<vtkIdType>(archive.str().size());
  output->Reset();
  output->SetName(namebuf.str().c_str());
  output->SetNumberOfTuples(item_count);

  char *write_here = output->WritePointer(0, item_count);
  memcpy(write_here, archive.str().data(), archive.str().size());
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::RestoreStringArray(vtkCharArray *input,
                                       vtkStringArray *output)
{
  const char *data = input->GetPointer(0);
  vtkStdString dataStr(data, input->GetNumberOfTuples());
  vtksys_ios::istringstream instream(dataStr);
  vtkSerializeArrays::RestoreStringArray(instream, output);
}

// ----------------------------------------------------------------------

void
vtkSerializeArrays::RestoreVariantArray(vtkCharArray *input,
                                        vtkVariantArray *output)
{
  const char *data = input->GetPointer(0);
  vtkStdString dataStr(data, input->GetNumberOfTuples());
  vtksys_ios::istringstream instream(dataStr);
  vtkSerializeArrays::RestoreVariantArray(instream, output);
}
