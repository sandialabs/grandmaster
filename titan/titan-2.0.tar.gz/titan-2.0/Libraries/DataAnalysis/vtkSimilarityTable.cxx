/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkArrayData.h"
#include "vtkArrayNorm.h"
#include "vtkArrayPrint.h"
#include "vtkCommand.h"
#include "vtkSimilarityTable.h"
#include "vtkDoubleArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"

#include <boost/scoped_ptr.hpp>

#include <algorithm>
#include <limits>
#include <map>
#include <stdexcept>

typedef std::multimap<double, vtkIdType, std::greater<double> > similarities_t;

static void StoreSimilarities(
  const vtkIdType vector_a,
  const similarities_t& similarities,
  const double minimum_threshold,
  const vtkIdType minimum_count,
  const vtkIdType maximum_count,
  vtkIdTypeArray* source_array,
  vtkIdTypeArray* target_array,
  vtkDoubleArray* similarity_array
  )
{
  vtkIdType count = 0;
  for(similarities_t::const_iterator similarity = similarities.begin(); similarity != similarities.end(); ++similarity, ++count)
    {
    if(count >= maximum_count)
      break;

    if(similarity->first < minimum_threshold && count >= minimum_count)
      break;

    source_array->InsertNextValue(vector_a);
    target_array->InsertNextValue(similarity->second);
    similarity_array->InsertNextValue(similarity->first);
    }
}

// ----------------------------------------------------------------------



// ----------------------------------------------------------------------

vtkSimilarityTable::vtkSimilarityTable() :
  VectorDimension(1),
  MinimumThreshold(1),
  MinimumCount(1),
  MaximumCount(10),
  UpperDiagonal(true),
  Diagonal(false),
  LowerDiagonal(false),
  FirstSecond(true),
  SecondFirst(true),
  Window(0, std::numeric_limits<vtkIdType>::max())
{
  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(1);
}

// ----------------------------------------------------------------------

vtkSimilarityTable::~vtkSimilarityTable()
{
}

void vtkSimilarityTable::SetWindow(const vtkArrayRange& window)
{
  if(this->Window == window)
    return;

  this->Window = window;
  this->Modified();
}

const vtkArrayRange vtkSimilarityTable::GetWindow()
{
  return this->Window;
}

// ----------------------------------------------------------------------

void vtkSimilarityTable::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "VectorDimension: " << this->VectorDimension << endl;
  os << indent << "MinimumThreshold: " << this->MinimumThreshold << endl;
  os << indent << "MinimumCount: " << this->MinimumCount << endl;
  os << indent << "MaximumCount: " << this->MaximumCount << endl;
  os << indent << "UpperDiagonal: " << this->UpperDiagonal << endl;
  os << indent << "Diagonal: " << this->Diagonal << endl;
  os << indent << "LowerDiagonal: " << this->LowerDiagonal << endl;
  os << indent << "FirstSecond: " << this->FirstSecond << endl;
  os << indent << "SecondFirst: " << this->SecondFirst << endl;
  os << indent << "Window: " << this->Window << endl;
}

int vtkSimilarityTable::FillInputPortInformation(int port, vtkInformation* info)
{
  switch(port)
    {
    case 0:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;
    case 1:
      info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;
    }

  return 0;
}

// ----------------------------------------------------------------------

int vtkSimilarityTable::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    // We will use a context object to minimize argument-passing during iteration.
    Context context;
    context.InputVector = inputVector;
    context.OutputVector = outputVector;

    // Enforce our preconditions ...
    if(this->VectorDimension != 0 && this->VectorDimension != 1)
      throw std::runtime_error("VectorDimension must be zero or one.");

    vtkArrayData* const input_a = vtkArrayData::GetData(inputVector[0]);
    if(!input_a)
      throw std::runtime_error("Missing array data input on input port 0.");
    if(input_a->GetNumberOfArrays() != 1)
      throw std::runtime_error("Array data on input port 0 must contain exactly one array.");
    context.ArrayA = vtkTypedArray<double>::SafeDownCast(input_a->GetArray(0));
    if(!context.ArrayA)
      throw std::runtime_error("Array on input port 0 must be a vtkTypedArray<double>.");
    if(context.ArrayA->GetDimensions() != 2)
      throw std::runtime_error("Array on input port 0 must be a matrix.");
    if(!context.ArrayA->GetExtents().ZeroBased())
      throw std::runtime_error("Array on input port 0 must use zero-based indices.");

    context.ArrayB = context.ArrayA;
    vtkArrayData* const input_b = vtkArrayData::GetData(inputVector[1]);
    if(input_b)
      {
      if(input_b->GetNumberOfArrays() != 1)
        throw std::runtime_error("Array data on input port 1 must contain exactly one array.");
      context.ArrayB = vtkTypedArray<double>::SafeDownCast(input_b->GetArray(0));
      if(!context.ArrayB)
        throw std::runtime_error("Array on input port 1 must be a vtkTypedArray<double>.");
      if(context.ArrayB->GetDimensions() != 2)
        throw std::runtime_error("Array on input port 1 must be a matrix.");
      if(!context.ArrayB->GetExtents().ZeroBased())
        throw std::runtime_error("Array on input port 1 must use zero-based indices.");
      }

    context.VectorDimensionA = this->VectorDimension;
    context.VectorDimensionB = this->VectorDimension;
    context.ElementDimensionA = 1 - context.VectorDimensionA;
    context.ElementDimensionB = 1 - context.VectorDimensionB;

    const vtkIdType vector_count_a = context.ArrayA->GetExtent(context.VectorDimensionA).GetSize();
    const vtkIdType element_count_a = context.ArrayA->GetExtent(context.ElementDimensionA).GetSize();

    const vtkIdType vector_count_b = context.ArrayB->GetExtent(context.VectorDimensionB).GetSize();
    const vtkIdType element_count_b = context.ArrayB->GetExtent(context.ElementDimensionB).GetSize();

    if(element_count_a != element_count_b)
      throw std::runtime_error("Input array vector lengths must match.");

    context.ElementBegin = std::min(element_count_a, std::min(element_count_b, this->Window.GetBegin()));
    context.ElementEnd = std::min(element_count_a, std::min(element_count_b, this->Window.GetEnd()));

    // Setup output arrays ...
    vtkTable* const output = vtkTable::GetData(outputVector);

    vtkIdTypeArray* const source_array = vtkIdTypeArray::New();
    source_array->SetName("source");

    vtkIdTypeArray* const target_array = vtkIdTypeArray::New();
    target_array->SetName("target");

    vtkDoubleArray* const similarity_array = vtkDoubleArray::New();
    similarity_array->SetName("similarity");

    // Okay let outside world know that I'm starting
    double progress = 0;
    this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

    if(input_b)
      {
      // Compare the first matrix with the second matrix ...
      if(this->FirstSecond)
        {
        this->StartIteration(context);
        for(vtkIdType vector_a = 0; vector_a != vector_count_a; ++vector_a)
          {
          similarities_t similarities;
          for(vtkIdType vector_b = 0; vector_b != vector_count_b; ++vector_b)
            {
            similarities.insert(std::make_pair(this->ComputePairwiseScore(context, vector_a, vector_b), vector_b));
            }

          StoreSimilarities(vector_a, similarities, this->MinimumThreshold, this->MinimumCount, this->MaximumCount, source_array, target_array, similarity_array);
          }
        this->FinishIteration(context);
        }
      // Compare the second matrix with the first matrix ...
      if(this->SecondFirst)
        {
        std::swap(context.ArrayA, context.ArrayB);
        std::swap(context.VectorDimensionA, context.VectorDimensionB);
        std::swap(context.ElementDimensionA, context.ElementDimensionB);

        this->StartIteration(context);
        for(vtkIdType vector_b = 0; vector_b != vector_count_b; ++vector_b)
          {
          similarities_t similarities;
          for(vtkIdType vector_a = 0; vector_a != vector_count_a; ++vector_a)
            {
            similarities.insert(std::make_pair(this->ComputePairwiseScore(context, vector_b, vector_a), vector_a));
            }

          StoreSimilarities(vector_b, similarities, this->MinimumThreshold, this->MinimumCount, this->MaximumCount, target_array, source_array, similarity_array);
          }
        this->FinishIteration(context);
        }
      }
    // Compare the one matrix with itself ...
    else
      {
      this->StartIteration(context);
      for(vtkIdType vector_a = 0; vector_a != vector_count_a; ++vector_a)
        {
        similarities_t similarities;
        for(vtkIdType vector_b = 0; vector_b != vector_count_a; ++vector_b)
          {
          if((vector_b > vector_a) && !this->UpperDiagonal)
            continue;

          if((vector_b == vector_a) && !this->Diagonal)
            continue;

          if((vector_b < vector_a) && !this->LowerDiagonal)
            continue;

          similarities.insert(std::make_pair(this->ComputePairwiseScore(context, vector_a, vector_b), vector_b));
          }

        StoreSimilarities(vector_a, similarities, this->MinimumThreshold, this->MinimumCount, this->MaximumCount, source_array, target_array, similarity_array);
        }
      this->FinishIteration(context);
      }

    output->AddColumn(source_array);
    output->AddColumn(target_array);
    output->AddColumn(similarity_array);

    source_array->Delete();
    target_array->Delete();
    similarity_array->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }
}
