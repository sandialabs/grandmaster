/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/*
* Copyright (c) 2008, Sandia Corporation
* All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions are met:
*     * Redistributions of source code must retain the above copyright
*       notice, this list of conditions and the following disclaimer.
*     * Redistributions in binary form must reproduce the above copyright
*       notice, this list of conditions and the following disclaimer in the
*       documentation and/or other materials provided with the distribution.
*     * Neither the name of the Sandia Corporation nor the
*       names of its contributors may be used to endorse or promote products
*       derived from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY Sandia Corporation ``AS IS'' AND ANY
* EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
* DISCLAIMED. IN NO EVENT SHALL Sandia Corporation BE LIABLE FOR ANY
* DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
* (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
* LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
* (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#include <vtkTextAnalysisTest.h>
#include <vtkMultiProcessController.h>
#include <vtkTimerLog.h>

std::ostream* vtkTextAnalysisTest::OutputStream = &std::cout;
int vtkTextAnalysisTest::CurrentRun = 0;
std::map<std::string, int> vtkTextAnalysisTest::ComponentIndices;
std::map<std::string, std::map<std::string, int> > vtkTextAnalysisTest::MetricIndices;

///////////////////////////////////////////////////////////////////////////////////////
// vtkTextAnalysisTest::CPUTimer

vtkTextAnalysisTest::CPUTimer::CPUTimer() :
  StartTime(vtkTimerLog::GetCPUTime())
{
}

const double vtkTextAnalysisTest::CPUTimer::Elapsed() const
{
  return vtkTimerLog::GetCPUTime() - this->StartTime;
}

void vtkTextAnalysisTest::CPUTimer::Reset()
{
  this->StartTime = vtkTimerLog::GetCPUTime();
}

///////////////////////////////////////////////////////////////////////////////////////
// vtkTextAnalysisTest::WallclockTimer

vtkTextAnalysisTest::WallclockTimer::WallclockTimer() :
  StartTime(vtkTimerLog::GetUniversalTime())
{
}

const double vtkTextAnalysisTest::WallclockTimer::Elapsed() const
{
  return vtkTimerLog::GetUniversalTime() - this->StartTime;
}

void vtkTextAnalysisTest::WallclockTimer::Reset()
{
  this->StartTime = vtkTimerLog::GetUniversalTime();
}

void vtkTextAnalysisTest::SetOutputStream(std::ostream& stream)
{
  OutputStream = &stream;
}

std::ostream& vtkTextAnalysisTest::GetOutputStream()
{
  return *OutputStream;
}

void vtkTextAnalysisTest::SetCurrentRun(int run)
{
  CurrentRun = run;
}

int vtkTextAnalysisTest::GetCurrentRun()
{
  return CurrentRun;
}

///////////////////////////////////////////////////////////////////////////////////////
// vtkTextAnalysisTest::PrintColumnHeadings

void vtkTextAnalysisTest::PrintColumnHeadings()
{
  *OutputStream << "%run_index, cpu_index, cpu_count, component_index, metric_index, value, component, metric, units\n";
}

void vtkTextAnalysisTest::PrintMessage(const std::string& message)
{
  *OutputStream << message << std::endl;
}

void vtkTextAnalysisTest::PrintMetric(vtkMultiProcessController* controller, vtkObject* component, const std::string& metric, const CPUTimer& timer)
{
  PrintMetric(controller, component, metric, timer.Elapsed(), "seconds");
}

void vtkTextAnalysisTest::PrintMetric(vtkMultiProcessController* controller, const std::string& component, const std::string& metric, const CPUTimer& timer)
{
  PrintMetric(controller, component, metric, timer.Elapsed(), "seconds");
}

void vtkTextAnalysisTest::PrintMetric(vtkMultiProcessController* controller, const std::string& component, const std::string& metric, const WallclockTimer& timer)
{
  PrintMetric(controller, component, metric, timer.Elapsed(), "seconds");
}
