/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkSimilarityTable_h
#define __vtkSimilarityTable_h

#include <vtkArrayRange.h>
#include <vtkTypedArray.h>
#include <vtkTableAlgorithm.h>
#include "titanDataAnalysis.h"

/// \class vtkSimilarityTable vtkSimilarityTable.h <DataAnalysis/vtkSimilarityTable.h>
/// \brief base class for similarity computation filters.
///
///  Treats matrices as collections of vectors and computes similarity metrics.
///  The results are returned as an edge-table that lists the index of each vector
///  and their computed similarity.  The output edge-table is typically used with
///  vtkTableToGraph to create a similarity graph.
///
///  Developers should derive a new class from vtkSimilarityTable and implement
///  their similarity-metric of choice in the ComputePairwiseScore() method, which
///  will be called once for each pair of vectors to be scored.
///
///  The StartIteration() and FinishIteration() methods can be used to do one-time
///  setup and cleanup of cached data or intermediate data structures for
///  optimizaation - for example, if computing cosine-angle similarities, an
///  implementation might cache the inverse norm of every input vector, so the
///  norms aren't calculated repetitively during iteration.
///
///  vtkSimilarityTable can be used with one or two input matrices.  If you provide a
///  single matrix as input, every vector in the matrix is compared with every
///  other vector. If you provide two matrices, every vector in the first matrix
///  is compared with every vector in the second matrix.
///
///  Note that the arguments passed to StartIteration(), ComputePairwiseScore(),
///  and FinishIteration() will always reference two valid arrays, but in the
///  one-input case those references will happen to refer to the same array.
///
///  Implementations of StartIteration(), ComputePairwiseScore(), and
///  FinishIteration() may throw exceptions to indicate an error condition.  In
///  particular, implementations that wish to impose extra constraints on their
///  inputs (such as constraining the inputs to be a specific size, etc)
///  should throw an exception in StartIteration().
///
///  You may optionally use a vtkArrayRange object to define a "window" of
///  vector elements to be compared.  This would typically be used when computing
///  truncated LSA similarities.
///
///  Inputs:
///    Input port 0: (required) A vtkDenseArray<double> with two dimensions.
///    Input port 1: (optional) A vtkDenseArray<double> with two dimensions.
///
///  Outputs:
///    Output port 0: A vtkTable containing "source", "target", and "similarity"
///      columns.
///
/// \warning
///  Note that the complexity of this filter is quadratic!  It also requires double
///  arrays as input, in the future it should be generalized to accept arrays
///  containing other types.
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_DATA_ANALYSIS_EXPORT vtkSimilarityTable : public vtkTableAlgorithm
{
public:
  vtkTypeMacro(vtkSimilarityTable, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Controls whether to compute similarities for row-vectors or column-vectors.
  /// 0 = rows, 1 = columns.
  vtkGetMacro(VectorDimension, vtkIdType);
  vtkSetMacro(VectorDimension, vtkIdType);
  ///@}

  ///@{
  /// When computing similarities for a single input matrix, controls whether the
  /// results will include the upper diagonal of the similarity matrix.
  /// Default: true.
  vtkGetMacro(UpperDiagonal, int);
  vtkSetMacro(UpperDiagonal, int);
  ///@}

  ///@{
  /// When computing similarities for a single input matrix, controls whether the
  /// results will include the diagonal of the similarity matrix.  Default: false.
  vtkGetMacro(Diagonal, int);
  vtkSetMacro(Diagonal, int);
  ///@}

  ///@{
  /// When computing similarities for a single input matrix, controls whether the
  /// results will include the lower diagonal of the similarity matrix.
  /// Default: false.
  vtkGetMacro(LowerDiagonal, int);
  vtkSetMacro(LowerDiagonal, int);
  ///@}

  ///@{
  /// When computing similarities for two input matrices, controls whether the
  /// results will include comparisons from the first matrix to the second matrix.
  vtkGetMacro(FirstSecond, int);
  vtkSetMacro(FirstSecond, int);
  ///@}

  ///@{
  /// When computing similarities for two input matrices, controls whether the
  /// results will include comparisons from the second matrix to the first matrix.
  vtkGetMacro(SecondFirst, int);
  vtkSetMacro(SecondFirst, int);
  ///@}

  ///@{
  /// Specifies a minimum threshold that a similarity must exceed to be included
  /// in the output.
  vtkGetMacro(MinimumThreshold, double);
  vtkSetMacro(MinimumThreshold, double);
  ///@}

  ///@{
  /// Specifies a minimum number of edges to include for each vector.
  vtkGetMacro(MinimumCount, vtkIdType);
  vtkSetMacro(MinimumCount, vtkIdType);
  ///@}

  ///@{
  /// Specifies a maximum number of edges to include for each vector.
  vtkGetMacro(MaximumCount, vtkIdType);
  vtkSetMacro(MaximumCount, vtkIdType);
  ///@}

  ///@{
  /// Specifies a "window" of vector elements to use for computation.
  void SetWindow(const vtkArrayRange&);
  const vtkArrayRange GetWindow();
  ///@}

//BTX
protected:
  vtkSimilarityTable();
  ~vtkSimilarityTable();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

  ///@{
  /// Internal state that is available to implementations during iteration.
  struct Context
  {
    vtkInformationVector** InputVector;
    vtkInformationVector* OutputVector;
    vtkTypedArray<double>* ArrayA;
    vtkTypedArray<double>* ArrayB;
    vtkIdType VectorDimensionA;
    vtkIdType VectorDimensionB;
    vtkIdType ElementDimensionA;
    vtkIdType ElementDimensionB;
    vtkIdType ElementBegin;
    vtkIdType ElementEnd;
  };
  ///@}

  /// Implement this in derived classes to perform one-time setup before
  /// iteration begins.
  virtual void StartIteration(const Context& context) = 0;

  ///@{
  /// Implement this in derived classes to compute the score between two
  /// input vectors.
  virtual double ComputePairwiseScore(
    const Context& context,
    vtkIdType vector_a,
    vtkIdType vector_b) = 0;
  ///@}

  /// Implement this in derived classes to cleanup any cached information
  /// after iteration finishes.
  virtual void FinishIteration(const Context& context) = 0;

private:
  vtkSimilarityTable(const vtkSimilarityTable&); // Not implemented
  void operator=(const vtkSimilarityTable&);   // Not implemented

  vtkIdType VectorDimension;
  double MinimumThreshold;
  vtkIdType MinimumCount;
  vtkIdType MaximumCount;
  vtkArrayRange Window;

  int UpperDiagonal;
  int Diagonal;
  int LowerDiagonal;
  int FirstSecond;
  int SecondFirst;
//ETX
};

#endif
