/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkArrayData.h"
#include "vtkCosineSimilarityTable.h"
#include "vtkDenseArray.h"
#include "vtkInformation.h"
#include "vtkObjectFactory.h"

#include <cmath>
#include <stdexcept>

// ----------------------------------------------------------------------


vtkStandardNewMacro(vtkCosineSimilarityTable);

// ----------------------------------------------------------------------

vtkCosineSimilarityTable::vtkCosineSimilarityTable() :
  WeightingVector(0)
{
  // Override the number of input ports specified by the base class ...
  this->SetNumberOfInputPorts(3);
}

// ----------------------------------------------------------------------

vtkCosineSimilarityTable::~vtkCosineSimilarityTable()
{
}

// ----------------------------------------------------------------------

void vtkCosineSimilarityTable::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkCosineSimilarityTable::FillInputPortInformation(int port, vtkInformation* info)
{
  // Provide information for our input port, defer to the base class for
  // everything else ...
  switch(port)
    {
    case 2:
      info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;

    default:
      return this->Superclass::FillInputPortInformation(port, info);
    }

  return 0;
}

void vtkCosineSimilarityTable::StartIteration(const Context& context)
{
  if(!vtkDenseArray<double>::SafeDownCast(context.ArrayA))
    throw std::runtime_error("First input must be vtkDenseArray<double>.");
  if(!vtkDenseArray<double>::SafeDownCast(context.ArrayB))
    throw std::runtime_error("Second input must be vtkDenseArray<double>.");

  vtkArrayData* const weighting_array_data = vtkArrayData::GetData(context.InputVector[2]);
  if(!weighting_array_data)
    {
    this->WeightingVector = 0;
    return;
    }

  if(weighting_array_data->GetNumberOfArrays() != 1)
    throw std::runtime_error("Array data on input port 2 must contain exactly one array.");
  this->WeightingVector = vtkDenseArray<double>::SafeDownCast(weighting_array_data->GetArray(0));
  if(!this->WeightingVector)
    throw std::runtime_error("Array on input port 2 must be a vtkDenseArray<double>.");
  if(this->WeightingVector->GetDimensions() != 1)
    throw std::runtime_error("Array on input port 2 must be a vector.");

  if(this->WeightingVector->GetExtent(0) != context.ArrayA->GetExtent(context.ElementDimensionA))
    throw std::runtime_error("Input port 2 array length doesn't match input matrix length.");
}

double vtkCosineSimilarityTable::ComputePairwiseScore(const Context& context, vtkIdType vector_a, vtkIdType vector_b)
{
  vtkArrayCoordinates coordinates_a(0, 0);
  coordinates_a[context.VectorDimensionA] = vector_a;

  vtkArrayCoordinates coordinates_b(0, 0);
  coordinates_b[context.VectorDimensionB] = vector_b;

  // Compute the dot-product of a & b, norm a, and norm b ...
  double dot_product = 0;
  double norm_a = 0;
  double norm_b = 0;
  for(vtkIdType element = context.ElementBegin; element != context.ElementEnd; ++element)
    {
    coordinates_a[context.ElementDimensionA] = element;
    coordinates_b[context.ElementDimensionB] = element;
    double a = context.ArrayA->GetValue(coordinates_a);
    double b = context.ArrayB->GetValue(coordinates_b);

    if(this->WeightingVector)
      {
      a *= this->WeightingVector->GetValue(element);
      b *= this->WeightingVector->GetValue(element);
      }

    dot_product += a * b;
    norm_a += std::pow(a, 2);
    norm_b += std::pow(b, 2);
    }

  if(!norm_a)
    return 0;
  if(!norm_b)
    return 0;

  return dot_product * (1.0 / std::pow(norm_a, 0.5)) * (1.0 / std::pow(norm_b, 0.5));
}

void vtkCosineSimilarityTable::FinishIteration(const Context& context)
{
}
