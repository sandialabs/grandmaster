/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkDataSetAttributes.h"
#include "vtkDistinctRows.h"
#include "vtkDoubleArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkIntArray.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkStdString.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"

#include <map>
#include <vector>
#include <algorithm>

// ----------------------------------------------------------------------


vtkStandardNewMacro(vtkDistinctRows);

class vtkDistinctRows::vtkVector : public std::vector<vtkStdString>
{
};

// ----------------------------------------------------------------------

vtkDistinctRows::vtkDistinctRows()
{
  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);

  this->DistinctColumns = new vtkDistinctRows::vtkVector();
  this->CountColumnName = 0;
  this->SetCountColumnName("count");
  this->AddCountColumn = false;
}

// ----------------------------------------------------------------------

vtkDistinctRows::~vtkDistinctRows()
{
  delete this->DistinctColumns;
  this->SetCountColumnName(0);
}

int vtkDistinctRows::FillInputPortInformation(int port, vtkInformation* info)
{
  switch(port)
    {
    case 0:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

  return 0;
}

//----------------------------------------------------------------------------
void vtkDistinctRows::AddDistinctColumn(const char *column)
{
  this->DistinctColumns->push_back(column);
  this->Modified();
}

//----------------------------------------------------------------------------
void vtkDistinctRows::RemoveAllDistinctColumns()
{
  this->DistinctColumns->clear();
  this->Modified();
}

// ----------------------------------------------------------------------
void vtkDistinctRows::CopyDistinctRows(vtkTable* input, vtkTable* output)
{
  // Keep track of current progress
  double currentProgress=0;

  // Add a column to keep track of counts
  if(this->AddCountColumn)
    {
    vtkSmartPointer<vtkIntArray> countCol = vtkSmartPointer<vtkIntArray>::New();
    countCol->SetName(this->CountColumnName);
    output->AddColumn(countCol);
    }


  // Make a map of the values in the column they want to do a 'distinct' on
  typedef std::map<vtkStdString, std::pair<vtkIdType,int> > index_map_t;
  index_map_t index_map;
  vtkIdType numRows = input->GetNumberOfRows();
  for(vtkIdType i = 0; i < numRows; ++i)
    {

    // Create the 'key' for this row (might be combination of multiple columns)
    vtkStdString key;
    std::vector<vtkStdString>::iterator iter;
    for(iter = this->DistinctColumns->begin(); iter != this->DistinctColumns->end(); ++iter)
      {
      vtkAbstractArray* const column = input->GetColumnByName((*iter).c_str());
      if (!column)
        {
        vtkErrorMacro("Could not find column " << (*iter).c_str() << endl);
        }
      else
        {
        key += column->GetVariantValue(i).ToString();
        }
      }

    // Toss the key into a map and accumulate accordingly
    index_map_t::iterator findIter = index_map.find(key);
    int count = 0;
    if (findIter != index_map.end())
      {
      count = findIter->second.second;
      }
    index_map[key] = std::make_pair(i,++count);


    // Emit a progress event
    double progress = (double)i/numRows;
    if ((int)(progress*100) != (int)(currentProgress*100))
      {
      currentProgress = progress;
      this->InvokeEvent(vtkCommand::ProgressEvent, &currentProgress);
      }
    }

  // Okay now simply go through the index map, copying over only
  // rows with unique keys to the output table
  for(index_map_t::iterator i = index_map.begin();i != index_map.end(); ++i)
    {
    vtkVariantArray* row = input->GetRow(i->second.first);
    if(this->AddCountColumn)
      row->InsertNextValue(i->second.second);
    output->InsertNextRow(row);
    }
}

// ----------------------------------------------------------------------

int vtkDistinctRows::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{

  vtkTable* input = vtkTable::GetData(inputVector[0]);
  vtkTable* output = vtkTable::GetData(outputVector);

  if (this->DistinctColumns->size() == 0)
    {
    output->ShallowCopy(input);
    return 1;
    }

  for (int n = 0; n < input->GetNumberOfColumns(); n++)
    {
    vtkAbstractArray* col = input->GetColumn(n);
    vtkAbstractArray* ncol = vtkAbstractArray::CreateArray(col->GetDataType());
    ncol->SetName(col->GetName());
    ncol->SetNumberOfComponents(col->GetNumberOfComponents());
    output->AddColumn(ncol);

    if(input->GetRowData()->GetPedigreeIds() == col)
      output->GetRowData()->SetPedigreeIds(ncol);

    ncol->Delete();
    }

  this->CopyDistinctRows(input, output);

  return 1;
}


// ----------------------------------------------------------------------

void vtkDistinctRows::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "CountColumnName: " << (this->CountColumnName ? "" : "(null)") << endl;
  os << indent << "AddCountColumn: "
     << (this->AddCountColumn ? "on" : "off") << endl;
}
