/*=========================================================================

Program:   Visualization Toolkit
Module:    $RCSfile: vtkKMeansClustering.h,v $

Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
All rights reserved.
See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

This software is distributed WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
Copyright 2008 Sandia Corporation.
Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/
// .NAME vtkNormalizeTableVectors - Gives the Lx Norm of vectors within
//  a table.
//
// .SECTION Description

#ifndef __vtkNormalizeTableVectors_h
#define __vtkNormalizeTableVectors_h

#include <vtkTableAlgorithm.h>
#include <vtkDataArray.h>

#include "titanCommon.h"


class TITAN_COMMON_EXPORT vtkNormalizeTableVectors : public vtkTableAlgorithm
{
public:
  static vtkNormalizeTableVectors *New();

  vtkTypeMacro(vtkNormalizeTableVectors,vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  int FillInputPortInformation(int port, vtkInformation* info);
  int FillOutputPortInformation( int port, vtkInformation* info );



  vtkSetMacro(ObservationDimension,unsigned int);
  vtkGetMacro(ObservationDimension,unsigned int);

  vtkSetMacro(NormalizingPower,double);
  vtkGetMacro(NormalizingPower,double);


  ///@{
  /// Add Feature columns, call this for each column to be
  /// included as a feature for the clustering
  void AddFeatureColumn(const char* column);
  ///@}

protected:
  vtkNormalizeTableVectors();
  ~vtkNormalizeTableVectors();

  int RequestData( vtkInformation*, vtkInformationVector**, vtkInformationVector* );


private:
  std::vector<std::string> FeatureColumns;
  std::vector<vtkDataArray*> FeatureArrays;

  unsigned int ObservationDimension;
  double NormalizingPower;


  vtkNormalizeTableVectors(const vtkNormalizeTableVectors&);  // Not implemented.
  void operator=(const vtkNormalizeTableVectors&);  // Not implemented.
};

#endif
