/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanNormalizeFeatures titanNormalizeFeatures.h <Clustering/titanNormalizeFeatures.h>
/// \brief ...
///
///  titanNormalizeFeatures normalizes the features of each vector. Note that the number
///  of vectors never changes using this method.
#ifndef __titanNormalizeFeatures_h
#define __titanNormalizeFeatures_h

#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <iostream>
#include <limits>

using namespace std;
class titanNormalizeFeatures
{
public:
  std::vector<double> min_values;
  std::vector<double> max_values;
  std::vector<double> ranges;

  double user_global_min_value;
  double user_global_max_value;

  double global_min_value;
  double global_max_value;
  double global_range;

  double  normalized_min_value;
  double  normalized_max_value;

  titanNormalizeFeatures()
  {
    normalized_min_value=0;
    normalized_max_value=1;

    global_min_value=0;
    global_max_value=0;

    user_global_min_value=0;
    user_global_max_value=0;
  }

  std::vector<double> * GetMinValues()
  {
    return &this->min_values;
  }

  std::vector<double> * GetMaxValues()
  {
    return &this->max_values;
  }

  std::vector<double> * GetRanges()
  {
    return &this->ranges;
  }

  void SetNormalizedMinMax(double min, double max)
  {
    this->normalized_min_value = min;
    this->normalized_max_value = max;
  }

  void SetGlobalMinMax(double min, double max)
  {
    this->user_global_min_value = min;
    this->user_global_max_value = max;
  }

  template<typename VectorIteratorT>
  void GenerateModel(
     VectorIteratorT begin,  VectorIteratorT end, bool generate_global_norm
    )
  {
    typedef typename VectorIteratorT::value_type observation_type;

    double value;

    min_values.resize(vector_traits<observation_type>::size(
        *begin));
    max_values.resize(vector_traits<observation_type>::size(
        *begin));
    ranges.resize(vector_traits<observation_type>::size(
        *begin));

    std::fill(min_values.begin(),min_values.end(),std::numeric_limits<double>::max());
    std::fill(max_values.begin(),max_values.end(),-(std::numeric_limits<double>::max()));

    // If the user has set the global min and max, then we will just use those, no need to iterate
    if (user_global_min_value < user_global_max_value)
    {
      global_min_value = user_global_min_value;
      global_max_value = user_global_max_value;
    }
    else
    {
      global_min_value = std::numeric_limits<double>::max();
      global_max_value = -(std::numeric_limits<double>::max());
      global_range = 0;

      for (VectorIteratorT observation = begin; observation != end;
          ++observation)
          {
        for (size_t i = 0;
            i != vector_traits<observation_type>::size(*observation); ++i)
            {
          value = vector_traits<observation_type>::get(*observation, i);

          if (value < min_values[i])
            min_values[i] = value;
          if (value > max_values[i])
            max_values[i] = value;

          if (value < global_min_value)
            global_min_value = value;
          if (value > global_max_value)
            global_max_value = value;
        }
      }

      for (size_t i = 0; i != vector_traits<observation_type>::size(*begin);
          ++i)
          {
        ranges[i] = max_values[i] - min_values[i];
      }
    }

    global_range = global_max_value - global_min_value;

    if (generate_global_norm)
    {
      for (size_t i = 0; i != vector_traits<observation_type>::size(
          *begin); ++i)
      {
        ranges[i] = global_range;
        max_values[i] = global_max_value;
        min_values[i] = global_min_value;
      }
    }
  }

  template<typename VectorIteratorT>
  void operator()(
     VectorIteratorT begin,  VectorIteratorT end
    )
  {
    typedef typename VectorIteratorT::value_type observation_type;

    if (min_values.size() != vector_traits<observation_type>::size(*begin))
      return;

    double normalized_range = normalized_max_value - normalized_min_value;

    for (VectorIteratorT observation = begin; observation != end; ++observation)
    {
      for (size_t i = 0; i != vector_traits<observation_type>::size(
          *observation); ++i)
      {
        if (ranges[i] != 0)
        {
          vector_traits<observation_type>::put(*observation, i, ((vector_traits<
              observation_type>::get(*observation, i) - min_values[i])
              / ranges[i]) * normalized_range + normalized_min_value );
        }
        else
          vector_traits<observation_type>::put(*observation, i, 0);
      }
    }
  }
};


#endif
