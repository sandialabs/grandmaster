/*=========================================================================

Program:   Visualization Toolkit
Module:    $RCSfile: vtkKMeansClustering.h,v $

Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
All rights reserved.
See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

This software is distributed WITHOUT ANY WARRANTY; without even
the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
Copyright 2008 Sandia Corporation.
Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/
// .NAME vtkNormalizeTableFeatures - Gives the Lx Norm of vectors within
//  a table.
//
// .SECTION Description

#ifndef __vtkNormalizeTableFeatures_h
#define __vtkNormalizeTableFeatures_h

#include <vtkTableAlgorithm.h>
#include <vtkDataArray.h>

#include "titanCommon.h"

#include "titanNormalizeFeatures.h"

class TITAN_COMMON_EXPORT vtkNormalizeTableFeatures : public vtkTableAlgorithm
{
public:
  static vtkNormalizeTableFeatures *New();

  vtkTypeMacro(vtkNormalizeTableFeatures,vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  int FillInputPortInformation(int port, vtkInformation* info);
  int FillOutputPortInformation( int port, vtkInformation* info );



  vtkSetMacro(ObservationDimension,unsigned int);
  vtkGetMacro(ObservationDimension,unsigned int);

  vtkSetMacro(NormalizedMinValue,double);
  vtkGetMacro(NormalizedMinValue,double);

  vtkSetMacro(NormalizedMaxValue,double);
  vtkGetMacro(NormalizedMaxValue,double);

  vtkSetMacro(GenerateGlobalNorm,bool);
  vtkGetMacro(GenerateGlobalNorm,bool);

  ///@{
  /// Add Feature columns, call this for each column to be
  /// included as a feature for the clustering
  void AddFeatureColumn(const char* column);
  ///@}

  ///@{
  /// Reset the normalization model, clearing all range values
  void Reset();
  ///@}

  void SetGlobalMinMax(double min, double max);


protected:
  vtkNormalizeTableFeatures();
  ~vtkNormalizeTableFeatures();

  int RequestData( vtkInformation*, vtkInformationVector**, vtkInformationVector* );


private:
  std::vector<std::string> FeatureColumns;
  std::vector<vtkDataArray*> FeatureArrays;

  titanNormalizeFeatures  Normalizer;
  bool  NormalizationModelGenerated;

  void InitializeProximityGenerator();
  void InitializePrimaryCentroidGenerator();


  unsigned int ObservationDimension;

  double  NormalizedMinValue;
  double  NormalizedMaxValue;

  bool GenerateGlobalNorm;
  double GlobalMax;
  double GlobalMin;

  vtkNormalizeTableFeatures(const vtkNormalizeTableFeatures&);  // Not implemented.
  void operator=(const vtkNormalizeTableFeatures&);  // Not implemented.
};

#endif
