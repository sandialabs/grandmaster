/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanVectorOperations titanVectorOperations.h <Common/titanVectorOperations.h>
/// \brief ...
///
///  titanVectorOperations is a collection functions to facilitate operations
///  for vectors of doubles, such as addition, multiplication, normalization,
///  etc.
///

#ifndef __titanVectorOperations_h
#define __titanVectorOperations_h

#include <iostream>
#include <iterator>
#include <vector>
#include <stdlib.h>
#include <math.h>

#include <Common/titanVectorTraits.h>

template<typename ValueT>
void zero(ValueT& value)
{
  value = 0;
}

template<>
inline void zero(std::vector<double>& value)
{
  std::fill(value.begin(), value.end(), 0);
}

inline std::vector<double>& operator+=(std::vector<double>& a, const std::vector<double>& b)
{
  for(size_t i = 0; i != a.size() && i != b.size(); ++i)
    a[i] += b[i];
  return a;
}

inline std::vector<double>& operator-=(std::vector<double>& a, const std::vector<double>& b)
{
  for(size_t i = 0; i != a.size() && i != b.size(); ++i)
    a[i] -= b[i];
  return a;
}

inline std::vector<double>& operator*=(std::vector<double>& a, const std::vector<double>& b)
{
  for(size_t i = 0; i != a.size() && i != b.size(); ++i)
    a[i] *= b[i];
  return a;
}

inline std::vector<double>& operator^=(std::vector<double>& a, const double exponent)
{
  // This slightly awkward dance is intended to assure the compiler
  // that we're not ignoring the return value of pow().
  double x, y;
  for(size_t i = 0; i != a.size(); ++i)
    {
    x = a[i];
    y = pow(x, exponent);
    a[i] = y;
    }
  return a;
}

inline std::vector<double>& operator/=(std::vector<double>& a, const double b)
{
  for(size_t i = 0; i != a.size(); ++i)
    a[i] /= b;
  return a;
}

inline std::vector<double>& operator*=(std::vector<double>& a, const double b)
{
  for(size_t i = 0; i != a.size(); ++i)
    a[i] *= b;
  return a;
}

template<typename First, typename Second>
void generic_copy(First& a, const Second& b)
{
  a=b;
}

template<typename ElementT, typename Second>
void generic_copy(std::vector<ElementT>& a, const Second& b)
{
  a.resize(b.size());
  for(size_t i = 0; i != b.size(); ++i)
    a[i] = b[i];
}

template<typename VectorT>
inline double computeNorm(const VectorT& a, double power)
{
  double norm=0;
  if (power==0)
    return 0;

  for(size_t i = 0; i != vector_traits<VectorT>::size(a); ++i)
    norm += pow(vector_traits<VectorT>::get(a,i),power);
  return pow(norm,1/power);

}

inline double computeNorm(const double a, double power)
{
  return a;
}

template<typename VectorT>
inline VectorT& normalize(VectorT& a, double power)
{
  double norm;

  if (power==0) return a;

  norm=computeNorm(a,power);

  if (norm==1)
    return a;

  if (norm!=0)
  {
    for (size_t i = 0; i != vector_traits<VectorT>::size(a); ++i)
    {
      vector_traits<VectorT>::put(a,i, vector_traits<VectorT>::get(a,i)/norm);
    }
  }
  else
  {
    for(size_t i = 0; i != vector_traits<VectorT>::size(a); ++i)
    {
      vector_traits<VectorT>::put(a,i,0);
    }
  }

  return a;
}


namespace std
{

  inline ostream& operator<<(ostream& stream, const std::vector<double>& value)
  {
    stream << "[ ";
    copy(value.begin(), value.end(), ostream_iterator<double>(stream, " "));
    stream << "]";

    return stream;
  }

}
#endif
