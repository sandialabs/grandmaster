/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/
#include <iostream>

#include "vtkCategoryToBitVector.h"
#include "vtkStdString.h"
#include "vtkTable.h"
#include "vtkIdTypeArray.h"
#include "vtkFloatArray.h"
#include "vtkStringArray.h"

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#define DUMP_TABLES 1

using namespace std;

int main(int argc, char* argv[])
{
  int retVal = 0;

  VTK_CREATE(vtkStringArray, ColClass);

  ColClass->SetName("Class");

  ColClass->InsertNextValue("setosa,versicolor");
  ColClass->InsertNextValue("setosa");
  ColClass->InsertNextValue("virginica,versicolor");
  ColClass->InsertNextValue("versicolor,narcissus,setosa");
  ColClass->InsertNextValue("virginica,setosa");
  ColClass->InsertNextValue("narcissus");

  VTK_CREATE(vtkTable, ClassTable);
  ClassTable->AddColumn(ColClass);

  cout << "Table:" << endl;
  ClassTable->Dump(20);

  VTK_CREATE(vtkCategoryToBitVector, test);
  test->SetInputData(0, ClassTable);
  test->SetCategoryColumn("Class");
  test->Update();

  vtkTable * output = test->GetOutput();
  cout << endl << "Output" << endl;
  output->Dump();

  test->GetOutput(1)->Dump();

  if(test->GetOutput()->GetValue(0,0).ToInt() != 0 ||
    output->GetValue(1,0).ToInt() != 0 ||
    output->GetValue(2,0).ToInt() != 0 ||
    output->GetValue(3,0).ToInt() != 1 ||
    output->GetValue(4,0).ToInt() != 0 ||
    output->GetValue(5,0).ToInt() != 1)
    {
    cerr << "FAILED Test 1 (Values): I found the table had the values: "
      << "{ " << test->GetOutput()->GetValue(0,0).ToString() << ", "
      << output->GetValue(1,0).ToInt() << ", "
      << output->GetValue(2,0).ToInt() << ", "
      << output->GetValue(3,0).ToInt() << ", "
      << output->GetValue(4,0).ToInt() << ", "
      << output->GetValue(5,0).ToInt() << " }"
      << " but expected: " << "{ 0, 0, 0, 1, 0, 1 }" << endl;
    retVal = 1;
    }

  if(test->GetOutput()->GetValue(0,1).ToInt() != 1 ||
    output->GetValue(1,1).ToInt() != 1 ||
    output->GetValue(2,1).ToInt() != 0 ||
    output->GetValue(3,1).ToInt() != 1 ||
    output->GetValue(4,1).ToInt() != 1 ||
    output->GetValue(5,1).ToInt() != 0)
    {
    cerr << "FAILED Test 2 (Values): I found the table had the values: "
      << "{ " << test->GetOutput()->GetValue(0,1).ToString() << ", "
      << output->GetValue(1,1).ToInt() << ", "
      << output->GetValue(2,1).ToInt() << ", "
      << output->GetValue(3,1).ToInt() << ", "
      << output->GetValue(4,1).ToInt() << ", "
      << output->GetValue(5,1).ToInt() << " }"
      << " but expected: " << "{ 1, 1, 0, 1, 1, 0 }" << endl;
    retVal = 1;
    }

  if(test->GetOutput()->GetValue(0,2).ToInt() != 1 ||
    output->GetValue(1,2).ToInt() != 0 ||
    output->GetValue(2,2).ToInt() != 1 ||
    output->GetValue(3,2).ToInt() != 1 ||
    output->GetValue(4,2).ToInt() != 0 ||
    output->GetValue(5,2).ToInt() != 0)
    {
    cerr << "FAILED Test 3 (Values): I found the table had the values: "
      << "{ " << test->GetOutput()->GetValue(0,2).ToString() << ", "
      << output->GetValue(1,2).ToInt() << ", "
      << output->GetValue(2,2).ToInt() << ", "
      << output->GetValue(3,2).ToInt() << ", "
      << output->GetValue(4,2).ToInt() << ", "
      << output->GetValue(5,2).ToInt() << " }"
      << " but expected: " << "{ 1, 0, 1, 1, 0, 0 }" << endl;
    retVal = 1;
    }

  if(test->GetOutput()->GetValue(0,3).ToInt() != 0 ||
    output->GetValue(1,3).ToInt() != 0 ||
    output->GetValue(2,3).ToInt() != 1 ||
    output->GetValue(3,3).ToInt() != 0 ||
    output->GetValue(4,3).ToInt() != 1 ||
    output->GetValue(5,3).ToInt() != 0)
    {
    cerr << "FAILED Test 4 (Values): I found the table had the values: "
      << "{ " << test->GetOutput()->GetValue(0,3).ToString() << ", "
      << output->GetValue(1,3).ToInt() << ", "
      << output->GetValue(2,3).ToInt() << ", "
      << output->GetValue(3,3).ToInt() << ", "
      << output->GetValue(4,3).ToInt() << ", "
      << output->GetValue(5,3).ToInt() << " }"
      << " but expected: " << "{ 0, 0, 1, 0, 1, 0 }" << endl;
    retVal = 1;
    }

 return retVal;
}
