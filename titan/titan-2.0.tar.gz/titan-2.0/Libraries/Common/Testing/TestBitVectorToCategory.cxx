/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/
#include <iostream>

#include "vtkBitVectorToCategory.h"
#include "vtkStdString.h"
#include "vtkTable.h"
#include "vtkIdTypeArray.h"
#include "vtkFloatArray.h"
#include "vtkStringArray.h"
#include "vtkDoubleArray.h"

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace std;

int main(int argc, char* argv[])
{
  int retVal = 0;

  VTK_CREATE(vtkDoubleArray, ColClassSetosa);
  VTK_CREATE(vtkDoubleArray, ColClassVersicolor);
  VTK_CREATE(vtkDoubleArray, ColClassVirginica);
  VTK_CREATE(vtkDoubleArray, ColClassNarcissus);

  ColClassSetosa->SetName("setosa");
  ColClassSetosa->InsertNextValue(0.2);
  ColClassSetosa->InsertNextValue(0.7);
  ColClassSetosa->InsertNextValue(0.0);
  ColClassSetosa->InsertNextValue(0.1);
  ColClassSetosa->InsertNextValue(0.9);

  ColClassVersicolor->SetName("versicolor");
  ColClassVersicolor->InsertNextValue(0.8);
  ColClassVersicolor->InsertNextValue(0.4);
  ColClassVersicolor->InsertNextValue(0.1);
  ColClassVersicolor->InsertNextValue(0.2);
  ColClassVersicolor->InsertNextValue(0.01);

  ColClassVirginica->SetName("virginica");
  ColClassVirginica->InsertNextValue(0.4);
  ColClassVirginica->InsertNextValue(0.1);
  ColClassVirginica->InsertNextValue(0.3);
  ColClassVirginica->InsertNextValue(0.85);
  ColClassVirginica->InsertNextValue(0.2);

  ColClassNarcissus->SetName("narcissus");
  ColClassNarcissus->InsertNextValue(0.1);
  ColClassNarcissus->InsertNextValue(0.88);
  ColClassNarcissus->InsertNextValue(0.314);
  ColClassNarcissus->InsertNextValue(0.71);
  ColClassNarcissus->InsertNextValue(1.0);

  VTK_CREATE(vtkTable, ClassTable);
  ClassTable->AddColumn(ColClassSetosa);
  ClassTable->AddColumn(ColClassVersicolor);
  ClassTable->AddColumn(ColClassVirginica);
  ClassTable->AddColumn(ColClassNarcissus);

  cout << "Table:" << endl;
  ClassTable->Dump(10);

  // TEST 1 -- Just get the strings that match "Alpha" from ColString
  cout << endl << "Test 1" << endl;
  {
  VTK_CREATE(vtkBitVectorToCategory, test);
  test->SetInputData(0, ClassTable);
  test->AddBitColumn("setosa");
  test->AddBitColumn("versicolor");
  test->AddBitColumn("virginica");
  test->AddBitColumn("narcissus");
  test->Update();

  vtkTable * output = test->GetOutput();
  cout << endl << "Output" << endl;
  output->Dump();

  if(output->GetValue(0,0).ToString() != "versicolor" ||
     output->GetValue(1,0).ToString() != "narcissus" ||
     output->GetValue(2,0).ToString() != "narcissus" ||
     output->GetValue(3,0).ToString() != "virginica" ||
     output->GetValue(4,0).ToString() != "narcissus")
    {
    cerr << "FAILED Test 1 (Values): I found the table had the values: "
         << "{ " << output->GetValue(0,0).ToString() << ", "
         << output->GetValue(1,0).ToString() << ", "
         << output->GetValue(2,0).ToString() << ", "
         << output->GetValue(3,0).ToString() << ", "
         << output->GetValue(4,0).ToString() << " }"
         << "but expected: " << "{ versicolor, narcissus, narcissus, virginica, narcissus }" << endl;
    retVal = 1;
    }

  if(5 != test->GetOutput()->GetNumberOfRows())
    {
    cerr << "FAILED Test 2 (Rows): I found "
         << test->GetOutput()->GetNumberOfRows()
         << " rows but expected only 5" << endl;
    retVal = 1;
    }
  }

 return retVal;
}
