/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkMatrixVectorAdaptor vtkMatrixVectorAdaptor <vtkMatrixVectorAdaptor.h>
/// \brief vtkMatrixVectorAdaptor


#ifndef __vtkMatrixVectorAdaptor_h
#define __vtkMatrixVectorAdaptor_h

#include <iterator>
#include <vector>

#include <iostream>

#include <vtkSmartPointer.h>
#include <Common/vtkMatrixVectorIterator.h>
#include <Common/titanVectorTraits.h>

//#include <vtkDenseArray.h>

using namespace std;

/// Vector compatible container vtkDenseArrays
template<typename ArrayT, typename ElementT>
class vtkMatrixVectorAdaptor
{

public:
  typedef vtkMatrixVectorIterator<ArrayT, ElementT> iterator;
  typedef typename std::iterator_traits<iterator>::value_type  value_type;

  vtkMatrixVectorAdaptor(ArrayT* array, unsigned int vector_dimension) :
    Array(array),
    VectorDimension(vector_dimension),
    ElementDimension(1-vector_dimension),
    VectorBegin(iterator(Array, vector_dimension, 0)),
    VectorEnd(iterator(Array, vector_dimension, array->GetExtent(vector_dimension).GetSize()))

  {
    this->Vectors.clear();
    this->resize(VectorEnd - VectorBegin);

  }

  ~vtkMatrixVectorAdaptor()
  {
    this->Vectors.clear();
    this->Array = 0;
  }

  void resize(const size_t& new_size, ElementT default_value)
  {
    this->resize(new_size);

    for (size_t i = 0; i != this->size(); ++i)
    {
      for (size_t j = 0; j != (this->operator [](i)).size(); ++j)
      {
        (this->operator [](i))[j]=default_value;
      }
    }

  }

  void resize(const size_t& new_size)
  {
    if (this->size()==new_size)
      return;

    if (new_size != static_cast<size_t>(this->Array->GetExtent(VectorDimension).GetSize()))
    {
      if (this->VectorDimension == 0)
        this->Array->Resize(static_cast<vtkArrayCoordinates::CoordinateT>(new_size),
          this->Array->GetExtent(ElementDimension).GetSize());
      else
        this->Array->Resize(this->Array->GetExtent(ElementDimension).GetSize(),
            static_cast<vtkArrayCoordinates::CoordinateT>(new_size));
    }

    VectorEnd.CurrentCoordinates[this->VectorDimension] = static_cast<vtkArrayCoordinates::CoordinateT>(new_size);

    Vectors.clear();
    Vectors.resize(new_size,iterator(this->Array,this->VectorDimension,0));

    for (size_t index=0; index != new_size; ++index)
    {
      Vectors[index].CurrentCoordinates[this->VectorDimension] = static_cast<vtkArrayCoordinates::CoordinateT>(index);
    }
    return;
  }

  size_t size() const
  {
    return Vectors.size();
  }

  typename std::iterator_traits<iterator>::value_type operator[](const size_t& i) const
  {
    return *(Vectors[i]);
  }

  typename std::iterator_traits<iterator>::value_type& operator[](const size_t& i)
  {
    return *(Vectors[i]);
  }

  iterator begin() const
  {
    return VectorBegin;
  }

  iterator end() const
  {
    return VectorEnd;
  }

  ArrayT*  get_array()
  {
    return Array;
  }

  void dump() const
  {
    for (size_t i=0; i != this->size(); ++i)
    {
      for (size_t j=0; j != (*VectorBegin).size()-1; ++j)
      {
        cout << (this->operator [](i))[j] << ",";
      }
      cout << (this->operator [](i))[(*VectorBegin).size()-1] << endl;
    }
  }

private:
  ArrayT* Array;
  unsigned int VectorDimension;
  unsigned int ElementDimension;
  iterator VectorBegin;
  iterator VectorEnd;
  std::vector<iterator> Vectors;
};

#endif
