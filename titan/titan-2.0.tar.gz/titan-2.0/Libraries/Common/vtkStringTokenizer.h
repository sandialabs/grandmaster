// -*- c++ -*-
/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkTemporalRanges.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

// .NAME vtkStringTokenizer - A simple class that manages tokenizing strings.
//
// .SECTION Description
//
// vtkStringTokenizer accepts any class that behaves like the STL string
// (that is, implements the same methods and operators).
//

#ifndef __vtkStringTokenizer_h
#define __vtkStringTokenizer_h

#include <vector>

//BTX
template<class StringT>
class vtkStringTokenizer
{
public:
  /// The type of string used with this tokenizer.
  typedef StringT string_type;

  /// An iterator over the tokenized values.
  typedef typename std::vector<string_type>::const_iterator iterator;

  vtkStringTokenizer(const string_type &buffer, const string_type &delimiters) {
    this->Tokenize(buffer, delimiters);
  }

  iterator begin() { return this->Tokens.begin(); }
  iterator end() { return this->Tokens.end(); }

protected:
  std::vector<string_type> Tokens;

  void Tokenize(const string_type &buffer, const string_type &delimiters)
  {
    this->Tokens.clear();
    typename StringT::size_type tokenStart = 0;
    while ((tokenStart < buffer.size()) && (tokenStart != StringT::npos))
      {
      tokenStart = buffer.find_first_not_of(delimiters);
      if (tokenStart == StringT::npos) break;
      typename StringT::size_type tokenEnd = buffer.find_first_of(delimiters);
      this->Tokens.push_back(buffer.substr(tokenStart, tokenEnd));
      tokenStart = tokenEnd;
      }
  }

private:
  vtkStringTokenizer();  // Not implemented.
};
//ETX

#endif //__vtkStringTokenizer_h
