/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkDataSetAttributes.h"
#include "vtkSampleTableRows.h"
#include "vtkDoubleArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkStdString.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"
#include "vtkTableRowIterator.h"
#include "vtkUnsignedIntArray.h"

#include <map>
#include <vector>
#include <algorithm>


typedef vtkTableRowIterator<vtkDataArray, double> double_tablerow_iterator;
typedef vtkTableRowIterator<vtkAbstractArray, double> abstract_tablerow_iterator;

// ----------------------------------------------------------------------

#define VTK_CREATE(type, name)                                  \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkSampleTableRows);

// ----------------------------------------------------------------------

vtkSampleTableRows::vtkSampleTableRows()
{
  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(2);

  this->SetMode(vtkSampleTableRows::MODE_SAMPLE);
  this->SetAgnosticSampling(true);
  this->UnsetRandomGeneratorSeed();
  this->SetMinSelections(1);
  this->SetSamplingParameter(1);
  this->SetIgnoreClassNegatives(true);
  this->SetSampleWithReplacement(false);
  this->SetSamplingMethod(this->SAMPLE_ABSOLUTE);
}

// ----------------------------------------------------------------------

vtkSampleTableRows::~vtkSampleTableRows()
{
}

int vtkSampleTableRows::FillInputPortInformation(int port, vtkInformation* info)
{
  switch (port)
  {
  case 0:
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    return 1;
  case 1:
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
    return 1;
  }

  return 0;
}

int vtkSampleTableRows::FillOutputPortInformation(int port,
    vtkInformation* info)
{
  if (port == 0)
  {
    //port 0 contains the observation table
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
  }
  else if (port == 1)
  {
    //port 1 contains the sample indices
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
  }
  return 0;
}


void vtkSampleTableRows::SetRandomGeneratorSeed(unsigned int seed)
{
  this->RandomGeneratorSeed = seed;
  this->TableSampler.SetRandomGeneratorSeed(seed);
}

void vtkSampleTableRows::UnsetRandomGeneratorSeed()
{
  this->TableSampler.UnsetRandomGeneratorSeed();

  this->Modified();
}

void vtkSampleTableRows::AddTruthColumn(const char * column)
{
  string s(column);
  this->TruthColumns.push_back(s);
  this->Modified();
}

int vtkSampleTableRows::SetupTruthArrays(vtkTable *observation_truth_table,
    std::vector<vtkDataArray*>& observation_truth_arrays)
{
  // Feature columns
  observation_truth_arrays.clear();
  vector<string>::iterator I;
  vtkDataArray* feature_column;

  for (I = this->TruthColumns.begin(); I != this->TruthColumns.end(); ++I)
  {
    feature_column = vtkDataArray::SafeDownCast(observation_truth_table->GetColumnByName(
        (*I).c_str()));
    if (!feature_column)
    {
      vtkErrorMacro( "vtkSampleTableRows cannot find array: " << (*I).c_str());
      return 0;
    }
    observation_truth_arrays.push_back(feature_column);

  }

  return 1;
}

// ----------------------------------------------------------------------
bool vtkSampleTableRows::SampleRows(vtkTable* input, std::vector<vtkDataArray*> truth_arrays, vtkTable* input_indices_table,
    vtkTable* output_table, vtkTable* output_indices_table)
{
  double currentProgress = 0;

  vtkIdType num_cols = input->GetNumberOfColumns();

  std::vector<vtkAbstractArray*> abstract_columns;
  std::vector<vtkDataArray*> numeric_columns;

  // Extracting the columns into std vectors. One vector holds pointers to all
  // the columns, and one to just the numeric columns (for class-aware selection).
  vtkAbstractArray * col;
  vtkDataArray * data_col;
  for (vtkIdType input_col_index = 0;
      input_col_index != input->GetNumberOfColumns(); ++input_col_index)
      {
    col = input->GetColumn(input_col_index);
    data_col = vtkDataArray::SafeDownCast(col);

    abstract_columns.push_back(col);

    if (data_col)
      numeric_columns.push_back(data_col);
  }

  // Using the std vectors to create table row iterators
  abstract_tablerow_iterator abstract_rows_begin = abstract_tablerow_iterator(
      abstract_columns.begin(), abstract_columns.end(), 0);
  abstract_tablerow_iterator abstract_rows_end = abstract_tablerow_iterator(
      abstract_columns.begin(), abstract_columns.end(),
      input->GetNumberOfRows());

  double_tablerow_iterator  class_rows_begin(truth_arrays.begin(), truth_arrays.end(), 0);
  double_tablerow_iterator  class_rows_end(truth_arrays.begin(), truth_arrays.end(), input->GetNumberOfRows());

  std::vector<size_t> * random_row_indices;

  if (!input_indices_table)
  {
    this->TableSampler.SetMode(this->GetMode());
    this->TableSampler.SetMinSelections(this->GetMinSelections());
    this->TableSampler.SetSamplingParameter(this->GetSamplingParameter());
    this->TableSampler.SetIgnoreClassNegatives(this->GetIgnoreClassNegatives());
    this->TableSampler.SetSampleWithReplacement(
        this->GetSampleWithReplacement());
    this->TableSampler.SetSamplingMethod(this->GetSamplingMethod());

    if (this->GetMode() == vtkSampleTableRows::MODE_PROJECT)
      random_row_indices = this->TableSampler.Project(abstract_rows_begin,
          abstract_rows_end);
    else if (this->GetMode() == vtkSampleTableRows::MODE_PROJECT_DIFF)
      random_row_indices = this->TableSampler.ProjectDiff(abstract_rows_begin,
          abstract_rows_end);
    else if (this->GetAgnosticSampling())
      random_row_indices = this->TableSampler.SampleAgnostic(
          abstract_rows_begin, abstract_rows_end);
    else
      random_row_indices = this->TableSampler.SampleAware(class_rows_begin,
          class_rows_end);
  }
  else
  {
    random_row_indices = new std::vector<size_t>();
    random_row_indices->resize(input_indices_table->GetNumberOfRows());

    vtkUnsignedIntArray* col = vtkUnsignedIntArray::SafeDownCast(input_indices_table->GetColumnByName("indices"));

    for (vtkIdType i = 0; i != col->GetNumberOfTuples(); ++i)
    {
      random_row_indices->operator [](static_cast<size_t>(i)) = col->GetValue(i);
    }
  }


  if (!random_row_indices)
    return false;


    // Set up output table
  for (int n = 0; n < input->GetNumberOfColumns(); n++)
  {
    vtkAbstractArray* col = input->GetColumn(n);
    vtkAbstractArray* ncol = vtkAbstractArray::CreateArray(col->GetDataType());
    ncol->SetName(col->GetName());
    ncol->SetNumberOfComponents(col->GetNumberOfComponents());
    output_table->AddColumn(ncol);

    if (input->GetRowData()->GetPedigreeIds() == col)
      output_table->GetRowData()->SetPedigreeIds(ncol);

    ncol->Delete();
  }

  VTK_CREATE(vtkUnsignedIntArray,indices_array);
  indices_array->SetName("indices");
//  indices_array->SetNumberOfComponents(1);
  output_indices_table->AddColumn(indices_array);


  output_table->SetNumberOfRows(random_row_indices->size());
  output_indices_table->SetNumberOfRows(random_row_indices->size());

  vtkIdType random_row_index;

  for (vtkIdType row_index = 0; static_cast<size_t>(row_index) != random_row_indices->size();
      ++row_index)
      {
    random_row_index = (*random_row_indices)[static_cast<size_t>(row_index)];

    for (vtkIdType col_index = 0; col_index != num_cols; ++col_index)
    {
      output_table->GetColumn(col_index)->SetVariantValue(row_index,
          input->GetColumn(col_index)->GetVariantValue(random_row_index));
    }
    indices_array->SetValue(row_index,random_row_index);

    // Emit a progress event
    double progress = (double) row_index / random_row_indices->size();
    if ((int) (progress * 100) != (int) (currentProgress * 100))
    {
      currentProgress = progress;
      this->InvokeEvent(vtkCommand::ProgressEvent, &currentProgress);
    }
  }

  currentProgress = 1;
  this->InvokeEvent(vtkCommand::ProgressEvent, &currentProgress);

  return true;
}

// ----------------------------------------------------------------------

int vtkSampleTableRows::RequestData(vtkInformation*,
    vtkInformationVector** inputVector, vtkInformationVector* outputVector)
{

  vtkTable* input_table = vtkTable::GetData(inputVector[0]);
  vtkTable* input_indices_table = vtkTable::GetData(inputVector[1]);

  vtkTable* output_table = vtkTable::GetData(outputVector,0);
  vtkTable* output_indices_table = vtkTable::GetData(outputVector,1);

  std::vector<vtkDataArray*> truth_arrays;

  // Ensure that we have truth columns (i.e., TruthColumns.size() != 0)
  //
  if (this->Mode == this->MODE_SAMPLE)
  {
    // If no columns have been specified, add all the columns in the
    // truth table.
    if (this->TruthColumns.size() == 0)
    {
      for (vtkIdType i = 0; i
          != input_table->GetNumberOfColumns(); ++i)
      {
        vtkDataArray* column = vtkDataArray::SafeDownCast(
            input_table->GetColumn(i));
        if (column)
        {
          std::stringstream ss;
          ss.str("");
          ss << column->GetName();
          this->TruthColumns.push_back(ss.str());
        }
      }
    }
    else
    {
      vector<string>::iterator I;
      for (I = this->TruthColumns.begin(); I != this->TruthColumns.end(); ++I)
      {
        vtkDataArray* column = vtkDataArray::SafeDownCast(
            input_table->GetColumnByName((*I).c_str()));
        if (!column)
        {
          vtkErrorMacro( "Cannot find truth array: " << (*I).c_str());
          return 0;
        }
      }
    }

    if (!this->SetupTruthArrays(input_table, truth_arrays))
    {
      vtkErrorMacro("The input truth table does not have the required columns,\
                     see vtkMultiLayerPerceptron.h for description of input");
      return 0;
    }

  }

  if (input_indices_table)
  {
    if (!input_indices_table->GetColumnByName("indices"))
    {
      vtkErrorMacro("The indices table does not contain a column named 'indices'. Aborting.");
      return 0;
    }
  }

  if (this->SampleRows(input_table, truth_arrays, input_indices_table, output_table, output_indices_table))
    return 1;

  return 0;
}

// ----------------------------------------------------------------------

void vtkSampleTableRows::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
