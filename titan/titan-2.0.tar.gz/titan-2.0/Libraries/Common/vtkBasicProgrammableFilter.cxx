/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkBasicProgrammableFilter.h"

#include <vtkDataObject.h>
#include <vtkDemandDrivenPipeline.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkObjectFactory.h>
#include <vtkStdString.h>

#include <map>

vtkStandardNewMacro(vtkBasicProgrammableFilter);

class vtkBasicProgrammableFilter::Implementation
{
public:
  std::map<int, vtkStdString> Inputs;
  std::map<int, vtkStdString> Outputs;
  std::tr1::function<void()> Callback;
  void* CallbackArgument;
  std::tr1::function<void(void*)> DeleteCallbackArgument;
};

vtkBasicProgrammableFilter::vtkBasicProgrammableFilter() :
  Internal(new Implementation())
{
  Superclass::SetNumberOfInputPorts(1);
  Superclass::SetNumberOfOutputPorts(1);

  this->Internal->Inputs[0] = "vtkDataObject";

  this->Internal->CallbackArgument = 0;
}

vtkBasicProgrammableFilter::~vtkBasicProgrammableFilter()
{
  if(this->Internal->CallbackArgument && this->Internal->DeleteCallbackArgument)
    this->Internal->DeleteCallbackArgument(this->Internal->CallbackArgument);

  delete this->Internal;
}

void vtkBasicProgrammableFilter::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

void vtkBasicProgrammableFilter::SetNumberOfInputPorts(int n)
{
  Superclass::SetNumberOfInputPorts(n);
}

void vtkBasicProgrammableFilter::SetNumberOfOutputPorts(int n)
{
  Superclass::SetNumberOfOutputPorts(n);
}

void vtkBasicProgrammableFilter::SetInputDataType(int port, const vtkStdString& type)
{
  this->Internal->Inputs[port] = type;
  this->Modified();
}

void vtkBasicProgrammableFilter::SetOutputDataType(int port, const vtkStdString& type)
{
  this->Internal->Outputs[port] = type;
  this->Modified();
}

void vtkBasicProgrammableFilter::SetCallback(const std::tr1::function<void()>& callback)
{
  if(this->Internal->CallbackArgument && this->Internal->DeleteCallbackArgument)
    this->Internal->DeleteCallbackArgument(this->Internal->CallbackArgument);
  this->Internal->CallbackArgument = 0;

  this->Internal->Callback = callback;
  this->Modified();
}

void vtkBasicProgrammableFilter::SetCallback(void(*f)(void*), void* argument)
{
  if(this->Internal->CallbackArgument && this->Internal->DeleteCallbackArgument)
    this->Internal->DeleteCallbackArgument(this->Internal->CallbackArgument);
  this->Internal->CallbackArgument = argument;

  this->Internal->Callback = std::tr1::bind(f, argument);
  this->Modified();
}

void vtkBasicProgrammableFilter::SetCallbackArgDelete(void(*f)(void*))
{
  this->Internal->DeleteCallbackArgument = f;
  this->Modified();
}

int vtkBasicProgrammableFilter::FillInputPortInformation(int port, vtkInformation* info)
{
  if(!this->Internal->Inputs.count(port))
    {
    vtkErrorMacro(<< "Data type for input port " << port << " unspecified.");
    return 0;
    }

  info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), this->Internal->Inputs[port]);

  return 1;
}

int vtkBasicProgrammableFilter::FillOutputPortInformation(int port, vtkInformation* info)
{
  if(!this->Internal->Outputs.count(port))
    {
    vtkErrorMacro(<< "Data type for output port " << port << " unspecified.");
    return 0;
    }

  info->Set(vtkDataObject::DATA_TYPE_NAME(), this->Internal->Outputs[port]);

  return 1;
}

int vtkBasicProgrammableFilter::ProcessRequest(
  vtkInformation* request,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  if(request->Has(vtkDemandDrivenPipeline::REQUEST_DATA()))
    {
    if(!this->Internal->Callback)
      {
      vtkErrorMacro(<< "Empty callback.");
      return 0;
      }

    this->Internal->Callback();
    return 1;
    }

  return this->Superclass::ProcessRequest(request, inputVector, outputVector);
}
