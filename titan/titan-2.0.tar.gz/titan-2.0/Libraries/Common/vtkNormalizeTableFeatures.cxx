/*=========================================================================

 Program:   Visualization Toolkit
 Module:    $RCSfile: vtkNormalizeTableFeatures.cxx,v $

 Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
 All rights reserved.
 See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

 This software is distributed WITHOUT ANY WARRANTY; without even
 the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 PURPOSE.  See the above copyright notice for more information.

 =========================================================================*/
/*-------------------------------------------------------------------------
 Copyright 2008 Sandia Corporation.
 Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
 the U.S. Government retains certain rights in this software.
 -------------------------------------------------------------------------*/
#include <vtkNormalizeTableFeatures.h>

//#include <vtkArrayConversions.h>
#include <vtkArrayData.h>
#include <vtkCommand.h>
#include <vtkDenseArray.h>
#include <vtkIdTypeArray.h>
#include <vtkDataArray.h>
#include <vtkDoubleArray.h>
#include <vtkStringArray.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkObjectFactory.h>
#include <vtkTable.h>
#include <vtkUnsignedIntArray.h>

#include <vtksys/ios/sstream>

#include <vtkSmartPointer.h>

#include <Common/titanVectorTraits.h>

/* Iterators/Vector Operators */
#include <vtkTableRowIterator.h>

//#include <titanVectorOperations.h>
#include <titanNormalizeVectors.h>

typedef vtkTableRowIterator<vtkDataArray, double> double_tablerow_iterator;

#define VTK_CREATE(type, name)                                  \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

vtkStandardNewMacro(vtkNormalizeTableFeatures);

vtkNormalizeTableFeatures::vtkNormalizeTableFeatures()
{
  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(2);
  this->SetObservationDimension(0);

  this->SetNormalizedMaxValue(1);
  this->SetNormalizedMinValue(0);

  this->SetObservationDimension(0);
  this->SetGenerateGlobalNorm(false);

  this->SetGlobalMinMax(0, 0);

  this->NormalizationModelGenerated = false;

  this->Modified();
}

vtkNormalizeTableFeatures::~vtkNormalizeTableFeatures()
{
}

void vtkNormalizeTableFeatures::SetGlobalMinMax(double min, double max)
{
  this->GlobalMin = min;
  this->GlobalMax = max;
}

int vtkNormalizeTableFeatures::FillInputPortInformation(int port,
    vtkInformation* info)
{

  if (port == 0)
  {
    // port 0 is a table of observations
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    return 1;
  }
  if (port == 1)
  {
    // port 1 is an optional table of normalization parameters
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
    return 1;
  }
  return 0;
}

int vtkNormalizeTableFeatures::FillOutputPortInformation(int port,
    vtkInformation* info)
{
  if (port == 0)
  {
    //port 0 contains the observation table with normalized values appended.
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
  }
  if (port == 1)
  {
    //port 1 contains the parameter table with the normalized feature names, min values, and max values.
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
  }
  return 0;
}

void vtkNormalizeTableFeatures::AddFeatureColumn(const char * column)
{
  string s(column);
  this->FeatureColumns.push_back(s);
  this->Modified();
}

int vtkNormalizeTableFeatures::RequestData(vtkInformation *vtkNotUsed(request),
    vtkInformationVector **inputVector, vtkInformationVector *outputVector)
{
  /* Process input vectors */

  // input data table
  vtkTable* const input_data_table = vtkTable::GetData(inputVector[0]);
  if (!input_data_table)
  {
    vtkErrorMacro("Missing input table.");
    return 0;
  }

  if ((input_data_table->GetNumberOfRows() == 0)
      || (input_data_table->GetNumberOfColumns() == 0))
  {
    vtkErrorMacro("Table exists, but is empty.");
    return 0;
  }

  vtkTable* const input_parameter_table = vtkTable::GetData(inputVector[1]);

  // output_data_table
  vtkTable* const output_data_table = vtkTable::GetData(outputVector, 0);
  output_data_table->ShallowCopy(input_data_table);

  vtkTable* const output_parameter_table = vtkTable::GetData(outputVector, 1);

  std::vector<char *> original_feature_names;

  VTK_CREATE(vtkTable, observation_table);

  this->FeatureArrays.clear();
  if (this->FeatureColumns.size() == 0)
  {
    for (vtkIdType i = 0; i != input_data_table->GetNumberOfColumns(); ++i)
    {
      vtkDataArray* column = vtkDataArray::SafeDownCast(
          input_data_table->GetColumn(i));
      if (column)
      {
        VTK_CREATE(vtkDoubleArray, new_column);

        std::stringstream ss;
        ss.str("");
        ss << column->GetName();
        ss << "_normF";

        new_column->SetName(ss.str().c_str());
        new_column->SetNumberOfTuples(column->GetNumberOfTuples());

        for (vtkIdType row = 0; row != column->GetNumberOfTuples(); ++row)
        {
          new_column->SetValue(row, column->GetVariantValue(row).ToDouble());
        }
        observation_table->AddColumn(new_column);
        this->FeatureArrays.push_back(new_column);
        original_feature_names.push_back(column->GetName());
      }
    }
  }
  else
  {
    vector<string>::iterator I;
    for (I = this->FeatureColumns.begin(); I != this->FeatureColumns.end(); ++I)
    {
      vtkDataArray* column = vtkDataArray::SafeDownCast(
          input_data_table->GetColumnByName((*I).c_str()));
      if (!column)
      {
        vtkErrorMacro( "Cannot find array: " << (*I).c_str());
        return 0;
      }

      VTK_CREATE(vtkDoubleArray, new_column);

      std::stringstream ss;
      ss.str("");
      ss << column->GetName();
      ss << "_normF";

      new_column->SetName(ss.str().c_str());
      new_column->SetNumberOfTuples(column->GetNumberOfTuples());

      for (vtkIdType row = 0; row != column->GetNumberOfTuples(); ++row)
      {
        new_column->SetValue(row, column->GetVariantValue(row).ToDouble());
      }
      observation_table->AddColumn(new_column);
      this->FeatureArrays.push_back(new_column);
      original_feature_names.push_back(column->GetName());
    }
  }

  double progress = 0.0;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  // Setup observations
  double_tablerow_iterator observation_begin = double_tablerow_iterator(
      this->FeatureArrays.begin(), this->FeatureArrays.end(), 0);

  double_tablerow_iterator observation_end = double_tablerow_iterator(
      this->FeatureArrays.begin(), this->FeatureArrays.end(),
      input_data_table->GetNumberOfRows());

  /* Normalize */
  if (this->NormalizationModelGenerated == false)
  {
    this->Normalizer.SetNormalizedMinMax(this->NormalizedMinValue,
        this->NormalizedMaxValue);

    if (input_parameter_table)
    {
      size_t num_parameter_columns =
          static_cast<size_t>(input_parameter_table->GetNumberOfColumns());

      size_t num_parameters = static_cast<size_t>(input_parameter_table->GetNumberOfRows());

      if ( (num_parameter_columns != 0) && (num_parameters == this->FeatureArrays.size()) )
      {

        std::vector<double> * max_values = this->Normalizer.GetMaxValues();
        std::vector<double> * min_values = this->Normalizer.GetMinValues();
        std::vector<double> * ranges = this->Normalizer.GetRanges();

        max_values->resize(num_parameters);
        min_values->resize(num_parameters);
        ranges->resize(num_parameters);

        for (size_t feature_array_index=0; feature_array_index != this->FeatureArrays.size(); ++feature_array_index)
        {
          char * col_name = this->FeatureArrays[feature_array_index]->GetName();

          size_t norm_feature_index;
          for (norm_feature_index = 0; norm_feature_index != num_parameters; ++norm_feature_index)
          {
            if (!input_parameter_table->GetValueByName(norm_feature_index,"feature_normF").ToString().compare(col_name))
            {
              break;
            }
          }
          if (norm_feature_index == num_parameters)
          {
            return 0;
          }

          // Else we have found the current featureArray name in the table
          (*max_values)[feature_array_index] = input_parameter_table->GetValueByName(norm_feature_index,"max").ToDouble();
          (*min_values)[feature_array_index] = input_parameter_table->GetValueByName(norm_feature_index,"min").ToDouble();
          (*ranges)[feature_array_index] = (*max_values)[feature_array_index] - (*min_values)[feature_array_index];

        }

      }
      this->NormalizationModelGenerated=true;
    }
    else
    {
      this->Normalizer.GenerateModel(observation_begin,observation_end,this->GenerateGlobalNorm);
      this->NormalizationModelGenerated=true;
      if (this->GlobalMin < this->GlobalMax)
      this->Normalizer.SetGlobalMinMax(this->GlobalMin,this->GlobalMax);
    }
  }

  this->Normalizer(observation_begin, observation_end);

  for (vtkIdType i = 0; i != observation_table->GetNumberOfColumns(); ++i)
  {
    output_data_table->AddColumn(observation_table->GetColumn(i));
  }

  if (!input_parameter_table)
  {
    VTK_CREATE(vtkStringArray, original_feature_name_array);
    original_feature_name_array->SetName("feature");

    VTK_CREATE(vtkStringArray, normalized_feature_name_array);
    normalized_feature_name_array->SetName("feature_normF");

    VTK_CREATE(vtkDoubleArray, min_array);
    min_array->SetName("min");

    VTK_CREATE(vtkDoubleArray, max_array);
    max_array->SetName("max");

    output_parameter_table->AddColumn(original_feature_name_array);
    output_parameter_table->AddColumn(normalized_feature_name_array);
    output_parameter_table->AddColumn(min_array);
    output_parameter_table->AddColumn(max_array);

    output_parameter_table->SetNumberOfRows(this->FeatureArrays.size());
    std::vector<double> * min_values = this->Normalizer.GetMinValues();
    std::vector<double> * max_values = this->Normalizer.GetMaxValues();

    for (vtkIdType i = 0; static_cast<size_t>(i) != this->FeatureArrays.size();
        ++i)
        {
      char* column_name = this->FeatureArrays[i]->GetName();

      original_feature_name_array->SetValue(i, original_feature_names[i]);
      normalized_feature_name_array->SetValue(i, column_name);
      min_array->SetValue(i, min_values->operator [](i));
      max_array->SetValue(i, max_values->operator [](i));
    }
  }
  else
  {
    output_parameter_table->ShallowCopy(input_parameter_table);
  }

  progress = 1.0;
  this->InvokeEvent(vtkCommand::ProgressEvent, &progress);

  return 1;
}

void vtkNormalizeTableFeatures::Reset()
{
  this->NormalizationModelGenerated = false;
}

void vtkNormalizeTableFeatures::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
