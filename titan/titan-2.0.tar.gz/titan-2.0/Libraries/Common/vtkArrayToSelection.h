/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
// .NAME vtkArrayToSelection - Converts an array to an index selection
// selection.
//
// .SECTION Description
// Converts a vtkIdTypeArray into an index selection containing the set of
// unique array values.  Specify the array to be converted using
// SetInputArrayToProcess().
//
// TODO: Handle a wider range of input array types and output selection types.

#ifndef __vtkArrayToSelection_h
#define __vtkArrayToSelection_h

#include "titanCommon.h"
#include "vtkSelectionAlgorithm.h"

class TITAN_COMMON_EXPORT vtkArrayToSelection : public vtkSelectionAlgorithm
{
public:
  static vtkArrayToSelection* New();
  vtkTypeMacro(vtkArrayToSelection, vtkSelectionAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  /// Control the field-type of the output vtkSelection.
  /// See vtkSelection::SelectionField for allowable values.
  vtkGetMacro(FieldType, int);
  vtkSetMacro(FieldType, int);

protected:
  vtkArrayToSelection();
  ~vtkArrayToSelection();

  virtual int FillInputPortInformation(int port, vtkInformation* info);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

  int FieldType;

private:
  vtkArrayToSelection(const vtkArrayToSelection&); // Not implemented
  void operator=(const vtkArrayToSelection&);   // Not implemented
};

#endif
