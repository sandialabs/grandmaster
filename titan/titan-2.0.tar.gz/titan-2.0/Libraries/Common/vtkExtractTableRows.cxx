/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkDataSetAttributes.h"
#include "vtkExtractTableRows.h"
#include "vtkIdTypeArray.h"
#include "vtkIndent.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkStdString.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"

#include <vector>
#include <algorithm>

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

// #define DEBUG 0



vtkStandardNewMacro(vtkExtractTableRows);



//----------------------------------------------------------------------------
vtkExtractTableRows::vtkExtractTableRows()
{
  this->ConditionTable = vtkTable::New();

  VTK_CREATE(vtkStringArray, ColNames);
  VTK_CREATE(vtkVariantArray, ColValues);
  ColNames->SetName("ColNames");
  ColValues->SetName("ColValues");
  this->ConditionTable->AddColumn(ColNames);
  this->ConditionTable->AddColumn(ColValues);
}



//----------------------------------------------------------------------------
vtkExtractTableRows::~vtkExtractTableRows()
{
  this->ConditionTable->Delete();
}



//----------------------------------------------------------------------------
void vtkExtractTableRows::AddMatch(const char *ColumnName, const char *Value)
{
  vtkIdType rowID = -1;
  VTK_CREATE(vtkVariantArray, newRow);

  newRow->InsertNextValue( vtkVariant(ColumnName) );
  newRow->InsertNextValue( vtkVariant(Value) );

  rowID = this->ConditionTable->InsertNextRow( newRow );

  #if defined(DEBUG)
  cout << "+ AddMatch inserted (" << this->ConditionTable->GetValue(rowID, 0).ToString()
       << "," << this->ConditionTable->GetValue(rowID, 1).ToString()
       << ") into position " << rowID << " of ConditionTable." << endl;
  #endif
  this->Modified();
}


//----------------------------------------------------------------------------
void vtkExtractTableRows::ClearMatches()
{
  this->ConditionTable->Initialize();

  VTK_CREATE(vtkStringArray, ColNames);
  VTK_CREATE(vtkVariantArray, ColValues);
  ColNames->SetName("ColNames");
  ColValues->SetName("ColValues");
  this->ConditionTable->AddColumn(ColNames);
  this->ConditionTable->AddColumn(ColValues);

  this->Modified();
}

//----------------------------------------------------------------------------
int vtkExtractTableRows::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // Get input table
  vtkInformation* inputInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* input = vtkTable::SafeDownCast(
    inputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get output tables
  vtkInformation* outputInfo = outputVector->GetInformationObject(0);
  vtkTable* output = vtkTable::SafeDownCast(
    outputInfo->Get(vtkDataObject::DATA_OBJECT()));

  if(this->ConditionTable->GetNumberOfRows() == 0)
    {
    output->ShallowCopy(input);
    return 1;
    }

  // This will copy only the meta data and not the row data
  output->vtkDataObject::ShallowCopy(input);

  // Need to create empty columns in output to match the columns from the input
  for (int n = 0; n < input->GetNumberOfColumns(); n++)
    {
    vtkAbstractArray* col = input->GetColumn(n);
    vtkAbstractArray* ncol = vtkAbstractArray::CreateArray(col->GetDataType());
    ncol->SetName(col->GetName());
    ncol->SetNumberOfComponents(col->GetNumberOfComponents());
    output->AddColumn(ncol);
    if(input->GetRowData()->GetPedigreeIds() == col)
      {
      output->GetRowData()->SetPedigreeIds(ncol);
      }
    ncol->Delete();
    }

  vtkAbstractArray ** inputColPtrs = NULL;
  inputColPtrs = (vtkAbstractArray**)malloc(sizeof(vtkAbstractArray*)*ConditionTable->GetNumberOfRows());

  double totalWork = input->GetNumberOfRows()+ConditionTable->GetNumberOfRows();

  // Sanity check: Make sure the tables actually *have* the columns we're looking
  // for or this won't be terribly exciting.  We also yoink the pointer to the proper
  // column in the input so we don't search it every time.
  for(vtkIdType i=0; i<ConditionTable->GetNumberOfRows(); i++)
    {
    vtkStdString colName = ConditionTable->GetValue(i, 0).ToString();
    inputColPtrs[i] = input->GetColumnByName(colName);
    if(!inputColPtrs[i])
      {
      vtkErrorMacro(<< "Could not find column '" << colName.c_str() << "' in input table");
      }
    double progress = i / totalWork;
    this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
    }

  // Iterate over data set and copy rows that match.
  for(vtkIdType inputRow=0; inputRow<input->GetNumberOfRows(); inputRow++)
    {
    bool matched = false;
    for(vtkIdType ctRow=0; !matched && ctRow<ConditionTable->GetNumberOfRows(); ctRow++)
      {
      if(inputColPtrs[ctRow] &&
         ConditionTable->GetValue(ctRow,1) == inputColPtrs[ctRow]->GetVariantValue(inputRow))
        {
        #if defined(DEBUG)
        cout << "match found on row " << inputRow << endl;
        #endif
        output->InsertNextRow( input->GetRow( inputRow ) );
        matched = true;
        }
      }
      // EMIT A PROGRESS EVENT
      double progress = (inputRow+ConditionTable->GetNumberOfRows()) / totalWork;
      this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
    }

  free( inputColPtrs );
  return 1;
}



//----------------------------------------------------------------------------
void vtkExtractTableRows::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  for(vtkIdType i=0; i<this->ConditionTable->GetNumberOfRows(); i++)
    {
    cout << indent << i << ":   "
         << "   ColumnName: '" << this->ConditionTable->GetValue(i,0).ToString()
         << "'   Value: " << this->ConditionTable->GetValue(i,1).ToString()
         << endl;
    }
}
