/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkCategoryToBitVector.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkCategoryToBitVector vtkCategoryToBitVector.h <Common/vtkCategoryToBitVector.h>
/// \brief Extracts a set of rows from a table based on matching.
///
/// Given a table and a set of ColumnName,Value pairs
/// return a table containing only rows that contain a value match in its
/// specified column.
///

#ifndef __vtkCategoryToBitVector_h
#define __vtkCategoryToBitVector_h

#include "titanCommon.h"
#include <vtkTableAlgorithm.h>

#include <string>
#include <vector>
#include <map>

#include <vtkStdString.h>

class vtkTable;

class TITAN_COMMON_EXPORT vtkCategoryToBitVector : public vtkTableAlgorithm
{
public:
  static vtkCategoryToBitVector* New();
  vtkTypeMacro(vtkCategoryToBitVector, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  int FillInputPortInformation(int port, vtkInformation* info);
  int FillOutputPortInformation( int port, vtkInformation* info );


  vtkGetStringMacro(CategoryColumn);
  vtkSetStringMacro(CategoryColumn);

  ///@{
  /// Add columns to turn to BitVectors
  void AddCategoryColumn(const char* column);
  void AddCategoryColumn(const char* column, const char* category_values);
  ///@}

  vtkSetStringMacro(CategoryLabelDelimiter);
  vtkGetStringMacro(CategoryLabelDelimiter);

  vtkGetMacro(UsePrefix, bool);
  vtkSetMacro(UsePrefix, bool);

protected:
  vtkCategoryToBitVector();
  ~vtkCategoryToBitVector();

  int RequestData(vtkInformation*, vtkInformationVector**, vtkInformationVector*);

private:
  vtkCategoryToBitVector(const vtkCategoryToBitVector&); // Not implemented
  void operator=(const vtkCategoryToBitVector&);   // Not implemented

//BTX
  std::vector<vtkStdString> CategoryColumns;
  char* CategoryColumn;
  std::map<vtkStdString, vtkStdString> CategoryColumValueMap;
  char* CategoryLabelDelimiter;
  bool UsePrefix; // Whether to prefix the bitvector array names with the category name
//ETX
};

#endif
