/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkAssignPedigreeIds.h"

#include "vtkAbstractArray.h"
#include "vtkAnnotation.h"
#include "vtkAnnotationLayers.h"
#include "vtkCellData.h"
#include "vtkDataSet.h"
#include "vtkDataSetAttributes.h"
#include "vtkDoubleArray.h"
#include "vtkConvertSelection.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkDataSet.h"
#include "vtkScalarsToColors.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnsignedCharArray.h"


vtkStandardNewMacro(vtkAssignPedigreeIds);

vtkAssignPedigreeIds::vtkAssignPedigreeIds()
{
  this->ArrayName = 0;
  this->FieldType = vtkAssignPedigreeIds::ROW_DATA;
}

vtkAssignPedigreeIds::~vtkAssignPedigreeIds()
{
  this->SetArrayName(0);
}

int vtkAssignPedigreeIds::RequestData(
  vtkInformation *vtkNotUsed(request),
  vtkInformationVector **inputVector,
  vtkInformationVector *outputVector)
{
  // get the info objects
  vtkInformation* inInfo = inputVector[0]->GetInformationObject(0);
  vtkInformation* outInfo = outputVector->GetInformationObject(0);

  // get the input and ouptut
  vtkDataObject* input = inInfo->Get(vtkDataObject::DATA_OBJECT());
  vtkDataObject* output = outInfo->Get(vtkDataObject::DATA_OBJECT());

  if (!this->ArrayName)
    {
    vtkErrorMacro(<<"Array name not specified");
    return 1;
    }

  vtkDataSetAttributes* ods=0;
  if (vtkDataSet::SafeDownCast(input))
    {
    vtkDataSet *dsInput = vtkDataSet::SafeDownCast(input);
    vtkDataSet *dsOutput = vtkDataSet::SafeDownCast(output);
    // This has to be here because it initialized all field datas.
    dsOutput->CopyStructure( dsInput );

    if ( dsOutput->GetFieldData() && dsInput->GetFieldData() )
      {
      dsOutput->GetFieldData()->PassData( dsInput->GetFieldData() );
      }
    dsOutput->GetPointData()->PassData( dsInput->GetPointData() );
    dsOutput->GetCellData()->PassData( dsInput->GetCellData() );
    switch (this->FieldType)
      {
      case vtkAssignPedigreeIds::POINT_DATA:
        ods = dsOutput->GetPointData();
        break;
      case vtkAssignPedigreeIds::CELL_DATA:
        ods = dsOutput->GetCellData();
        break;
      default:
        vtkErrorMacro(<<"Data must be point or cell for vtkDataSet");
        return 0;
      }
    }
  else if (vtkGraph::SafeDownCast(input))
    {
    vtkGraph *graphInput = vtkGraph::SafeDownCast(input);
    vtkGraph *graphOutput = vtkGraph::SafeDownCast(output);
    graphOutput->ShallowCopy( graphInput );
    switch (this->FieldType)
      {
      case vtkAssignPedigreeIds::VERTEX_DATA:
        ods = graphOutput->GetVertexData();
        break;
      case vtkAssignPedigreeIds::EDGE_DATA:
        ods = graphOutput->GetEdgeData();
        break;
      default:
        vtkErrorMacro(<<"Data must be vertex or edge for vtkGraph");
        return 0;
      }
    }
  else if (vtkTable::SafeDownCast(input))
    {
    vtkTable *tableInput = vtkTable::SafeDownCast(input);
    vtkTable *tableOutput = vtkTable::SafeDownCast(output);
    tableOutput->ShallowCopy( tableInput );
    switch (this->FieldType)
      {
      case vtkAssignPedigreeIds::ROW_DATA:
        ods = tableOutput->GetRowData();
        break;
      default:
        vtkErrorMacro(<<"Data must be row for vtkTable");
        return 0;
      }
    }

  if(!ods)
    {
    vtkErrorMacro(<<"Invalid field data.");
    }

  vtkAbstractArray* ary = ods->GetAbstractArray(this->ArrayName);
  if(!ary)
    {
    vtkErrorMacro(<<"Could not find array name provided in field data.");
    }

  ods->SetPedigreeIds(ary);

  return 1;
}

int vtkAssignPedigreeIds::FillInputPortInformation(int vtkNotUsed(port), vtkInformation* info)
{
  // This algorithm may accept a vtkPointSet or vtkGraph.
  info->Remove(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE());
  info->Append(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkDataSet");
  info->Append(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
  info->Append(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
  return 1;
}

void vtkAssignPedigreeIds::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
