/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkRandomizeTableRows.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkRandomizeTableRows vtkRandomizeTableRows.h <Common/vtkRandomizeTableRows.h>
/// \brief This filter randomizes the rows of a table, selecting without
/// replacement, creating a separate table with entries from the input ordered
/// randomly.
///
/// If a random seed is not set, the filter uses milliseconds from the local
/// time as provided by boost::posix_time::ptime.

#ifndef __vtkRandomizeTableRows_h
#define __vtkRandomizeTableRows_h

#include "titanCommon.h"
#include <vtkTableAlgorithm.h>

#include <boost/random.hpp>

class vtkAbstractArray;
class vtkTable;

class TITAN_COMMON_EXPORT vtkRandomizeTableRows : public vtkTableAlgorithm
{
public:
  static vtkRandomizeTableRows* New();
  vtkTypeMacro(vtkRandomizeTableRows, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  void SetRandomGeneratorSeed(const unsigned int seed);
  void UnsetRandomGeneratorSeed();

  ///@{
  /// Sets the Proximity from the enumerated ProximityType. Some of these
  /// proximities (such as ProximityKL) will require a numeric parameter, set
  /// with SetProximityNumericParameter1().
  vtkSetMacro(UsePreviousRowMap,bool);
  ///@}
  vtkGetMacro(UsePreviousRowMap,bool);


protected:
  vtkRandomizeTableRows();
  ~vtkRandomizeTableRows();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkRandomizeTableRows(const vtkRandomizeTableRows&); // Not implemented
  void operator=(const vtkRandomizeTableRows&);   // Not implemented

  void RandomizeRows(vtkTable* input, vtkTable* output);

  std::vector<vtkIdType> RandomRowIndices;

  bool UsePreviousRowMap;

  boost::mt19937 RandomGenerator;

};

#endif
