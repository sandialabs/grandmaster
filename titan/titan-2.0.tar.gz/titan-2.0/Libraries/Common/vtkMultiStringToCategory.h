/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkMultiStringToCategory.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkMultiStringToCategory vtkMultiStringToCategory.h <Common/vtkMultiStringToCategory.h>
/// \brief vtkMultiStringToCategory converts one or more string arrays into integer arrays
/// by assigning numbers to each unique string value in the array. The original columns will
/// remain and the new integer columns will have the string "_category" appended to the name.
/// The output table also contains the mapping from integer back to the represented string in
/// the form of a collection of string arrays. These arrays (which may be of varying length for
/// each input array) are retrieved by calling GetFieldData() on the output table. The names of
/// the mapping arrays match the original input array names.
///
/// \sa vtkStringToCategory
///

#ifndef __vtkMultiStringToCategory_h
#define __vtkMultiStringToCategory_h

#include "titanCommon.h"
#include "vtkTableAlgorithm.h"
#include "vtkStdString.h"

class vtkMultiStringToCategoryInternal;

class TITAN_COMMON_EXPORT vtkMultiStringToCategory : public vtkTableAlgorithm
{
public:
  static vtkMultiStringToCategory *New();
  vtkTypeMacro(vtkMultiStringToCategory, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  /// Adds an array name to process by this filter.
  void AddInputArray(const vtkStdString& s);

  /// Clears the input arrays to process.
  void ResetInputArrays();

protected:
  vtkMultiStringToCategory();
  ~vtkMultiStringToCategory();

  int RequestData(
    vtkInformation *vtkNotUsed(request),
    vtkInformationVector **inputVector,
    vtkInformationVector *outputVector);

  vtkMultiStringToCategoryInternal* Internal;

private:
  vtkMultiStringToCategory(const vtkMultiStringToCategory&);  // Not implemented.
  void operator=(const vtkMultiStringToCategory&);  // Not implemented.
};

#endif
