/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkMultiStringToCategory.h"

#include "vtkAbstractArray.h"
#include "vtkFieldData.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkNew.h"
#include "vtkObjectFactory.h"
#include "vtkStringArray.h"
#include "vtkStringToCategory.h"
#include "vtkTable.h"

#include <vector>

class vtkMultiStringToCategoryInternal
{
public:
  std::vector<vtkStdString> Columns;
};

vtkStandardNewMacro(vtkMultiStringToCategory);

vtkMultiStringToCategory::vtkMultiStringToCategory()
{
  this->Internal = new vtkMultiStringToCategoryInternal;
}

vtkMultiStringToCategory::~vtkMultiStringToCategory()
{
  delete this->Internal;
}

void vtkMultiStringToCategory::AddInputArray(const vtkStdString& s)
{
  this->Internal->Columns.push_back(s);
}

void vtkMultiStringToCategory::ResetInputArrays()
{
  this->Internal->Columns.clear();
}

int vtkMultiStringToCategory::RequestData(
  vtkInformation *vtkNotUsed(request),
  vtkInformationVector **inputVector,
  vtkInformationVector *outputVector)
{
  vtkInformation* inInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* in = vtkTable::SafeDownCast(inInfo->Get(vtkDataObject::DATA_OBJECT()));
  vtkInformation* outInfo = outputVector->GetInformationObject(0);
  vtkTable* out = vtkTable::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));

  out->ShallowCopy(in);

  vtkNew<vtkStringToCategory> strToCat;
  strToCat->SetInputData(in);
  for (size_t i = 0; i < this->Internal->Columns.size(); ++i)
    {
    vtkStdString inName = this->Internal->Columns[i];
    vtkStdString outName = inName + "_category";
    strToCat->SetInputArrayToProcess(0, 0, 0, vtkDataObject::ROW, inName.c_str());
    strToCat->SetCategoryArrayName(outName.c_str());
    strToCat->Update();
    vtkTable* outData = vtkTable::SafeDownCast(strToCat->GetOutput(0));
    out->AddColumn(outData->GetColumnByName(outName.c_str()));
    vtkTable* outMap = vtkTable::SafeDownCast(strToCat->GetOutput(1));
    vtkStringArray* mapArr = vtkStringArray::SafeDownCast(outMap->GetColumn(0));
    mapArr->SetName(inName.c_str());
    out->GetFieldData()->AddArray(mapArr);
    }

  return 1;
}

void vtkMultiStringToCategory::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
}
