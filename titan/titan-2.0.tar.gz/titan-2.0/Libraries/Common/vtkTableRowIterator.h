/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkTableRowIterator_h
#define __vtkTableRowIterator_h

#include <vtkArray.h>

#include <iterator>
#include <vector>

#include <iostream>

#include "titanVectorTraits.h"

using namespace std;

/// Represents a single row in a table
template<typename ColumnT, typename ElementTypeT>
class vtkTableRow
{
public:
  std::vector<ColumnT*> columns;
  typedef ElementTypeT value_type;
  vtkArray::CoordinateT Row;

  std::vector<size_t> ElementIndices;

  size_t size() const
  {
    return columns.size();
  }

  void resize(const size_t& new_size)
  {
    return;
  }

  value_type operator[](size_t i) const
  {
    return *(columns[i]->GetTuple(this->Row));
  }

  /// WARNING: Using this as an l-value will not modify the underlying table.
  /// Use put() instead.
  value_type& operator[](size_t i)
  {
    return *(columns[i]->GetTuple(this->Row));
  }

  void put(size_t i, value_type v)
  {
    columns[i]->SetTuple1(this->Row, v);
  }

  template<typename VectorT>
  vtkTableRow& operator=(const VectorT& b)
  {
    for(size_t i = 0; i != this->size(); ++i)
    {
      (*this)[i] = b[i];
    }
    return *this;
  }

  vtkTableRow& operator=(const vtkTableRow& b)
  {
    for(size_t i = 0; i != this->size(); ++i)
    {
      this->put(i, b[i]);
    }
    return *this;
  }
};

/// Adapts vtkTableRow to vector_traits
template<typename ColumnT, typename ElementT>
struct vector_traits<vtkTableRow<ColumnT, ElementT> >
{
  typedef vtkTableRow<ColumnT, ElementT> row_type;

  static size_t size(const row_type& t)
  {
    return t.size();
  }

  static void resize(row_type& t, const size_t& new_size)
  {
    t.resize(new_size);
  }

  static typename row_type::value_type get(const row_type& t, const size_t& index)
  {
    return t[index];
  }

  static typename row_type::value_type& get(row_type& t, const size_t& index)
  {
    return t[index];
  }

  static void put(row_type& t, size_t& index, const typename row_type::value_type value)
  {
    t.put(index,value);
  }
};

/// Model of RandomAccessIterator that makes a collection of vtkTable columns
/// "look like" a collection of rows.  Callers must supply a collection of
/// vtkAbstractArray-derived types, all of which must return the same type
/// of value (all floats, all ints, all doubles, etc).
///
/// The non-const subscript for vtkTableRow does not work correctly as an l-value
template<typename ColumnT, typename ElementTypeT>
class vtkTableRowIterator
{

public:

  typedef std::random_access_iterator_tag iterator_category;
  typedef vtkTableRow<ColumnT, ElementTypeT> value_type;
  typedef value_type* pointer;
  typedef value_type& reference;
  typedef vtkIdType difference_type;


  template<typename ColumnIteratorT>
  vtkTableRowIterator(ColumnIteratorT column_begin, ColumnIteratorT column_end, vtkIdType row) :
    Columns(column_begin, column_end),
    Row(static_cast<vtkArray::CoordinateT>(row))
  {
    this->CurrentValue.columns = this->Columns;
  }

  template<typename ColumnIteratorT>
  vtkTableRowIterator(ColumnIteratorT column_begin, ColumnIteratorT column_end, std::vector<size_t> iteratable_row_indices, vtkIdType row) :
    Columns(column_begin, column_end),
    IterableRowIndices(iteratable_row_indices),
    Row(static_cast<vtkArray::CoordinateT>(row))
  {
    this->CurrentValue.columns = this->Columns;
  }

  vtkIdType operator-(const vtkTableRowIterator& other) const
  {
    return this->Row - other.Row;
  }

  bool operator!=(const vtkTableRowIterator& other) const
  {
    return this->Row != other.Row;
  }

  bool operator<(const vtkTableRowIterator& other) const
  {
    return this->Row < other.Row;
  }

  vtkTableRowIterator& operator++()
  {
    ++this->Row;
    return *this;
  }

  vtkTableRowIterator operator+(const size_t offset) const
  {
    return vtkTableRowIterator(this->Columns.begin(), this->Columns.end(), IterableRowIndices, this->Row + static_cast<vtkArray::CoordinateT>(offset));
  }

  reference operator*() const
  {
    if (this->IterableRowIndices.size() == 0)
      this->CurrentValue.Row = this->Row;
    else
    {
      this->CurrentValue.Row = this->IterableRowIndices[this->Row];
    }
    return this->CurrentValue;
  }

  void SetIterableRowIndices(std::vector<size_t> * iterable_row_indices, vtkIdType row)
  {
    if (!iterable_row_indices)
    {
      this->IterableRowIndices.clear();
    }
    else
    {
      this->IterableRowIndices = (*iterable_row_indices);
    }

    this->Row = row;
  }

private:
  std::vector<ColumnT*> Columns;
  std::vector<size_t> IterableRowIndices;


  vtkIdType Row;
  mutable value_type CurrentValue;
};

#endif
