/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanVectorTraits titanVectorTraits.h <titanVectorTraits.h>
/// \brief ...
///
///

#ifndef __titanVectorTraits_h
#define __titanVectorTraits_h

#include <iostream>
#include <iterator>
#include <vector>
#include <stdlib.h>
#include <math.h>

template<typename T>
struct vector_traits
{
  static size_t size(const T& t)
  {
    return t.size();
  }

  static void resize(T& t, const size_t& new_size)
  {
    t.resize(new_size);
  }

  static typename T::value_type get(const T& t, const size_t& index)
  {
    return t[index];
  }

  static typename T::value_type& get(T& t, const size_t& index)
  {
    return t[index];
  }

  static void put(T& t, const size_t& index, const typename T::value_type value)
  {
    t[index]=value;
  }
};

template<>
struct vector_traits<double>
{
  static size_t size(const double& t)
  {
    return 1;
  }

  static void resize(double& t, const size_t& new_size)
  {
  }

  static double get(const double& t, const size_t& index)
  {
    if (index !=0)
    {

    }
    return t;
  }

  static double& get(double& t, const size_t& index)
  {
    if (index !=0)
    {

    }
    return t;
  }

  static void put(double& t, const size_t& index, const double value)
  {
    if (index !=0)
    {

    }
    t=value;
  }
};

template<>
struct vector_traits<size_t>
{
  static size_t size(const size_t& t)
  {
    return 1;
  }

  static void resize(size_t& t, const size_t& new_size)
  {
  }

  static size_t get(const size_t& t, const size_t& index)
  {
    if (index !=0)
    {

    }
    return t;
  }

  static size_t& get(size_t& t, const size_t& index)
  {
    if (index !=0)
    {

    }
    return t;
  }

  static void put(size_t& t, const size_t& index, const size_t value)
  {
    if (index !=0)
    {

    }
    t=value;
  }
};

// From T to U
template<typename T, typename U>
struct vector_assign
{
  static void copy_vector(const T&t, U& u)
  {
    if (vector_traits<T>::size(t) != vector_traits<U>::size(u))
      vector_traits<U>::resize(u, vector_traits<T>::size(t));

    for (size_t i=0; i!= vector_traits<T>::size(t); ++i)
      vector_traits<U>::put(u,i, vector_traits<T>::get(t,i));
  }
};

template<typename T, typename U>
struct vector_compare
{
  static bool equal(const T&t, const U& u)
  {
    if (vector_traits<T>::size(t) != vector_traits<U>::size(u))
      return false;

    for (size_t i=0; i!= vector_traits<T>::size(t); ++i)
    {
      if (vector_traits<T>::get(t,i) != vector_traits<U>::get(u,i))
        return false;
    }
    return true;
  }
};

#endif
