/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkDataSetAttributes.h"
#include "vtkRandomizeTableRows.h"
#include "vtkDoubleArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkIntArray.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkStdString.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"

#include <map>
#include <vector>
#include <algorithm>

#include <boost/random.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

// ----------------------------------------------------------------------

#define VTK_CREATE(type, name)                                  \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkRandomizeTableRows);

// ----------------------------------------------------------------------

vtkRandomizeTableRows::vtkRandomizeTableRows()
{
  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);
  this->UsePreviousRowMap=false;
  this->UnsetRandomGeneratorSeed();
}

// ----------------------------------------------------------------------

vtkRandomizeTableRows::~vtkRandomizeTableRows()
{
}

int vtkRandomizeTableRows::FillInputPortInformation(int port, vtkInformation* info)
{
  switch(port)
    {
    case 0:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

  return 0;
}


void vtkRandomizeTableRows::SetRandomGeneratorSeed(const unsigned int seed)
{
  this->RandomGenerator.seed(seed);
}

void vtkRandomizeTableRows::UnsetRandomGeneratorSeed()
{
  unsigned int random_seed;
  boost::posix_time::ptime now =
      boost::posix_time::microsec_clock::local_time();
  random_seed = static_cast<unsigned int>(now.time_of_day().total_microseconds());

  this->RandomGenerator.seed(random_seed);

  this->Modified();
}

// ----------------------------------------------------------------------
void vtkRandomizeTableRows::RandomizeRows(vtkTable* input, vtkTable* output)
{
  double currentProgress=0;

  vtkIdType num_rows = input->GetNumberOfRows();
  vtkIdType num_cols = input->GetNumberOfColumns();

  if (this->GetUsePreviousRowMap())
  {
    if (this->RandomRowIndices.size()==0) return;

    if (num_rows != static_cast<vtkIdType>(RandomRowIndices.size()))
    {
      vtkWarningMacro(
          "Number of input rows is not equivalent to stored map cardinality. Aborting...");
      return;
    }
  }
  else
  {
    RandomRowIndices.resize(static_cast<size_t>(num_rows));

    std::vector<vtkIdType> unique_row_indices(num_rows);
    for (vtkIdType row_index=0; row_index != num_rows; ++row_index)
    {
      unique_row_indices[row_index] = row_index;
    }


    vtkIdType selection_pool_index, unique_row_index;

    for (vtkIdType row_selection=0; row_selection != num_rows; ++row_selection)
    {
      boost::uniform_int<> random_map(0, static_cast<unsigned int>(num_rows-row_selection-1) );

      boost::variate_generator<boost::mt19937&, boost::uniform_int<> > random_selection_pool_index(RandomGenerator, random_map);

      selection_pool_index=random_selection_pool_index();

      unique_row_index = unique_row_indices[selection_pool_index];
      unique_row_indices.erase(unique_row_indices.begin() + selection_pool_index);

      RandomRowIndices[static_cast<size_t>(row_selection)] = unique_row_index;
    }

  }

  // Set up output table
  for (int n = 0; n < input->GetNumberOfColumns(); n++)
  {
    vtkAbstractArray* col = input->GetColumn(n);
    vtkAbstractArray* ncol = vtkAbstractArray::CreateArray(col->GetDataType());
    ncol->SetName(col->GetName());
    ncol->SetNumberOfComponents(col->GetNumberOfComponents());
    output->AddColumn(ncol);

    if (input->GetRowData()->GetPedigreeIds() == col)
      output->GetRowData()->SetPedigreeIds(ncol);

    ncol->Delete();
  }

  output->SetNumberOfRows(num_rows);



  vtkIdType random_row_index;

  for (vtkIdType row_index = 0; row_index != num_rows; ++row_index)
  {
    random_row_index = RandomRowIndices[row_index];

    for (vtkIdType col_index = 0; col_index != num_cols; ++col_index)
    {
      output->GetColumn(col_index)->SetVariantValue(row_index,
          input->GetColumn(col_index)->GetVariantValue(random_row_index));
    }

    // Emit a progress event
    double progress = (double) row_index / num_rows;
    if ((int) (progress * 100) != (int) (currentProgress * 100))
    {
      currentProgress = progress;
      this->InvokeEvent(vtkCommand::ProgressEvent, &currentProgress);
    }
  }

  currentProgress = 1;
  this->InvokeEvent(vtkCommand::ProgressEvent, &currentProgress);
}

// ----------------------------------------------------------------------

int vtkRandomizeTableRows::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{

  vtkTable* input = vtkTable::GetData(inputVector[0]);

  vtkTable* output = vtkTable::GetData(outputVector);

  this->RandomizeRows(input, output);

  return 1;
}


// ----------------------------------------------------------------------

void vtkRandomizeTableRows::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
