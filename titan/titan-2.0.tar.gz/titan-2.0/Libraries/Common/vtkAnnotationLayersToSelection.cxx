/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "vtkAnnotationLayersToSelection.h"

#include "vtkAnnotation.h"
#include "vtkAnnotationLayers.h"
#include "vtkDataSetAttributes.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkSelection.h"
#include "vtkSelectionNode.h"
#include "vtkSelectionSource.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"


vtkStandardNewMacro(vtkAnnotationLayersToSelection);

vtkAnnotationLayersToSelection::vtkAnnotationLayersToSelection()
{
  this->Domain = 0;
  this->UseDomain = false;

  this->SetNumberOfInputPorts(1);
}

vtkAnnotationLayersToSelection::~vtkAnnotationLayersToSelection()
{
  this->SetDomain(0);
}

void vtkAnnotationLayersToSelection::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkAnnotationLayersToSelection::FillInputPortInformation(int port, vtkInformation* info)
{
  switch(port)
    {
    case 0:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkAnnotationLayers");
      return 1;
    }

  return 0;
}

int vtkAnnotationLayersToSelection::RequestData(
  vtkInformation* vtkNotUsed(request),
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // Get input data
  vtkInformation* inputInfo = inputVector[0]->GetInformationObject(0);
  vtkAnnotationLayers* input = vtkAnnotationLayers::SafeDownCast(inputInfo->Get(vtkDataObject::DATA_OBJECT()));
  vtkSelection* const output = vtkSelection::GetData(outputVector);

  for(int i=0; i<input->GetNumberOfAnnotations(); ++i)
    {
    vtkAnnotation* a = input->GetAnnotation(i);

    bool canUnion = true;
    if(this->UseDomain && this->Domain)
      {
      int j=0;
      while(canUnion && j<a->GetSelection()->GetNumberOfNodes())
        {
        vtkStdString name = a->GetSelection()->GetNode(j)->GetSelectionList()->GetName();
        if(name != this->Domain)
          {
          canUnion = false;
          }
        j++;
        }
      }

    if(canUnion)
      {
      output->Union(a->GetSelection());
      }
    }

  return 1;
}
