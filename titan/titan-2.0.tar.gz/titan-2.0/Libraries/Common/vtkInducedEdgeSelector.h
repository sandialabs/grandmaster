/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkInducedEdgeSelector.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
// .NAME vtkInducedEdgeSelector - Given a graph and a selection, add an edge
//      selection to the output of those edges connecting selected vertices.
//
// .SECTION Description
// Input port 0: vtkSelection
// Input port 1: vtkGraph
//      Retrieve the selected edges and vertices from the input. Pass the
//  selected vertices to the output. Add to the selected edges those edges where
//  both their source and target vertex are among the selected vertices.
//
//
// .SECTION Thanks
//
// .SECTION See Also

#ifndef __vtkInducedEdgeSelector_h
#define __vtkInducedEdgeSelector_h

#include "titanCommon.h"
#include "vtkSelectionAlgorithm.h"

class TITAN_COMMON_EXPORT vtkInducedEdgeSelector : public vtkSelectionAlgorithm
{
public:
  static vtkInducedEdgeSelector *New();
  vtkTypeMacro(vtkInducedEdgeSelector, vtkSelectionAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  // Convenience method for setting the graph connection (second port).
  void SetGraphConnection(vtkAlgorithmOutput* conn)
    { this->SetInputConnection(1, conn); }

protected:
  vtkInducedEdgeSelector();
  ~vtkInducedEdgeSelector();

  virtual int RequestData(
    vtkInformation *,
    vtkInformationVector **,
    vtkInformationVector *);

  virtual int FillInputPortInformation(
    int port, vtkInformation* info);

private:
  vtkInducedEdgeSelector(const vtkInducedEdgeSelector&);  // Not implemented.
  void operator=(const vtkInducedEdgeSelector&);  // Not implemented.
};

#endif
