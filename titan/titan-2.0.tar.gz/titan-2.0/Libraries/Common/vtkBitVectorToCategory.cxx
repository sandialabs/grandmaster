/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkDataSetAttributes.h"
#include "vtkDoubleArray.h"
#include "vtkBitVectorToCategory.h"
#include "vtkIdTypeArray.h"
#include "vtkIndent.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkStdString.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"
#include "vtkDataArray.h"

#include "vtkSmartPointer.h"
#include <sstream>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

// #define DEBUG 0



vtkStandardNewMacro(vtkBitVectorToCategory);

//----------------------------------------------------------------------------
vtkBitVectorToCategory::vtkBitVectorToCategory()
{
  this->SetHasPrefix(false);
}

//----------------------------------------------------------------------------
vtkBitVectorToCategory::~vtkBitVectorToCategory()
{
}

void vtkBitVectorToCategory::AddBitColumn(const char * column)
{
  std::string s(column);
  this->BitColumns.push_back(s);
  this->Modified();
}

//----------------------------------------------------------------------------
int vtkBitVectorToCategory::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // Get input table
  vtkInformation* inputInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* input = vtkTable::SafeDownCast(
    inputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get output tables
  vtkInformation* outputInfo = outputVector->GetInformationObject(0);
  vtkTable* output = vtkTable::SafeDownCast(
    outputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // If the user doesn't specify BitColumns, then add all
  if (this->BitColumns.size() == 0)
  {
      for (vtkIdType i = 0; i != input->GetNumberOfColumns(); ++i)
      {
        vtkDataArray* column = vtkDataArray::SafeDownCast(input->GetColumn(i));
        if (column)
        {
          std::stringstream ss;
          ss.str("");
          ss << column->GetName();
          this->BitColumns.push_back(ss.str());
        }
      }
  }
  else
  {
    std::vector<std::string>::iterator I;
    for (I = this->BitColumns.begin(); I != this->BitColumns.end(); ++I)
    {
      vtkDataArray* column = vtkDataArray::SafeDownCast(
          input->GetColumnByName((*I).c_str()));
      if (!column)
      {
        vtkErrorMacro( "Cannot find array: " << (*I).c_str());
        return 0;
      }
    }
  }

  if(input->GetNumberOfRows() == 0)
    {
    output->ShallowCopy(input);
    return 1;
    }

  // This will copy only the meta data and not the row data
  output->vtkDataObject::ShallowCopy(input);

  vtkDataArray* bit_column;
  std::vector<std::string>::iterator I;

  vtkIdType r = 0;
  vtkStringArray * classColumn = vtkStringArray::New();
  double max = VTK_DOUBLE_MIN, value = 0.0;
  vtkStdString classIndex;
  for(r = 0; r < input->GetNumberOfRows(); r++)
    {

    for (I = this->BitColumns.begin(); I != this->BitColumns.end(); ++I)
      {
      bit_column = vtkDataArray::SafeDownCast(
          input->GetColumnByName((*I).c_str()));

      value = bit_column->GetVariantValue(r).ToDouble();
      if(value > max)
        {
        max = value;
        classIndex = bit_column->GetName();
        }
      }

      vtkStdString className;
      if (HasPrefix)
      {
        classIndex.erase(0,classIndex.find_first_of("_",0)+1);
      }
//      else
  //      className=classIndex;

      classColumn->InsertNextValue(classIndex);
      max = VTK_DOUBLE_MIN;
    }

  output->AddColumn(classColumn);
  classColumn->Delete();

  return 1;
}



//----------------------------------------------------------------------------
void vtkBitVectorToCategory::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
