/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkDistinctRows.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkDistinctRows vtkDistinctRows.h <Common/vtkDistinctRows.h>
/// \brief This filter operates much like the SQL 'distinct'
/// command. It pulls out rows from a table for each distinct value of the
/// specified column value (or distinct combination of columns).
///
/// vtkDistinctRows operates much like the SQL 'distinct'
/// command. It pulls out rows from a table for each distinct value of the
/// specified column value (or distinct combination of columns).

#ifndef __vtkDistinctRows_h
#define __vtkDistinctRows_h

#include "titanCommon.h"
#include <vtkTableAlgorithm.h>

class vtkAbstractArray;
class vtkTable;

class TITAN_COMMON_EXPORT vtkDistinctRows : public vtkTableAlgorithm
{
public:
  static vtkDistinctRows* New();
  vtkTypeMacro(vtkDistinctRows, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Add/Clear columns. Rows having unique tuples of values across all
  /// distinct columns will be copied to the output.
  void AddDistinctColumn(const char *column);
  void RemoveAllDistinctColumns();
  ///@}

  ///@{
  /// Specifies whether or not to add a column to the output that
  /// indicates the number of rows in the input that matched the
  /// given value.
  vtkGetMacro(AddCountColumn, bool);
  vtkSetMacro(AddCountColumn, bool);
  vtkBooleanMacro(AddCountColumn, bool);
  ///@}

  ///@{
  /// Used to store the optional output count column name.
  vtkGetStringMacro(CountColumnName);
  vtkSetStringMacro(CountColumnName);
  ///@}

protected:
  vtkDistinctRows();
  ~vtkDistinctRows();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkDistinctRows(const vtkDistinctRows&); // Not implemented
  void operator=(const vtkDistinctRows&);   // Not implemented

  void CopyDistinctRows(vtkTable* input, vtkTable* output);

  char *CountColumnName;
  bool AddCountColumn;

//BTX
  class vtkVector;
  vtkVector* DistinctColumns;
//ETX
};

#endif
