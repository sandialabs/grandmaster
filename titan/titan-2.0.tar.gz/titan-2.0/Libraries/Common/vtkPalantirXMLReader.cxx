/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkPalantirXMLReader.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2009 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/

#include "vtkPalantirXMLReader.h"

#include "vtkBitArray.h"
#include "vtkInformation.h"
#include "vtkIdTypeArray.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"
#include "vtkGraph.h"

#include "vtk_libxml2.h"
#include VTKLIBXML2_HEADER(parser.h)
#include VTKLIBXML2_HEADER(tree.h)


vtkStandardNewMacro(vtkPalantirXMLReader);


vtkPalantirXMLReader::vtkPalantirXMLReader()
{
  this->FileName = 0;
  this->XMLString = 0;
  this->SetNumberOfInputPorts(0);
  this->SetNumberOfOutputPorts(1);
  this->EdgePedigreeIdArrayName = 0;
  this->SetEdgePedigreeIdArrayName("edge id");
}

vtkPalantirXMLReader::~vtkPalantirXMLReader()
{
  this->SetFileName(0);
  this->SetXMLString(0);
  this->SetEdgePedigreeIdArrayName(0);
}

void vtkPalantirXMLReader::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "FileName: "
     << (this->FileName ? this->FileName : "(none)") << endl;
  os << indent << "XMLString: "
     << (this->XMLString ? this->XMLString : "(none)") << endl;
  os << indent << "EdgePedigreeIdArrayName: "
     << (this->EdgePedigreeIdArrayName ? this->EdgePedigreeIdArrayName : "(null)") << endl;
}


// Helper functions
// This is a psuedo-breadth first search for a named node
static xmlNode* ReturnNamedChildNode(xmlNode *parent, const char* queryName)
{
  // Sanity check
  if (!parent)
    {
    return 0;
    }

  // Check yourself for the queryName
  if (!strcmp(reinterpret_cast<const char*>(parent->name),queryName))
    {
    if (parent->type == XML_ELEMENT_NODE)
      return parent; // Found it
    }

  // Check all immediate children for the queryName
  for (xmlNode *curNode = parent->children; curNode != 0; curNode = curNode->next)
    {
    if (!strcmp(reinterpret_cast<const char*>(curNode->name),queryName))
      {
      if (curNode->type == XML_ELEMENT_NODE)
        return curNode; // Found it
      }
    }

  // Recurse
  for (xmlNode *curNode = parent->children; curNode != 0; curNode = curNode->next)
    {
    xmlNode *foundNode = ReturnNamedChildNode(curNode,queryName);
    if (foundNode)
      {
      return foundNode; // Found it
      }
    }

  // Could not find the queryName in any of the children
  return 0;
}

// Get both the matching name and type of the child node
static xmlNode* ReturnNamedTypedChildNode(xmlNode *parent, const char* queryName, const char* queryType)
{
  // Check all immediate children for the queryName
  for (xmlNode *curNode = parent->children; curNode != 0; curNode = curNode->next)
    {
    xmlNode *foundNode = ReturnNamedChildNode(curNode,queryName);
    if (foundNode)
      {
      for (xmlAttr *curAttr = foundNode->properties; curAttr; curAttr = curAttr->next)
        {
        const char *attributeName = reinterpret_cast<const char*>(curAttr->name);
        if (!strcmp(attributeName,"type"))
          {
          const char *value = reinterpret_cast<const char*>(curAttr->children->content);

          // Matching property_type
          if (!strcmp(value, queryType))
            {
            return foundNode; // Found it
            }
          }
        }
      }
    }

  // Could not find the name/type combination in any of the children
  return 0;
}

// Helper function
static int Valid(xmlDoc *doc)
{
  // NULL document is not valid
  if (doc == 0)
    {
    return 0;
    }

  // Get the root element node
  xmlNode *rootNode = xmlDocGetRootElement(doc);

  // Root should be 'palantir'
  if (strcmp(reinterpret_cast<const char*>(rootNode->name),"palantir"))
    {
    return 0;
    }

  // A child element node should be 'graph'
  xmlNode *graph = ReturnNamedChildNode(rootNode, "graph");

  // A child element node should be 'objectSet'
  xmlNode *objectSet = ReturnNamedChildNode(rootNode, "objectSet");

  // Make sure we found everything
  return (graph && objectSet);
}



// Helper functions
// This class makes a big assumption that your handing it an XML node that has a child
// named propertySet.
static const char* GetPropertyDataValue(xmlNode *node, const char* property_type, const char* component)
{
  xmlNode *propertySet = ReturnNamedChildNode(node, "propertySet");
  if (propertySet)
    {
    // One of the children should be a property with this property_type
    xmlNode *propertyNode = ReturnNamedTypedChildNode(propertySet, "property", property_type);
    if (propertyNode)
      {
      xmlNode *componentNode = ReturnNamedTypedChildNode(propertyNode, "propertyComponent", component);

      if (componentNode)
        {
        xmlNode *propertyData = ReturnNamedChildNode(propertyNode, "propertyData");
        const char *value = reinterpret_cast<const char*>(propertyData->children->content);
        return value;
        }
      }
    }

  // Could not find the property node of this type
  return 0;
}


int vtkPalantirXMLReader::RequestData(
  vtkInformation*,
  vtkInformationVector**,
  vtkInformationVector *outputVector)
{
  if (!this->FileName && !this->XMLString)
    {
    // Allow for an empty output without complaining if reader is not yet initialized
    return 1;
    }

  xmlDoc *doc = 0;
  if (this->FileName)
    {
    // Parse the file and get the DOM
    doc = xmlReadFile(this->FileName, 0, 0);
    }
  else if (this->XMLString)
    {
    // Parse from memory and get the DOM
    doc = xmlReadMemory(this->XMLString, static_cast<int>(strlen(this->XMLString)), "noname.xml", 0, 0);
    }

  if (!Valid(doc))
    {
    vtkErrorMacro("The file is not a valid pXML file");
    return 0;
    }

  // Store the Palantir XML data into a vtkMutableDirectedGraph
  vtkSmartPointer<vtkMutableDirectedGraph> builder =
    vtkSmartPointer<vtkMutableDirectedGraph>::New();


  // Add arrays to the vertex data
  vtkDataSetAttributes *vertexData = builder->GetVertexData();

  vtkStringArray *idArr = vtkStringArray::New();
  idArr->SetName("id");
  vertexData->SetPedigreeIds(idArr);   // Make this the pedigree ids
  idArr->Delete();

  vtkStringArray *labelArr = vtkStringArray::New();
  labelArr->SetName("label");
  vertexData->AddArray(labelArr);
  labelArr->Delete();

  vtkStringArray *typeArr = vtkStringArray::New();
  typeArr->SetName("type");
  vertexData->AddArray(typeArr);
  typeArr->Delete();

  // Add arrays to the edge data
  vtkDataSetAttributes *edgeData = builder->GetEdgeData();

  vtkIdTypeArray *edgeIdArr = vtkIdTypeArray::New();
  edgeIdArr->SetName(this->GetEdgePedigreeIdArrayName());
  edgeData->SetPedigreeIds(edgeIdArr);   // Make this the pedigree ids
  edgeIdArr->Delete();

  vtkStringArray *edgeLabelArr = vtkStringArray::New();
  edgeLabelArr->SetName("label");
  edgeData->AddArray(edgeLabelArr);
  edgeLabelArr->Delete();

  vtkStringArray *edgeTypeArr = vtkStringArray::New();
  edgeTypeArr->SetName("type");
  edgeData->AddArray(edgeTypeArr);
  edgeTypeArr->Delete();

  vtkStringArray *edgeTextArr = vtkStringArray::New();
  edgeTextArr->SetName("text");
  edgeData->AddArray(edgeTextArr);
  edgeTextArr->Delete();



  // Get the vertices (objectSet) and the edges (linkSet)
  // from the XML. The vertices must be here and that is
  // already checked in the Valid method above. The edges
  // are optional.

  // Get the root element node
  xmlNode *rootNode = xmlDocGetRootElement(doc);
  xmlNode *objectSet = ReturnNamedChildNode(rootNode, "objectSet");
  xmlNode *linkSet = ReturnNamedChildNode(rootNode, "linkSet");
  if (!linkSet)
    {
    vtkWarningMacro("This pXML file does not contain a linkSet.");
    }

  // Create a new vertex for each child of the objectSet
  for (xmlNode *curNode = objectSet->children; curNode; curNode = curNode->next)
    {
    if (curNode->type != XML_ELEMENT_NODE)
      {
      continue;
      }

    // Add vertex
    vtkIdType vertex_id = builder->AddVertex();

    // Append the attributes to the vertex
    for (xmlAttr *curAttr = curNode->properties; curAttr; curAttr = curAttr->next)
      {
      const char *attributeName = reinterpret_cast<const char*>(curAttr->name);

      // Check for the attributes for id, type, and label (see header file for
      // full description of the extracted attributes).
      if (!strcmp(attributeName,"id"))
        {
        const char *value = reinterpret_cast<const char*>(curAttr->children->content);
        idArr->InsertValue(vertex_id,value);
        }
      if (!strcmp(attributeName,"type"))
        {
        const char *value = reinterpret_cast<const char*>(curAttr->children->content);
        typeArr->InsertValue(vertex_id,value);
        }

      // This is an amazingly complicated way of getting a label (see header file
      // for a full description of the extracted label).
      const char *value = GetPropertyDataValue(curNode,"com.palantir.property.IntrinsicTitle","TITLE");
      if (value)
        {
        labelArr->InsertValue(vertex_id,value);
        }
      else
        {
        vtkErrorMacro("Could not find a property value");
        return 0;
        }

      } // each attribute

    } // each child of objectSet


  // Create a new edge for each child of the linkSet
  vtkIdType edgePedigreeID = 0;
  for (xmlNode *curNode = linkSet->children; curNode; curNode = curNode->next)
    {
    if (curNode->type != XML_ELEMENT_NODE)
      {
      continue;
      }

    // Get the attributes of the edge
    vtkStdString fromVertex, toVertex, type, text, label;
    for (xmlAttr *curAttr = curNode->properties; curAttr; curAttr = curAttr->next)
      {
      const char *attributeName = reinterpret_cast<const char*>(curAttr->name);

      // Check for the attributes for parentRef, childRef, and type (see header file
      // for full description of the extracted attributes).
      if (!strcmp(attributeName,"parentRef"))
        {
        const char *value = reinterpret_cast<const char*>(curAttr->children->content);
        fromVertex = value;
        }
      if (!strcmp(attributeName,"childRef"))
        {
        const char *value = reinterpret_cast<const char*>(curAttr->children->content);
        toVertex = value;
        }
      if (!strcmp(attributeName,"type"))
        {
        const char *value = reinterpret_cast<const char*>(curAttr->children->content);
        type = value;
        vtkStdString prefix = "com.palantir.link.";
        label = type.substr(prefix.size(),vtkStdString::npos);
        }

      // Set if there is an optional text field for the edge
      xmlNode *textNode = ReturnNamedChildNode(curNode, "text");
      if (textNode)
        {
        text  = reinterpret_cast<const char*>(textNode->children->content);
        }
      else
        {
        text = "no entry";
        }
      }

    // Add edge
    builder->AddEdge(fromVertex, toVertex);
    edgeIdArr->InsertNextValue(edgePedigreeID++);
    edgeTypeArr->InsertNextValue(type);
    edgeTextArr->InsertNextValue(text);
    edgeLabelArr->InsertNextValue(label);

    } // each child of linkSet


  // Move the data into the output vtkGraph
  vtkDirectedGraph *output = vtkDirectedGraph::GetData(outputVector);
  if (!output->CheckedShallowCopy(builder))
    {
    vtkErrorMacro(<<"Structure is not a valid graph!");
    return 0;
    }

  return 1;
  }
