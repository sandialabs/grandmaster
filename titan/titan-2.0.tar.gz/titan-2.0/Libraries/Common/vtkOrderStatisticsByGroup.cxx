/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkOrderStatisticsByGroup.h"

#include "vtkAbstractArray.h"
#include "vtkDataSetAttributes.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMultiBlockDataSet.h"
#include "vtkObjectFactory.h"
#include "vtkOrderStatistics.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkVariantArray.h"

#include <map>

vtkStandardNewMacro(vtkOrderStatisticsByGroup);

vtkOrderStatisticsByGroup::vtkOrderStatisticsByGroup()
{
  this->ArrayName = 0;
  this->GroupArrayName = 0;
}

vtkOrderStatisticsByGroup::~vtkOrderStatisticsByGroup()
{
  this->SetArrayName(0);
  this->SetGroupArrayName(0);
}

int vtkOrderStatisticsByGroup::RequestData(
  vtkInformation *vtkNotUsed(request),
  vtkInformationVector **inputVector,
  vtkInformationVector *outputVector)
{
  // get the info objects
  vtkInformation* inInfo = inputVector[0]->GetInformationObject(0);
  vtkInformation* outInfo = outputVector->GetInformationObject(0);

  // get the input and ouptut
  vtkTable* input = vtkTable::SafeDownCast(inInfo->Get(vtkDataObject::DATA_OBJECT()));
  vtkTable* output = vtkTable::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));

  if (!this->ArrayName)
    {
    vtkErrorMacro("Array name not specified");
    return 0;
    }
  vtkAbstractArray* arr = input->GetColumnByName(this->ArrayName);
  if (!arr)
    {
    vtkErrorMacro("Array not found");
    return 0;
    }

  if (!this->GroupArrayName)
    {
    vtkErrorMacro("Group array name not specified");
    return 0;
    }
  vtkAbstractArray* garr = input->GetColumnByName(this->GroupArrayName);
  if (!garr)
    {
    vtkErrorMacro("Group array not found");
    return 0;
    }

  // group the elements of the data array by the group array
  std::map<vtkVariant, vtkSmartPointer<vtkAbstractArray> > groups;
  for (vtkIdType i = 0; i < input->GetNumberOfRows(); ++i)
    {
    vtkVariant v = garr->GetVariantValue(i);
    if (groups.find(v) == groups.end())
      {
      groups[v].TakeReference(vtkAbstractArray::CreateArray(arr->GetDataType()));
      groups[v]->SetName(this->ArrayName);
      }
    vtkAbstractArray* carr = groups[v];
    carr->InsertVariantValue(carr->GetNumberOfTuples(), arr->GetVariantValue(i));
    }

  vtkSmartPointer<vtkOrderStatistics> stats = vtkSmartPointer<vtkOrderStatistics>::New();

  vtkSmartPointer<vtkTable> table = vtkSmartPointer<vtkTable>::New();
  stats->SetInputData(table);
  stats->AddColumn(this->ArrayName);
  vtkSmartPointer<vtkVariantArray> quantiles_row = vtkSmartPointer<vtkVariantArray>::New();
  vtkSmartPointer<vtkVariantArray> row = vtkSmartPointer<vtkVariantArray>::New();
  std::map<vtkVariant, vtkSmartPointer<vtkAbstractArray> >::iterator it;
  for (it = groups.begin(); it != groups.end(); ++it)
    {
    // run order statistics on the subset
    table->RemoveColumnByName(this->ArrayName);
    table->AddColumn(it->second);
    table->Modified();
    stats->Update();
    vtkMultiBlockDataSet* out = vtkMultiBlockDataSet::SafeDownCast(stats->GetOutputDataObject(vtkStatisticsAlgorithm::OUTPUT_MODEL));
    vtkTable* cardinality = vtkTable::SafeDownCast( out->GetBlock( 1 ) );
    vtkTable* quantiles = vtkTable::SafeDownCast( out->GetBlock( 2 ) );
    vtkAbstractArray* quantileData = quantiles->GetColumnByName(this->ArrayName);
    vtkAbstractArray* cardinalityData = cardinality->GetColumnByName("Cardinality");
    if (it == groups.begin())
      {
      // set up the output table columns: Group, Cardinality, <Quantile1>, ..., <QuantileN>
      vtkSmartPointer<vtkAbstractArray> ga;
      ga.TakeReference(vtkAbstractArray::CreateArray(garr->GetDataType()));
      ga->SetName("Group");
      output->AddColumn(ga);

      vtkSmartPointer<vtkAbstractArray> ca;
      ca.TakeReference(vtkAbstractArray::CreateArray(cardinalityData->GetDataType()));
      ca->SetName("Cardinality");
      output->AddColumn(ca);

      vtkAbstractArray* quantileNames = quantiles->GetColumnByName("Quantile");
      for (vtkIdType c = 0; c < quantiles->GetNumberOfRows(); ++c)
        {
        vtkSmartPointer<vtkAbstractArray> qa;
        qa.TakeReference(vtkAbstractArray::CreateArray(quantileData->GetDataType()));
        qa->SetName(quantileNames->GetVariantValue(c).ToString());
        output->AddColumn(qa);
        }
      }
    // insert the results in a row in the output table
    row->Initialize();
    row->InsertNextValue(it->first);
    row->InsertNextValue(cardinalityData->GetVariantValue(0));
    for (vtkIdType i = 0; i < quantiles->GetNumberOfRows(); ++i)
      {
      row->InsertNextValue(quantileData->GetVariantValue(i));
      }
    output->InsertNextRow(row);
    }

  return 1;
}

void vtkOrderStatisticsByGroup::PrintSelf(ostream& os, vtkIndent indent)
{
  os << indent << "ArrayName: " << (this->ArrayName ? this->ArrayName : "(none)") << endl;
  os << indent << "GroupArrayName: " << (this->GroupArrayName ? this->GroupArrayName : "(none)") << endl;
  this->Superclass::PrintSelf(os,indent);
}
