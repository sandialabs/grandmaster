/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkPalantirXMLWriter.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2009 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/
// .NAME vtkPalantirXMLWriter - reads a Palantir XML file into a vtkGraph
//
// .SECTION Description
// vtkPalantirXMLWriter parses a Palantir XML file and uses the objectSet and
// the linkSet to construct and vtkGraph. The graph is directed, the
// direction of the edge is determined by the parentRef, childRef pair
// in the linkSet:link items.
//
// Current Schema mappings (all other entities/values currently ignored)
// vtkGraph vertex attribute arrays (all vtkStringArray):
//      id = Palantir object id (e.g. PT_OBJECT2)
//      label = com.palantir.property.IntrinsicTitle:propertyData:propertyValue:
//              propertyComponent type="TITLE":propertyData (e.g. John Doe)
//      type = Palantir object type (e.g. com.palantir.object.person)
//
// vtkGraph edge attribute arrays (all vtkStringArray):
//      edge id = 0 to N-1 based edge pedigree ids. The name can be changed
//                by using EdgePedigreeIdArrayName.
//      label = The last part of the type (e.g. "SiblingOf" for "com.palantir.link.SiblingOf"
//      type = Palantir link type (e.g. com.palantir.link.SiblingOf)
//
#ifndef __vtkPalantirXMLWriter_h
#define __vtkPalantirXMLWriter_h

#include "titanCommon.h"
#include "vtkXMLWriter.h"

class TITAN_COMMON_EXPORT vtkPalantirXMLWriter : public vtkXMLWriter
{
public:
  static vtkPalantirXMLWriter* New();
  vtkTypeMacro(vtkPalantirXMLWriter, vtkXMLWriter);
  void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  // Get the default file extension for files written by this writer.
  virtual const char* GetDefaultFileExtension(){return ".xml";};

protected:
  vtkPalantirXMLWriter();
  ~vtkPalantirXMLWriter();

  virtual const char* GetDataSetName(){return "vtkGraph";}

  virtual int WriteData();

  void WriteObjectSet();
  void WriteLinkSet();

private:
  vtkPalantirXMLWriter(const vtkPalantirXMLWriter&); // Not implemented
  void operator=(const vtkPalantirXMLWriter&);   // Not implemented
};

#endif
