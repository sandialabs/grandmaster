/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkDataSetAttributes.h"
#include "vtkDoubleArray.h"
#include "vtkCategoryToBitVector.h"
#include "vtkIdTypeArray.h"
#include "vtkIndent.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"

#include <vector>
#include <algorithm>
#include <set>

#include <vtksys/String.hxx>
#include <vtksys/SystemTools.hxx>

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#include <boost/algorithm/string/trim.hpp>

#include <sstream>

// #define DEBUG 0


vtkStandardNewMacro(vtkCategoryToBitVector);

//----------------------------------------------------------------------------
vtkCategoryToBitVector::vtkCategoryToBitVector()
{
  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(2);
  this->CategoryColumn = NULL;
  this->CategoryLabelDelimiter = NULL;
  this->SetCategoryLabelDelimiter(",");
  this->SetUsePrefix(false);
}

//----------------------------------------------------------------------------
vtkCategoryToBitVector::~vtkCategoryToBitVector()
{
  this->SetCategoryColumn( NULL );
  this->SetCategoryLabelDelimiter( NULL );
}

//----------------------------------------------------------------------------


void vtkCategoryToBitVector::AddCategoryColumn(const char * column)
{
  vtkStdString s(column);
  this->CategoryColumns.push_back(s);
  this->Modified();
}


void vtkCategoryToBitVector::AddCategoryColumn(const char * column, const char * category_values)
{
  vtkStdString s(column);
  this->CategoryColumns.push_back(s);
  this->CategoryColumValueMap[column]=category_values;
  this->Modified();
}


int vtkCategoryToBitVector::FillInputPortInformation(int port,
    vtkInformation* info)
{

  if (port == 0)
  {
    // port 0 is a table of observations
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    return 1;
  }
  else if (port == 1)
  {
    // port 1 is a parameter table
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
    return 1;
  }

  return 0;
}

int vtkCategoryToBitVector::FillOutputPortInformation(int port,
    vtkInformation* info)
{
  if (port == 0)
  {
    //port 0 contains the observation table with cluster_id columns appended.
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
  }
  else if (port == 1)
  {
    //port 1 contains the model parameters.
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
  }
  return 0;
}

int vtkCategoryToBitVector::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // Get input table
  vtkInformation* inputInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* input = vtkTable::SafeDownCast(
    inputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get output tables
  vtkInformation* outputInfo = outputVector->GetInformationObject(0);
  vtkTable* output = vtkTable::SafeDownCast(
    outputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // This will copy only the meta data and not the row data
  output->vtkDataObject::ShallowCopy(input);

  if(input->GetNumberOfRows() == 0)
    {
    output->ShallowCopy(input);
    return 1;
    }

  vtkTable* const outputCategoryMap = vtkTable::GetData(outputVector, 1);


  vtkSmartPointer<vtkStringArray> column_names = vtkSmartPointer<vtkStringArray>::New();
  column_names->SetName("column_name");
  vtkSmartPointer<vtkStringArray> unique_labels = vtkSmartPointer<vtkStringArray>::New();
  unique_labels->SetName("unique_labels");

  outputCategoryMap->AddColumn(column_names);
  outputCategoryMap->AddColumn(unique_labels);

  outputCategoryMap->SetNumberOfRows(this->CategoryColumns.size());

  // If the user doesn't specify CategoryColumns, then add all
  if (this->CategoryColumns.size() == 0)
  {
      cout << "INFO:\tNo category column specified. Processing all columns." << endl;
      for (vtkIdType i = 0; i != input->GetNumberOfColumns(); ++i)
      {
        vtkAbstractArray* column = vtkAbstractArray::SafeDownCast(input->GetColumn(i));
        if (column)
        {
          std::stringstream ss;
          ss.str("");
          ss << column->GetName();
          this->CategoryColumns.push_back(ss.str());
        }
      }
  }
  else
  {
    std::vector<vtkStdString>::iterator I;
    for (I = this->CategoryColumns.begin(); I != this->CategoryColumns.end(); ++I)
    {
      vtkAbstractArray* column = vtkAbstractArray::SafeDownCast(
          input->GetColumnByName((*I).c_str()));
      if (!column)
      {
        vtkErrorMacro( "Cannot find array: " << (*I).c_str());
        return 0;
      }
    }
  }


  std::vector<vtkStdString>::iterator I;
  bool append_label;
  int index = 0;
  for (I = this->CategoryColumns.begin(); I != this->CategoryColumns.end(); ++I)
  {

    append_label = false;

    const char * categoryColumn = (*I).c_str();

    vtkAbstractArray * categories = NULL;

    categories = input->GetColumnByName(categoryColumn);

    vtkIdType i = 0;
    size_t j = 0;
    std::set<vtksys::String> uniqueLabels;

    // If the category values are labeled explicitly, then use them in that order
    if ((this->CategoryColumValueMap.find(categoryColumn) != this->CategoryColumValueMap.end()) && (this->CategoryColumValueMap[categoryColumn].compare("")))
    {
      std::vector<vtksys::String> categoryLabels =
                vtksys::SystemTools::SplitString(this->CategoryColumValueMap[categoryColumn],
                    ',');
      for (j = 0; j < categoryLabels.size(); j++)
      {
        // Trimming whitespace
        boost::algorithm::trim(categoryLabels[j]);
        uniqueLabels.insert(categoryLabels[j]);
      }
    }
    // Otherwise, search through the rows and extract the unique labels
    else
    {
      for (i = 0; i < input->GetNumberOfRows(); i++)
      {
        std::vector<vtksys::String> categoryLabels =
            vtksys::SystemTools::SplitString(
                categories->GetVariantValue(i).ToString().c_str(),
                *this->CategoryLabelDelimiter);

        for (j = 0; j < categoryLabels.size(); j++)
        {
          // Trimming whitespace
          boost::algorithm::trim(categoryLabels[j]);
          uniqueLabels.insert(categoryLabels[j]);
        }
      }
    }

    vtkStringArray * nameArray = vtkStringArray::SafeDownCast(outputCategoryMap->GetColumn(0));
    nameArray->SetValue(index,categoryColumn);

    vtkStringArray * uniqueLabelsArray = vtkStringArray::SafeDownCast(outputCategoryMap->GetColumn(1));

    vtkStdString uniqueLabelString="";

    std::set<vtksys::String>::iterator iter;
    bool foundCategoryInLabel = false;
    for (iter = uniqueLabels.begin(); iter != uniqueLabels.end();
        ++iter)
        {
      vtkDoubleArray * vector = vtkDoubleArray::New();

      if (this->UsePrefix)
      {
        std::stringstream ss;
        ss.str("");
        ss << categoryColumn;
        ss << "_";
        ss << (*iter).c_str();
        vector->SetName(ss.str().c_str());
      }
      else
        vector->SetName((*iter).c_str());

      uniqueLabelString.append((*iter).c_str());
      uniqueLabelString.append(",");

      for (i = 0; i < input->GetNumberOfRows(); i++)
      {
        std::vector<vtksys::String> categoryLabels =
            vtksys::SystemTools::SplitString(
                categories->GetVariantValue(i).ToString().c_str(),
                *this->CategoryLabelDelimiter);

        foundCategoryInLabel = false;
        for (j = 0; j < categoryLabels.size(); j++)
        {
          // Trimming whitespace
          boost::algorithm::trim(categoryLabels[j]);
          if ((*iter) == categoryLabels[j])
          {
            foundCategoryInLabel = true;
            break;
          }
        }

        if (foundCategoryInLabel)
        {
          vector->InsertNextValue(1.0);
        }
        else
        {
          vector->InsertNextValue(0.0);
        }
      }
      output->AddColumn(vector);
      vector->Delete();
    }
    uniqueLabelsArray->SetValue(index,uniqueLabelString.substr(0,uniqueLabelString.size()-1));

    ++index;
  }
  return 1;
}



//----------------------------------------------------------------------------
void vtkCategoryToBitVector::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  cout << "   ColumnName: '" << this->CategoryColumn
       << endl;
}
