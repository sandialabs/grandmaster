/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
// .NAME vtkAnnotationLayersToSelection -

#ifndef __vtkAnnotationLayersToSelection_h
#define __vtkAnnotationLayersToSelection_h

#include "titanCommon.h"
#include "vtkSelectionAlgorithm.h"

class TITAN_COMMON_EXPORT vtkAnnotationLayersToSelection : public vtkSelectionAlgorithm
{
public:
  static vtkAnnotationLayersToSelection* New();
  vtkTypeMacro(vtkAnnotationLayersToSelection, vtkSelectionAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  vtkSetStringMacro(Domain);
  vtkGetStringMacro(Domain);

  vtkSetMacro(UseDomain, bool);
  vtkGetMacro(UseDomain, bool);
  vtkBooleanMacro(UseDomain, bool);

protected:
  vtkAnnotationLayersToSelection();
  ~vtkAnnotationLayersToSelection();

  virtual int FillInputPortInformation(int port, vtkInformation* info);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

  char* Domain;
  bool UseDomain;

private:
  vtkAnnotationLayersToSelection(const vtkAnnotationLayersToSelection&); // Not implemented
  void operator=(const vtkAnnotationLayersToSelection&);   // Not implemented
};

#endif
