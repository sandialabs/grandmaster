/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
#include "vtkMTGLSelectionFilterCSG.h"

#include "vtkCellData.h"
#include "vtkCommand.h"
#include "vtkDataArray.h"
#include "vtkDirectedGraph.h"
#include "vtkUndirectedGraph.h"
#include "vtkEventForwarderCommand.h"
#include "vtkExtractSelection.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"

#include <vtkConvertSelection.h>
#include <vtkPointData.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkObjectFactory.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkSignedCharArray.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>

#include <vtksys/stl/set>
#include "vtkMTGLGraphAdapter.h"

#include <mtgl/graph_traits.hpp>
#include <mtgl/mtgl_boost_property.hpp>
// #include <mtgl/graph.h>
#include <mtgl/connection_subgraphs.hpp>
//#include <mtgl/dynamic_array.hpp>

using vtksys_stl::set;
using namespace std;
using namespace mtgl;

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()



vtkStandardNewMacro(vtkMTGLSelectionFilterCSG);


vtkMTGLSelectionFilterCSG::vtkMTGLSelectionFilterCSG()
{
  this->SetNumberOfInputPorts(2);
  this->Distance = -1;
  this->NumberOfIterations = 1;
  this->IncludeShortestPaths = false;
  this->OutputPedigreeIdSelection = true;
}


vtkMTGLSelectionFilterCSG::~vtkMTGLSelectionFilterCSG()
{
}


int vtkMTGLSelectionFilterCSG::FillInputPortInformation(int port,
                                                        vtkInformation* info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    return 1;
    }
  else if (port == 1)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  return 0;
}


void vtkMTGLSelectionFilterCSG::SetGraphConnection(vtkAlgorithmOutput* in)
{
  this->SetInputConnection(1, in);
}

void vtkMTGLSelectionFilterCSG::SetGraphData(vtkDataObject* in)
{
  this->SetInputData(1, in);
}

int vtkMTGLSelectionFilterCSG::RequestData(vtkInformation* vtkNotUsed(request),
                                           vtkInformationVector** inputVector,
                                           vtkInformationVector* outputVector)
{
  vtkSelection* input = vtkSelection::GetData(inputVector[0]);
  vtkGraph* graph = vtkGraph::SafeDownCast(vtkGraph::GetData(inputVector[1]));
  vtkSelection* output = vtkSelection::GetData(outputVector);

  // Convert the selection into a vertex-index selection
  VTK_CREATE(vtkIdTypeArray, indexArray);
  vtkConvertSelection::GetSelectedVertices(input, graph, indexArray);

  // Execute the search
  this->ExecuteCSGSearch(indexArray, graph);

  // Convert back to a pedigree id selection
  VTK_CREATE(vtkSelection, indexSelection);
  VTK_CREATE(vtkSelectionNode, node);
  indexSelection->AddNode(node);
  node->SetSelectionList(indexArray);
  node->SetFieldType(vtkSelectionNode::VERTEX);
  node->SetContentType(vtkSelectionNode::INDICES);

  vtkSmartPointer<vtkSelection> pedigreeIdSelection;
  pedigreeIdSelection.TakeReference(
    vtkConvertSelection::ToPedigreeIdSelection(indexSelection, graph)
    );
  output->DeepCopy(pedigreeIdSelection);

  return 1;
}


void vtkMTGLSelectionFilterCSG::ExecuteCSGSearch(vtkIdTypeArray* const idArr, vtkGraph* const graph)
{
  // get S and T (should be only two selected)
  if(idArr->GetNumberOfTuples()!=2)
    {
    cerr << "ERROR: Wrong # of vertices selected!" << endl;
    return;
    }

  // call S-T Search
  int s = idArr->GetValue(1);     // currently the [shift-clicked] vertex.
  int t = idArr->GetValue(0);     // currently the [clicked] vertex

  // delete any entries in current selection list
  idArr->Reset();

  assert(graph != NULL);

  // not sure of order, is s shift clicked or the clicked vertex?
  cout << "CSG: searching for path [" << s << " -?-> " << t << "]" << endl;

  int numIterations = this->NumberOfIterations;

  // Put some limits on how many iterations we can do
  if(this->NumberOfIterations < 1)
    {
    vtkWarningMacro(<< "NumberOfIterations value is < 1, using 1.");
    numIterations = 1;
    }
  else if(this->NumberOfIterations > 50)
    {
    vtkWarningMacro(<< "NumberOfIterations value is > 50, using 50.");
    numIterations = 50;
    }
  cout << "CSG: will attempt " << numIterations << " iterations" << endl;

  // Set up parameters
  int    distPastShortPath =   3;  // how far past the shortest path can we go?
  double penaltyMultiplier = 1.0;  // adjusts penalty assessed per node in paths.

  // == MTGL BEGIN ==
  if( vtkDirectedGraph::SafeDownCast( graph ) )
    {
    vtkErrorMacro(<< "MTGL Connection Subgraphs does not work correctly with directed graphs");
    //typedef vtkMTGLGraphAdapter<directedS> mtgl_graph_adapter;
    //mtgl_graph_adapter ga(*graph);
    //this->mtgl_worker(ga, idArr, s, t, numIterations, distPastShortPath, penaltyMultiplier);
    }
  else if( vtkUndirectedGraph::SafeDownCast( graph ) )
    {
    typedef vtkMTGLGraphAdapter<undirectedS> mtgl_graph_adapter;
    mtgl_graph_adapter ga(*graph);
    this->mtgl_worker(ga, idArr, s, t, numIterations, distPastShortPath, penaltyMultiplier);
    }
}



/// MTGL Worker
template<typename graph_adapter>
void vtkMTGLSelectionFilterCSG::
mtgl_worker(graph_adapter& ga, vtkIdTypeArray* idArr, int s, int t,
            int numIterations, int distPastShortPath, double penaltyMultiplier)
{
  mtgl::dynamic_array<int> vids;
  mtgl::dynamic_array<int> vidResultList;   // container for the returned vertices

  // Call the connection subgraphs routine.
  connection_subgraph<graph_adapter>
  csg(ga, s, t, vidResultList, distPastShortPath, numIterations, penaltyMultiplier);

  csg.run();

  cout << "CSG: found " << vidResultList.size() << " vertices in path." << endl;

  // Insert result entries into the selection list
  for(int i=0; i<vidResultList.size(); i++)
    {
    idArr->InsertNextValue( vidResultList[i] );
    }
}



void vtkMTGLSelectionFilterCSG::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "IncludeShortestPaths: "
     << (this->IncludeShortestPaths ? "on" : "off") << endl;
}
