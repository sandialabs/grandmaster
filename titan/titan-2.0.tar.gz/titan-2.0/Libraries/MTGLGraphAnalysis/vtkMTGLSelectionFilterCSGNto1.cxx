/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
#include "vtkMTGLSelectionFilterCSGNto1.h"
#include "vtkMTGLSelectionFilterCSG.h"

#include <vtkCellData.h>
#include <vtkCommand.h>
#include <vtkConvertSelection.h>
#include <vtkDataArray.h>
#include <vtkEventForwarderCommand.h>
#include <vtkExtractSelection.h>
#include <vtkGraph.h>
#include <vtkIdTypeArray.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkObjectFactory.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkSelectionSource.h>
#include <vtkPointData.h>
#include <vtkSmartPointer.h>
#include <vtkSortDataArray.h>

#include <vtksys/stl/set>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using vtksys_stl::set;
using namespace std;


vtkStandardNewMacro(vtkMTGLSelectionFilterCSGNto1);



vtkMTGLSelectionFilterCSGNto1::vtkMTGLSelectionFilterCSGNto1()
{
  this->SetNumberOfInputPorts(3);
  this->NumberOfIterations = 1;
  this->OutputPedigreeIdSelection = true;
}



vtkMTGLSelectionFilterCSGNto1::~vtkMTGLSelectionFilterCSGNto1()
{
}



int vtkMTGLSelectionFilterCSGNto1::FillInputPortInformation(int port, vtkInformation* info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    return 1;
    }
  if (port == 1)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    return 1;
    }
  else if (port == 2)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  return 0;
}



void vtkMTGLSelectionFilterCSGNto1::SetGraphConnection(vtkAlgorithmOutput * in)
{
  this->SetInputConnection(1, in);
}



int vtkMTGLSelectionFilterCSGNto1::RequestData(vtkInformation* vtkNotUsed(request),
                                               vtkInformationVector** inputVector,
                                               vtkInformationVector* outputVector)
{
  vtkSelection * inputSrc  = vtkSelection::GetData(inputVector[0]);
  vtkSelection * inputTgt  = vtkSelection::GetData(inputVector[1]);
  vtkGraph     * graph  = vtkGraph::GetData(inputVector[2]);
  vtkSelection * output = vtkSelection::GetData(outputVector);

  VTK_CREATE(vtkIdTypeArray, indexArraySrc);
  vtkConvertSelection::GetSelectedVertices(inputSrc, graph, indexArraySrc);

  VTK_CREATE(vtkIdTypeArray, indexArrayTgt);
  vtkConvertSelection::GetSelectedVertices(inputTgt, graph, indexArrayTgt);

  // Do a quick sanity check
  if(indexArraySrc->GetNumberOfTuples() < 1)
    {
    return 1;
    }

  if(indexArrayTgt->GetNumberOfTuples() < 1)
    {
    output->ShallowCopy(inputSrc);
    return 1;
    }
  else
    {
    // do pairwise ST searches and merge
    // results.
    double counter = 0;

    vtkIdType srcid = indexArraySrc->GetValue(0);
    for(int j=0; j<indexArrayTgt->GetNumberOfTuples(); j++)
      {
      counter += 1.0;
      vtkIdType trgid = indexArrayTgt->GetValue(j);
      //cout << "Finding S-T for pair: " << srcid << "::" << trgid << endl;

      VTK_CREATE(vtkSelectionSource, CurrentPair);
      CurrentPair->SetFieldType(vtkSelectionNode::VERTEX);
      CurrentPair->SetContentType(vtkSelectionNode::INDICES);
      CurrentPair->AddID(0, srcid);
      CurrentPair->AddID(0, trgid);

      // Create search
      VTK_CREATE(vtkMTGLSelectionFilterCSG, search);
      search->SetNumberOfIterations(this->NumberOfIterations);
      search->SetOutputPedigreeIdSelection(this->OutputPedigreeIdSelection);
      search->AddInputConnection( CurrentPair->GetOutputPort() );
      search->SetGraphData( graph );
      search->Update();

      // If we didn't get anything, just add the input points
      if(search->GetOutput()->GetNumberOfNodes()==0)
        {
        output->Union( CurrentPair->GetOutput() );
        }
      else
        {
        output->Union( search->GetOutput() );
        }
      double progress = counter / indexArrayTgt->GetNumberOfTuples();
      this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
      }
    }

  return 1;
}



void vtkMTGLSelectionFilterCSGNto1::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "OutputPedigreeIdSelection: "
     << (this->OutputPedigreeIdSelection ? "on" : "off") << endl;
}
