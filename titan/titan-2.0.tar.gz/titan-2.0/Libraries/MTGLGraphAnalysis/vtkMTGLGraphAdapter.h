/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef vtkMTGLGraphAdapter_HPP
#define vtkMTGLGraphAdapter_HPP

#include <vtkAdjacentVertexIterator.h>
#include <vtkDirectedGraph.h>
#include <vtkEdgeListIterator.h>
#include <vtkGraph.h>
#include <vtkGraphEdge.h>
#include <vtkMutableUndirectedGraph.h>
#include <vtkMutableDirectedGraph.h>
#include <vtkOutEdgeIterator.h>
#include <vtkSmartPointer.h>
#include <vtkUndirectedGraph.h>

#include <mtgl/mtgl_adapter.hpp>
#include <mtgl/dynamic_array.hpp>
//#include <mtgl/compressed_sparse_row_graph.hpp>

#include <algorithm>
#include <cassert>
#include <utility>
#include <vector>
#include <ostream>

#include <boost/shared_ptr.hpp>

//#include "vtkInfovisWin32Header.h"
//#include "titanMTGLGraphAnalysis.h"

namespace mtgl
{

typedef std::vector<vtkEdgeType> vtkMTGLEdgeList;

// forward declaration
template <typename DIRECTION>
class vtkMTGLGraphAdapter;


////////////////////////////////////////////////////////////////////////////////
// vtkMTGLEdge
//
/// Provides an MTGL-compatible representation of a single edge
///
class vtkMTGLEdge :  public mtgl::pair<vtkIdType, vtkIdType>
{
public:
  vtkMTGLEdge(vtkIdType Source, vtkIdType Target, vtkIdType Edge)
    : mtgl::pair<vtkIdType, vtkIdType>(Source, Target),
      edge(Edge)
  {
  }

  /// Returns the unique zero-based index for this edge
  vtkIdType get_id() const
  {
    return edge;
  }

private:
  vtkIdType edge;
};



///////////////////////////////////////////////////////////////////////////////
// vtkMTGLVertexIterator
//
/// Provides MTGL-compatible random-access iteration over every vertex in a graph
///
template <class size_type>
class vtkMTGLVertexIterator
{
public:
  vtkMTGLVertexIterator()
 //   : Position(-1)
  {
  }

  vtkIdType operator[](size_type i) const
  {
    return i;
  }

};



////////////////////////////////////////////////////////////////////////////////
// vtkMTGLAdjacentVertexIterator
//
/// Provides MTGL-compatible random-access iteration over the set of vertices
/// that are adjacent to vertex
template <typename vertex_descriptor, typename size_type, typename DIRECTION>
class vtkMTGLAdjacentVertexIterator
{
public:

  vtkMTGLAdjacentVertexIterator()
    : Vertex(-1)
      //,Position(-1)
      , Graph(NULL)
  {
  }

  vertex_descriptor operator[](size_type i) const
  {
    return adjacent_vertex(Vertex, i, Graph);
  }

private:

  friend class vtkMTGLGraphAdapter<DIRECTION>;

  vtkMTGLAdjacentVertexIterator(const vertex_descriptor vertex,
                                size_type position,
                                const vtkMTGLGraphAdapter<DIRECTION> * graph)
    : Vertex(vertex),
      Graph(graph)
  {
  }


  const vertex_descriptor Vertex;

  const vtkMTGLGraphAdapter<DIRECTION> * Graph;
};



////////////////////////////////////////////////////////////////////////////////
// vtkMTGLEdgeIterator
//
/// Provides MTGL-compatible random-access iteration over every edge within a graph
///
template <typename edge_descriptor, typename size_type, typename DIRECTION>
class vtkMTGLEdgeIterator
{
public:

  vtkMTGLEdgeIterator()
    : Graph(NULL)
  {
  }

  edge_descriptor operator[](size_type i) const
  {
    return get_edge(i, *Graph);
  }

private:

  friend class vtkMTGLGraphAdapter<DIRECTION>;

  vtkMTGLEdgeIterator(const vtkMTGLGraphAdapter<DIRECTION> * graph)
    : Graph(graph)
  {
  }

  const vtkMTGLGraphAdapter<DIRECTION> * Graph;
};



////////////////////////////////////////////////////////////////////////////////
// vtkMTGLOutEdgeIterator
//
/// Provides MTGL-compatible random-access iteration over the set of edges
/// incident to a vertex
template <typename vertex_t, typename size_type, typename DIRECTION>
class vtkMTGLOutEdgeIterator
{
public:

  vtkMTGLOutEdgeIterator()
    : Vertex(-1), Graph(NULL)
  {
  }

  vtkMTGLEdge operator[](size_type i) const
  {
  return out_edge(Vertex, i, *Graph);
  }

private:

  friend class vtkMTGLGraphAdapter<DIRECTION>;

  vtkMTGLOutEdgeIterator(size_type vertex,
                         const vtkMTGLGraphAdapter<DIRECTION> * graph)
    : Vertex(vertex)
      ,Graph(graph)
  {
  }

  /// Stores the vertex descriptor of the vertex we're iterating over
  vertex_t Vertex;

  const vtkMTGLGraphAdapter<DIRECTION> * Graph;
};



////////////////////////////////////////////////////////////////////////////////
// vtkMTGLTypeMap
//
/// Placeholder for an MTGL-compatible graph type map
class vtkMTGLTypeMap
  {
  public:
  };



////////////////////////////////////////////////////////////////////////////////
/// vtkMTGLGraphAdapter
///
/// Adapts a vtkGraph for use with MTGL algorithms
///
template <typename DIRECTION = directedS>
class vtkMTGLGraphAdapter
{
public:
  // vertices
  typedef vtkIdType  vertex_descriptor;

  // types
  typedef vtkIdType            size_type;
  typedef vtkMTGLTypeMap       type_map_type;
  typedef vtkGraph             graph_type;
  typedef vtkMTGLGraphAdapter  base_adapter_type;
  typedef DIRECTION            directed_category;

  // edges
  typedef vtkMTGLEdge edge_descriptor;

  // iterators

  // iterate over all entities in the graph
  typedef vtkMTGLEdgeIterator<edge_descriptor,size_type,DIRECTION> edge_iterator;
  typedef vtkMTGLVertexIterator<size_type>                         vertex_iterator;

  // iterating over neighbors
  typedef vtkMTGLAdjacentVertexIterator<vertex_descriptor,size_type,DIRECTION>  adjacency_iterator;
  typedef vtkMTGLOutEdgeIterator<vertex_descriptor,size_type,DIRECTION>         out_edge_iterator;

  // These are void until we get bidirectional adpater working...
  typedef void in_edge_iterator;
  typedef void in_adjacency_iterator;

  int directed;


  // Default constructor (empty)
  vtkMTGLGraphAdapter()
    : MutableDirectedGraph(vtkSmartPointer<vtkMutableDirectedGraph>::New()),
      Graph(0)
      ,MutableUndirectedGraph(0)
  {
    validate_direction();
    //assert(0);
  } // makes mtgl happy (but shouldn't be called)


  // Constructor
  vtkMTGLGraphAdapter(vtkGraph& graph)
    : Graph(&graph)
      ,MutableDirectedGraph(vtkMutableDirectedGraph::SafeDownCast(&graph))
      ,MutableUndirectedGraph(vtkMutableUndirectedGraph::SafeDownCast(&graph))
  {
    validate_direction();
  }


  /// Validate Directedness
  void validate_direction()
  {
    if(this->Graph)
      {
      // Make sure directedness is consistent.
      if(vtkDirectedGraph::SafeDownCast(this->Graph) &&
         !this->is_directed())
        {
        cerr << "vtkMTGLGraphAdapter: "
             << "vtkGraph is directed but vtkMTGLGraphAdapter template isn't."
             << endl;
        assert(0);
        }
      else if(vtkUndirectedGraph::SafeDownCast(this->Graph) &&
              !this->is_undirected())
        {
        cerr << "vtkMTGLGraphAdapter: "
             << "vtkGraph is undirected but vtkMTGLGraphAdapter template isn't."
             << endl;
        assert(0);
        }
      else if(this->is_bidirectional())
        {
        cerr << "vtkMTGLGraphAdapter: "
             << "Bidirectional graphs are not supported yet." << endl;
        assert(0);
        }
      }
    else if(this->MutableDirectedGraph && !this->is_directed())
      {
      cerr << "vtkMTGLGraphAdapter: "
           << "vtkGraph is directed but vtkMTGLGraphAdapter template isn't."
           << endl;
      assert(0);
      }
    else if(this->MutableUndirectedGraph && !this->is_undirected())
      {
      cerr << "vtkMTGLGraphAdapter: "
           << "vtkGraph is undirected but vtkMTGLGraphAdapter template isn't."
           << endl;
      assert(0);
      }
    else
      {
      assert(0);
      }
  }


  /// get_graph
  const vtkSmartPointer<vtkGraph> * get_graph(void)
  {
    return &Graph;
  }


  /// vertices
  vertex_iterator vertices() const
  {
    return vertex_iterator();
  }


  /// out_edges
  out_edge_iterator out_edges(const vertex_descriptor& v) const
  {
    return out_edge_iterator(v, this);
  }


  // out_edge
  edge_descriptor out_edge(const vertex_descriptor& v, const size_type i) const
  {
    vtkOutEdgeType e = Graph->GetOutEdge(v,i);
    return edge_descriptor(v, e.Target, e.Id);
  }


  // adjacent_vertices
  adjacency_iterator adjacent_vertices(const vertex_descriptor& v) const
  {
    return adjacency_iterator(v, 0, this);
  }


  // adjacent_vertex
  size_type adjacent_vertex(const vertex_descriptor& v, const size_type i) const
  {
    vtkOutEdgeType e = Graph->GetOutEdge(v,i);
    return e.Target;
  }


  /// edges
  edge_iterator edges() const
  {
    const vtkMTGLGraphAdapter * pG = this;
    return edge_iterator(pG);
  }

  /// get_edge
  edge_descriptor get_edge(const size_type i) const
  {
    return edge_descriptor(Graph->GetSourceVertex(i),Graph->GetTargetVertex(i), i);
  }


  /// out_degree
  size_type out_degree(vertex_descriptor v) const
  {
     return Graph.GetPointer()->GetOutDegree(v);
  }


  /// in_degree
  size_type in_degree(vertex_descriptor v) const
  {
    // TODO: Implement something real here.
    // return Graph.GetPointer()->GetInDegree(v);
    return 0;
  }


  /// degree
  size_type degree(vertex_descriptor v) const
  {
     return out_degree(v)+in_degree(v);
  }


  /// Directedness
  bool is_directed() const
  {
//    if(vtkDirectedGraph::SafeDownCast(this->Graph))
//      return true;
//    return false;
    return DIRECTION::is_directed();
  }


  /// is_undirected
  bool is_undirected() const
  {
//    if(vtkUndirectedGraph::SafeDownCast(this->Graph))
//      return true;
//    return false;
    return !this->is_directed();
  }


  /// is_bidirectional
  bool is_bidirectional() const
  {
    // return DIRECTION::is_bidirectional();  (TODO support this!)
    return false;     // currently not bidirectional
  }


  /// Size metrics
  size_type get_order() const
  {
    return Graph.GetPointer()->GetNumberOfVertices();
  }


  /// get_size
  size_type get_size() const
  {
    return Graph.GetPointer()->GetNumberOfEdges();
  }


  /// clear
  void clear()
  {
    // TODO: Implement something here (perhaps contingent upon a mutable graph)
    assert(0);
  }


  /// init
  void init(size_type n, size_type m, size_type *srcs, size_type *trgs)
  {
    // TODO: Need to do something with property maps, etc. ...
    if(this->MutableDirectedGraph)
      {
      for(size_type i=0; i<n; i++)
        {
        this->MutableDirectedGraph->AddVertex();
        }
      for(size_type i=0; i<m; i++)
        {
        this->MutableDirectedGraph->AddGraphEdge(srcs[i],trgs[i]);
        }
      }
    else if(this->MutableUndirectedGraph)
      {
        for(size_type i=0; i<n; i++)
        {
        this->MutableUndirectedGraph->AddVertex();
        }
      for(size_type i=0; i<m; i++)
        {
        this->MutableUndirectedGraph->AddEdge(srcs[i],trgs[i]);
        }
      }
  }


private:


  vtkMTGLGraphAdapter& operator=(const vtkMTGLGraphAdapter& rhs)
  {
    assert(0);   // not implemented
  }


  /// Helper class that magically gives us access to vtkOutEdgeIterator internals
  class PublicOutEdgeIterator : public vtkOutEdgeIterator
  {
  public:
    friend class vtkMTGLGraphAdapter;
  };


  /// Helper function that magically gives us access to vtkOutEdgeIterator internals
  static PublicOutEdgeIterator* MakePublic(vtkOutEdgeIterator* iterator)
  {
    return static_cast<PublicOutEdgeIterator*>(iterator);
  }

#if 0
  // wcm: deprecated
  /// Helper class that sorts edges by edge ID
  struct SortEdgeId
  {
    const bool operator()(const vtkEdgeType& lhs, const vtkEdgeType& rhs) const
    {
      return lhs.Id < rhs.Id;
    }
  };
#endif

  /// Stores the underlying vtkGraph object.  This smart-pointer is used for
  /// read-only access to the vtkGraph, which is always available.
  const vtkSmartPointer<vtkGraph> Graph;

  /// If the main vtkGraph is mutable and directed, this pointer will be non-NULL.
  vtkMutableDirectedGraph* const MutableDirectedGraph;

  /// If the main vtkGraph is mutable and undirected, this pointer will be non-NULL.
  vtkMutableUndirectedGraph* const MutableUndirectedGraph;

};
///
///  END  class vtkMTGLGraphAdapter
///
////////////////////////////////////////////////////////////////////////////////



/// Convenience typedef to improve readability
//typedef vtkMTGLGraphAdapter<DIRECTION> vtk_graph;

/// Convenience typedef to improve readability
//typedef graph_traits<vtk_graph> vtk_graph_traits;


/// num_vertices
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::size_type
num_vertices(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.get_order();
}


/// num_edges
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::size_type
num_edges(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.get_size();
}


/// get_vertex
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor
get_vertex(typename vtkMTGLGraphAdapter<DIRECTION>::size_type i,
           const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return i;
}


/// get_edge
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::edge_descriptor
get_edge(typename vtkMTGLGraphAdapter<DIRECTION>::size_type i,
         const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.get_edge(i);
}


/// out_degree
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::size_type
out_degree(typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor v,
           const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.out_degree(v);
}


/// in_degree
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::size_type
in_degree(typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor v,
          const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.in_degree(v);
}


/// degree
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::size_type
degree(typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor v,
       const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.degree(v);
}


/// out_edges
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::out_edge_iterator
out_edges(const typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor& v,
          const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.out_edges(v);
}


/// out_edge
template<typename DIRECTION>
inline
vtkMTGLEdge
out_edge(const typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor& v,
         const typename vtkMTGLGraphAdapter<DIRECTION>::size_type i,
         const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.out_edge(v,i);
}


/// vertices
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::vertex_iterator
vertices(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.vertices();
}


/// adjacent_vertices
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::adjacency_iterator
adjacent_vertices(typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor v,
                  const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.adjacent_vertices(v);
}

/// adjacent_vertex
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::size_type
adjacent_vertex(const typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor& v,
                const typename vtkMTGLGraphAdapter<DIRECTION>::size_type i,
                const vtkMTGLGraphAdapter<DIRECTION>* g)
{
  return g->adjacent_vertex(v,i);
}

/// edges
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::edge_iterator
edges(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.edges();
}


/// other
/*
//template<typename DIRECTION>
inline
// Not sure why, but it can't find the class if I use the templated version
// will have to get some C++ gurus to have a looksee once we're back up and
// running.
//typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor
//other(vtkMTGLGraphAdapter<DIRECTION>::edge_descriptor& e,
//      vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor& v)
vtkIdType other(const mtgl::vtkMTGLEdge& e, const vtkIdType& v)
{
  if (v == e.first)
  {
    return e.second;
  }
  else if (v == e.second)
  {
    return e.first;
  }
  else
  {
    std::cout << "error: other((" << e.first << ", " << e.second
              << "), " << e.get_id() << ")" << std::endl;
    return e.first;
  }
}
*/

template <typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor
other(
    const typename vtkMTGLGraphAdapter<DIRECTION>::edge_descriptor& e,
    const typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor& v,
    const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  if (v == e.first)
  {
    return e.second;
  }
  else if (v == e.second)
  {
    return e.first;
  }
  else
  {
    cout << "error: other((" << e.first << ", " << e.second << "), " << e.get_id() << endl;
    return e.first;
  }
}




// source
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor
source(const typename vtkMTGLGraphAdapter<DIRECTION>::edge_descriptor& e,
       const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return e.first;
}


/// target
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor
target(const typename vtkMTGLGraphAdapter<DIRECTION>::edge_descriptor& e,
       const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return e.second;
}


/// is_directed
template<typename DIRECTION>
inline
bool
is_directed(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.is_directed();
}


// is_undirected
template<typename DIRECTION>
inline
bool
is_undirected(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.is_undirected();
}


/// is_bidirectional
template<typename DIRECTION>
inline
bool
is_bidirectional(const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  return g.is_bidirectional();
}


/// in_adjacent_vertices
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::adjacency_iterator
in_adjacent_vertices(typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor v,
                     const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  assert(0);  // TODO: Implement this function.
}


/// in_edges
template<typename DIRECTION>
inline
typename vtkMTGLGraphAdapter<DIRECTION>::in_edge_iterator
in_edges(typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor v,
         const vtkMTGLGraphAdapter<DIRECTION>& g)
{
  assert(0); // TODO: Implement this function.
}


/// clear
template<typename DIRECTION>
inline
void
clear(vtkMTGLGraphAdapter<DIRECTION>& g)
{
  g.clear();
}


// init
template<typename DIRECTION>
inline
void
init(typename vtkMTGLGraphAdapter<DIRECTION>::size_type n,
     typename vtkMTGLGraphAdapter<DIRECTION>::size_type m,
     typename vtkMTGLGraphAdapter<DIRECTION>::size_type *srcs,
     typename vtkMTGLGraphAdapter<DIRECTION>::size_type *trgs,
     vtkMTGLGraphAdapter<DIRECTION>& g)
{
  g.init(n, m, srcs, trgs);
}



/// vertex_id_map
template <typename DIRECTION>
class vertex_id_map<vtkMTGLGraphAdapter<DIRECTION> > :
  public put_get_helper<typename vtkMTGLGraphAdapter<DIRECTION>::size_type,
                        vertex_id_map<vtkMTGLGraphAdapter<DIRECTION> > >
{
public:
  typedef typename vtkMTGLGraphAdapter<DIRECTION>::vertex_descriptor key_type;
  typedef typename vtkMTGLGraphAdapter<DIRECTION>::size_type value_type;

  vertex_id_map() {}
  value_type operator[] (const key_type& k) const { return k; }
};



/// edge_id_map
template <typename DIRECTION>
class edge_id_map<vtkMTGLGraphAdapter<DIRECTION> > :
  public put_get_helper<typename vtkMTGLGraphAdapter<DIRECTION>::size_type,
                        edge_id_map<vtkMTGLGraphAdapter<DIRECTION> > >
{
public:
  typedef typename vtkMTGLGraphAdapter<DIRECTION>::edge_descriptor key_type;
  typedef typename vtkMTGLGraphAdapter<DIRECTION>::size_type value_type;

  edge_id_map() {}
  value_type operator[] (const key_type& k) const { return k.get_id(); }
};



}  // end namespace MTGL

// TODO: Provide a hook to vtkMTGLGraphAdapter outside the mtgl namespace.
// typedef mtgl::MTGLGraphAdapter vtkMTGLGraphAdapter;


#endif   // vtkMTGLGraphAdapter_HPP
