/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkCommand.h"
#include "vtkGraph.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkIntArray.h"
#include "vtkFloatArray.h"
#include "vtkIdTypeArray.h"
#include "vtkMath.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"

#include <vtkConvertSelection.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkSignedCharArray.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>

#include "vtkGraphAlgorithm.h"
#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLSearchSSSPDeltastepping.h"

#include <mtgl/graph_traits.hpp>
#include <mtgl/mtgl_boost_property.hpp>
//#include <mtgl/graph.hpp>
#include <mtgl/sssp_deltastepping.hpp>
//#include <mtgl/dynamic_array.hpp>

using namespace std;
using namespace mtgl;

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()



vtkStandardNewMacro(vtkMTGLSearchSSSPDeltastepping);


vtkMTGLSearchSSSPDeltastepping::vtkMTGLSearchSSSPDeltastepping()
{
  this->OutputArrayNameVertexWeights = NULL;
  this->InputArrayNameEdgeWeights    = NULL;
  this->SetNumberOfInputPorts(2);
}



vtkMTGLSearchSSSPDeltastepping::~vtkMTGLSearchSSSPDeltastepping()
{
  // release mem
  this->SetOutputArrayNameVertexWeights(0);
  this->SetInputArrayNameEdgeWeights(0);
}



int vtkMTGLSearchSSSPDeltastepping::
FillInputPortInformation(int port, vtkInformation * info)
{
  if(port==0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  else if(port==1)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    return 1;
    }
  return 0;
}



void vtkMTGLSearchSSSPDeltastepping::SetGraphConnection(vtkAlgorithmOutput * in)
{
  this->SetInputConnection(0, in);
}



void vtkMTGLSearchSSSPDeltastepping::SetSelectionConnection(vtkAlgorithmOutput * in)
{
  this->SetInputConnection(1, in);
}



int
vtkMTGLSearchSSSPDeltastepping::
RequestData(vtkInformation        * vtkNotUsed(request),
            vtkInformationVector ** inputVector,
            vtkInformationVector  * outputVector)
{
  // get the info objects
  vtkInformation * outInfo        = outputVector->GetInformationObject(0);
  vtkGraph       * input          = vtkGraph::GetData(inputVector[0]);
  vtkSelection   * inputSelection = vtkSelection::GetData(inputVector[1]);

  // get the input and output
  vtkGraph * output = vtkGraph::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()) );

  // Do a shallow copy of the input to the output
  output->ShallowCopy(input);

  // ** note to self: check into vtkDataArray()
  //    -- encapsulates the getValue API

  // Get the input array info (hopefully edge_weights)
  vtkFloatArray * EdgeWeightArray = NULL;
  if(this->InputArrayNameEdgeWeights)
    {
      EdgeWeightArray = vtkFloatArray::SafeDownCast(input->GetEdgeData()->GetArray(this->InputArrayNameEdgeWeights) );
    }
  else
    {
      EdgeWeightArray = vtkFloatArray::SafeDownCast(input->GetEdgeData()->GetArray("edge_weights") );
    }
  assert(EdgeWeightArray);

  VTK_CREATE(vtkIdTypeArray, idArr);
  vtkConvertSelection::GetSelectedVertices(inputSelection, input, idArr);

  if(idArr->GetNumberOfTuples() != 1)
    {
    cerr << "Error: " << idArr->GetNumberOfTuples()
         << " vertex selected, needed 1" << endl;
    return(0);
    }

  // create output array for vertex-times
  VTK_CREATE(vtkFloatArray, VertexWeightArray);
  if(this->OutputArrayNameVertexWeights)
    {
    VertexWeightArray->SetName(this->OutputArrayNameVertexWeights);
    }
  else
    {
    VertexWeightArray->SetName("vertex_times");
    }
  VertexWeightArray->SetNumberOfTuples(output->GetNumberOfVertices());

  // get source vertex
  int source = idArr->GetValue(0);

  // == MTGL BEGIN ==
  if( vtkDirectedGraph::SafeDownCast( output ) )
    {
    typedef vtkMTGLGraphAdapter<directedS> graph_adapter;
    graph_adapter ga(*output);
    this->mtgl_worker(ga, VertexWeightArray, EdgeWeightArray, source);
    }
  else if (vtkUndirectedGraph::SafeDownCast( output ) )
    {
    typedef vtkMTGLGraphAdapter<undirectedS> graph_adapter;
    graph_adapter ga(*output);
    this->mtgl_worker(ga, VertexWeightArray, EdgeWeightArray, source);
    }

  // Add attribute array to the output
  output->GetVertexData()->AddArray(VertexWeightArray);

  return(1);
}

template<typename graph_adapter>
void
vtkMTGLSearchSSSPDeltastepping::
mtgl_worker(graph_adapter&  ga,
            vtkFloatArray* VertexWeightArray,
            vtkFloatArray* EdgeWeightArray,
            int source )
{
  // Extract edge weights
  double * edgeWeights = (double*)malloc(sizeof(double)*mtgl::num_edges(ga));
  for(int i=0; i<mtgl::num_edges(ga); i++)
    {
    edgeWeights[i] = EdgeWeightArray->GetValue(i);
    }

  // initialize vertexWeights array
  double * vertexWeights = (double*)malloc(sizeof(double)*mtgl::num_vertices(ga));
  for(int i=0; i<mtgl::num_vertices(ga); i++)
    {
    vertexWeights[i] = -1.0;
    }

  cout << "source vertex id: " << source << endl;

  double cs;
  sssp_deltastepping<graph_adapter,int>
    sssp_ds(ga, source, edgeWeights, &cs, vertexWeights);
  sssp_ds.run();

  // Fill the output arrays
  for(int i=0; i<mtgl::num_vertices(ga); i++)
    {
    VertexWeightArray->SetValue(i, vertexWeights[i]);
    }

  // cleanup
  free(vertexWeights);
  vertexWeights=NULL;
}




void vtkMTGLSearchSSSPDeltastepping::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "InputArrayNameEdgeWeights: "
     << (this->InputArrayNameEdgeWeights ? this->InputArrayNameEdgeWeights : "(none)")
     << endl;
  os << indent << "OutputArrayNameVertexWeights: "
     << (this->OutputArrayNameVertexWeights ? this->OutputArrayNameVertexWeights : "(none)")
     << endl;
}
