/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
#include "vtkMTGLConnectedComponents.h"

#include <iostream>

#include "vtkCellData.h"
#include "vtkCommand.h"
#include "vtkDataArray.h"
#include "vtkDirectedGraph.h"
#include "vtkUndirectedGraph.h"
#include "vtkEventForwarderCommand.h"
#include "vtkExtractSelection.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"

#include <vtkConvertSelection.h>
#include <vtkPointData.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkMTGLGraphAdapter.h>
#include <vtkObjectFactory.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkSignedCharArray.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>

#include <vtksys/stl/set>
#include "vtkMTGLGraphAdapter.h"

#include <mtgl/graph_traits.hpp>
#include <mtgl/mtgl_boost_property.hpp>
//#include <mtgl/graph.hpp>
#include <mtgl/adjacency_list.hpp>
#include <mtgl/connected_components.hpp>
#include <mtgl/dynamic_array.hpp>
#include <mtgl/xmt_hash_table.hpp>
//#include <mtgl/graph_traits.hpp>

using vtksys_stl::set;
using namespace std;
using namespace mtgl;

#define PRINT_TRACE 0
#define UNIT 1024

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkMTGLConnectedComponents);


vtkMTGLConnectedComponents::vtkMTGLConnectedComponents()
  : ComponentArrayName(0)
{
  this->SetNumberOfInputPorts(1);
  this->SetComponentArrayName("component");
}



vtkMTGLConnectedComponents::~vtkMTGLConnectedComponents()
{
  this->SetComponentArrayName(0);
}



int vtkMTGLConnectedComponents::
FillInputPortInformation(int port, vtkInformation* info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  return 0;
}



void vtkMTGLConnectedComponents::SetGraphConnection(vtkAlgorithmOutput* in)
{
  this->SetInputConnection(0, in);
}



int
vtkMTGLConnectedComponents::
RequestData(vtkInformation*        vtkNotUsed(request),
            vtkInformationVector** inputVector,
            vtkInformationVector*  outputVector)
{
  // get the input and output ...
  vtkInformation * outInfo = outputVector->GetInformationObject(0);
  vtkGraph       * input   = vtkGraph::GetData(inputVector[0]);

  // Do a shallow copy of the input to the output ...
  vtkGraph * output = vtkGraph::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));
  output->ShallowCopy(input);

  // Setup output arrays ...
  if(!(this->ComponentArrayName && strlen(this->ComponentArrayName)))
    {
    vtkErrorMacro(<< "No component array name defined.");
    return 0;
    }

  vtkIdType num_verts = output->GetNumberOfVertices();
  vtkIdType num_edges = output->GetNumberOfEdges();

  VTK_CREATE(vtkIdTypeArray, component_array);
  component_array->SetName(this->ComponentArrayName);
  component_array->SetNumberOfTuples(num_verts);

  // =====[ MTGL STUFF HERE ]=====
  if( vtkDirectedGraph::SafeDownCast( output ) )
    {
    // Directed graph
    typedef vtkMTGLGraphAdapter<directedS> mtgl_graph_adapter ;
    mtgl_graph_adapter g(*output);
    this->mtgl_worker(g, component_array);
    }
  else if( vtkUndirectedGraph::SafeDownCast( output ))
    {
    // Undirected graph
    typedef vtkMTGLGraphAdapter<undirectedS> mtgl_graph_adapter;
    mtgl_graph_adapter g(*output);
    this->mtgl_worker(g, component_array);
    }

  // Add the community array to the output graph.
  output->GetVertexData()->AddArray(component_array);

  return 1;
}


/// MTGL Worker
template<typename graph_adapter>
void vtkMTGLConnectedComponents::
mtgl_worker(graph_adapter& g, vtkIdTypeArray* component_array)
{
  typedef typename graph_adapter::vertex_descriptor vertex_t;
  typedef typename graph_adapter::size_type size_type;
  typedef array_property_map< vertex_t, vertex_id_map<graph_adapter> > component_map;

  size_type num_verts = num_vertices(g);

  vertex_t * result = new vertex_t[ num_verts ];
  component_map components(result, get(_vertex_id_map, g));
  connected_components_gcc_sv<graph_adapter, component_map> cc_gcc_sv(g, components);
  cc_gcc_sv.run();
  // Record the component map data into the vertex attribute array on output.
  for(size_type i=0; i<num_verts; i++)
    {
    component_array->SetValue(i, components[i]);
    }
  delete result;
}


void vtkMTGLConnectedComponents::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "ComponentArrayName = '" << this->ComponentArrayName << "'" << endl;
}
