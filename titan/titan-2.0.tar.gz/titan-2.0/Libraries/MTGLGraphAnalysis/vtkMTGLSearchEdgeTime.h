/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkMTGLSearchEdgeTime_h
#define __vtkMTGLSearchEdgeTime_h

#include "vtkGraphAlgorithm.h"
#include "titanMTGLGraphAnalysis.h"
//#include "vtkInfovisWin32Header.h"

class TITAN_MTGL_EXPORT vtkMTGLSearchEdgeTime : public vtkGraphAlgorithm
{
public:
  static vtkMTGLSearchEdgeTime *New();

  vtkTypeMacro(vtkMTGLSearchEdgeTime, vtkGraphAlgorithm);
  void PrintSelf(ostream & os, vtkIndent indent);

  void SetGraphConnection(vtkAlgorithmOutput *);
  void SetSelectionConnection(vtkAlgorithmOutput * in);

  /// Specify the input port (i.e., the edge-selection)
  int FillInputPortInformation(int, vtkInformation *);

  ///@{
  /// Set the output array name.  If no output array name is
  /// set then name "vertex_time" is used.
  vtkSetStringMacro(OutputArrayNameVertexTime);
  ///@}

  ///@{
  /// Set the output array name for the edge flags.
  /// If no name is specified, defaults to "edge_flag"
  vtkSetStringMacro(OutputArrayNameEdgeFlag);
  ///@}

  // set the input array name.  If no input array name is set
  // then uses "edge_time".
  vtkSetStringMacro(InputArrayNameEdgeTime);

protected:
  vtkMTGLSearchEdgeTime();
  ~vtkMTGLSearchEdgeTime();

  int RequestData(vtkInformation *,
                  vtkInformationVector **,
                  vtkInformationVector *);

private:

  char * OutputArrayNameVertexTime;
  char * OutputArrayNameEdgeFlag;
  char * InputArrayNameEdgeTime;

  vtkMTGLSearchEdgeTime(const vtkMTGLSearchEdgeTime&); // not implemented
  void operator=(const vtkMTGLSearchEdgeTime&);	     // not implemented

};

#endif
