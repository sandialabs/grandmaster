/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkMTGLSearchEdgeTime.h"

#include "vtkCommand.h"
#include "vtkGraph.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkIntArray.h"
#include "vtkIdTypeArray.h"
#include "vtkMath.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"

#include <vtkConvertSelection.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkSignedCharArray.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>

#include "vtkGraphAlgorithm.h"
#include "vtkMTGLGraphAdapter.h"
#include <mtgl/graph_traits.hpp>
#include <mtgl/mtgl_boost_property.hpp>
//#include <mtgl/graph.h>
#include <mtgl/mtgl_search_edgetime.hpp>
//#include <mtgl/dynamic_array.hpp>

using namespace std;
using namespace mtgl;

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkMTGLSearchEdgeTime);


vtkMTGLSearchEdgeTime::vtkMTGLSearchEdgeTime()
{
  //this->OutputArrayName = NULL;
  //this->InputArrayName  = NULL;
  this->OutputArrayNameVertexTime = NULL;
  this->OutputArrayNameEdgeFlag   = NULL;
  this->InputArrayNameEdgeTime    = NULL;
  this->SetNumberOfInputPorts(2);
}


vtkMTGLSearchEdgeTime::~vtkMTGLSearchEdgeTime()
{
  // release mem
  //this->SetOutputArrayName(0);
  //this->SetInputArrayName(0);
  this->SetOutputArrayNameEdgeFlag(0);
  this->SetOutputArrayNameVertexTime(0);
  this->SetInputArrayNameEdgeTime(0);
}


int vtkMTGLSearchEdgeTime::FillInputPortInformation(int port, vtkInformation * info)
{
  if(port==0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  else if(port==1)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    return 1;
    }
    return 0;
}


void vtkMTGLSearchEdgeTime::SetGraphConnection(vtkAlgorithmOutput * in)
{
  this->SetInputConnection(0, in);
}


void vtkMTGLSearchEdgeTime::SetSelectionConnection(vtkAlgorithmOutput * in)
{
  this->SetInputConnection(1, in);
}


int vtkMTGLSearchEdgeTime::RequestData(vtkInformation        * vtkNotUsed(request),
                                       vtkInformationVector ** inputVector,
                                       vtkInformationVector  * outputVector)
{
  typedef vtkMTGLGraphAdapter<directedS> mtgl_graph_adapter ;

  // get the info objects
  vtkInformation * outInfo        = outputVector->GetInformationObject(0);
  vtkGraph       * input          = vtkGraph::GetData(inputVector[0]);
  vtkSelection   * inputSelection = vtkSelection::GetData(inputVector[1]);

  // get the input and output
  vtkGraph * output = vtkGraph::SafeDownCast(outInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Do a shallow copy of the input to the output
  output->ShallowCopy(input);

  // Get the input array info (hopefully edge_time)
  vtkIntArray * EdgeTimeArray = NULL;
  if(this->InputArrayNameEdgeTime)
    {
    EdgeTimeArray = vtkIntArray::SafeDownCast(
                        input->GetEdgeData()->GetArray(this->InputArrayNameEdgeTime));
    }
  else
    {
    EdgeTimeArray = vtkIntArray::SafeDownCast(input->GetEdgeData()->GetArray("edge_time"));
    }

    // Create the edge_included output array
    vtkIntArray * EdgeIncludedarray = vtkIntArray::New();

    // Convert input selection into an index selection of edges.
    VTK_CREATE(vtkIdTypeArray, idArr);
    vtkConvertSelection::GetSelectedEdges(inputSelection, input, idArr);

    if(idArr->GetNumberOfTuples()!=1)
      {
      cerr << "Error: " << idArr->GetNumberOfTuples()
           << " edges selected, needed 1" << endl;
      return(0);
      }

    int source_edge = idArr->GetValue(0);     // for now, just using an int.

    mtgl_graph_adapter ga( *input );

    int * edgeTime  = (int*)malloc(sizeof(int)*ga.get_size() );
    int * vertTime  = (int*)malloc(sizeof(int)*ga.get_order());
    int * incEdgeId = (int*)malloc(sizeof(int)*ga.get_order());

    // fill edge time stamps
    for(int i=0; i<ga.get_size(); i++)
      {
      edgeTime[i] = EdgeTimeArray->GetValue(i);
      }

    // initialize vertTime and incEdgeId arrays
    for(int i=0; i<ga.get_order(); i++)
      {
      vertTime[i]  = 0;
      incEdgeId[i] = 0;
      }

    cout << "source edge id: " << source_edge << endl;

    mtgl_search_edgetime<mtgl_graph_adapter, int>
      sssp_etime(ga, edgeTime);

    sssp_etime.run(source_edge, vertTime, incEdgeId);

    // Create the output array for vertex-times
    vtkIntArray * VertexTimeArray = vtkIntArray::New();
    if(this->OutputArrayNameVertexTime)
      {
      VertexTimeArray->SetName(this->OutputArrayNameVertexTime);
      }
    else
      {
      VertexTimeArray->SetName("vertex_time");
      }
    VertexTimeArray->SetNumberOfTuples(output->GetNumberOfVertices());

    // Create the output array for edge-flags
    vtkIntArray * EdgeFlagArray = vtkIntArray::New();
    if(this->OutputArrayNameEdgeFlag)
      {
      EdgeFlagArray->SetName(this->OutputArrayNameEdgeFlag);
      }
    else
      {
      EdgeFlagArray->SetName("edge_flag");
      }
    EdgeFlagArray->SetNumberOfTuples(output->GetNumberOfEdges());

    // Initialize edge-flag array to 0's
    for(int i=0; i<ga.get_size(); i++)
      {
      EdgeFlagArray->SetValue(i, 0);
      }

    // Fill the output arrays
    for(int i=0; i<ga.get_order(); i++)
      {
      if(vertTime[i] == sssp_etime.INFTIME)
        {
        VertexTimeArray->SetValue(i, -1);
        }
      else
        {
        VertexTimeArray->SetValue(i, vertTime[i]);
        }

      if(incEdgeId[i] != -99)
        {
        cout << "Including " << i << endl;
        EdgeFlagArray->SetValue(incEdgeId[i], 1);
        // this needs fixing, possibly eid != eid in refactored graph???
        }
      }

    free(edgeTime);   edgeTime  = NULL;
    free(vertTime);   vertTime  = NULL;
    free(incEdgeId);  incEdgeId = NULL;

    // Add attribute array to the output
    output->GetVertexData()->AddArray(VertexTimeArray);
    VertexTimeArray->Delete();

    output->GetEdgeData()->AddArray(EdgeFlagArray);
    EdgeFlagArray->Delete();

    return(1);
}


void vtkMTGLSearchEdgeTime::PrintSelf(ostream& os, vtkIndent indent)
{
    this->Superclass::PrintSelf(os, indent);
    os << indent << "InputArrayNameEdgeTime: "
       << (this->InputArrayNameEdgeTime ? this->InputArrayNameEdgeTime : "(none)")
       << endl;
    os << indent << "OutputArrayNameVertexTime: "
       << (this->OutputArrayNameVertexTime ? this->OutputArrayNameVertexTime : "(none)")
       << endl;
    os << indent << "OutputArrayNameEdgeFlag: "
       << (this->OutputArrayNameEdgeFlag ? this->OutputArrayNameEdgeFlag : "(none)")
       << endl;
}
