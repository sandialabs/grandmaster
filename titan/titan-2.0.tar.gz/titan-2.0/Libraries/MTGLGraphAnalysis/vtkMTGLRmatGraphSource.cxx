/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifdef WIN32
#define _CRT_RAND_S
#endif

#include <iostream>

#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLRmatGraphSource.h"

#include "vtkCellData.h"
#include "vtkExecutive.h"
#include "vtkFloatArray.h"
#include "vtkGraph.h"
#include "vtkInformation.h"
#include "vtkMath.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkMutableUndirectedGraph.h"
#include "vtkIntArray.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkSmartPointer.h"

#include <mtgl/generate_rmat_graph.hpp>

#include <vtksys/stl/set>
#include <vtksys/stl/algorithm>


vtkStandardNewMacro(vtkMTGLRmatGraphSource);

using namespace std;
using namespace mtgl;

// ----------------------------------------------------------------------

vtkMTGLRmatGraphSource::vtkMTGLRmatGraphSource()
{
  this->ScaleFactor = 5;
  this->EdgeFactor = 4;
  this->Directed = 0;
  this->Seed = 1177;
  this->SetNumberOfInputPorts(0);
  this->SetNumberOfOutputPorts(1);
  this->ParamA = 0.57;
  this->ParamB = 0.19;
  this->ParamC = 0.19;
  this->ParamD = 0.05;
}

// ----------------------------------------------------------------------

vtkMTGLRmatGraphSource::~vtkMTGLRmatGraphSource()
{
}

// ----------------------------------------------------------------------

void
vtkMTGLRmatGraphSource::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Scale Factor: " << this->ScaleFactor << endl;
  os << indent << "Edge Factor : " << this->EdgeFactor << endl;
  os << indent << "Directed    : " << this->Directed << endl;
  os << indent << "Partition A probability (a0) = " << this->ParamA << endl;
  os << indent << "Partition B probability (b0) = " << this->ParamB << endl;
  os << indent << "Partition C probability (c0) = " << this->ParamC << endl;
  os << indent << "Partition D probability (d0) = " << this->ParamD << endl;
}

// ----------------------------------------------------------------------

int
vtkMTGLRmatGraphSource::RequestData( vtkInformation*,
                     vtkInformationVector**,
                     vtkInformationVector *outputVector)
{
  vtkMath::RandomSeed(this->Seed);

  vtkSmartPointer<vtkMutableDirectedGraph> dirBuilder;
  vtkSmartPointer<vtkMutableUndirectedGraph> undirBuilder;

  vtkIdType NumberOfVertices = 0;
  vtkIdType NumberOfEdges = 0;

  // Check that a0+b0+c0+d0 = 1.0
  double probTot = ParamA+ParamB+ParamC+ParamD;
  double e = 1E-5;
  if( probTot < 1.0-e || probTot > 1.0+e )
    {
    vtkErrorMacro(<<"Total edge probability a0+b0+c0+d0 = "
                  << probTot
                  << ", should be 1.0");
    return(0);
    }

  // == MTGL BEGIN ==
  if(this->Directed)
    {
    typedef vtkMTGLGraphAdapter<directedS> mtgl_graph_adapter;
    typedef mtgl_graph_adapter::size_type mtgl_size_t;

    // create a mutable graph of the appropriate type.
    dirBuilder   = vtkSmartPointer<vtkMutableDirectedGraph>::New();
    mtgl_graph_adapter graph_adapter( * dirBuilder );

//    mtgl::generate_rmat_graph<mtgl_graph_adapter>
//            grg(this->ScaleFactor, this->EdgeFactor);

    mtgl::generate_rmat_graph(graph_adapter,
                              this->ScaleFactor,
                              this->EdgeFactor,
                              this->ParamA,
                              this->ParamB,
                              this->ParamC,
                              this->ParamD);

    NumberOfVertices = mtgl::num_vertices(graph_adapter);
    NumberOfEdges    = mtgl::num_edges(graph_adapter);
    }
  else
    {
    typedef vtkMTGLGraphAdapter<undirectedS> mtgl_graph_adapter;
    typedef mtgl_graph_adapter::size_type mtgl_size_t;

    // create a mutable graph of the appropriate type.
    undirBuilder = vtkSmartPointer<vtkMutableUndirectedGraph>::New();
    mtgl_graph_adapter graph_adapter( *undirBuilder );

    mtgl::generate_rmat_graph(graph_adapter,
                              this->ScaleFactor,
                              this->EdgeFactor,
                              this->ParamA,
                              this->ParamB,
                              this->ParamC,
                              this->ParamD);

    NumberOfVertices = mtgl::num_vertices(graph_adapter);
    NumberOfEdges    = mtgl::num_edges(graph_adapter);
    }

  // == MTGL END ==

  //std::cout << "Generate Rmat Graph:" << std::endl;
  //std::cout << "NumberOfVertices = " << NumberOfVertices << std::endl;
  //std::cout << "NumberOfEdges    = " << NumberOfEdges << std::endl;

  // Create vertex Pedigree-Ids
  vtkIntArray * vertexIdArray = vtkIntArray::New();
  vertexIdArray->SetNumberOfValues(NumberOfVertices);
  for(vtkIdType i=0; i<NumberOfVertices; i++)
    {
    vertexIdArray->SetValue(i,i);
    }
  vertexIdArray->SetName("vertex id");

  // Create edge Pedigree-Ids
  vtkIntArray * edgeIdArray = vtkIntArray::New();
  edgeIdArray->SetNumberOfValues(NumberOfEdges);
  for(vtkIdType i=0; i<NumberOfEdges; i++)
    {
    edgeIdArray->SetValue(i,i);
    }
  edgeIdArray->SetName("edge id");

  // Copy the structure into the output.
  vtkGraph *output = vtkGraph::GetData(outputVector);
  if (this->Directed)
    {
    if (!output->CheckedShallowCopy(dirBuilder))
      {
      vtkErrorMacro(<<"Invalid structure.");
      return 0;
      }
    }
  else
    {
    if (!output->CheckedShallowCopy(undirBuilder))
      {
      vtkErrorMacro(<<"Invalid structure.");
      return 0;
      }
    }
  output->GetVertexData()->SetPedigreeIds( vertexIdArray );
  output->GetEdgeData()->SetPedigreeIds( edgeIdArray );
  vertexIdArray->Delete();
  edgeIdArray->Delete();
  return 1;
}



//----------------------------------------------------------------------------
int vtkMTGLRmatGraphSource::RequestDataObject( vtkInformation*,
                           vtkInformationVector**,
                           vtkInformationVector* )
{
  vtkDataObject *current = this->GetExecutive()->GetOutputData(0);
  if (!current || (this->Directed && !vtkDirectedGraph::SafeDownCast(current))
               || (!this->Directed && vtkDirectedGraph::SafeDownCast(current)))
    {
    vtkGraph *output = 0;
    if( this->Directed )
      {
      output = vtkDirectedGraph::New();
      }
    else
      {
      output = vtkUndirectedGraph::New();
      }
      this->GetExecutive()->SetOutputData(0, output);
      output->Delete();
    }
  return 1;
}
