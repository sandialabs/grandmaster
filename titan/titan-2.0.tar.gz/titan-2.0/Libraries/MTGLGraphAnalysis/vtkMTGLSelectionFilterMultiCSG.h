/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
/// \class vtkMTGLSelectionFilterMultiCSG vtkMTGLSelectionFilterMultiCSG.h <MTGLGraphAnalysis/vtkMTGLSelectionFilterMultiCSG.h>
/// \brief ...
///
///  vtkMTGLSelectionFilterMultiCSG takes a vtkSelection containing multiple
///  vertices from a vtkGraph and finds the S-T short paths between each
///  pair.  If a single node is selected then that node is returned as the
///  output selection.
///  This filter differs from the standard S-T search slightly in that if
///  selected nodes are disconnected, it will still return the selected nodes
///  in the output selection.
///  Currently, this search is somewhat brute-forceish as it just performs
///  S-T searches against the pairs of input vertices and returns the union
///  of the results.  Currently, we don't check for directed graphs and only
///  run (v^2)/2 searches where v is the number of selected vertices
///  (Assuming G is undirected, thus S-T is symmetric).
///  If the input selection only has 1 vertex we just return the input selection.
///
/// \todo
///  Add capability to detect directed graphs in the input and compute both
///  S-T and T-S for completeness.
///
/// \sa
///  vtkGraph
///  vtkMTGLSelectionFilterST
///
/// \par Thanks :
///
#ifndef __vtkMTGLSelectionFilterMultiCSG_h
#define __vtkMTGLSelectionFilterMultiCSG_h

#include "vtkSelectionAlgorithm.h"
#include "titanMTGLGraphAnalysis.h"
//#include "vtkInfovisWin32Header.h"

// Forward Declarations
class vtkGraph;

class TITAN_MTGL_EXPORT vtkMTGLSelectionFilterMultiCSG : public vtkSelectionAlgorithm
{
public:
  static vtkMTGLSelectionFilterMultiCSG * New();
  vtkTypeMacro(vtkMTGLSelectionFilterMultiCSG, vtkSelectionAlgorithm);
  void PrintSelf(ostream & os, vtkIndent indent);

  /// Convenience method for setting the graph input.
  void SetGraphConnection(vtkAlgorithmOutput * in);

  /// Specify the inputs
  int FillInputPortInformation(int port, vtkInformation * info);

  ///@{
  /// Set/Get NumberOfIterations controls the number of iterations the CSG
  /// code performs for each S-T search.
  /// If set to 1, only a single short path is returned.
  /// Each additional iteration adds an additional path, or an additional
  /// spur to an existing path.  There is no guarantee that additional paths
  /// will be found with additional iterations. Default value is 1.
  vtkSetMacro(NumberOfIterations, int);
  vtkGetMacro(NumberOfIterations, int);
  ///@}

  ///@{
  /// Set/Get whether to output a pedigree id selection
  vtkSetMacro(OutputPedigreeIdSelection, bool);
  vtkGetMacro(OutputPedigreeIdSelection, bool);
  ///@}

protected:
  vtkMTGLSelectionFilterMultiCSG();
  ~vtkMTGLSelectionFilterMultiCSG();

  int RequestData(vtkInformation *,
                  vtkInformationVector **,
                  vtkInformationVector *);

  int  NumberOfIterations;
  bool OutputPedigreeIdSelection;

private:
  vtkMTGLSelectionFilterMultiCSG(const vtkMTGLSelectionFilterMultiCSG &); // Not implemented
  void operator=(const vtkMTGLSelectionFilterMultiCSG &); // Not implemented


};
#endif
