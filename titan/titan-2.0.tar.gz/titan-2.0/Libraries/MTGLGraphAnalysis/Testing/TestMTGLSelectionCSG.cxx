/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#include "vtkAbstractArray.h"
#include "vtkMTGLSelectionFilterCSG.h"
#include "vtkRandomGraphSource.h"
#include "vtkSelectionSource.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace std;

////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLSelectionCSG(int, char** const)
int main(int argc, char* argv[])
{
try
  {
  int testFailed = false;

  // Create a random graph with edge weights
  VTK_CREATE(vtkRandomGraphSource, graph_source);
  graph_source->SetNumberOfVertices(15);
  graph_source->SetEdgeProbability(0.1);
  graph_source->UseEdgeProbabilityOn();
  graph_source->AllowParallelEdgesOn();
  graph_source->AllowSelfLoopsOn();
  graph_source->SetIncludeEdgeWeights(true);
  graph_source->SetStartWithTree(true);
  graph_source->Update();

  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST MTGL CSG Search" << endl
       << "==========================================================" << endl
       << endl;

  VTK_CREATE(vtkSelectionSource, selection);
  selection->SetFieldType(3);
  selection->SetContentType(4);
  selection->AddID(0,0);
  selection->AddID(0,9);

  VTK_CREATE(vtkMTGLSelectionFilterCSG, csg_search);
  csg_search->SetGraphConnection(graph_source->GetOutputPort());
  csg_search->SetInputConnection(0, selection->GetOutputPort());
  csg_search->SetNumberOfIterations(3);
  csg_search->Update();

  cout << "output selection size = "
       << csg_search->GetOutput()->GetNode(0)->GetSelectionList()->GetNumberOfTuples()
       << endl;

  // Create a MTGL graph adapter and link the source graph to it.
  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
