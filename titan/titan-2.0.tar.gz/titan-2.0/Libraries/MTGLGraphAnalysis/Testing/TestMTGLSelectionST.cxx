/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkMutableUndirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSelectionSource.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"
#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLSelectionFilterST.h"

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;


////////////////////////////////////////////////////////////////////////////////
///
///
void print_vtk_graph(vtkGraph * the_graph)
{
  for(int i=0; i<the_graph->GetNumberOfVertices(); i++)
    {
    printf("%5lu (%2lu) { ", (long unsigned int)i,
                             (long unsigned int)the_graph->GetOutDegree(i));
    VTK_CREATE(vtkOutEdgeIterator, outEdgeIter);
    the_graph->GetOutEdges( i, outEdgeIter );
    while(outEdgeIter->HasNext())
      {
      vtkOutEdgeType outEdge = outEdgeIter->Next();
      printf("%lu ", (long unsigned int)outEdge.Target);
      }
    printf("}\n");
    }
}



////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLSelectionST(int, char** const)
int
main(int /*argc*/, char* /*argv*/[])
{
try
  {
  int testFailed = false;

  VTK_CREATE(vtkRandomGraphSource, graph_source);
  graph_source->SetNumberOfVertices(20);
  graph_source->SetEdgeProbability(0.042);
  graph_source->UseEdgeProbabilityOn();
  graph_source->SetStartWithTree(true);
  graph_source->Update();

  // ====================================================
  // Build an undirected graph
  //
  VTK_CREATE(vtkMutableUndirectedGraph, undirected_graph);
  VTK_CREATE(vtkIdTypeArray, vertexIds);

  vertexIds->SetName("ID");

  undirected_graph->GetVertexData()->AddArray( vertexIds );
  undirected_graph->GetVertexData()->SetPedigreeIds(vertexIds);

  for(vtkIdType i=0; i<16; i++)
    {
    vertexIds->InsertNextValue(i);
    undirected_graph->AddVertex();
    }

  undirected_graph->AddGraphEdge( 0, 1 );
  undirected_graph->AddGraphEdge( 1, 2 );
  undirected_graph->AddGraphEdge( 2, 3 );
  undirected_graph->AddGraphEdge( 3, 4 );
  undirected_graph->AddGraphEdge( 1, 5 );
  undirected_graph->AddGraphEdge( 1, 6 );
  undirected_graph->AddGraphEdge( 6, 8 );
  undirected_graph->AddGraphEdge( 2, 7 );
  undirected_graph->AddGraphEdge( 2, 8 );
  undirected_graph->AddGraphEdge( 3, 9 );
  undirected_graph->AddGraphEdge( 3,10 );
  undirected_graph->AddGraphEdge( 9,11 );
  undirected_graph->AddGraphEdge( 4,11 );
  undirected_graph->AddGraphEdge( 4,12 );
  undirected_graph->AddGraphEdge( 13,14 );
  undirected_graph->AddGraphEdge( 14,15 );
  undirected_graph->AddGraphEdge( 13,15 );

  //
  //
  // ==================================================

  // ====================================================
  // Build a directed graph
  //
  VTK_CREATE(vtkMutableDirectedGraph, directed_graph);
  VTK_CREATE(vtkIdTypeArray, vertexIds_directed);

  vertexIds_directed->SetName("ID");

  directed_graph->GetVertexData()->AddArray( vertexIds_directed );
  directed_graph->GetVertexData()->SetPedigreeIds( vertexIds_directed );

  for(vtkIdType i=0; i<16; i++)
    {
    vertexIds_directed->InsertNextValue(i);
    directed_graph->AddVertex();
    }

  directed_graph->AddGraphEdge( 0, 1 );
  directed_graph->AddGraphEdge( 1, 2 );
  directed_graph->AddGraphEdge( 2, 3 );
  directed_graph->AddGraphEdge( 3, 4 );
  directed_graph->AddGraphEdge( 1, 5 );
  directed_graph->AddGraphEdge( 1, 6 );
  directed_graph->AddGraphEdge( 6, 8 );
  directed_graph->AddGraphEdge( 2, 7 );
  directed_graph->AddGraphEdge( 2, 8 );
  directed_graph->AddGraphEdge( 3, 9 );
  directed_graph->AddGraphEdge( 3,10 );
  directed_graph->AddGraphEdge( 9,11 );
  directed_graph->AddGraphEdge( 4,11 );
  directed_graph->AddGraphEdge( 4,12 );
  directed_graph->AddGraphEdge( 13,14 );
  directed_graph->AddGraphEdge( 14,15 );
  directed_graph->AddGraphEdge( 13,15 );
  //
  //
  // ==================================================


  //vtkGraph * undirected_graph = graph_source->GetOutput();

  cout << endl
       << "==========================================================" << endl
       << "==========[ Undirected Graph" << endl
       << "==========================================================" << endl
       << endl;

  print_vtk_graph(undirected_graph);

  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST MTGL ST Search" << endl
       << "==========================================================" << endl
       << endl;

  VTK_CREATE(vtkSelectionSource, selection);
  selection->SetFieldType( vtkSelectionNode::VERTEX );//3);
  //selection->SetContentType( vtkSelectionNode::INDICES );//4);
  selection->AddID(0,0);
  selection->AddID(0,9);

  VTK_CREATE(vtkMTGLSelectionFilterST, st_search);
//  st_search->SetGraphConnection(graph_source->GetOutputPort());
  st_search->SetGraphData(undirected_graph);
  st_search->SetInputConnection(0, selection->GetOutputPort());
  st_search->Update();

  int udir_size = st_search->GetOutput()->GetNode(0)->GetSelectionList()->GetNumberOfTuples();
  cout << "output selection size = " << udir_size << endl;

  if( udir_size != 5 )
    {
    cout << "ERROR: Selection size should be 5" << endl;
    testFailed = true;
    }

  cout << endl
       << "==========================================================" << endl
       << "==========[ Directed Graph" << endl
       << "==========================================================" << endl
       << endl;

  print_vtk_graph(directed_graph);

  cout << "Directed graphs are currently known to not work unless the shortest"
       << " path is contained within a strongly-connected component." << endl;

  VTK_CREATE(vtkSelectionSource, selectionD);
  selectionD->SetFieldType( vtkSelectionNode::VERTEX );
  selectionD->SetContentType( vtkSelectionNode::INDICES );
  selectionD->AddID(0,0);
  selectionD->AddID(0,9);

  VTK_CREATE(vtkMTGLSelectionFilterST, st_searchD);
  st_searchD->SetGraphData(directed_graph);
  st_searchD->SetInputConnection(0, selectionD->GetOutputPort());
  st_searchD->Update();

  int dir_size = st_searchD->GetOutput()->GetNode(0)->GetSelectionList()->GetNumberOfTuples();
  cout << "output selection size = " << dir_size << endl;

  if( dir_size != 5 )
    {
    cout << "ERROR: Selection size should be 5" << endl;
    //testFailed = true;
    }


  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
