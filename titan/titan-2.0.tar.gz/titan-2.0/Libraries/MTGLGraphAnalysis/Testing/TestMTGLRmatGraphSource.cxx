/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ostream>
#include <iostream>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSelectionSource.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"
#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLRmatGraphSource.h"

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;


////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLRmatGraphSource(int, char** const)
int main(int argc, char* argv[])
{
try
  {
  int testFailed = false;

  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST MTGL R-MAT Graph Source" << endl
       << "==========================================================" << endl
       << endl;

  VTK_CREATE(vtkMTGLRmatGraphSource, source);
  source->DirectedOff();
  source->SetScaleFactor(5);
  source->SetEdgeFactor(5);
  source->Update();

  // Print out the graph's metadata.
  source->GetOutput()->PrintSelf(cout, vtkIndent(0));

  cout << "Num Verts: " << source->GetOutput()->GetNumberOfVertices() << endl;
  cout << "Num Edges: " << source->GetOutput()->GetNumberOfEdges() << endl;

  // Check some basic information.
  vtkIdType numVerts = source->GetOutput()->GetNumberOfVertices();
  if(numVerts != 32)
    {
    cout << "ERROR: bad number of vertices, expected 32, got "
         << numVerts << endl;
    fflush(stdout);
    testFailed = true;
    }
  else
    {
    cout << "Expected 32 vertices, found 32 vertices." << endl;
    }

  // Completed.
  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
