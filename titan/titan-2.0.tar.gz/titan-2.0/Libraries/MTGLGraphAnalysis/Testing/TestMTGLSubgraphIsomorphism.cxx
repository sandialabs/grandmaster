/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <iomanip>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkMutableUndirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"

#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLSubgraphIsomorphism.h"

//#include <mtgl/graph.hpp>
//#include <mtgl/graph_traits.hpp>
#include <mtgl/mtgl_adapter.hpp>
#include <mtgl/mtgl_boost_property.hpp>

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;



template<typename graph_adapter, typename table_adapter, typename size_type>
bool test_subg_iso(graph_adapter& bigG, graph_adapter& trgG,
                   table_adapter& walk,
                   const size_type* const desired_Eresult)
{
  bool testFailed = false;

  VTK_CREATE(vtkMTGLSubgraphIsomorphism, subg_iso);
  subg_iso->SetBigGraphData( bigG );
  subg_iso->SetTargetGraphData( trgG );
  subg_iso->SetWalkTableData( walk );

  subg_iso->SetGraphVertexAttribute("vertex_color");
  subg_iso->SetGraphEdgeAttribute("edge_color");

  subg_iso->SetTargetVertexAttribute("vertex_color");
  subg_iso->SetTargetEdgeAttribute("edge_color");

  subg_iso->SetWalkTableColumnName("graph_walk");

  subg_iso->SetSubgraphComponentArrayName("subgraph");

  subg_iso->Update();

  //subg_iso->GetOutput()->PrintSelf(cout, vtkIndent(0));

  cout << "Verify Edge Markup" << endl;
  vtkIdTypeArray* Eresult = vtkIdTypeArray::SafeDownCast(subg_iso->GetOutput()->GetEdgeData()->GetArray("subgraph"));
  assert(Eresult);

  for(size_type i=0; i<bigG->GetNumberOfEdges(); i++)
    {
    cout << "edge: " << setw(-3) << i
         << ": desired: " << setw(-3) << desired_Eresult[i]
         << "  actual: " << setw(-3) << Eresult->GetValue(i);
    if(desired_Eresult[i] != Eresult->GetValue(i))
      {
      cout << "\t ERROR!";
      testFailed = true;
      }
    cout << endl;
    }

  return testFailed;
}



template<typename graph_adapter, typename size_type>
bool
build_graph(graph_adapter& Graph,
            const size_type numV,
            const size_type numE,
            const size_type* const srcs,
            const size_type* const trgs,
            const int* const vTypes,
            const int* const eTypes)
{
  bool testFailed = false;

  // =====[ Build Vertices ]=====
  VTK_CREATE(vtkIdTypeArray, vertexIdArray);
  vertexIdArray->SetName("vertex_id");
  vertexIdArray->SetNumberOfTuples(numV);

  VTK_CREATE(vtkIdTypeArray, vertexColorArray);
  vertexColorArray->SetName("vertex_color");
  vertexColorArray->SetNumberOfTuples(numV);

  for(size_type i=0; i<numV; i++)
    {
    Graph->AddVertex();
    vertexIdArray->SetValue(i,i);
    vertexColorArray->SetValue(i,vTypes[i]);
    }

  Graph->GetVertexData()->AddArray(vertexIdArray);
  Graph->GetVertexData()->AddArray(vertexColorArray);

  // =====[ Build Edges ]=====
  VTK_CREATE(vtkIdTypeArray, edgeIdArray);
  edgeIdArray->SetName("edge_id");
  edgeIdArray->SetNumberOfTuples(numE);

  VTK_CREATE(vtkIdTypeArray, edgeColorArray);
  edgeColorArray->SetName("edge_color");
  edgeColorArray->SetNumberOfTuples(numE);

  for(size_type i=0; i<numE; i++)
    {
    //cout << i << "\t( " << srcs[i] << " , " << trgs[i] << " )" << endl;
    Graph->AddGraphEdge(srcs[i], trgs[i]);
    edgeIdArray->SetValue(i, i);
    edgeColorArray->SetValue(i, eTypes[i]);
    }

  Graph->GetEdgeData()->AddArray(edgeIdArray);
  Graph->GetEdgeData()->AddArray(edgeColorArray);

  // Pedigree Ids
  Graph->GetVertexData()->SetPedigreeIds( vertexIdArray );
  Graph->GetEdgeData()->SetPedigreeIds( edgeIdArray );

  return testFailed;
}



template<typename size_type, typename TABLE>
bool create_walk_table(TABLE& tbl,
                       size_type walk_len,
                       const size_type * const walk_ids)
{
  bool testFailed = false;

  VTK_CREATE(vtkIdTypeArray, walkColumnArray);
  walkColumnArray->SetNumberOfTuples(walk_len);
  walkColumnArray->SetName("graph_walk");
  for(size_type i=0; i<walk_len; i++)
    {
    walkColumnArray->SetValue(i, walk_ids[i]);
    }

  tbl->AddColumn(walkColumnArray);

  tbl->Dump(10);

  return testFailed;
}


////////////////////////////////////////////////////////////////////////////////
///
///
void print_vtk_graph(vtkGraph * the_graph)
{
  for(int i=0; i<the_graph->GetNumberOfVertices(); i++)
    {
    printf("%5lu (%2lu) { ", (long unsigned int)i,
                             (long unsigned int)the_graph->GetOutDegree(i));
    VTK_CREATE(vtkOutEdgeIterator, outEdgeIter);
    the_graph->GetOutEdges( i, outEdgeIter );
    while(outEdgeIter->HasNext())
      {
      vtkOutEdgeType outEdge = outEdgeIter->Next();
      printf("%lu ", (long unsigned int)outEdge.Target);
      }
    printf("}\n");
    }
}


////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLGraphAdapter(int, char** const)
int
main(int /*argc*/, char * /*argv*/[])
{
try
  {
  int testFailed = false;

  typedef vtkIdType size_type;

  // =====[ SOURCE GRAPH ]=====
  const size_type num_verts_G = 6;
  const size_type num_edges_G = 7;
  size_type srcsG[num_edges_G] = { 1, 2, 1, 2, 3, 3, 4 };
  size_type trgsG[num_edges_G] = { 0, 0, 2, 3, 4, 5, 5 };

  int vTypesG[num_verts_G] = { 1, 2, 3, 2, 3, 1 };
  int eTypesG[num_edges_G] = { 1, 2, 3, 3, 3, 1, 2 };

  // =====[ TARGET GRAPH ]=====
  const size_type num_verts_T = 3;
  const size_type num_edges_T = 3;
  size_type srcsT[num_edges_T] = { 1, 2, 1 };
  size_type trgsT[num_edges_T] = { 0, 0, 2 };

  int vTypesT[num_verts_T] = { 1, 2, 3 };
  int eTypesT[num_edges_T] = { 1, 2, 3 };

  const size_type walk_len = 7;
  size_type walk_ids[walk_len] = { 0, 0, 1, 2, 2, 1, 0 };

  // Create the walk table
  VTK_CREATE(vtkTable, edgeWalkTable);
  testFailed &= create_walk_table(edgeWalkTable, walk_len, walk_ids);

  cout << "==================================================" << endl
       << " Directed Graph Test" << endl
       << "==================================================" << endl;

  const size_type directed_result[num_edges_G] = {0,0,0,-1,3,3,3};

  // Create the graphs
  VTK_CREATE(vtkMutableDirectedGraph, DbigG);
  VTK_CREATE(vtkMutableDirectedGraph, DtrgG);

  testFailed &= build_graph(DbigG, num_verts_G, num_edges_G,
                            srcsG, trgsG, vTypesG, eTypesG);

  testFailed &= build_graph(DtrgG, num_verts_T, num_edges_T,
                            srcsT, trgsT, vTypesT, eTypesT);

  print_vtk_graph(DbigG);
  cout << endl;

  //DbigG->PrintSelf(cout, vtkIndent(0));

  // Run the subgraph isomorphism routine
  testFailed &= test_subg_iso(DbigG, DtrgG, edgeWalkTable, directed_result);

  cout << "==================================================" << endl
       << " Undirected Graph Test" << endl
       << "==================================================" << endl
       << endl;

  const size_type undirected_result[num_edges_G] = {0,0,0,0,0,0,0};

  VTK_CREATE(vtkMutableUndirectedGraph, UbigG);
  VTK_CREATE(vtkMutableUndirectedGraph, UtrgG);

  testFailed &= build_graph(UbigG, num_verts_G, num_edges_G,
                            srcsG, trgsG, vTypesG, eTypesG);

  testFailed &= build_graph(UtrgG, num_verts_T, num_edges_T,
                            srcsT, trgsT, vTypesT, eTypesT);

  //UbigG->PrintSelf(cout, vtkIndent(0));

  // Run the subgraph isomorphism routine
  testFailed &= test_subg_iso(UbigG, UtrgG, edgeWalkTable, undirected_result);

  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
