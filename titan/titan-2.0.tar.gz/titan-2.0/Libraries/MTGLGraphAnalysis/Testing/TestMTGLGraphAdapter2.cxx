/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSmartPointer.h"
#include "vtkMTGLGraphAdapter.h"

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;

//#define BIDIRECTIONAL

////////////////////////////////////////////////////////////////////////////////
///
///
void print_vtk_graph(vtkGraph * the_graph)
{
  for(int i=0; i<the_graph->GetNumberOfVertices(); i++)
    {
    printf("%5lu (%2lu) { ", (long unsigned int)i,
                             (long unsigned int)the_graph->GetOutDegree(i));
    VTK_CREATE(vtkOutEdgeIterator, outEdgeIter);
    the_graph->GetOutEdges( i, outEdgeIter );
    while(outEdgeIter->HasNext())
      {
      vtkOutEdgeType outEdge = outEdgeIter->Next();
      printf("%lu ", (long unsigned int)outEdge.Target);
      }
    printf("}\n");
    }
}



////////////////////////////////////////////////////////////////////////////////
///
///
template<typename graph_adapter>
bool test_graph_direction(graph_adapter &ga)
{
  bool testFailed = false;

  cout << "==========[ TEST graph direction" << endl;
  cout << "\tis_directed      = " << is_directed(ga) << endl;
  cout << "\tis_undirected    = " << is_undirected(ga) << endl;
  cout << "\tis_bidirectional = " << is_bidirectional(ga) << endl;

  return testFailed;
}




template<typename graph_adapter>
bool test_get_vertex(graph_adapter& ga,
                     typename graph_adapter::size_type numVerts,
                     vertex_id_map<graph_adapter>& vipm,
                     edge_id_map<graph_adapter>& eipm
                     )
{
  typedef typename graph_adapter::size_type size_type;
  typedef typename graph_adapter::vertex_descriptor vertex_descriptor;

  bool testFailed = false;
  cout << "Testing get_vertex():" << endl;
  for(size_type i=0; i<numVerts; ++i)
    {
    vertex_descriptor v = get_vertex(i, ga);
    size_type vid = get(vipm, v);
    cout << "\t" << vid << ": (";

    size_type deg = degree(v,ga);
    cout << deg << ", ";

    size_type out_deg = out_degree(v,ga);
    cout << out_deg << ")";

    if(deg != out_deg)
      {
      cout << "\tERROR!";
      testFailed = true;
      }
    cout << endl;
    }
  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  cout << endl;
  return testFailed;
}


template<typename graph_adapter>
bool test_vertex_iterator_and_degree(
              graph_adapter& ga,
              typename graph_adapter::size_type order,
              vertex_id_map<graph_adapter>& vipm,
              edge_id_map<graph_adapter>& eipm
                                    )
{
  typedef typename graph_adapter::size_type size_type;
  typedef typename graph_adapter::vertex_descriptor vertex_descriptor;
  typedef typename graph_adapter::vertex_iterator   vertex_iterator;

  bool testFailed = false;
  cout << "Test vertex iterator and degree functions:" << endl;
  vertex_iterator vIter = vertices(ga);
  for(size_type i=0; i<order; ++i)
    {
    vertex_descriptor v = vIter[i];
    size_type vid = get(vipm, v);
    cout << "\t" << vid << ": (";

    size_type deg = degree(v, ga);
    cout << deg << ", ";

    size_type out_deg = out_degree(v, ga);
    cout << out_deg << ")";
    if(deg != out_deg)
      {
      cout << "\tERROR!";
      testFailed = true;
      }
    cout << endl;
    }
  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  cout << endl;

  return testFailed;
}


template<typename graph_adapter>
bool test_edge_iterator(
              graph_adapter& ga,
              typename graph_adapter::size_type size,
              vertex_id_map<graph_adapter>& vipm,
              edge_id_map<graph_adapter>& eipm
                       )
{
  typedef typename graph_adapter::size_type         size_type;
  typedef typename graph_adapter::vertex_descriptor vertex_descriptor;
  typedef typename graph_adapter::vertex_iterator   vertex_iterator;
  typedef typename graph_adapter::edge_descriptor   edge_descriptor;
  typedef typename graph_adapter::edge_iterator     edge_iterator;

  bool testFailed = false;

  cout << "Test edge iterator:" << endl;
  edge_iterator eIter = edges(ga);
  for(size_type i=0; i<size; ++i)
    {
    edge_descriptor e = eIter[i];
    size_type eid = get(eipm, e);

    vertex_descriptor src = source(e,ga);
    vertex_descriptor trg = target(e,ga);

    size_type sid = get(vipm, src);
    size_type tid = get(vipm, trg);

    cout << "\t" << eid << ": (" << sid << " -> " << tid << ")" << endl;
    }
  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  cout << endl;
  return testFailed;
}


template<typename graph_adapter>
bool test_get_edge(graph_adapter& ga,
                   typename graph_adapter::size_type size,
                   vertex_id_map<graph_adapter>& vipm,
                   edge_id_map<graph_adapter>& eipm
                   )
{
  typedef typename graph_adapter::size_type         size_type;
  typedef typename graph_adapter::vertex_descriptor vertex_descriptor;
  typedef typename graph_adapter::vertex_iterator   vertex_iterator;
  typedef typename graph_adapter::edge_descriptor   edge_descriptor;
  typedef typename graph_adapter::edge_iterator     edge_iterator;

  bool testFailed = false;

  cout << "Test get_edge():" << endl;
  for (size_type i=0; i < size; ++i)
  {
    edge_descriptor e = get_edge(i, ga);
    size_type eid = get(eipm, e);

    vertex_descriptor src = source(e, ga);
    vertex_descriptor trg = target(e, ga);

    size_type sid = get(vipm, src);
    size_type tid = get(vipm, trg);

    cout << "\t" << eid << ": (" << sid << " -> " << tid << ")" << endl;
  }
  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  cout << endl;
  return testFailed;
}


template<typename graph_adapter>
bool test_adjacent_vertex_iterator(
                   graph_adapter& ga,
                   typename graph_adapter::size_type order,
                   vertex_id_map<graph_adapter>& vipm,
                   edge_id_map<graph_adapter>& eipm
                   )
{
  typedef typename graph_adapter::size_type          size_type;
  typedef typename graph_adapter::vertex_descriptor  vertex_descriptor;
  typedef typename graph_adapter::vertex_iterator    vertex_iterator;
  typedef typename graph_adapter::edge_descriptor    edge_descriptor;
  typedef typename graph_adapter::edge_iterator      edge_iterator;
  typedef typename graph_adapter::adjacency_iterator adjacency_iterator;

  bool testFailed = false;

  cout << "Test adjacent vertex iterator:" << endl;
  vertex_iterator vIter = vertices(ga);
  for (size_type i=0; i < order; ++i)
  {
    vertex_descriptor v = vIter[i];

    size_type vid = get(vipm, v);
    cout << "\t" << vid << "  |";

    size_type out_deg = out_degree(v, ga);
    adjacency_iterator adjIter = adjacent_vertices(v, ga);
    for (size_type j=0; j < out_deg; ++j)
    {
      size_type vid2 = get(vipm, adjIter[j]);

      cout << "  " << vid2;
    }
    cout << endl;
  }
  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  cout << endl;
  return testFailed;
}

template<typename graph_adapter>
bool test_incident_edge_iterator(
    graph_adapter& ga,
    typename graph_adapter::size_type order,
    vertex_id_map<graph_adapter>& vipm,
    edge_id_map<graph_adapter>& eipm
    )
{
  typedef typename graph_adapter::size_type          size_type;
  typedef typename graph_adapter::vertex_descriptor  vertex_descriptor;
  typedef typename graph_adapter::vertex_iterator    vertex_iterator;
  typedef typename graph_adapter::edge_descriptor    edge_descriptor;
  typedef typename graph_adapter::edge_iterator      edge_iterator;
  typedef typename graph_adapter::adjacency_iterator adjacency_iterator;
  typedef typename graph_adapter::out_edge_iterator  out_edge_iterator;

  bool testFailed = false;

  cout << "Test incident edge iterator" << endl;
  vertex_iterator vIter = vertices(ga);
  for(size_type i=0; i<order; ++i)
    {
    vertex_descriptor v = vIter[i];

    size_type vid = get(vipm, v);
    cout << "\t" << vid << ":";

    size_type out_deg = out_degree(v,ga);
    out_edge_iterator oeIter = out_edges(v,ga);
    for(size_type j=0; j<out_deg; ++j)
      {
      edge_descriptor e = oeIter[j];
      size_type eid = get(eipm, e);

      vertex_descriptor src = source(e,ga);
      vertex_descriptor trg = target(e,ga);

      size_type sid = get(vipm, src);
      size_type tid = get(vipm, trg);
      cout << "  {" << eid << "}: (" << sid << " -> " << tid << ")";
      }
    cout << endl;
    }


  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  return testFailed;
}


template<typename graph_adapter>
bool test_in_adjacent_vertex_iterator(
    graph_adapter& ga,
    typename graph_adapter::size_type order,
    vertex_id_map<graph_adapter>& vipm,
    edge_id_map<graph_adapter>& eipm
    )
{
  typedef typename graph_adapter::size_type             size_type;
  typedef typename graph_adapter::vertex_descriptor     vertex_descriptor;
  typedef typename graph_adapter::edge_descriptor       edge_descriptor;
  typedef typename graph_adapter::vertex_iterator       vertex_iterator;
  typedef typename graph_adapter::adjacency_iterator    adjacency_iterator;
  typedef typename graph_adapter::in_adjacency_iterator in_adjacency_iterator;
  typedef typename graph_adapter::edge_iterator         edge_iterator;
  typedef typename graph_adapter::out_edge_iterator     out_edge_iterator;
  typedef typename graph_adapter::in_edge_iterator      in_edge_iterator;

  bool testFailed = false;
  cout << "Test in adjacent vertex iterator" << endl;

  vertex_iterator vIter = vertices(ga);
  for (size_type i=0; i < order; ++i)
   {
    vertex_descriptor v = vIter[i];

    size_type vid = get(vipm, v);
    cout << "\t" << vid;

    size_type in_deg = in_degree(v, ga);
    in_adjacency_iterator adjIter = in_adjacent_vertices(v, ga);
    for (size_type j = 0; j < in_deg; ++j)
      {
      size_type vid2 = get(vipm, adjIter[j]);
      cout << "  " << vid2;
      }
    cout << endl;
  }
  cout << endl;

  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  return testFailed;
}

template<typename graph_adapter>
bool test_in_edge_iterator(
    graph_adapter& ga,
    typename graph_adapter::size_type order,
    vertex_id_map<graph_adapter>& vipm,
    edge_id_map<graph_adapter>& eipm
    )
{
  typedef typename graph_adapter::size_type             size_type;
  typedef typename graph_adapter::vertex_descriptor     vertex_descriptor;
  typedef typename graph_adapter::edge_descriptor       edge_descriptor;
  typedef typename graph_adapter::vertex_iterator       vertex_iterator;
  typedef typename graph_adapter::adjacency_iterator    adjacency_iterator;
  typedef typename graph_adapter::in_adjacency_iterator in_adjacency_iterator;
  typedef typename graph_adapter::edge_iterator         edge_iterator;
  typedef typename graph_adapter::out_edge_iterator     out_edge_iterator;
  typedef typename graph_adapter::in_edge_iterator      in_edge_iterator;

  bool testFailed = false;
  cout << "Test in edge iterator" << endl;

  vertex_iterator vIter = vertices(ga);

  for(size_type i=0; i<order; ++i)
    {
    vertex_descriptor v = vIter[i];

    size_type vid = get(vipm, v);
    cout << "\t" << vid << ":";

    size_type in_deg = in_degree(v, ga);
    in_edge_iterator ieIter = in_edges(v,ga);
    for(size_type j=0; j<in_deg; ++j)
      {
      edge_descriptor e = ieIter[j];
      size_type eid = get(eipm, e);

      vertex_descriptor src = source(e, ga);
      vertex_descriptor trg = target(e, ga);

      size_type sid = get(vipm, src);
      size_type tid = get(vipm, trg);

      cout << "  {" << eid << "}: (" << sid << " -> " << tid << ")";
      }
    cout << endl;
    }

  if(!testFailed)
    cout << "\tOK" << endl;
  else
    cout << "\tFAIL" << endl;
  return testFailed;
}



template<typename graph_adapter>
bool
test_graph(graph_adapter& ga,
           typename graph_adapter::size_type numVerts,
           typename graph_adapter::size_type numEdges,
           typename graph_adapter::size_type* const srcs,
           typename graph_adapter::size_type* const trgs)
{
  typedef typename graph_adapter::size_type size_type;

  bool testFailed = false;

  init(numVerts,numEdges,srcs,trgs,ga);

  size_type order = num_vertices(ga);
  size_type size  = num_edges(ga);

  cout << "order: " << order << endl;
  cout << " size: " << size  << endl;

  cout << "The graph:" << endl;
  print(ga);
  cout << endl;

  cout << "Testing copy constructor" << endl;
  graph_adapter ga2(ga);
  print(ga2);
  cout << endl;

  vertex_id_map<graph_adapter> vipm = get(_vertex_id_map, ga);
  edge_id_map<graph_adapter>   eipm = get(_edge_id_map, ga);

  testFailed &= test_get_vertex(ga, numVerts, vipm, eipm);

  testFailed &= test_vertex_iterator_and_degree(ga, order, vipm, eipm);

  testFailed &= test_edge_iterator(ga, size, vipm, eipm);

  testFailed &= test_get_edge(ga, size, vipm, eipm);

  testFailed &= test_adjacent_vertex_iterator(ga,order,vipm,eipm);

  testFailed &= test_incident_edge_iterator(ga,order,vipm,eipm);

#if BIDIRECTIONAL
  testFailed &= test_in_adjacent_vertex_iterator(ga,order,vipm,eipm);

  testFailed &= test_in_edge_iterator(ga,order,vipm,eipm);
#endif

  cout << endl;
  cout << "Test is_directed:      " << is_directed(ga) << endl;
  cout << "Test is_undirected:    " << is_undirected(ga) << endl;
  cout << "Test is_bidirectional: " << is_bidirectional(ga) << endl;

  return testFailed;
}



////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLGraphAdapter(int, char** const)
int
main(int /*argc*/, char * /*argv*/[])
{
try
  {
  int testFailed = false;

  // ---------------------------------------
  // Set some MTGL typedefs
  // ---------------------------------------
  typedef vtkIdType size_type;
  typedef vtkMTGLGraphAdapter<directedS>   DirectedGraph;
  typedef vtkMTGLGraphAdapter<undirectedS> UndirectedGraph;

  // ---------------------------------------
  // Set up the MTGL graph adapter
  // ---------------------------------------
  size_type numVerts = 6;
  size_type numEdges = 8;
  size_type srcs[8] = {0,0,1,1,2,3,3,4};
  size_type trgs[8] = {1,2,2,3,4,4,5,5};

  cout << "==================================================" << endl
       << "==========[ TEST DIRECTED GRAPH" << endl
       << "==================================================" << endl;
  // Create a directed graph
  VTK_CREATE(vtkMutableDirectedGraph, mutableDirectedGraph);
  DirectedGraph mdga(*mutableDirectedGraph);

  testFailed &= test_graph(mdga,numVerts,numEdges,srcs,trgs);

  if(testFailed)
    cout << "Directed graph FAILED test(s)" << endl;
  else
    cout << "Directed graph PASSED test(s)" << endl;




  cout << "==================================================" << endl
       << "==========[ TEST UNDIRECTED GRAPH" << endl
       << "==================================================" << endl;
  // Create an undirected graph
  VTK_CREATE(vtkMutableUndirectedGraph, mutableUndirectedGraph);
  UndirectedGraph mudga(*mutableUndirectedGraph);

  testFailed &= test_graph(mudga,numVerts,numEdges,srcs,trgs);

  if(testFailed)
    cout << "Undirected graph FAILED test(s)" << endl;
  else
    cout << "Undirected graph PASSED test(s)" << endl;




  // Create a MTGL graph adapter and link the source graph to it.
  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
