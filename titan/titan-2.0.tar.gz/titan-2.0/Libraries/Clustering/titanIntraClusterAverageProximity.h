/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanIntraClusterAverageProximity titanIntraClusterAverageProximity.h <Clustering/titanIntraClusterAverageProximity.h>
/// \brief Calculate the average intra cluster proximity for each cluster
///
///  Given a set of centroids, a set of observations, a set of cluster
///  assignments, and proximity generator, compute average intra-cluster
///  proximities.
///
///  This metric assumes hard clustering.

#ifndef __titanIntraClusterAverageProximity_h
#define __titanIntraClusterAverageProximity_h

#include <cmath>
#include <iostream>
#include <boost/multi_array.hpp>

class titanIntraClusterAverageProximity
{
private:
  mutable std::vector<double> ProximityValues; /// Stores the intra-cluster average squared proximities
  mutable std::vector<size_t> Counts; /// Stores the number of observations per cluster

//  mutable bool UseProximityMatrix; /// True if the metric will attempt to use a proximity matrix
//  mutable boost::multi_array<double, 2> * ProximityMatrix; /// Reference to a proximity matrix

public:
  // If passed in with no arguments, the constructor will set
  titanIntraClusterAverageProximity()
//  :
//    UseProximityMatrix(false)
  {
  }

  /*
  titanIntraClusterAverageProximity(boost::multi_array<double, 2>* proximityMatrix) :
    ProximityMatrix(proximityMatrix), UseProximityMatrix(true)
  {
  }
*/

  template<typename CentroidContainerT,
  typename ObservationIteratorT,
  typename ClusterAssignmentMatrixT,
  typename ProximityGeneratorT,
  typename ProximityMatrixT>
  bool operator()(
      const ObservationIteratorT observation_begin,
      const ObservationIteratorT observation_end,
      const ClusterAssignmentMatrixT& cluster_assignments,
      const CentroidContainerT& centroids,
      const ProximityGeneratorT& proximity_generator,
      const ProximityMatrixT * proximity_matrix) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    if ((observation_end-observation_begin) < 0) return false;

    size_t num_observations = static_cast<size_t>(observation_end-observation_begin);

    // Setup per-cluster distance storage ...
    ProximityValues.resize(centroids.size(), 0);
    Counts.resize(centroids.size(), 0);

    double proximityValue;

    size_t observation_index = 0;
    if (!proximity_matrix)
    {
      for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
      {
        size_t cluster_index = cluster_assignments[observation_index][0];
        // minus proximity.closest_value() for similarity compatibility
        proximityValue = proximity_generator.proximity(*observation, *(centroids.begin() + cluster_index));
        ProximityValues[cluster_index] += std::pow(proximityValue, 2.0);
        Counts[cluster_index] += 1;
      }
    }
    // If the ProximityMatrix is not the correct size, throw some type of error
    else if (
        (vector_traits<ProximityMatrixT>::size(*proximity_matrix)!=num_observations) ||
        (vector_traits<typename ProximityMatrixT::value_type>::size(vector_traits<ProximityMatrixT>::get(*proximity_matrix,0))!=centroids.size()) )
    {
      std::cerr << "Incorrect Proximity Matrix size" << std::endl;
      // throw
    }
    else
    {
      for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
      {
        size_t cluster_index = cluster_assignments[observation_index][0];
        // minus proximity.closest_value() for similarity compatibility
        proximityValue = (*proximity_matrix)[observation_index][cluster_index];
        cout << "observation_index " << observation_index << endl;
        cout << "proximityValue " << proximityValue << endl;
        cout << "cluster_index " << cluster_index << endl;
        cout << "ProximityValues.size() " << ProximityValues.size() << endl;
        ProximityValues[cluster_index] += std::pow(proximityValue, 2.0);
        Counts[cluster_index] += 1;
      }
    }


    for(size_t cluster_index = 0; cluster_index != ProximityValues.size(); ++cluster_index)
    {
      if(Counts[cluster_index])
      {
        ProximityValues[cluster_index] /= Counts[cluster_index];
      }
       else
         ProximityValues[cluster_index] = proximity_generator.closest_value();
    }
    return true;
  }

  /// Returns a reference to the ProximityValues attribute
  std::vector<double> * get_proximities()
  {
    return &ProximityValues;
  }

  /// Returns a reference to the observations-per-cluster counts
  std::vector<size_t> * get_counts()
  {
    return &Counts;
  }

};

#endif
