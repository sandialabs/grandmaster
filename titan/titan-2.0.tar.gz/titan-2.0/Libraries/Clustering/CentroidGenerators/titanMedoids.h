/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanMedoids titanMedoids.h <Clustering/titanMedoids.h>
/// \brief Calculates medoids for partitional clustering
///
///  titanMedoids is a model of the CentroidGenerator concept that
///  recomputes each centroid using the medoid of the cluster.  The medoid is
///  the observation which has the lowest total intra-cluster distance. Note
///  that the number of centroids never changes using this method.
///
///  This is a naive implementation awaiting a faster remake.
///
///  This centroid generator assumes hard clustering.

#ifndef __titanMedoids_h
#define __titanMedoids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Common/titanVectorOperations.h>

#include <boost/multi_array.hpp>


class titanMedoids
{
public:
  titanMedoids()
  {
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;

    if ((observation_end-observation_begin) < 0)
      return false;


    Counts.resize(centroids.size(), 0);
    ClosestObservationIndices.resize(centroids.size(), 0);
    size_t observation_index=0;
    size_t num_observations = static_cast<size_t>(observation_end-observation_begin);

    //  Create a new ProximityMatrix if one does not exist already
    //  or if it is the wrong shape
    if (ProximityMatrix.shape()[0]!=num_observations || ProximityMatrix.shape()[1]!=num_observations)
    {
      boost::array<array_type::index,2> dims = {{num_observations, num_observations}};
      ProximityMatrix.resize(dims);

      std::fill( ProximityMatrix.data(), ProximityMatrix.data() + ProximityMatrix.num_elements(), proximity_generator.farthest_value() );

      // Set diagonal to closest value
      for (size_t row=0;row!=num_observations;++row)
      {
        ProximityMatrix[row][row] = proximity_generator.closest_value();
      }
    }

    std::vector<std::vector<size_t> > cluster_members(centroids.size());
    std::vector<std::vector<double> > proximityValuesPerObservation(centroids.size());

    double prox;
    double closest_proximity;

    // Create a list of the members of each table and count them
    for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
    {
      cluster_members[cluster_assignments[observation_index][0]].push_back(observation_index);
    }

    for (size_t i=0;i!=Counts.size();i++)
    {
      Counts[i] = cluster_members[i].size();
    }


    // For each centroid, calculate the intra-cluster proximities for each observation
    // Currently doesn't use titanRelationProximities because it is calculating
    // the proximities on a need to know basis, instead of all at once.
    if (proximity_generator.symmetric())
    {
      for (size_t centroid_index = 0; centroid_index != centroids.size(); ++centroid_index)
      {
        proximityValuesPerObservation[centroid_index].resize(Counts[centroid_index], 0);

        //Add identity values
        for (size_t row = 0; row != Counts[centroid_index]; ++row)
        {
          proximityValuesPerObservation[centroid_index][row]
              += proximity_generator.closest_value();
        }

        // Fill the any necessary values missing from the proximity matrix
        for (size_t row = 0; row != Counts[centroid_index]; ++row)
        {
          for (size_t col = row + 1; col != Counts[centroid_index]; ++col)
          {
            ObservationIteratorT sourceObservationIterator(observation_begin
                + cluster_members[centroid_index][row]);
            ObservationIteratorT targetObservationIterator(observation_begin
                + cluster_members[centroid_index][col]);

            prox = ProximityMatrix[cluster_members[centroid_index][row]][cluster_members[centroid_index][col]];

            // lazy evaluation of proximity
            if (prox == proximity_generator.farthest_value())
            {
              prox = proximity_generator.proximity(*sourceObservationIterator, *targetObservationIterator);
              ProximityMatrix[cluster_members[centroid_index][row]][cluster_members[centroid_index][col]] = prox;
              ProximityMatrix[cluster_members[centroid_index][col]][cluster_members[centroid_index][row]] = prox;
            }
            proximityValuesPerObservation[centroid_index][row] += prox;
            proximityValuesPerObservation[centroid_index][col] += prox;

          }
        }

        closest_proximity = proximity_generator.farthest_value();

        size_t closest_row = 0;
        for (size_t row = 0; row != Counts[centroid_index]; ++row)
        {
          if (proximity_generator.closer(proximityValuesPerObservation[centroid_index][row], closest_proximity))
          {
            closest_proximity
                = proximityValuesPerObservation[centroid_index][row];
            ClosestObservationIndices[centroid_index]
                = cluster_members[centroid_index][row];
            closest_row = row;
          }
        }
      }
    }
    else
    {
      for (size_t centroid_index = 0; centroid_index != centroids.size(); ++centroid_index)
      {
        proximityValuesPerObservation[centroid_index].resize(Counts[centroid_index], 0);

        //Add identity values
        for (size_t row = 0; row != Counts[centroid_index]; ++row)
        {
          proximityValuesPerObservation[centroid_index][row]
              += proximity_generator.closest_value();
        }

        // Fill the any necessary values missing from the proximity matrix
        for (size_t row = 0; row != Counts[centroid_index]; ++row)
        {
          for (size_t col = row + 1; col != Counts[centroid_index]; ++col)
          {
            ObservationIteratorT sourceObservationIterator(observation_begin
                + cluster_members[centroid_index][row]);
            ObservationIteratorT targetObservationIterator(observation_begin
                + cluster_members[centroid_index][col]);

            prox = ProximityMatrix[cluster_members[centroid_index][row]][cluster_members[centroid_index][col]];

            // lazy evaluation of proximity
            if (prox == proximity_generator.farthest_value())
            {
              prox = proximity_generator.proximity(*sourceObservationIterator, *targetObservationIterator);
              ProximityMatrix[cluster_members[centroid_index][row]][cluster_members[centroid_index][col]] = prox;
            }

            proximityValuesPerObservation[centroid_index][row] += prox;

            prox = ProximityMatrix[cluster_members[centroid_index][col]][cluster_members[centroid_index][row]];

            // lazy evaluation of proximity
            if (prox == proximity_generator.farthest_value())
            {
              prox = proximity_generator.proximity(*targetObservationIterator, *sourceObservationIterator);
              ProximityMatrix[cluster_members[centroid_index][col]][cluster_members[centroid_index][row]] = prox;
            }

            proximityValuesPerObservation[centroid_index][col] += prox;

          }
        }

        closest_proximity = proximity_generator.farthest_value();

        size_t closest_row = 0;
        for (size_t row = 0; row != Counts[centroid_index]; ++row)
        {
          if (proximity_generator.closer(proximityValuesPerObservation[centroid_index][row], closest_proximity))
          {
            closest_proximity
                = proximityValuesPerObservation[centroid_index][row];
            ClosestObservationIndices[centroid_index]
                = cluster_members[centroid_index][row];
            closest_row = row;
          }
        }
      }



    }

    for(size_t i = 0; i != centroids.size(); ++i)
    {
      vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin+ClosestObservationIndices[i]), centroids[i]);
    }


    return true;

  }

  boost::multi_array<double, 2> GetProximityMatrix()
  {
  return ProximityMatrix;
  }

  void SetProximityMatrix(boost::multi_array<double, 2> proximityMatrix)
  {
  ProximityMatrix = proximityMatrix;
  }

  std::vector<size_t> * GetClosestObservationIndices()
  {
    return &ClosestObservationIndices;
  }



private:
  typedef boost::multi_array<double, 2> array_type;
  typedef array_type::index index;
  mutable array_type ProximityMatrix;
  mutable std::vector<size_t> Counts;
  mutable std::vector<size_t> ClosestObservationIndices;

};


#endif
