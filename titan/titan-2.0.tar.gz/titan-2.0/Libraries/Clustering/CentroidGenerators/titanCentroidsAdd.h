/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanCentroidsAdd titanCentroidsAdd.h <Clustering/titanCentroidsAdd.h>
/// \brief titanCentroidsAdd is a model of the CentroidGenerator
///  concept that adds a new centroid.
///
///  titanCentroidsAdd is a model of the ClusterAdjustment
///  concept that adds a new centroid.
///
///  The default behavior is to place the new centroid in a cluster that has
///  the highest dispersion by some measure. Currently, that measure is
///  titanIntraClusterAverageSquaredProximity.
///  The addition can be constrained to a maximum number of centroids, although
///  the optional behavior/parameters of this are still under consideration.
///
///  Centroids can always be modified directly, by manually using their
///  container. This model is for automation of a specific method of centroid
///  modification.

#ifndef __titanCentroidsAdd_h
#define __titanCentroidsAdd_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Clustering/titanIntraClusterFarthestOutlier.h>
#include <algorithm>

#include <boost/multi_array.hpp>
#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>
#include <iostream>

using namespace std;

typedef boost::multi_array<double, 2> prox_matrix_type;

class titanCentroidsAdd
{
private:
  mutable size_t MaxK;  // The maximum amount of clusters allowed.
  mutable bool UseMatrix;
  mutable prox_matrix_type * ProximityMatrix;

public:
  titanCentroidsAdd()
    : MaxK(std::numeric_limits<size_t>::max()), UseMatrix(false)
  {
  }


  /// Constructor which allows the caller to set the maximum number of clusters
  /// that this class will add
  titanCentroidsAdd(size_t maxK)
    : MaxK(maxK), UseMatrix(false)
  {
  }



  /// Allows the setting of a pointer to a matrix of observation-observation
  /// proximities, useful for determining where to add a new centroid
  void set_proximity_matrix(prox_matrix_type * proximityMatrix)
  {
    UseMatrix=true;
    ProximityMatrix = proximityMatrix;
  }



  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;

    // If the number of centroids is >= MaxK then we cannot add any more
    if (centroids.size() >= this->MaxK)
      return false;

    size_t weak_cluster = 0;

    // Compute intra-cluster average squared proximities
    std::vector<double> * proximities;

    // Use intra-cluster average squared proximity as a dispersion metric.
    // If a proximity matrix has been passed in, use it. Otherwise, calculate
    // the proximities on the fly.
    titanIntraClusterAverageSquaredProximity  proximityMetric;

    if (UseMatrix)
    {
      proximityMetric.set_proximity_matrix(ProximityMatrix);
    }

    proximityMetric(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

    proximities= proximityMetric.get_proximities();

    // Find the weakest cluster (the one with the most disperse average
    // squared proximity)
    double farthest_proximity = proximity_generator.closest_value();
    size_t observation_index=0;

    for (size_t i = 0; i != (*proximities).size(); i++)
    {
      if (proximity_generator.closer(farthest_proximity, (*proximities)[i]))
      {
        farthest_proximity = (*proximities)[i];
        weak_cluster = i;
      }
    }


    // Find the first observation in the weakest cluster. It will be the new
    // centroid.
    for (size_t current_obs=1; current_obs != cluster_assignments.size(); ++current_obs)
    {
      if (vector_traits<typename ClusterAssignmentContainerT::value_type>::get(cluster_assignments[current_obs],0) == weak_cluster)
      {
        observation_index = current_obs;
        break;
      }
    }

    // Add the observation to the list of new centroids
    centroids.resize(centroids.size()+1);

    vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + observation_index), centroids[centroids.size()-1]);

    return true;
  }
};

#endif
