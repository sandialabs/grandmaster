/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanKKZCentroids titanKKZCentroids.h <Clustering/titanKKZCentroids.h>
/// \brief Generate centroids from randomly selected observations
///
/// titanKKZCentroids is a model of the ClusterAdjustment concept based on the
/// paper:
/// Katsavounidis, I., Kuo, C. and Zhang, Z., 1994. A new initialization
/// technique for generalized Lioyd iteration. IEEE Signal Process Lett. 1 10,
/// pp. 144�146.
///

#ifndef __titanKKZCentroids_h
#define __titanKKZCentroids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <boost/unordered/unordered_set.hpp>
#include <iostream>

#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <iostream>

#include <Clustering/titanRelationProximities.h>
#include <Clustering/titanRelationProximityRanking.h>

using namespace std;

class titanKKZCentroids
{
public:
  titanKKZCentroids() :
    CentroidCount(2)
  {
  }
  /// Initialize the number of random centroids to generate.
  titanKKZCentroids(const size_t centroid_count) :
    CentroidCount(centroid_count)
  {
  }

  void SetNumberOfCentroids(const size_t centroid_count)
  {
    this->CentroidCount = centroid_count;
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentMatrixT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentMatrixT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;

    const size_t num_observations = static_cast<size_t>(observation_end - observation_begin);
    if(this->CentroidCount && !num_observations)
      throw std::runtime_error("Cannot generate KKV centroids without observations.");

    centroids.resize(CentroidCount);

    // Find the observation with the largest norm
    double max_norm_value=0;
    double norm_value;
    size_t max_index=0;
    for (size_t i=0; i != num_observations; ++i)
    {
      norm_value = computeNorm(*(observation_begin+i),2);
      if (norm_value > max_norm_value)
      {
        max_index=i;
        max_norm_value = norm_value;
      }
    }

    // Assign the observation with the greatest norm to the first centroid

    vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + max_index), centroids[0]);

    // Not using titanRelationProximities here, because it currently isn't compatible
    // with calculating ranges of relations. This way, proposed by Katsavounidis et al.
    // should take the same time as one iteration of clustering.

    // Assign the remaining centroids
    double proximity;
    double farthest_proximity;
    size_t farthest_proximity_index;

    std::vector<double> closest_prox_vector(num_observations, proximity_generator.farthest_value());

    for (size_t new_centroid_index = 1; new_centroid_index != this->CentroidCount; ++new_centroid_index)
    {
      farthest_proximity = proximity_generator.closest_value();
      farthest_proximity_index = 0;

      // First get minimum distances of each observation to the existing
      // centroids
      for (size_t observation_index=0; observation_index != num_observations; ++observation_index)
      {
        if (closest_prox_vector[observation_index] == proximity_generator.closest_value())
          continue;

        // Get the proximity between the observation and the newest centroid.
        proximity = proximity_generator.proximity(*(observation_begin + observation_index),
            centroids[new_centroid_index - 1]);

        // If that proximity is closer than the stored one, update the
        // closest_prox value for that observation
        if (proximity_generator.closer(proximity, closest_prox_vector[observation_index]))
        {
          closest_prox_vector[observation_index] = proximity;
        }

        // If this newest proximity is farther than our farthest closest_prox,
        // update the farthest_proximity and farthest_index
        if (proximity_generator.closer(farthest_proximity, closest_prox_vector[observation_index]))
        {
          farthest_proximity = closest_prox_vector[observation_index];
          farthest_proximity_index = observation_index;
        }
      }
      // Assign this observation that is farthest away from all other centroids to be a new centroid
      closest_prox_vector[farthest_proximity_index] = proximity_generator.closest_value();
      vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + farthest_proximity_index), centroids[new_centroid_index]);
    }

    return true;
  }

private:
  size_t CentroidCount;
};

#endif
