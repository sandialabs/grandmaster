/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanPearsonCorrelationCoefficient titanPearsonCorrelationCoefficient.h <Clustering/titanPearsonCorrelationCoefficient.h>
/// \brief ...
///
///  titanPearsonCorrelationCoefficient is a model of the ProximityGenerator concept that
///  computes the Pearson Product Moment Correlation Coefficient.
///

#ifndef __titanPearsonCorrelationCoefficient_h
#define __titanPearsonCorrelationCoefficient_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Common/titanVectorTraits.h>

#include <cmath>
#include <vector>

class titanPearsonCorrelationCoefficient
{
public:
  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 1;
  }

  double farthest_value() const
  {
    return -1;
  }

  bool closer(const double a, const double b) const
  {
    return a > b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {

    double sumA=0, sumB=0, sumAB=0, sumA2=0, sumB2=0;
    double numerator=0;
    double denominatorA=0, denominatorB=0;

    double a_i, b_i;

    for(size_t i = 0; i < vector_traits<Observation1T>::size(a) && i < vector_traits<Observation2T>::size(b); ++i)
    {
      a_i = vector_traits<Observation1T>::get(a,i);
      b_i = vector_traits<Observation2T>::get(b,i);

      sumA+=a_i;
      sumA2+=a_i*a_i;

      sumB+=b_i;
      sumB2+=b_i*b_i;

      sumAB+=a_i*b_i;

    }

    numerator = sumAB-(sumA*sumB)/vector_traits<Observation1T>::size(a);
    denominatorA = sumA2-(sumA*sumA)/vector_traits<Observation1T>::size(a);
    denominatorB = sumB2-(sumB*sumB)/vector_traits<Observation2T>::size(b);

    if ((denominatorA < .00001) && (denominatorA > -.00001))
      return 0;
    if ((denominatorB < .00001) && (denominatorB > -.00001))
      return 0;

    return numerator/std::sqrt(denominatorA*denominatorB);
  }


  double proximity(const double a, const double b) const
  {
    return 0;
  }
};

typedef titanPearsonCorrelationCoefficient  titanPearsonCorrelationCoefficientType;



#endif
