/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanChebyshevDistance titanChebyshevDistance.h <Clustering/titanChebyshevDistance.h>
/// \brief Calculates the Chebyshev (L-infinity) distance between two
/// observations
///
///  titanChebyshevDistance is a model of the titanProximityGenerator concept. It
///  represents the L-Infinity Norm.
///

#ifndef __titanChebyshevDistance_h
#define __titanChebyshevDistance_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Common/titanVectorTraits.h>

#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

class titanChebyshevDistance
{
public:
  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 0;
  }

  double farthest_value() const
  {
    return std::numeric_limits<double>::max();
  }

  bool closer(const double a, const double b) const
  {
    return a < b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double distance = 0;
    for(size_t i = 0; i != vector_traits<Observation1T>::size(a) && i != vector_traits<Observation2T>::size(b); ++i)
      distance = std::max<double>(std::fabs(vector_traits<Observation1T>::get(a,i) - vector_traits<Observation2T>::get(b,i)), distance);
    return distance;
  }

  double proximity(const double a, const double b) const
  {
    return std::abs(a - b);
  }

};

typedef titanChebyshevDistance  titanChebyshevDistanceType;

#endif
