/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanEuclideanDistance titanEuclideanDistance.h <Clustering/titanEuclideanDistance.h>
/// \brief Calculates the Euclidean distance between two observations.
///
///  titanEuclideanDistance is a model of the ProximityGenerator concept that
///  computes Euclidean distances.
///
#ifndef __titanEuclideanDistance_h
#define __titanEuclideanDistance_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <cmath>
#include <limits>
#include <vector>

#include <Common/titanVectorTraits.h>

class titanEuclideanDistance
{
private:
  bool CalculateRoot;

public:
  titanEuclideanDistance() :
      CalculateRoot(true)
  {
  }

  titanEuclideanDistance(bool calculate_root) :
      CalculateRoot(calculate_root)
  {
  }

  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 0;
  }

  double farthest_value() const
  {
    return std::numeric_limits<double>::max();
  }

  bool closer(const double a, const double b) const
  {
    return a < b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double distance = 0;
    for (size_t i = 0;
        i < vector_traits<Observation1T>::size(a)
            && i < vector_traits<Observation2T>::size(b); ++i)
      distance += std::pow(
          vector_traits<Observation1T>::get(a, i)
              - vector_traits<Observation2T>::get(b, i), 2);

    if (this->CalculateRoot)
      return std::sqrt(distance);
    else
      return distance;
  }

  double proximity(const double& a, const double& b) const
  {
    return std::abs(a - b);
  }

};

typedef titanEuclideanDistance titanEuclideanDistanceType;

#endif
