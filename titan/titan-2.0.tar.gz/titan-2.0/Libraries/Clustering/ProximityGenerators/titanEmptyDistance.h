/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanEmptyDistance titanEmptyDistance.h <Clustering/titanEmptyDistance.h>
/// \brief ...
///
///  titanEmptyDistance is a model of the titanProximityGenerator concept
///  that does nothing. It is used as a place holder for concepts that require
///  a proximity generator
///

#ifndef __titanEmptyDistance_h
#define __titanEmptyDistance_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <vector>
#include <limits>

class titanEmptyDistance
{
public:
  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 0;
  }

  double farthest_value() const
  {
    return std::numeric_limits<double>::max();
  }

  bool closer(const double a, const double b) const
  {
    return a < b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    return 0;
  }
};

typedef titanEmptyDistance  titanEmptyDistanceType;

#endif
