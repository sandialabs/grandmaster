/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanCosineSimilarity titanCosineSimilarity.h <Clustering/titanCosineSimilarity.h>
/// \brief Cosine Similarity
///
///  titanCosineSimilarity is a model of the titanProximityGenerator concept. It
///  calculates the cosine similarity between two observations.
///
#ifndef __titanCosineSimilarity_h
#define __titanCosineSimilarity_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Common/titanVectorTraits.h>

#include <cmath>
#include <vector>

class titanCosineSimilarity
{
public:
  titanCosineSimilarity() :
    Log2Normalized(false)
  {
  }

  titanCosineSimilarity(bool log2normalized) :
      Log2Normalized(log2normalized)
  {
  }

  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 1.0;
  }

  double farthest_value() const
  {
    return -1.0;
  }

  bool closer(const double a, const double b) const
  {
    return a > b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double dotProduct = 0.0;
    double magnitudeItem1 = 0.0;
    double magnitudeItem2 = 0.0;

    for (size_t i = 0;
        i < vector_traits<Observation1T>::size(a)
            && i < vector_traits<Observation2T>::size(b); ++i)
        {
      dotProduct += vector_traits<Observation1T>::get(a, i)
          * vector_traits<Observation2T>::get(b, i);
    }

    if (this->Log2Normalized)
      return dotProduct;

    for (size_t i = 0;
        i < vector_traits<Observation1T>::size(a)
            && i < vector_traits<Observation2T>::size(b); ++i)
        {
      magnitudeItem1 += vector_traits<Observation1T>::get(a, i)
          * vector_traits<Observation1T>::get(a, i);
      magnitudeItem2 += vector_traits<Observation2T>::get(b, i)
          * vector_traits<Observation2T>::get(b, i);
    }

    magnitudeItem1 = std::sqrt(magnitudeItem1);
    magnitudeItem2 = std::sqrt(magnitudeItem2);

    if ((magnitudeItem1 * magnitudeItem2) == 0)
      return 0;
    else
      return dotProduct / (magnitudeItem1 * magnitudeItem2);
  }

  double proximity(const double a, const double b) const
  {
    if ((a * b) == 0)
      return 0;
    else
      return (a * b) / (std::sqrt(a * a) * std::sqrt(b * b));
  }

private:
  bool Log2Normalized;

};

typedef titanCosineSimilarity titanCosineSimilarityType;

#endif
