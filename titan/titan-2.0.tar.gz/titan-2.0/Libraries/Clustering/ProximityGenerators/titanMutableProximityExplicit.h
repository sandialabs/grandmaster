/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanMutableProximity titanMutableProximity.h <Clustering/ProximityGenerators/titanMutableProximity.h>
/// \brief A proximity that can be dynamically decided.
///
///  titanMutableProximity is a model of the ProximityGenerator concept that
///  can manifest as any included proximity generator. This may be at the
///  expense of speed, but can provide runtime flexibility if necessary.
///  If the desired proximity function is known ahead of time, it may be better
///  to code a specific instance which utilizes the desired proximity.
///
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Clustering/ProximityGenerators/titanMinkowskiDistance.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Clustering/ProximityGenerators/titanHellingerDistance.h>
#include <Clustering/ProximityGenerators/titanChebyshevDistance.h>
#include <Clustering/ProximityGenerators/titanManhattanDistance.h>
#include <Clustering/ProximityGenerators/titanCosineSimilarity.h>
#include <Clustering/ProximityGenerators/titanKLDivergence.h>
#include <Clustering/ProximityGenerators/titanKLDivergenceJensenShannon.h>
#include <Clustering/ProximityGenerators/titanPearsonCorrelationCoefficient.h>
#include <Clustering/ProximityGenerators/titanEmptyDistance.h>
#include <Clustering/ProximityGenerators/titanJaccardSimilarity.h>

#ifndef __titanMutableProximity_h
#define __titanMutableProximity_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <cmath>
#include <vector>

#include <iostream>

using namespace std;

class titanMutableProximity
{

private:
  titanChebyshevDistance titanChebyshevDistanceInstance;
  titanCosineSimilarity titanCosineSimilarityInstance;
  titanEuclideanDistance titanEuclideanDistanceInstance;
  titanHellingerDistance titanHellingerDistanceInstance;
  titanJaccardSimilarity titanJaccardSimilarityInstance;
  titanKLDivergence titanKLDivergenceInstance;
  titanKLDivergenceJensenShannon titanKLDivergenceJensenShannonInstance;
  titanManhattanDistance titanManhattanDistanceInstance;
  titanMinkowskiDistance titanMinkowskiDistanceInstance;
  titanPearsonCorrelationCoefficient titanPearsonCorrelationCoefficientInstance;

public:

  enum
  {
    ChebyshevDistance,
    CosineSimilarity,
    EuclideanDistance,
    HellingerDistance,
    Jaccard,
    KLDivergence,
    KLDivergenceJensenShannon,
    ManhattanDistance,
    MinkowskiDistance,
    PearsonCorrelationCoefficient,
  } ProximitySelection;


  titanMutableProximity()
  {
   ProximitySelection=EuclideanDistance;

   titanChebyshevDistanceInstance  = titanChebyshevDistance();
   titanCosineSimilarityInstance  = titanCosineSimilarity();
   titanEuclideanDistanceInstance  = titanEuclideanDistance();
   titanHellingerDistanceInstance  = titanHellingerDistance();
   titanJaccardSimilarityInstance = titanJaccardSimilarity();
   titanKLDivergenceInstance  = titanKLDivergence(2.0);
   titanKLDivergenceJensenShannonInstance  = titanKLDivergenceJensenShannon(2.0);
   titanManhattanDistanceInstance  = titanManhattanDistance();
   titanMinkowskiDistanceInstance  = titanMinkowskiDistance(2.0);
   titanPearsonCorrelationCoefficientInstance  = titanPearsonCorrelationCoefficient();
  }

  string GetProximityName()
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return "ChebyshevDistance";
    case CosineSimilarity :
      return "CosineSimilarity";
    case EuclideanDistance :
      return "EuclideanDistance";
    case HellingerDistance :
      return "Hellinger";
    case Jaccard :
      return "Jaccard";
    case KLDivergence :
      return "KLDivergence";
    case KLDivergenceJensenShannon :
      return "KLDivergenceJensenShannon";
    case ManhattanDistance :
      return "ManhattanDistance";
    case MinkowskiDistance :
      return "MinkowskiDistance";
    case PearsonCorrelationCoefficient :
      return "PearsonCorrelationCoefficient";
    default :
      return "Unknown";
    }
  }


  void SetProximityChebyshev()
  {
    ProximitySelection=ChebyshevDistance;
  }

  void SetProximityCosineSimilarity()
  {
    ProximitySelection=CosineSimilarity;
  }

  void SetProximityCosineSimilarity(bool log2normalized)
  {
    ProximitySelection=CosineSimilarity;
    titanCosineSimilarityInstance = titanCosineSimilarity(log2normalized);
  }

  void SetProximityEuclidean()
  {
    ProximitySelection=EuclideanDistance;
  }

  void SetProximityEuclidean(bool calculate_root)
  {
    ProximitySelection=EuclideanDistance;
    titanEuclideanDistanceInstance = titanEuclideanDistance(calculate_root);
  }

  void SetProximityHellinger()
  {
    ProximitySelection=HellingerDistance;
  }

  void SetProximityHellinger(bool calculate_root)
  {
    ProximitySelection=HellingerDistance;
    titanHellingerDistanceInstance = titanHellingerDistance(calculate_root);
  }

  void SetProximityJaccard()
  {
    ProximitySelection=Jaccard;
  }

  void SetProximityKLDivergence(double base)
  {
    ProximitySelection=KLDivergence;
    titanKLDivergenceInstance = titanKLDivergence(base);
  }

  void SetProximityKLDivergenceJensenShannon(double base)
  {
    ProximitySelection=KLDivergenceJensenShannon;
    titanKLDivergenceJensenShannonInstance  = titanKLDivergenceJensenShannon(base);
  }

  void SetProximityManhattan()
  {
    ProximitySelection=ManhattanDistance;
  }

  void SetProximityMinkowski(double order)
  {
    ProximitySelection=MinkowskiDistance;
    titanMinkowskiDistanceInstance  = titanMinkowskiDistance(order);
  }

  void SetProximityPearson()
  {
    ProximitySelection=PearsonCorrelationCoefficient;
  }

  double vector_norm() const
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return titanChebyshevDistanceInstance.vector_norm();
    case CosineSimilarity :
      return titanCosineSimilarityInstance.vector_norm();
    case EuclideanDistance :
      return titanEuclideanDistanceInstance.vector_norm();
    case HellingerDistance :
      return titanHellingerDistanceInstance.vector_norm();
    case Jaccard :
      return titanJaccardSimilarityInstance.vector_norm();
    case KLDivergence :
      return titanKLDivergenceInstance.vector_norm();
    case KLDivergenceJensenShannon :
      return titanKLDivergenceJensenShannonInstance.vector_norm();
    case ManhattanDistance :
      return titanManhattanDistanceInstance.vector_norm();
    case MinkowskiDistance :
      return titanMinkowskiDistanceInstance.vector_norm();
    case PearsonCorrelationCoefficient :
      return titanPearsonCorrelationCoefficientInstance.vector_norm();
    default :
      return 0;

    }
  }
  double closest_value() const
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return titanChebyshevDistanceInstance.closest_value();
    case CosineSimilarity :
      return titanCosineSimilarityInstance.closest_value();
    case EuclideanDistance :
      return titanEuclideanDistanceInstance.closest_value();
    case HellingerDistance :
      return titanHellingerDistanceInstance.closest_value();
    case Jaccard :
      return titanJaccardSimilarityInstance.closest_value();
    case KLDivergence :
      return titanKLDivergenceInstance.closest_value();
    case KLDivergenceJensenShannon :
      return titanKLDivergenceJensenShannonInstance.closest_value();
    case ManhattanDistance :
      return titanManhattanDistanceInstance.closest_value();
    case MinkowskiDistance :
      return titanMinkowskiDistanceInstance.closest_value();
    case PearsonCorrelationCoefficient :
      return titanPearsonCorrelationCoefficientInstance.closest_value();
    default :
      return 0;
    }
  }

  double farthest_value() const
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return titanChebyshevDistanceInstance.farthest_value();
    case CosineSimilarity :
      return titanCosineSimilarityInstance.farthest_value();
    case EuclideanDistance :
      return titanEuclideanDistanceInstance.farthest_value();
    case HellingerDistance :
      return titanHellingerDistanceInstance.farthest_value();
    case Jaccard :
      return titanJaccardSimilarityInstance.farthest_value();
    case KLDivergence :
      return titanKLDivergenceInstance.farthest_value();
    case KLDivergenceJensenShannon :
      return titanKLDivergenceJensenShannonInstance.farthest_value();
    case ManhattanDistance :
      return titanManhattanDistanceInstance.farthest_value();
    case MinkowskiDistance :
      return titanMinkowskiDistanceInstance.farthest_value();
    case PearsonCorrelationCoefficient :
      return titanPearsonCorrelationCoefficientInstance.farthest_value();
    default :
      return 0;
    }
  }

  bool closer(const double a, const double b) const
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return titanChebyshevDistanceInstance.closer(a,b);
    case CosineSimilarity :
      return titanCosineSimilarityInstance.closer(a,b);
    case EuclideanDistance :
      return titanEuclideanDistanceInstance.closer(a,b);
    case HellingerDistance :
      return titanHellingerDistanceInstance.closer(a,b);
    case Jaccard :
      return titanJaccardSimilarityInstance.closer(a,b);
    case KLDivergence :
      return titanKLDivergenceInstance.closer(a,b);
    case KLDivergenceJensenShannon :
      return titanKLDivergenceJensenShannonInstance.closer(a,b);
    case ManhattanDistance :
      return titanManhattanDistanceInstance.closer(a,b);
    case MinkowskiDistance :
      return titanMinkowskiDistanceInstance.closer(a,b);
    case PearsonCorrelationCoefficient :
      return titanPearsonCorrelationCoefficientInstance.closer(a,b);
    default :
      return false;
    }
  }

  bool symmetric() const
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return titanChebyshevDistanceInstance.symmetric();
    case CosineSimilarity :
      return titanCosineSimilarityInstance.symmetric();
    case EuclideanDistance :
      return titanEuclideanDistanceInstance.symmetric();
    case HellingerDistance :
      return titanHellingerDistanceInstance.symmetric();
    case Jaccard :
      return titanJaccardSimilarityInstance.symmetric();
    case KLDivergence :
      return titanKLDivergenceInstance.symmetric();
    case KLDivergenceJensenShannon :
      return titanKLDivergenceJensenShannonInstance.symmetric();
    case ManhattanDistance :
      return titanManhattanDistanceInstance.symmetric();
    case MinkowskiDistance :
      return titanMinkowskiDistanceInstance.symmetric();
    case PearsonCorrelationCoefficient :
      return titanPearsonCorrelationCoefficientInstance.symmetric();
    default :
      return 0;
    }

  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    switch (ProximitySelection)
    {
    case ChebyshevDistance :
      return titanChebyshevDistanceInstance.proximity(a,b);
    case CosineSimilarity :
      return titanCosineSimilarityInstance.proximity(a,b);
    case EuclideanDistance :
      return titanEuclideanDistanceInstance.proximity(a,b);
    case HellingerDistance :
      return titanHellingerDistanceInstance.proximity(a,b);
    case Jaccard :
      return titanJaccardSimilarityInstance.proximity(a,b);
    case KLDivergence :
      return titanKLDivergenceInstance.proximity(a,b);
    case KLDivergenceJensenShannon :
      return titanKLDivergenceJensenShannonInstance.proximity(a,b);
    case ManhattanDistance :
      return titanManhattanDistanceInstance.proximity(a,b);
    case MinkowskiDistance :
      return titanMinkowskiDistanceInstance.proximity(a,b);
    case PearsonCorrelationCoefficient :
      return titanPearsonCorrelationCoefficientInstance.proximity(a,b);
    default :
      return 0; //TODO throw appropriate exception?
    }
  }
};

typedef titanMutableProximity  titanMutableProximityType;

#endif
