/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanIntraClusterFarthestOutlier titanIntraClusterFarthestOutlier.h <Clustering/titanIntraClusterFarthestOutlier.h>
/// \brief Computes the farthest outlier for each cluster
///
///  Given a set of centroids, a set of observations, a set of cluster
///  assignments, and proximity generator, compute the farthest outlier for
///  each cluster.
///
///  This metric assumes hard clustering.

#ifndef __titanIntraClusterFarthestOutlier_h
#define __titanIntraClusterFarthestOutlier_h

#include <iostream>

class titanIntraClusterFarthestOutlier
{
private:
  mutable std::vector<double> ProximityValues; /// Stores the intra-cluster average squared proximities
  mutable std::vector<size_t> Outliers; /// Stores the farthest outlier for each cluster

  mutable boost::multi_array<double, 2> * ProximityMatrix; /// Reference to a proximity matrix
  mutable bool UseProximityMatrix; /// True if the metric will attempt to use a proximity matrix

public:
  // If passed in with no arguments, the constructor will set
  titanIntraClusterFarthestOutlier() :
    UseProximityMatrix(false)
  {
  }

  titanIntraClusterFarthestOutlier(boost::multi_array<double, 2>* proximityMatrix) :
    ProximityMatrix(proximityMatrix), UseProximityMatrix(true)
  {
  }

  template<typename CentroidContainerT,
  typename ObservationIteratorT,
  typename ClusterAssignmentMatrixT,
  typename ProximityGeneratorT>
  bool operator()(
      const ObservationIteratorT observation_begin,
      const ObservationIteratorT observation_end,
      const ClusterAssignmentMatrixT& cluster_assignments,
      const CentroidContainerT& centroids,
      const ProximityGeneratorT& proximity_generator) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    if ((observation_end-observation_begin) < 0)
      return false;

    size_t num_observations = static_cast<size_t>(observation_end-observation_begin);

    // Setup per-cluster distance storage ...
    // Note, initializing proximity_values to proximity.closest_value(), because this is not
    // an aggregation
    ProximityValues.resize(centroids.size(), proximity_generator.closest_value());
    Outliers.resize(centroids.size(),0);

    double proximityValue;

    size_t observation_index = 0;

    // Iterate through the observations, finding the farthest outlier for each
    // cluster
    if (!this->UseProximityMatrix)
    {
      for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
      {
        size_t cluster_index = cluster_assignments[observation_index][0];
        proximityValue = proximity_generator.proximity(*observation, *(centroids.begin() + cluster_index));
        if (proximity_generator.closer(ProximityValues[cluster_index],proximityValue))
        {
          ProximityValues[cluster_index]=proximityValue;
          Outliers[cluster_index]=observation_index;
        }
      }
    }
    // If the ProximityMatrix is not the correct size, throw some type of error
    else if (
        (ProximityMatrix->shape()[0]!=num_observations) ||
        (ProximityMatrix->shape()[1]!=centroids.size()) )
    {
      std::cerr << "Incorrect Proximity Matrix size" << std::endl;
      // throw
    }
    else
    {
      for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
      {
        size_t cluster_index = cluster_assignments[observation_index][0];
        proximityValue = (*ProximityMatrix)[observation_index][cluster_index];
        if (proximity_generator.closer(ProximityValues[cluster_index],proximityValue))
        {
          ProximityValues[cluster_index]=proximityValue;
          Outliers[cluster_index]=observation_index;
        }
      }

    }

    return true;
  }


  /// Sets the reference to the proximity matrix to use for calculations.
  void set_proximity_matrix(boost::multi_array<double, 2> * proximityMatrix)
  {
    UseProximityMatrix = true;
    ProximityMatrix = proximityMatrix;
  }

  /// Returns a reference to the ProximityValues attribute
  std::vector<double> * get_proximities()
  {
    return &ProximityValues;
  }

  /// Returns a reference to the observations-per-cluster counts
  std::vector<size_t> * get_outliers()
  {
    return &Outliers;
  }

};

#endif
