/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanClusterLinkageSingle titanClusterLinkageSingle.h <Clustering/titanClusterLinkageSingle.h>
/// \brief Return the closest proximity between two clusters
///
///  titanClusterLinkageSingle is a model of the titanClusterLinkage concept. It
///  uses the proximity of the closest two observations between the clusters.
///

#ifndef __titanClusterLinkageSingle_h
#define __titanClusterLinkageSingle_h

#include <Clustering/Linkages/titanClusterLinkage.h>
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <boost/progress.hpp>
#include <algorithm>


class titanClusterLinkageSingle
{
public:
  template<typename ProximityGeneratorT, typename ProximityMatrixT>
  void operator() (
    const ProximityGeneratorT proximity_generator,
    ProximityMatrixT& proximity_matrix,
    std::vector<size_t>& orphanClusterIds,
    size_t target_cluster_id,
    size_t first_cluster_id,
    size_t second_cluster_id,
    size_t& closest_orphan_id,
    double& closest_prox_value,
    std::vector<size_t>& leafMemberCount)
  {
    double proximity_value;
    size_t orphan_id;

    closest_prox_value = proximity_generator.farthest_value();

    // Skipping non-orphan calculations
    for (size_t orphan_index=0; orphan_index != orphanClusterIds.size(); ++ orphan_index)
    {
      orphan_id=orphanClusterIds[orphan_index];

      // Single linkage -
      //    The proximity of two clusters is equal to the proximity of
      //    their closest elements
      if (proximity_generator.closer(
          proximity_matrix[orphan_id][first_cluster_id],
          proximity_matrix[orphan_id][second_cluster_id]))
        proximity_value = proximity_matrix[orphan_id][first_cluster_id];
      else
        proximity_value = proximity_matrix[orphan_id][second_cluster_id];

      // Update proximities for our new cluster
      proximity_matrix[orphan_id][target_cluster_id]=proximity_value;
      proximity_matrix[target_cluster_id][orphan_id]=proximity_value;

      // Keep tabs on the closest orphan to our new cluster
      if (proximity_generator.closer(proximity_value,closest_prox_value))
      {
        closest_prox_value = proximity_value;
        closest_orphan_id = orphan_id;
      }

    }

    return;
  }
};

#endif
