/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanClusterLinkage titanClusterLinkage.h <Clustering/titanClusterLinkage.h>
/// \brief ...
///
///  titanClusterLinkage is a concept for calculating the proximity between two
///  clusters. It takes as parameters two cluster ids, the leaf members of each
///  cluster, an iterator pointing to the first observation amongs all (of any
///  cluster), and a proximity generator.
///

// Notation:
//
//   G - A type that is a model of ClusterLinkage.
//   O - A type of Observation iterator.
//   P - A type that is a model of ProximityGenerator.
//
//   g - Object of type G.
//   a - the cluster id of the first cluster
//   b - the cluster id of the second cluster
//   l - a vector of vectors of unsigned int, the first dimension representing
//        the leaf members of a, and the second representing the leaf members
//        of b
//   o - the beginning of O
//   p - Object of type P.
//
// Valid Expressions:
//
//   g(a, b, l, o, p)


#ifndef __titanClusterLinkage_h
#define __titanClusterLinkage_h

#endif
