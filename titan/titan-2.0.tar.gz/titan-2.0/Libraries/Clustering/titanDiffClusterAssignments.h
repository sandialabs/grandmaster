/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanDiffClusterAssignments titanDiffClusterAssignments.h <Clustering/titanDiffClusterAssignments.h>
/// \brief Generates diff statistics between a pair of assignment vectors
///
///  titanDiffClusterAssignments is a class that compares the old assignments
///  to the new assignments, generating statistics on the differences. This is
///  useful for termination control and other types of algorithm manipulations.
///

#ifndef __titanDiffClusterAssignments_h
#define __titanDiffClusterAssignments_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <algorithm>
#include <vector>
#include <stdlib.h>
#include <iostream>

#include <boost/multi_array.hpp>
#include <boost/unordered/unordered_set.hpp>
#include <Common/titanVectorTraits.h>

class titanDiffClusterAssignments
{
private:
  mutable boost::unordered_set<size_t> ChangedAssignments;
  mutable boost::unordered_set<size_t> ChangedClusters;
  mutable std::vector<size_t> ClusterSizeDifferences;
public:
  titanDiffClusterAssignments()
  {
  }

  /// Returns a pointer to the list of cluster size differences
  std::vector<size_t> * getClusterSizeDifferences()
  {
    return &ClusterSizeDifferences;
  }

  /// Returns a pointer to the list of observation IDs for observations which
  /// have changed assignment.
  boost::unordered_set<size_t>* getChangedAssignments()
  {
    return &ChangedAssignments;
  }

  /// Returns a pointer to the list of cluster IDs which have changed
  /// assignment.
  boost::unordered_set<size_t>* getChangedClusters()
  {
    return &ChangedClusters;
  }

  template<
    typename ClusterAssignmentContainerT,
    typename CentroidContainerT>
    bool operator()(
    ClusterAssignmentContainerT& old_cluster_assignments,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids
    ) const
  {
    // clear any former statistics
    this->ChangedAssignments.clear();
    this->ChangedClusters.clear();

    this->ClusterSizeDifferences.resize(centroids.size());
    std::fill(this->ClusterSizeDifferences.begin(),this->ClusterSizeDifferences.end(),0);


    // If the dimensions of the old and new assignments are the same, we can
    // proceed with valid comparisons
    if (cluster_assignments.size() == old_cluster_assignments.size())
    {
      for (size_t i=0; i < cluster_assignments.size(); i++)
      {
        // Check to see if the old and new assignment for observation i are the
        // same. If not, note the differences.
        if (!vector_compare<typename ClusterAssignmentContainerT::value_type, typename ClusterAssignmentContainerT::value_type>::equal(cluster_assignments[i], old_cluster_assignments[i]))
        {
          // The assignment for observation i has changed
          this->ChangedAssignments.insert(i);

          // The new and old clusters for observation i have changed
          this->ChangedClusters.insert(cluster_assignments[i][0]);
          this->ChangedClusters.insert(old_cluster_assignments[i][0]);

          // Adjust the sizes of the new and old clusters
          this->ClusterSizeDifferences[cluster_assignments[i][0]] += 1;
          this->ClusterSizeDifferences[old_cluster_assignments[i][0]] -= 1;
        }
      }

    }
    // Otherwise, comparisons may be invalid, so just regard everything as a
    // new assignment.
    else
    {
      for (size_t i=0; i < cluster_assignments.size(); i++)
      {
        this->ChangedAssignments.insert(i);
        this->ChangedClusters.insert(cluster_assignments[i][0]);
        this->ClusterSizeDifferences[cluster_assignments[i][0]] += 1;
      }
    }
    return true;
  }
};

#endif
