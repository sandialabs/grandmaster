/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanLinkClusterAdjustmentImplementation titanLinkClusterAdjustmentImplementation.h <Clustering/titanLinkClusterAdjustmentImplementation.h>
/// \brief ...
///
///  titanLinkClusterAdjustmentImplementation is a model of the ClusterAdjustment
///  concept that simply combines two other generators, calling them in-order.
///  Note that you can use multiple invocations of titanLinkClusterAdjustment to
///  create combintations of generators that are arbitrarily deep.
///
///  This can be modded, creating variants that conditionally perform the second
///  Cluster Adjustment based on the outcome of the first.

#ifndef __titanLinkClusterAdjustment_h
#define __titanLinkClusterAdjustment_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <boost/concept_check.hpp>

template<
  typename FirstT,
  typename SecondT>
class titanLinkClusterAdjustmentImplementation
{
public:
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<FirstT>));
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<SecondT>));

  titanLinkClusterAdjustmentImplementation(const FirstT& first, const SecondT& second) :
    First(first),
    Second(second)
  {
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    bool continueClusteringFirst, continueClusteringSecond;

    continueClusteringFirst=
      First(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

    // Can do this conditionally based on first one. This model performs the second regardless.
    continueClusteringSecond=
        Second(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

    // return First || Second, First && Second ...
    return (continueClusteringSecond);
  }

private:
  const FirstT& First;
  const SecondT& Second;
};

/// Convenience function for creating titanLinkClusterAdjustmentImplementation instances.
template<typename FirstT, typename SecondT>
titanLinkClusterAdjustmentImplementation<FirstT, SecondT> titanLinkClusterAdjustment(const FirstT& first, const SecondT& second)
{
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<FirstT>));
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<SecondT>));

  return titanLinkClusterAdjustmentImplementation<FirstT, SecondT>(first, second);
}

#endif
