/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanIntraClusterObservationCentroidProximity titanIntraClusterObservationCentroidProximity.h <Clustering/titanIntraClusterObservationCentroidProximity.h>
/// \brief Calculates the proximity of each observation to its assigned centroid.
///
///  Given a set of centroids, a set of observations, a set of cluster
///  assignments, and proximity generator, compute the proximity of each
///  observation to its assigned centroid.
///
///  This metric assumes hard clustering.

#ifndef __titanIntraClusterObservationCentroidProximity_h
#define __titanIntraClusterObservationCentroidProximity_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>

class titanIntraClusterObservationCentroidProximity
{
private:
  mutable std::vector<double> ProximityValues; /// Stores the intra-cluster average squared proximities

  mutable bool UseMatrix; /// True if the metric will attempt to use a proximity matrix
  mutable boost::multi_array<double, 2> * ProximityMatrix; /// Reference to a proximity matrix


public :
  // If passed in with no arguments, the constructor will set
  titanIntraClusterObservationCentroidProximity() : UseMatrix(false)
  {
  }

template<
  typename CentroidContainerT,
  typename ObservationIteratorT,
  typename ClusterAssignmentT,
  typename ProximityGeneratorT
  >
  bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    const ClusterAssignmentT& cluster_assignments,
    const CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    size_t observation_index = 0;

  // Setup per-observation proximity storage ...


    ProximityValues.resize(observation_end - observation_begin, 0);

    if (!UseMatrix)
    {
      for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
      {
        size_t cluster_index = cluster_assignments[observation_index][0];

        // Negative proximity values are made negative again after squaring. This
        // applies to proximities such as Cosine Similarity.
        ProximityValues[observation_index] = proximity_generator.proximity(*observation, *(centroids.begin() + cluster_index));
      }
    }
    // If the ProximityMatrix is not the correct size, throw some type of error
    else if (
        (ProximityMatrix->shape()[0]!=observation_end-observation_begin) ||
        (ProximityMatrix->shape()[1]!=centroids.size()) )
    {
      cerr << "Incorrect Proximity Matrix size" << endl;
      // throw

    }
    // If everything is correct, we can use the ProximityMatrix passed into the constructor
    else
    {
      for (ObservationIteratorT observation = observation_begin;
          observation != observation_end;
          ++observation, ++observation_index)
      {
        size_t cluster_index = cluster_assignments[observation_index][0];

        // Get value from the matrix
        ProximityValues[observation_index] = (*ProximityMatrix)[observation_index][cluster_index];
      }
    }

    return true;
  }


  /// Returns a reference to the ProximityValues attribute
  std::vector<double> * get_proximities()
  {
    return &ProximityValues;
  }

  /// Sets the reference to the proximity matrix to use for calculations.
  void set_proximity_matrix(boost::multi_array<double, 2> * proximityMatrix)
  {
    UseMatrix = true;
    ProximityMatrix = proximityMatrix;
  }


};

#endif
