/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanIntraClusterAverageSquaredProximity titanIntraClusterAverageSquaredProximity.h <Clustering/titanIntraClusterAverageSquaredProximity.h>
/// \brief ...
///
///  Given a set of centroids, a set of observations, a set of cluster
///  assignments, and proximity generator, compute average squared
///  intra-cluster squared proximities.
///
///  This metric assumes hard clustering.


#ifndef __titanIntraClusterAverageSquaredProximity_h
#define __titanIntraClusterAverageSquaredProximity_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>

#include <cmath>
#include <iostream>

#include <Common/titanVectorTraits.h>

using namespace std;

/// Given a set of centroids, a set of observations, a set of cluster assignments, and proximity generator, compute intra-cluster distances.
class titanIntraClusterAverageSquaredProximity
{
private:
  mutable std::vector<double> ProximityValues; /// Stores the intra-cluster average squared proximities
  mutable std::vector<size_t> Counts; /// Stores the number of observations per cluster

  mutable boost::multi_array<double, 2> * ProximityMatrix; /// Reference to a proximity matrix
  mutable bool UseProximityMatrix; /// True if the metric will attempt to use a proximity matrix


public:
  // If passed in with no arguments, the constructor will set
  titanIntraClusterAverageSquaredProximity() :
    UseProximityMatrix(false)
  {
  }

  titanIntraClusterAverageSquaredProximity(boost::multi_array<double, 2>* proximityMatrix) :
    ProximityMatrix(proximityMatrix), UseProximityMatrix(true)
  {
  }

  template<typename CentroidContainerT,
  typename ObservationIteratorT,
  typename ClusterAssignmentMatrixT,
  typename ProximityGeneratorT>
  bool operator()(
      const ObservationIteratorT observation_begin,
      const ObservationIteratorT observation_end,
      const ClusterAssignmentMatrixT& cluster_assignments,
      const CentroidContainerT& centroids,
      const ProximityGeneratorT& proximity_generator) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    if ((observation_end-observation_begin) < 0)
      return false;

    // Setup per-cluster proximity storage
    ProximityValues.resize(centroids.end() - centroids.begin(), 0);
    Counts.resize(centroids.end() - centroids.begin(), 0);
    double proximityValue;

    size_t observation_index = 0;
    size_t cluster_index;

    // Calculate and sum the squared proximities for each observation.
    if (!this->UseProximityMatrix)
    {
      for (ObservationIteratorT observation = observation_begin; observation
          != observation_end; ++observation, ++observation_index)
      {
        cluster_index = vector_traits<typename ClusterAssignmentMatrixT::value_type>::get(cluster_assignments[observation_index],0);
        // minus proximity.closest_value() for similarity compatibility
        proximityValue = proximity_generator.proximity(*observation, *(centroids.begin()
            + cluster_index));
        ProximityValues[cluster_index] += std::pow(proximityValue, 2.0)
            * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
        Counts[cluster_index] += 1;
      }
    }
    // If the ProximityMatrix is not the correct size, throw some type of error
    else if (
        (ProximityMatrix->shape()[0]!=static_cast<size_t>(observation_end-observation_begin)) ||
        (ProximityMatrix->shape()[1]!=centroids.size()) )
    {
      std::cerr << "Incorrect Proximity Matrix size" << std::endl;
      // throw
    }
    else
    {
      for (ObservationIteratorT observation = observation_begin; observation
          != observation_end; ++observation, ++observation_index)
      {
        cluster_index = vector_traits<typename ClusterAssignmentMatrixT::value_type>::get(cluster_assignments[observation_index],0);
        // minus proximity.closest_value() for similarity compatibility
        proximityValue = (*ProximityMatrix)[observation_index][cluster_index];
        ProximityValues[cluster_index] += std::pow(proximityValue, 2.0)
            * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
        Counts[cluster_index] += 1;
      }
    }

    // If a cluster has observations, then divide the squared proximities by
    // the number of observations. Otherwise, set the average squared proximity
    // to the value signifying the nearest proximity.
    for (cluster_index = 0; cluster_index != ProximityValues.size(); ++cluster_index)
    {
      if (Counts[cluster_index])
      {
        ProximityValues[cluster_index] /= Counts[cluster_index];
      }
      else
        ProximityValues[cluster_index] = proximity_generator.closest_value();
    }

    return true;
  }

  /// Sets the reference to the proximity matrix to use for calculations.
  void set_proximity_matrix(boost::multi_array<double, 2> * proximityMatrix)
  {
    UseProximityMatrix = true;
    ProximityMatrix = proximityMatrix;
  }

  /// Returns a reference to the ProximityValues attribute
  std::vector<double> * get_proximities()
  {
    return &ProximityValues;
  }

  /// Returns a reference to the observations-per-cluster counts
  std::vector<size_t> * get_counts()
  {
    return &Counts;
  }

};

#endif
