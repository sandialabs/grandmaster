/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <Clustering/CentroidGenerators/titanCentroidsAdd.h>
#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/CentroidGenerators/titanExplicitCentroids.h>
#include <Clustering/CentroidGenerators/titanExplicitSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/CentroidGenerators/titanMedoids.h>
#include <Clustering/CentroidGenerators/titanRandomSampleCentroids.h>


#include <boost/concept/requires.hpp>

int TestCentroidGenerators(int argc, char *argv[])
{
  try
  {
    BOOST_CONCEPT_ASSERT((titanCentroidGenerator<titanCentroidsAdd>));
    BOOST_CONCEPT_ASSERT((titanCentroidGenerator<titanExplicitCentroids>));
    BOOST_CONCEPT_ASSERT((titanCentroidGenerator<titanExplicitSampleCentroids>));
    BOOST_CONCEPT_ASSERT((titanCentroidGenerator<titanMeanCentroids>));
    BOOST_CONCEPT_ASSERT((titanCentroidGenerator<titanMedoids>));
    BOOST_CONCEPT_ASSERT((titanCentroidGenerator<titanRandomSampleCentroids>));

    return 0;
  }
  catch(std::exception& e)
  {
    std::cerr << e.what() << std::endl;
    return 1;
  }
}
