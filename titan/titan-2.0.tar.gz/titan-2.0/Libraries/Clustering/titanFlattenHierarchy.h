/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanCentroidsAdd titanCentroidsAdd.h <Clustering/titanCentroidsAdd.h>
/// \brief titanCentroidsAdd is a model of the CentroidGenerator
///  concept that adds a new centroid.
///
///  titanCentroidsAdd is a model of the ClusterAdjustment
///  concept that adds a new centroid.
///
///  The default behavior is to place the new centroid in a cluster that has
///  the highest dispersion by some measure. Currently, that measure is
///  titanIntraClusterAverageSquaredProximity.
///  The addition can be constrained to a maximum number of centroids, although
///  the optional behavior/parameters of this are still under consideration.
///
///  Centroids can always be modified directly, by manually using their
///  container. This model is for automation of a specific method of centroid
///  modification.

#ifndef __titanFlattenHierarchy_h
#define __titanFlattenHierarchy_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Clustering/titanIntraClusterFarthestOutlier.h>
#include <algorithm>

#include <boost/multi_array.hpp>

typedef boost::multi_array<double, 2> prox_matrix_type;

class titanFlattenHierarchy
{
private:
  mutable size_t MinK;  // The maximum amount of clusters allowed.

public:
  titanFlattenHierarchy()
    : MinK(1)
  {
  }


  /// Constructor which allows the caller to set the maximum number of clusters
  /// that this class will add
  titanFlattenHierarchy(size_t min_k)
    : MinK(min_k)
  {
  }


  void set_min_k(size_t min_k)
  {
    MinK = min_k;
  }


  template<
    typename ClusterAssignmentIteratorT>
  bool operator()(
    ClusterAssignmentIteratorT& new_assignments_begin,
    ClusterAssignmentIteratorT& new_assignments_end,
    size_t number_of_observations
    )
  {
    size_t number_of_hierarchy_levels = new_assignments_end - new_assignments_begin;

    size_t highest_valid_cluster_id = number_of_observations *2 - this->MinK - 1;


    std::vector<size_t> leafNodes(0);
    //cout << "highest_valid_cluster_id=" << highest_valid_cluster_id-1 << "\n";
    //cout << "number_of_observations=" << number_of_observations << "\n";
    //cout << "this->MinK()=" << this->MinK << "\n";

    // Observations/clusters belonging to clusters with indices higher than the
    // highest valid cluster id will be freed (set to max size_t)
    for (size_t observation_index = 0; observation_index != number_of_hierarchy_levels; ++observation_index)
    {
      if ((*(new_assignments_begin+observation_index))[0] > highest_valid_cluster_id)
      {
        (*(new_assignments_begin+observation_index))[0] = std::numeric_limits<size_t>::max();
      }
    }

    // flatten the clusters from top down, one by one
    for (size_t cluster_index=highest_valid_cluster_id; cluster_index >= number_of_observations; --cluster_index)
    {
      leafNodes.clear();
      this->GetLeafNodes(cluster_index, leafNodes, new_assignments_begin, new_assignments_end, number_of_observations);

      for (size_t leaf_array_index = 0; leaf_array_index != leafNodes.size(); ++leaf_array_index)
      {
        (*(new_assignments_begin+leafNodes[leaf_array_index]))[0]=cluster_index;
      }
    }


    // Reassign the flattened cluster indices to be contiguous starting from 0
    size_t cluster_id;
    size_t new_cluster_id=0;
    for (size_t observation_index = 0; observation_index != number_of_observations; ++observation_index)
    {
      cluster_id = (*(new_assignments_begin+observation_index))[0];

      if (cluster_id >= number_of_observations)
      {
        (*(new_assignments_begin+observation_index))[0] = new_cluster_id;

        if (cluster_id != std::numeric_limits<size_t>::max())
          for (size_t observation_index_2 = observation_index+1; observation_index_2 != number_of_observations; observation_index_2++)
          {
            if ((*(new_assignments_begin+observation_index_2))[0] == cluster_id)
              (*(new_assignments_begin+observation_index_2))[0]=new_cluster_id;
          }
          ++new_cluster_id;
      }
    }

    return true;
  }



  /*  GetLeafNodes
  * Fills the leafNodes with the ids of the observations within
  * clusterId
  *
  * Perhaps this utility should be provided outside of this filter..
  */
  template<typename ClusterAssignmentIteratorT>
  void  GetLeafNodes(size_t clusterId, std::vector<size_t>& leafNodes, ClusterAssignmentIteratorT& assignments_begin, ClusterAssignmentIteratorT& assignments_end, const size_t& number_of_observations)
  {
    std::vector<size_t>  children;

    size_t  childId;

    for (size_t observation_index=0;observation_index != (assignments_end-assignments_begin); ++observation_index)
    {
      if ((*(assignments_begin+observation_index))[0]==clusterId)
      {
        children.push_back(observation_index);
      }

    }


    for (size_t i=0;i<children.size();i++)
    {
      childId=children[i];

      if (childId < number_of_observations)
      {
        leafNodes.push_back(childId);
      }
      else
      {
        this->GetLeafNodes(childId, leafNodes, assignments_begin, assignments_end, number_of_observations);
      }
    }
  }

};

#endif
