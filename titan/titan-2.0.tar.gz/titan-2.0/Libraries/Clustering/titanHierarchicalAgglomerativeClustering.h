/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanHierarchicalAgglomerativeStrategy titanHierarchicalAgglomerativeStrategy.h <Clustering/titanHierarchicalAgglomerativeStrategy.h>
/// \brief Hierarchical Agglomerative clustering
///
///  titanHierarchicalAgglomerativeStrategy is a model of the Clustering Strategy
///  concept.
///

#ifndef __titanHierarchicalAgglomerativeClustering_h
#define __titanHierarchicalAgglomerativeClustering_h

#include <algorithm>
#include <cmath>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <vector>

#include <Common/titanVectorOperations.h>

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Clustering/titanRelationProximities.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>
#include <boost/tuple/tuple.hpp>

#include <boost/progress.hpp>

#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>

using namespace boost::lambda;

using namespace std;
/// Given a set of observations, compute a new set of clusters using K-means and caller-provided strategies for initial cluster generation and iteration.
class titanHierarchicalAgglomerativeClustering
{
protected:
  std::vector<double> ClosestProximity; // list of the closest proximities
  std::vector<std::vector<size_t> > ChildrenList;
  std::vector<size_t> LeafMemberCount;
  size_t NewClusterId;
  bool Verbose;
  std::vector<size_t> FirstClusterIdList;
  std::vector<size_t> SecondClusterIdList;

private:
  typedef boost::multi_array<double, 2> array_type;
  typedef array_type::index index;

public:




  template<typename ObservationIteratorT, typename ClusterLinkageT, class ProximityGeneratorT, typename ClusterAssignmentOutputT>
  void operator()(ObservationIteratorT observation_begin,
      ObservationIteratorT observation_end,
      ClusterLinkageT linkage,
      const ProximityGeneratorT& proximity_generator,
      const size_t& minClusters,
      const bool& normalize,
      ClusterAssignmentOutputT& output_cluster_assignments)
  {

    size_t numObservations = observation_end - observation_begin;
    size_t minimum_clusters = 1;
    minimum_clusters = std::max(minClusters,minimum_clusters);

    if (numObservations <= 0)
      throw std::runtime_error("Cannot cluster without observations.");

    std::vector<std::vector<double> > proximity_matrix;
    size_t max_total_clusters= 2 * numObservations - minimum_clusters;

    titanRelationProximities observation_observation_proximities(false);
    observation_observation_proximities(*observation_begin, *observation_end,
        *observation_begin, *observation_end, proximity_generator,
        proximity_matrix);

    this(linkage,
        proximity_generator,
        proximity_matrix,
        minimum_clusters,
        false,
        output_cluster_assignments);
  }


  template<typename ClusterLinkageT, class ProximityGeneratorT, class ProximityMatrixT, typename ClusterAssignmentOutputT>
  void operator()(ClusterLinkageT linkage,
      const ProximityGeneratorT& proximity_generator,
      ProximityMatrixT& proximity_matrix,
      const size_t& minClusters,
      const bool& normalize,
      ClusterAssignmentOutputT& output_cluster_assignments)
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    size_t numObservations = proximity_matrix.size();

    if (numObservations==0)
      throw std::runtime_error("Cannot cluster without observations.");

    size_t minimum_clusters = 1;
    minimum_clusters = std::max(minClusters,minimum_clusters);

    size_t max_total_clusters = 2 * numObservations - minimum_clusters;


    proximity_matrix.resize(max_total_clusters);
    for (size_t row_id = 0; row_id != max_total_clusters; ++row_id)
    {
      proximity_matrix[row_id].resize(max_total_clusters,
          proximity_generator.farthest_value());
      if (row_id >= numObservations)
      {
        std::fill(proximity_matrix[row_id].begin(),proximity_matrix[row_id].begin()+numObservations,proximity_generator.farthest_value());
      }
    }

    // Set aside temporary storage for cluster centroids and cluster assignments ...
    ClusterAssignmentOutputT cluster_assignments(
        boost::extents[max_total_clusters][1]);
    std::fill(cluster_assignments.data(), cluster_assignments.data()
        + cluster_assignments.num_elements(),
        std::numeric_limits<size_t>::max());

    double closest_proximity_value;
    size_t closest_orphan_id;

    std::vector<size_t> rank(numObservations); // ranking of observations with the closest neighbor
    std::vector<size_t> closest_orphan_index(numObservations); // list of the closest neighbors
    std::vector<size_t> orphan_cluster_ids(numObservations); // list of the orphan clusters

    ClosestProximity.resize(numObservations);

    size_t closest_row_id, closest_col_id;

    size_t target_cluster_id; // id for the newest cluster

    std::vector<std::vector<size_t> > childrenList; // List of children for each cluster
    std::vector<size_t> leafMemberCount; // Count of the number of total leaves under each cluster

    // Initialize Children List and LeafMemberCount vectors
    childrenList.resize(max_total_clusters);
    leafMemberCount.resize(max_total_clusters, 0);

    for (size_t i = 0; i != numObservations; i++)
    {
      // Each "cluster" only contains one leaf-- itself
      childrenList[i].push_back(i);
      leafMemberCount[i] = 1;
    }

    // Pre-allocate pair space
    // Every cluster from numObservations to max_total_clusters will be
    // of size 2
    for (size_t i = numObservations; i != childrenList.size(); ++i)
    {
      childrenList[i].resize(2);
    }

    // Add all current observations to orphan clusters
    for (size_t i = 0; i != numObservations; i++)
    {
      orphan_cluster_ids[i] = i;
    }

    // Find the closest observation for each observation
    double currentClosestMeasureValue;
    double proximity_value;

    for (size_t row = 0; row != numObservations; ++row)
    {
      closest_row_id = 0;
      closest_col_id = 0;
      currentClosestMeasureValue = proximity_generator.farthest_value();
      for (size_t col = 0; col != numObservations; ++col)
      {
        // Skip identity, which will always be closest
        if (row == col)
          continue;

        proximity_value = proximity_matrix[row][col];

        // Update the closest column and proximity if valid
        if (proximity_generator.closer(proximity_value,
            currentClosestMeasureValue))
        {
          currentClosestMeasureValue = proximity_value;
          closest_col_id = col;
        }
      }

      // Store the closest column and proximity
      closest_orphan_index[row] = closest_col_id;
      ClosestProximity[row] = currentClosestMeasureValue;
    }

    // Initialize rank vector
    for (size_t i = 0; i != numObservations; ++i)
    {
      rank[i] = i;
    }

    // Sort initial sources and targets by their proximity
    // TODO fix lambda expression so that the sort can utilize the closer() method
    if (proximity_generator.closer(0, 1))
    {
      std::stable_sort(rank.begin(), rank.end(), var(ClosestProximity)[_1]
          < var(ClosestProximity)[_2]);
    } else
    {
      std::stable_sort(rank.begin(), rank.end(), var(ClosestProximity)[_1]
          > var(ClosestProximity)[_2]);
    }

    // Sorting closest orphans and proximities given the rank ordering
    // Sorting with the lambda doesn't produce what it should...
    std::vector<size_t> tempVec(numObservations);

    size_t ithValue;

    for (size_t i = 0; i < closest_orphan_index.size(); ++i)
    {
      ithValue = rank[i];
      tempVec[i] = closest_orphan_index[ithValue];
    }

    closest_orphan_index = tempVec;

    std::vector<double> tempVecProx(numObservations);
    for (size_t i = 0; i < ClosestProximity.size(); ++i)
    {
      ithValue = rank[i];
      tempVecProx[i] = ClosestProximity[ithValue];
    }

    ClosestProximity = tempVecProx;

    /* Cluster */
    size_t first_cluster_id;
    size_t second_cluster_id;
    size_t merge_rank = 0; // The index in the rank list of the cluster to be merged

    target_cluster_id = numObservations;

    size_t max_elements_joined = 0, cur_max_elements_joined = 0, depth =
        0;

    // Loop until we coalesce to our desired number of clusters (minimum_clusters)
    for (size_t numClusters = numObservations; numClusters != minimum_clusters; --numClusters, ++merge_rank)
    {

      first_cluster_id = rank[merge_rank];
      second_cluster_id = closest_orphan_index[merge_rank];

      // If the next index in the list is not an orphan (it has a parent
      // cluster already) then skip it, while maintaining the previous
      // number of clusters
      if (std::find(orphan_cluster_ids.begin(), orphan_cluster_ids.end(),
          first_cluster_id) == orphan_cluster_ids.end())
      {
        numClusters++;
        continue;
      }

      if (this->Verbose)
        cout << "VERBOSE:\tMerging " << first_cluster_id << "\t" << second_cluster_id
          << "\t" << target_cluster_id << "\t" << ClosestProximity[merge_rank]
          << endl;

      FirstClusterIdList.push_back(first_cluster_id);
      SecondClusterIdList.push_back(second_cluster_id);

      // Assign the orphans to the new parent cluster
      cluster_assignments[first_cluster_id][0] = target_cluster_id;
      cluster_assignments[second_cluster_id][0] = target_cluster_id;

      /* Join Clusters */
      childrenList[target_cluster_id][0] = first_cluster_id;
      childrenList[target_cluster_id][1] = second_cluster_id;

      cur_max_elements_joined = max(leafMemberCount[first_cluster_id],
          leafMemberCount[second_cluster_id]);
      if (cur_max_elements_joined > max_elements_joined)
      {
        max_elements_joined = cur_max_elements_joined;
        depth++;
      }

      leafMemberCount[target_cluster_id] = leafMemberCount[first_cluster_id]
          + leafMemberCount[second_cluster_id];
      // Remove the merged clusters from the list of orphans
      std::vector<size_t>::iterator clusterToRemove;

      clusterToRemove = std::find(orphan_cluster_ids.begin(),
          orphan_cluster_ids.end(), first_cluster_id);

      orphan_cluster_ids.erase(clusterToRemove);

      clusterToRemove = std::find(orphan_cluster_ids.begin(),
          orphan_cluster_ids.end(), second_cluster_id);

      orphan_cluster_ids.erase(clusterToRemove);

      //Set the identity proximity
      proximity_matrix[target_cluster_id][target_cluster_id]
          = proximity_generator.closest_value();

      // Update the proximities to the new cluster using the desired cluster
      // linkage
      closest_orphan_id=orphan_cluster_ids[0];
      linkage(proximity_generator, proximity_matrix, orphan_cluster_ids,
          target_cluster_id, first_cluster_id, second_cluster_id,
          closest_orphan_id, closest_proximity_value, leafMemberCount);

      // If the closest orphan for any cluster is one of the clusters being
      // merged, replace that orphan with the new cluster
      for (size_t i = 0; i != closest_orphan_index.size(); ++i)
      {
        if ((closest_orphan_index[i] == first_cluster_id)
            || (closest_orphan_index[i] == second_cluster_id))
        {
          closest_orphan_index[i] = target_cluster_id;
        }
      }

      // Insert the new cluster into the rank list
      // This could possibly be made more efficient with a sorted insert
      size_t rank_to_insert;
      for (rank_to_insert = merge_rank + 1; rank_to_insert != rank.size(); ++rank_to_insert)
      {
        if (!proximity_generator.closer(ClosestProximity[rank_to_insert],
            closest_proximity_value))
          break;
      }

      // Add the rank, closest orphan, and closest proximities into the same
      // place in their respective lists
      rank.insert(rank.begin() + rank_to_insert, 1, target_cluster_id);
      ClosestProximity.insert(ClosestProximity.begin() + rank_to_insert, 1,
          closest_proximity_value);
      closest_orphan_index.insert(
          closest_orphan_index.begin() + rank_to_insert, 1, closest_orphan_id);

      // Add the new cluster to the list of orphans
      orphan_cluster_ids.push_back(target_cluster_id);

      target_cluster_id++;
    }

    // Return our final results ...
    output_cluster_assignments.resize(
        boost::extents[cluster_assignments.shape()[0]][cluster_assignments.shape()[1]]);
    output_cluster_assignments = cluster_assignments;


  }

  void set_verbose(bool verbose)
  {
    this->Verbose = verbose;
  }

  std::vector<double> * get_merge_proximities()
  {
    return &this->ClosestProximity;
  }

  std::vector<size_t> * get_first_cluster_id_list()
  {
    return &this->FirstClusterIdList;
  }

  std::vector<size_t> * get_second_cluster_id_list()
  {
    return &this->SecondClusterIdList;
  }

};
#endif
