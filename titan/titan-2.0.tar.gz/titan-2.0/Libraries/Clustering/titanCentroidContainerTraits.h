/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanEmptyDistance titanEmptyDistance.h <Clustering/titanEmptyDistance.h>
/// \brief ...
///
///  titanEmptyDistance is a model of the titanProximityGenerator concept
///  that does nothing. It is used as a place holder for concepts that require
///  a proximity generator
///

#ifndef __titanCentroidContainerTraits_h
#define __titanCentroidContainerTraits_h

#include <boost/multi_array.hpp>

//typedef boost::multi_array<unsigned int, 2> uint_matrix_type;
//typedef titanBoostMultiArrayIterator<uint_matrix_type,unsigned int> uint_matrix_iterator;

template<typename T>
class centroid_container_traits
{
public:
  static void resize(T& container, int new_size)
  {
    container.resize(new_size);
    return;
  }
};


template<>
class centroid_container_traits<boost::multi_array<double, 2> >
{
public:
  static void resize(boost::multi_array<double, 2>& container, int new_size)
  {
    container.resize(boost::extents[new_size][container.shape()[1]] );
    return;
  }
};

#endif
