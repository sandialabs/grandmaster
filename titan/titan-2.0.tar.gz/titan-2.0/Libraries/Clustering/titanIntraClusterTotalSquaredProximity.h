/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanIntraClusterTotalSquaredProximity titanIntraClusterTotalSquaredProximity.h <Clustering/titanIntraClusterTotalSquaredProximity.h>
/// \brief Calculates the total squared proximities for each cluster.
///
///  titanIntraClusterTotalSquaredProximity is a model of the Cluster
///  Adjustment concept. It calculates, for each cluster, the sum of the
///  proximities of each observation from the centroid.
///
///  This metric assumes hard clustering.

#ifndef __titanIntraClusterTotalSquaredProximity_h
#define __titanIntraClusterTotalSquaredProximity_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <iostream>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>

#include <Common/titanVectorOperations.h>

#include <cmath>

/// Given a set of centroids, a set of observations, a set of cluster assignments, and proximity generator, compute intra-cluster distances.
class titanIntraClusterTotalSquaredProximity
{
private:
  mutable std::vector<double> ProximityValues; /// Stores the intra-cluster average squared proximities
  mutable std::vector<size_t> Counts; /// Stores the number of observations per cluster


public:
  // If passed in with no arguments, the constructor will set
  titanIntraClusterTotalSquaredProximity()
  {
    ProximityValues.clear();
    Counts.clear();
  }

  template<typename CentroidContainerT, typename ObservationIteratorT,
      typename ClusterAssignmentT, typename ProximityGeneratorT>
  bool operator()(const ObservationIteratorT observation_begin,
      const ObservationIteratorT observation_end,
      const ClusterAssignmentT& cluster_assignments,
      const CentroidContainerT& centroids,
      const ProximityGeneratorT& proximity_generator) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    // Setup per-cluster distance storage ...
    ProximityValues.resize(centroids.end() - centroids.begin(), 0);
    Counts.resize(centroids.end() - centroids.begin(), 0);
    double proximityValue;

    size_t observation_index = 0;

    for (ObservationIteratorT observation = observation_begin; observation
        != observation_end; ++observation, ++observation_index)
    {
      size_t cluster_index = cluster_assignments[observation_index][0];

      proximityValue = proximity_generator.proximity(*observation,
          centroids[cluster_index]);


      // Negative proximity values are made negative again after squaring. This
      // applies to proximities such as Cosine Similarity.
      ProximityValues[cluster_index] += std::pow(proximityValue, 2.0)
          * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));

      Counts[cluster_index]++;
    }

    // If there are no observations in a cluster, its total squared intra-cluster
    // proximity is the value signifying the nearest proximity.
    for (size_t cluster_index = 0; cluster_index != ProximityValues.size(); ++cluster_index)
    {
      if (!Counts[cluster_index])
        ProximityValues[cluster_index] = proximity_generator.closest_value();
    }

    return true;
  }

  /// Returns a reference to the ProximityValues attribute
  std::vector<double> * get_proximities()
  {
    return &ProximityValues;
  }

  /// Returns a reference to the observations-per-cluster counts
  std::vector<size_t> * get_counts()
  {
    return &Counts;
  }

};

#endif
