/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanPartitionalClustering titanPartitionalClustering.h <Clustering/titanPartitionalClustering.h>
/// \brief ...
///
///  titanPartitionalClustering is a model of the Clustering Strategy concept.
///
///  This algorithm assumes hard clustering.

#ifndef __titanPartitionalClustering_h
#define __titanPartitionalClustering_h

#include <vector>
#include <stdexcept>
#include <iostream>

#include <boost/multi_array.hpp>

#include <Common/titanVectorOperations.h>


/// Given a set of observations, compute a new set of clusters using partional clustering
/// and caller-provided strategies for initial cluster generation and iteration.
template<typename ClusterT, class InitialClusterAdjustmentT, class ClusterAdjustmentT,
class ProximityGeneratorT, typename ObservationIteratorT, typename ClusterOutputT, typename ClusterAssignmentOutputT>
  void titanPartitionalClustering(
  const InitialClusterAdjustmentT& initial_cluster_adjustment,
  const ClusterAdjustmentT& cluster_adjustment,
  const ProximityGeneratorT& proximity_generator,
  const size_t max_iterations,
  const ObservationIteratorT observation_begin, const ObservationIteratorT observation_end,
  ClusterOutputT& output_clusters,
  ClusterAssignmentOutputT& output_cluster_assignments
  )
{
  const size_t observation_count = observation_end - observation_begin;
  if(!observation_count)
    throw std::runtime_error("Cannot cluster without observations.");

  // Set aside temporary storage for cluster centroids and cluster assignments ...
  std::vector<ClusterT> cluster_centroids(0);
  boost::multi_array<size_t, 2> cluster_assignments(boost::extents[observation_end - observation_begin][1]);
  std::fill(cluster_assignments.data(),cluster_assignments.data() + cluster_assignments.num_elements(), 0);

  typedef boost::multi_array<double, 2> array_type;
  typedef array_type::index index;
  array_type proximity_matrix;

  // Choose initial starting clusters ...
  initial_cluster_adjustment(observation_begin, observation_end, cluster_assignments, cluster_centroids, proximity_generator);

  size_t consecutive_static_iterations=0;
  size_t iteration;

  bool continueClustering=true;

  for(iteration = 0; iteration != max_iterations; ++iteration)
  {
    // Compute new cluster centroids ...
    continueClustering=cluster_adjustment(observation_begin, observation_end, cluster_assignments, cluster_centroids, proximity_generator);

    if (!continueClustering)
      break;

  }

  // Return our final results ...
  std::copy(cluster_centroids.begin(), cluster_centroids.end(), output_clusters);
 // std::copy(cluster_assignments.begin(), cluster_assignments.end(), output_cluster_assignments);
  output_cluster_assignments.resize(boost::extents[cluster_assignments.shape()[0]][cluster_assignments.shape()[1]]);
  output_cluster_assignments=cluster_assignments;
}



#endif
