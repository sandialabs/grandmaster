/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanClusterAssignmentRanked titanClusterAssignmentRanked.h <Clustering/titanClusterAssignmentRanked>
/// \brief Assign all observations to clusters by rank
///
///  titanClusterAssignmentRanked is a model of the ClusterAdjustment concept
///  that assigns each observation to all clusters with a rank, using the caller-
///  supplied ProximityGenerator. It can be used with a pre-computed proximity
///  matrix, or it can calculate the proximities itself.
///
///  The cluster assignments are stored in the cluster_assignments parameter.
///

#ifndef __titanClusterAssignmentRanked_h
#define __titanClusterAssignmentRanked_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <algorithm>

#include <boost/multi_array.hpp>

typedef boost::multi_array<double, 2> prox_matrix_type;

class titanClusterAssignmentRanked
{

public:
  titanClusterAssignmentRanked()
  {
    UseMatrix=false;
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {

    // If a proximity matrix has not been passed in, we will have to create one
    if (!UseMatrix)
    {
      titanRelationProximities proximities;
      proximities(observations.begin(), observations.end(), centroids.begin(), centroids.end(), proximity_generator);

      ProximityMatrix = proximities.get_relational_matrix();
    }

    // Calculate the ranking
    titanRelationProximityRanking ranking =
        titanRelationProximityRanking(ProximityMatrix);

    ranking(observations.begin(), observations.end(), centroids.begin(), centroids.end(), proximity_generator);

    prox_matrix_type * rankMatrix = ranking.get_relational_matrix();
    cluster_assignments.resize(boost::extents[(*rankMatrix).shape()[0]][(*rankMatrix).shape()[1]]);
    cluster_assignments=*rankMatrix;

    return true;
  }

  /// Sets the internal pointer to a proximity matrix for use in determining
  /// cluster assignments.
  /// Need better error handling here
  void set_proximity_matrix(prox_matrix_type * proximityMatrix)
  {
    if ((proximityMatrix->shape()[0]==0) || (proximityMatrix->shape()[1]==0))
    {
      UseMatrix=false;
      return;
    }

    UseMatrix= true;
    ProximityMatrix = proximityMatrix;
  }


private:
  mutable bool UseMatrix; // Use pre-supplied proximity matrix
  prox_matrix_type * ProximityMatrix;

};

#endif
