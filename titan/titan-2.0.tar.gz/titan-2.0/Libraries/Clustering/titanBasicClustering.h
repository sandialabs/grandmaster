/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __titanBasicClustering_h
#define __titanBasicClustering_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Clustering/titanHardClusterAssignment.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>

#include <algorithm>
#include <vector>

#include <iostream>

using namespace std;

/// Given a set of observations, compute a new set of clusters using caller-provided strategies for centroid generation and cluster assignment.
template<
  typename InitialCentroidGeneratorT,
  typename CentroidGeneratorT,
  typename ProximityGeneratorT,
  typename ObservationIteratorT,
  typename CentroidOutputT,
  typename ClusterAssignmentOutputT>
void titanBasicClustering(
  const InitialCentroidGeneratorT& initial_centroid_generator,
  const CentroidGeneratorT& centroid_generator,
  const ProximityGeneratorT& proximity_generator,
  const size_t max_iterations,
  const ObservationIteratorT& observation_begin,
  const ObservationIteratorT& observation_end,
  CentroidOutputT& centroids,
  ClusterAssignmentOutputT& cluster_assignments
  )
{
  BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

  // Choose initial starting centroids ...
  initial_centroid_generator(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

  titanHardClusterAssignment(1)(observation_begin, observation_end, centroids, cluster_assignments, proximity_generator);


  // Iteratively compute new centroids ...
  for(size_t iteration = 0; iteration != max_iterations; ++iteration)
  {
    centroid_generator(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    titanHardClusterAssignment(1)(observation_begin, observation_end, centroids, cluster_assignments, proximity_generator);
  }

}

#endif
