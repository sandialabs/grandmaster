/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanBoostMultiArrayAdaptor titanBoostMultiArrayAdaptor.h <Clustering/titanBoostMultiArrayAdaptor.h>
/// \brief titanBoostMultiArrayAdaptor


#ifndef __titanBoostMultiArrayAdaptor_h
#define __titanBoostMultiArrayAdaptor_h

#include <iterator>
#include <vector>

#include <iostream>

#include <Clustering/titanBoostMultiArrayIterator.h>

using namespace std;

/// Vector compatible container for boost multi_array
template<typename ArrayT, typename ElementT>
class titanBoostMultiArrayAdaptor
{

public:
  typedef titanBoostMultiArrayIterator<ArrayT, ElementT> iterator;
  typedef typename std::iterator_traits<iterator>::value_type  value_type;

  titanBoostMultiArrayAdaptor(ArrayT* array, size_t observation_dimension) :
    Array(array),
    ObservationDimension(observation_dimension),
    ElementDimension(1-observation_dimension),
    ObservationBegin(iterator(Array, 0, observation_dimension, false)),
    ObservationEnd(iterator(Array, array->shape()[observation_dimension], observation_dimension, false))

  {
    this->Observations.clear();
    this->resize(this->ObservationEnd - this->ObservationBegin);
  }

  titanBoostMultiArrayAdaptor(const titanBoostMultiArrayAdaptor& original)
  {
    this->Array = original.Array;
    this->ObservationDimension = original.ObservationDimension;
    this->ElementDimension = original.ElementDimension;
    this->ObservationBegin = original.ObservationBegin;
    this->ObservationEnd = original.ObservationEnd;
    this->Observations = original.Observations;

  }

  titanBoostMultiArrayAdaptor& operator=(const titanBoostMultiArrayAdaptor& original)
  {
    this->Array = original.Array;
    this->ObservationDimension = original.ObservationDimension;
    this->ElementDimension = original.ElementDimension;
    this->ObservationBegin = original.ObservationBegin;
    this->ObservationEnd = original.ObservationEnd;
    this->Observations = original.Observations;

    return *this;
  }

  void resize(const size_t& new_size)
  {
    if (this->size()==new_size)
      return;

    size_t old_size = this->size();

    if (this->ObservationDimension==0)
      this->Array->resize(boost::extents[new_size][this->Array->shape()[this->ElementDimension]]);
    else
      this->Array->resize(boost::extents[this->Array->shape()[this->ElementDimension]][new_size]);

    ObservationEnd.CurrentRow = new_size;
    Observations.resize(new_size,iterator(this->Array,0,this->ObservationDimension,false));

    if (new_size > old_size)
    {
      for (size_t i=old_size; i != new_size; ++i)
      {
        Observations[i].CurrentRow = i;
      }
    }
    return;
  }

  size_t size() const
  {
    return Observations.size();
  }

  typename std::iterator_traits<iterator>::value_type operator[](const size_t& i) const
  {
    return *(Observations[i]);
  }

  typename std::iterator_traits<iterator>::value_type& operator[](const size_t& i)
  {
    return *(Observations[i]);
  }

  iterator begin() const
  {
    return ObservationBegin;
  }

  iterator end() const
  {
    return ObservationEnd;
  }


  ArrayT*  get_array()
  {
    return Array;
  }

private:
  ArrayT* Array;
  size_t ObservationDimension;
  size_t ElementDimension;
  iterator ObservationBegin;
  iterator ObservationEnd;
  std::vector<iterator> Observations;
};

#endif
