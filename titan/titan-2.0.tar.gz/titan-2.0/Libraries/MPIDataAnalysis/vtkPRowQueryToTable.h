/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/



/// \class vtkPRowQueryToTable vtkPRowQueryToTable.h <MPIDataAnalysis/vtkPRowQueryToTable.h>
/// \brief executes an sql query and retrieves results into a table that gets distributed across processors
///
///  vtkPRowQueryToTable creates a vtkTable with the results of an arbitrary SQL
///  query.  To use this filter, you first need an instance of a vtkSQLDatabase
///  subclass.  You may use the database class to obtain a vtkRowQuery instance.
///  Set that query on this filter to extract the query as a table.  The
///  resulting table will be distributed evenly across all processes in the
///  group described by the Communicator ivar.
///
///  To use this class, instantiate it in all processes and set the
///  query object on the master node (i.e. the one that's actually going
///  to execute the query).  Leave the query NULL on all the others.  At
///  execution time the instances will all communicate among themselves
///  to figure out who's sending and who's receiving.
///
/// \par Thanks :
///  Thanks to Andrew Wilson from Sandia National Laboratories for his work
///  on the database classes.
///
/// \sa
///  vtkSQLDatabase vtkRowQuery

#ifndef __vtkPRowQueryToTable_h
#define __vtkPRowQueryToTable_h

#include <titanMPIDataAnalysis.h>
#include "vtkRowQueryToTable.h"
#include "vtkStdString.h"

class vtkCommunicator;
class vtkIntArray;
class vtkStringArray;
class vtkVariantArray;

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPRowQueryToTable : public vtkRowQueryToTable
{
public:
  static vtkPRowQueryToTable* New();
  vtkTypeMacro(vtkPRowQueryToTable, vtkRowQueryToTable);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Communicator describing the process group that will receive the
  /// results of the query.
  void SetCommunicator(vtkCommunicator *comm);
  vtkGetObjectMacro(Communicator, vtkCommunicator);
  ///@}

  ///@{
  /// Some databases may not support the row-at-a-time
  /// NextRow(vtkVariantArray *) method.  Turn this flag off to make the
  /// reader pull one value at a time.  This will be slow.
  vtkSetMacro(ReadEntireRow, bool);
  vtkGetMacro(ReadEntireRow, bool);
  vtkBooleanMacro(ReadEntireRow, bool);
  ///@}

protected:
  vtkPRowQueryToTable();
  ~vtkPRowQueryToTable();

  vtkCommunicator *Communicator;
  int MasterProcessId;
  bool ReadEntireRow;

  vtkSetMacro(MasterProcessId, int);
  vtkGetMacro(MasterProcessId, int);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

  /// The master process is the lowest-ID process with a non-null Query
  /// ivar.  It's the only one that will actually execute a database
  /// query.
  int LocateMasterProcess();

  ///@{
  /// The master process will send out the names and data types of the
  /// different columns as soon as it knows what they are.
  void AnnounceTableDefinition(vtkStringArray *names, vtkIntArray *types);
  void ReceiveTableDefinition(vtkTable *output);
  void SetupTable(vtkStringArray *names, vtkIntArray *types, vtkTable *table);
  ///@}

  void AnnounceQuerySuccess();
  void AnnounceQueryError(const vtkStdString &message);
  void AnnounceNoMoreRows();
  bool ListenForQueryStatus();
  void SendRowToProcess(vtkVariantArray *data, int DestinationProcess);
  bool AnotherRowAvailable();
  void ReceiveNextRow(vtkTable *table);

  /// If ReadEntireRow is set to false, this function emulates
  /// vtkRowQuery::NextRow(vtkVariantArray *).  If ReadEntireRow is set
  /// to true it calls that method directly.
  bool FetchNextRow(vtkVariantArray *output);

private:
  vtkPRowQueryToTable(const vtkPRowQueryToTable&); // Not implemented
  void operator=(const vtkPRowQueryToTable&);   // Not implemented
};

#endif
