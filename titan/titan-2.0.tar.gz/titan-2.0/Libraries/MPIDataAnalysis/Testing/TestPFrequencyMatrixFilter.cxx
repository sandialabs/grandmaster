/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <vtkArrayData.h>
#include <vtkArrayPrint.h>
#include <vtkMPIController.h>
#include <vtkPFrequencyMatrixFilter.h>
#include <vtkSmartPointer.h>
#include <vtkSparseArray.h>
#include <vtkTable.h>
#include <vtkUnicodeStringArray.h>

#include <vtksys/ios/iostream>
#include <vtksys/ios/sstream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  int result = 0;

  vtkSmartPointer<vtkMPIController> controller = vtkSmartPointer<vtkMPIController>::New();
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  try
    {
    if(controller->GetNumberOfProcesses() != 2)
      throw std::runtime_error("test requires exactly two processes");

    vtkUnicodeStringArray* const text = vtkUnicodeStringArray::New();
    text->SetName("text");
    text->InsertNextUTF8Value("red");
    text->InsertNextUTF8Value("dark red");
    text->InsertNextUTF8Value("green");
    text->InsertNextUTF8Value("dark green");
    text->InsertNextUTF8Value("blue");
    text->InsertNextUTF8Value("dark blue");
    vtkSmartPointer<vtkTable> input_features = vtkSmartPointer<vtkTable>::New();
    input_features->AddColumn(text);
    text->Delete();

    vtkSmartPointer<vtkSparseArray<double> > input_matrix = vtkSmartPointer<vtkSparseArray<double> >::New();
    switch(controller->GetLocalProcessId())
      {
      case 0:
        input_matrix->Resize(vtkArrayRange(0, text->GetNumberOfTuples()), vtkArrayRange(0, 3));
        input_matrix->AddValue(0, 0, 1);
        input_matrix->AddValue(0, 1, 1);
        input_matrix->AddValue(0, 2, 1);
        input_matrix->AddValue(1, 0, 3);
        input_matrix->AddValue(1, 1, 3);
        input_matrix->AddValue(2, 0, 1);
        input_matrix->AddValue(2, 1, 1);
        input_matrix->AddValue(2, 2, 1);
        input_matrix->AddValue(3, 0, 1);
        input_matrix->AddValue(3, 1, 1);
        input_matrix->AddValue(3, 2, 1);
        input_matrix->AddValue(4, 0, 1);
        input_matrix->AddValue(4, 1, 1);
        input_matrix->AddValue(4, 2, 1);
        input_matrix->AddValue(5, 0, 1);
        input_matrix->AddValue(5, 1, 1);
        input_matrix->AddValue(5, 2, 1);
        break;

      case 1:
        input_matrix->Resize(vtkArrayRange(0, text->GetNumberOfTuples()), vtkArrayRange(3, 6));
        input_matrix->AddValue(2, 3, 1);
        input_matrix->AddValue(4, 3, 1);
        input_matrix->AddValue(4, 4, 1);
        input_matrix->AddValue(4, 5, 1);
        input_matrix->AddValue(5, 3, 1);
        input_matrix->AddValue(5, 4, 1);
        break;
      }

    vtkSmartPointer<vtkArrayData> input_matrix_data = vtkSmartPointer<vtkArrayData>::New();
    input_matrix_data->AddArray(input_matrix);

    for(int i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        std::cout << "Process " << controller->GetLocalProcessId() << "\n";
        input_features->Dump(20);
        std::cout << std::endl;
        }
      controller->Barrier();
      }

    for(int i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        std::cout << "Process " << controller->GetLocalProcessId() << "\n";
        vtkPrintMatrixFormat(std::cout, input_matrix.GetPointer());
        std::cout << std::endl;
        }
      controller->Barrier();
      }

    vtkSmartPointer<vtkPFrequencyMatrixFilter> filter = vtkSmartPointer<vtkPFrequencyMatrixFilter>::New();
    filter->SetController(controller);
    filter->SetInputData(0, input_features);
    filter->SetInputData(1, input_matrix_data);

    vtkTable* output_features = 0;
    vtkArrayData* output_matrix_data = 0;
    vtkSparseArray<double>* output_matrix = 0;

    // Test filtering by minimum document count
    filter->SetMinimumDocumentCount(4);
    filter->SetMinimumDocumentPercent(0);
    filter->SetMinimumFeatureCount(0);
    filter->Update();

    output_features = vtkTable::SafeDownCast(filter->GetOutputDataObject(0));
    test_expression(output_features);
    output_matrix_data = vtkArrayData::SafeDownCast(filter->GetOutputDataObject(1));
    test_expression(output_matrix_data);
    test_expression(output_matrix_data->GetNumberOfArrays() == 1);
    output_matrix = vtkSparseArray<double>::SafeDownCast(output_matrix_data->GetArray(0));
    test_expression(output_matrix);
    test_expression(output_matrix->GetDimensions() == 2);

    test_expression(output_features->GetNumberOfRows() == 3);
    test_expression(output_features->GetValueByName(0, "text") == "green");
    test_expression(output_features->GetValueByName(1, "text") == "blue");
    test_expression(output_features->GetValueByName(2, "text") == "dark blue");

    test_expression(output_matrix->GetExtent(0) == vtkArrayRange(0, 3));
    switch(controller->GetLocalProcessId())
      {
      case 0:
        test_expression(output_matrix->GetExtent(1) == vtkArrayRange(0, 3));
        break;
      case 1:
        test_expression(output_matrix->GetExtent(1) == vtkArrayRange(3, 6));
        break;
      }

    // Test filtering by minimum document percent
    filter->SetMinimumDocumentCount(0);
    filter->SetMinimumDocumentPercent(0.7);
    filter->SetMinimumFeatureCount(0);
    filter->Update();

    output_features = vtkTable::SafeDownCast(filter->GetOutputDataObject(0));
    test_expression(output_features);
    output_matrix_data = vtkArrayData::SafeDownCast(filter->GetOutputDataObject(1));
    test_expression(output_matrix_data);
    test_expression(output_matrix_data->GetNumberOfArrays() == 1);
    output_matrix = vtkSparseArray<double>::SafeDownCast(output_matrix_data->GetArray(0));
    test_expression(output_matrix);
    test_expression(output_matrix->GetDimensions() == 2);

    test_expression(output_features->GetNumberOfRows() == 2);
    test_expression(output_features->GetValueByName(0, "text") == "blue");
    test_expression(output_features->GetValueByName(1, "text") == "dark blue");

    test_expression(output_matrix->GetExtent(0) == vtkArrayRange(0, 2));
    switch(controller->GetLocalProcessId())
      {
      case 0:
        test_expression(output_matrix->GetExtent(1) == vtkArrayRange(0, 3));
        break;
      case 1:
        test_expression(output_matrix->GetExtent(1) == vtkArrayRange(3, 6));
        break;
      }

    // Test filtering by minimum feature count
    filter->SetMinimumDocumentCount(0);
    filter->SetMinimumDocumentPercent(0);
    filter->SetMinimumFeatureCount(6);
    filter->Update();

    output_features = vtkTable::SafeDownCast(filter->GetOutputDataObject(0));
    test_expression(output_features);
    output_matrix_data = vtkArrayData::SafeDownCast(filter->GetOutputDataObject(1));
    test_expression(output_matrix_data);
    test_expression(output_matrix_data->GetNumberOfArrays() == 1);
    output_matrix = vtkSparseArray<double>::SafeDownCast(output_matrix_data->GetArray(0));
    test_expression(output_matrix);
    test_expression(output_matrix->GetDimensions() == 2);

/*
    for(int i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        std::cout << "Process " << controller->GetLocalProcessId() << "\n";
        output_features->Dump(20);
        std::cout << std::endl;
        }
      controller->Barrier();
      }

    for(int i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        std::cout << "Process " << controller->GetLocalProcessId() << "\n";
        vtkPrintMatrixFormat(std::cout, output_matrix);
        std::cout << std::endl;
        }
      controller->Barrier();
      }
*/

    test_expression(output_features->GetNumberOfRows() == 2);
    test_expression(output_features->GetValueByName(0, "text") == "dark red");
    test_expression(output_features->GetValueByName(1, "text") == "blue");

    test_expression(output_matrix->GetExtent(0) == vtkArrayRange(0, 2));
    switch(controller->GetLocalProcessId())
      {
      case 0:
        test_expression(output_matrix->GetExtent(1) == vtkArrayRange(0, 3));
        break;
      case 1:
        test_expression(output_matrix->GetExtent(1) == vtkArrayRange(3, 6));
        break;
      }
    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    result = 1;
    }

  controller->Finalize();
  return result;
}
