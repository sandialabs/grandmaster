/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#define RUN_TEST1
#define RUN_TEST2


#include <mpi.h>

#include "vtkPSQLTableWriter.h"

#include <vtkIntArray.h>
#include <vtkMPICommunicator.h>
#include <vtkRowQueryToTable.h>
#include <vtkShortArray.h>
#include <vtkSmartPointer.h>
#include <vtkSQLDatabase.h>
#include <vtkSQLiteDatabase.h>
#include <vtkSQLQuery.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkVariantArray.h>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#include <vtksys/ios/fstream>
#include <vtksys/ios/sstream>

#include <string.h>

#if !defined(WIN32)
# include <unistd.h>
#endif

vtkSQLDatabase *DB = NULL;

// ----------------------------------------------------------------------

void
PrintTable(vtkTable *table)
{
  int row, col;
  cerr << "Table " << table << " has " << table->GetNumberOfColumns() << " columns: ";
  for (col = 0; col < table->GetNumberOfColumns(); ++col)
    {
    if (col > 0)
      {
      cerr << ", ";
      }
    cerr << "'" << table->GetColumnName(col) << "'";
    }
  cerr << "\n";

  cerr << "Table data (" << table->GetNumberOfRows() << " rows):\n";
  for (row = 0; row < table->GetNumberOfRows(); ++row)
    {
    cerr << "Row " << row << ": ";
    for (col = 0; col < table->GetNumberOfColumns(); ++col)
      {
      if (col > 0)
        {
        cerr << ", ";
        }
      vtkVariant data = table->GetValue(row, col);
      if (data.GetType() == VTK_STRING)
        {
        cerr << "'" << data.ToString() << "'";
        }
      else
        {
        cerr << data.ToString();
        }
      }
    cerr << "\n";
    }
  cerr << "End of table.\n\n";
}

// ----------------------------------------------------------------------

void
SetupDatabase()
{
  DB = vtkSQLiteDatabase::SafeDownCast( vtkSQLDatabase::CreateFromURL( "sqlite://:memory:" ) );
  bool status = DB->Open("");

  if ( ! status )
    {
      cerr << "Couldn't open database.\n";
      return;
    }

  vtkSmartPointer<vtkSQLQuery> query;
  vtkSQLQuery *rawQuery = DB->GetQueryInstance();
  query.TakeReference(rawQuery);

  query->SetQuery("CREATE TABLE fellowship_all_fields ( NameField VARCHAR(32), RaceField VARCHAR(32), HomelandField VARCHAR(32), DummyField INTEGER, ProcessIdField INTEGER )");
  status = query->Execute();

  if (!status)
    {
    cerr << "Couldn't create first table.\n";
    return;
    }

  query->SetQuery("CREATE TABLE fellowship_subset ( name VARCHAR(32), race VARCHAR(32), source_process INTEGER )");
  status = query->Execute();

  if (!status)
    {
    cerr << "Couldn't create second table.\n";
    return;
    }
}

// ----------------------------------------------------------------------

vtkTable *
SetupTable(int MyProcessId)
{
  VTK_CREATE(vtkStringArray, names);
  VTK_CREATE(vtkStringArray, races);
  VTK_CREATE(vtkStringArray, homes);
  VTK_CREATE(vtkIntArray, dummy);
  VTK_CREATE(vtkShortArray, process_id);

  names->SetName("NameField");
  races->SetName("RaceField");
  homes->SetName("HomelandField");
  dummy->SetName("DummyField");
  process_id->SetName("ProcessIdField");

  names->InsertNextValue("Gandalf the Grey");
  names->InsertNextValue("Frodo Baggins");
  names->InsertNextValue("Meriadoc Brandybuck");
  names->InsertNextValue("Samwise Gamgee");
  names->InsertNextValue("Peregin Took");
  names->InsertNextValue("Legolas Greenleaf");
  names->InsertNextValue("Aragorn, son of Arathorn");
  names->InsertNextValue("Boromir of Gondor");
  names->InsertNextValue("Gimli, son of Gloin");

  races->InsertNextValue("Maia");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Woodland Elf");
  races->InsertNextValue("Man (Dunedain)");
  races->InsertNextValue("Man");
  races->InsertNextValue("Dwarf");

  homes->InsertNextValue("The West");
  homes->InsertNextValue("Bag-End (The Shire)");
  homes->InsertNextValue("Buckland (The Shire)");
  homes->InsertNextValue("The Shire (1)");
  homes->InsertNextValue("The Shire (2)");
  homes->InsertNextValue("Mirkwood");
  homes->InsertNextValue("Rivendell");
  homes->InsertNextValue("Minas Tirith, Gondor");
  homes->InsertNextValue("Thorin's Hall");

  for (int i = 0; i < names->GetNumberOfTuples(); ++i)
    {
    dummy->InsertNextValue(i);
    process_id->InsertNextValue(static_cast<short>(MyProcessId));
    }

  vtkTable *table = vtkTable::New();
  table->AddColumn(process_id);
  table->AddColumn(homes);
  table->AddColumn(dummy);
  table->AddColumn(names);
  table->AddColumn(races);

  return table;
}

// ----------------------------------------------------------------------

int
TestPSQLTableWriter_Master(vtkCommunicator *comm)
{
  vtkSmartPointer<vtkTable> myTable;
  myTable.TakeReference(SetupTable(comm->GetLocalProcessId()));

  vtkSmartPointer<vtkSQLQuery> writerQuery1, writerQuery2;
  writerQuery1.TakeReference(DB->GetQueryInstance());
  writerQuery2.TakeReference(DB->GetQueryInstance());

  VTK_CREATE(vtkPSQLTableWriter, writer1);
  VTK_CREATE(vtkPSQLTableWriter, writer2);

  // Writer 1 will dump the entire table into the database with
  // prepared statements disabled.  Writer 2 will write a subset of
  // the columns and rename them as it goes.
  writer1->SetInputData(myTable);
  writer1->SetTableName("fellowship_all_fields");
  writer1->SetCommunicator(comm);
  writer1->SetQuery(writerQuery1);
  writer1->UsePreparedStatementsOff();
//  writer1->DebugOn();

  VTK_CREATE(vtkStringArray, includedColumns);
  VTK_CREATE(vtkStringArray, dbColumnNames);
  includedColumns->InsertNextValue("NameField");
  includedColumns->InsertNextValue("RaceField");
  includedColumns->InsertNextValue("ProcessIdField");
  dbColumnNames->InsertNextValue("name");
  dbColumnNames->InsertNextValue("race");
  dbColumnNames->InsertNextValue("source_process");

  writer2->SetInputData(myTable);
  writer2->SetTableName("fellowship_subset");
  writer2->SetCommunicator(comm);
  writer2->SetQuery(writerQuery2);
  writer2->SetIncludedColumns(includedColumns);
  writer2->SetColumnNames(dbColumnNames);
//  writer2->DebugOn();

#if defined(RUN_TEST1)
  cerr << "Running test 1 on master process ("
       << comm->GetLocalProcessId()
       << "): writing all fields to database without renaming or prepared statements.\n";
  writer1->Update();

  cerr << "Reading tables back out of local database.\n\n";
  vtkSmartPointer<vtkSQLQuery> readerQuery1;
  readerQuery1.TakeReference(DB->GetQueryInstance());
  readerQuery1->SetQuery("SELECT * FROM fellowship_all_fields ORDER BY NameField");
  VTK_CREATE(vtkRowQueryToTable, reader1);
  reader1->SetQuery(readerQuery1);

  reader1->Update();
  PrintTable(reader1->GetOutput());
#endif // RUN_TEST1

#if defined(RUN_TEST2)
  cerr << "Running test 2 on master process ("
       << comm->GetLocalProcessId()
       << "): writing some fields to database with prepared statements and renaming.\n";
  writer2->Update();

  vtkSmartPointer<vtkSQLQuery> readerQuery2;
  readerQuery2.TakeReference(DB->GetQueryInstance());
  readerQuery2->SetQuery("SELECT * FROM fellowship_subset ORDER BY name");
  VTK_CREATE(vtkRowQueryToTable, reader2);
  reader2->SetQuery(readerQuery2);

  reader2->Update();
  PrintTable(reader2->GetOutput());
#endif // RUN_TEST2

  return 0;
}

// ----------------------------------------------------------------------

int
TestPSQLTableWriter_Slave(vtkCommunicator *comm)
{
  vtkSmartPointer<vtkTable> myTable;
  myTable.TakeReference(SetupTable(comm->GetLocalProcessId()));

  VTK_CREATE(vtkPSQLTableWriter, writer1);
  VTK_CREATE(vtkPSQLTableWriter, writer2);

  // Writer 1 will dump the entire table into the database with
  // prepared statements disabled.  Writer 2 will write a subset of
  // the columns and rename them as it goes.
  writer1->SetInputData(myTable);
  writer1->SetTableName("fellowship_all_fields");
  writer1->SetCommunicator(comm);
  writer1->UsePreparedStatementsOff();
//  writer1->DebugOn();

  VTK_CREATE(vtkStringArray, includedColumns);
  VTK_CREATE(vtkStringArray, dbColumnNames);
  includedColumns->InsertNextValue("NameField");
  includedColumns->InsertNextValue("RaceField");
  includedColumns->InsertNextValue("ProcessIdField");
  dbColumnNames->InsertNextValue("name");
  dbColumnNames->InsertNextValue("race");
  dbColumnNames->InsertNextValue("source_process");

  writer2->SetInputData(myTable);
  writer2->SetTableName("fellowship_subset");
  writer2->SetCommunicator(comm);
  writer2->SetIncludedColumns(includedColumns);
  writer2->SetColumnNames(dbColumnNames);

#if defined(RUN_TEST1)
  cerr << "Running test 1 on slave process ("
       << comm->GetLocalProcessId()
       << "): writing all fields to database without renaming or prepared statements.\n";
  writer1->Update();
#endif

#if defined(RUN_TEST2)
  cerr << "Running test 2 on slave process ("
       << comm->GetLocalProcessId()
       << "): writing some fields to database with prepared statements and renaming.\n";
  writer2->Update();
#endif

  return 0;
}

// ----------------------------------------------------------------------


int main(int argc, char *argv[])
{
  // This is here to avoid false leak messages from vtkDebugLeaks when
  // using mpich. It appears that the root process which spawns all the
  // main processes waits in MPI_Init() and calls exit() when
  // the others are done, causing apparent memory leaks for any objects
  // created before MPI_Init().


  int mpi_already_open = 0;
  MPI_Initialized(&mpi_already_open);
  if (!mpi_already_open)
    {
    MPI_Init(&argc, &argv);
    }

  vtkMPICommunicator *comm = vtkMPICommunicator::GetWorldCommunicator();
  int retval;

  if (comm->GetLocalProcessId() == 0)
    {
    SetupDatabase();
    retval = TestPSQLTableWriter_Master(comm);
    DB->Delete();
    }
  else
    {
#if !defined(WIN32)
      sleep(comm->GetLocalProcessId());
#endif
    retval = TestPSQLTableWriter_Slave(comm);
    }

  cerr << "Process " << comm->GetLocalProcessId() << " done with test.\n";

  comm->Delete();

  return retval;
}
