/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/



#include <mpi.h>

#include "vtkPRowQueryToTable.h"
#include "vtkMPICommunicator.h"

#include <vtkSmartPointer.h>
#include <vtkSQLDatabase.h>
#include <vtkSQLiteDatabase.h>
#include <vtkSQLQuery.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkVariantArray.h>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#include <vtksys/ios/fstream>
#include <vtksys/ios/sstream>

#include <string.h>

#if !defined(WIN32)
# include <unistd.h>
#endif

int
TestPRowQueryToTable_Master( vtkCommunicator *comm )
{
  vtkSmartPointer<vtkSQLiteDatabase> db = vtkSmartPointer<vtkSQLiteDatabase>::Take(vtkSQLiteDatabase::SafeDownCast( vtkSQLDatabase::CreateFromURL( "sqlite://:memory:" ) ));
  bool status = db->Open("");

  if ( ! status )
    {
      cerr << "Couldn't open database.\n";
      return 1;
    }

  vtkSmartPointer<vtkSQLQuery> query;
  vtkSQLQuery *rawQuery = db->GetQueryInstance();
  query.TakeReference(rawQuery);

  query->SetQuery("CREATE TABLE fellowship ( name VARCHAR(32), race VARCHAR(32), homeland VARCHAR(32), dummy INTEGER )");
  status = query->Execute();

  if (!status)
    {
    cerr << "Couldn't create table.\n";
    return 1;
    }

  VTK_CREATE(vtkStringArray, names);
  VTK_CREATE(vtkStringArray, races);
  VTK_CREATE(vtkStringArray, homes);

  query->SetQuery("INSERT INTO fellowship ( name, race, homeland, dummy ) VALUES ( ?, ?, ?, ? )");

  names->InsertNextValue("Gandalf the Grey");
  names->InsertNextValue("Frodo Baggins");
  names->InsertNextValue("Meriadoc Brandybuck");
  names->InsertNextValue("Samwise Gamgee");
  names->InsertNextValue("Peregin Took");
  names->InsertNextValue("Legolas Greenleaf");
  names->InsertNextValue("Aragorn, son of Arathorn");
  names->InsertNextValue("Boromir of Gondor");
  names->InsertNextValue("Gimli, son of Gloin");

  races->InsertNextValue("Maia");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Hobbit");
  races->InsertNextValue("Woodland Elf");
  races->InsertNextValue("Man (Dunedain)");
  races->InsertNextValue("Man");
  races->InsertNextValue("Dwarf");

  homes->InsertNextValue("The West");
  homes->InsertNextValue("Bag-End (The Shire)");
  homes->InsertNextValue("Buckland (The Shire)");
  homes->InsertNextValue("The Shire (1)");
  homes->InsertNextValue("The Shire (2)");
  homes->InsertNextValue("Mirkwood");
  homes->InsertNextValue("Rivendell");
  homes->InsertNextValue("Minas Tirith, Gondor");
  homes->InsertNextValue("Thorin's Hall");

  for (int i = 0; i < names->GetNumberOfTuples(); ++i)
    {
    query->BindParameter(0, names->GetValue(i));
    query->BindParameter(1, races->GetValue(i));
    query->BindParameter(2, homes->GetValue(i));
    query->BindParameter(3, i);
    status = query->Execute();
    if (!status)
      {
      cerr << "Couldn't insert row " << i << "\n";
      return 1;
      }
    }

  // At this point we have a simple database to play with.

  VTK_CREATE(vtkPRowQueryToTable, TableReader);
  TableReader->SetCommunicator(comm);

  vtkSmartPointer<vtkSQLQuery> ReaderQuery;
  rawQuery = db->GetQueryInstance();
  ReaderQuery.TakeReference(rawQuery);

  ReaderQuery->SetQuery("SELECT * FROM fellowship");
  TableReader->SetQuery(ReaderQuery);

  cerr << "About to execute table reader on master process "
       << comm->GetLocalProcessId() << ".\n";
  TableReader->Update();

  cerr << "After executing table reader, output table has "
       << TableReader->GetOutput()->GetNumberOfRows()
       << " rows on process "
       << comm->GetLocalProcessId() << ".\n";

  cerr << "Field names: ";
  int i;
  vtkTable *table = TableReader->GetOutput();
  for (i = 0; i < table->GetNumberOfColumns(); ++i)
    {
    if (i > 0)
      {
      cerr << ", ";
      }
    cerr << "'" << table->GetColumnName(i) << "'";
    }
  cerr << "\n";
  cerr << "Data:\n";
  for (i = 0; i < table->GetNumberOfRows(); ++i)
    {
    cerr << "Row " << i << ": ";
    for (int j = 0; j < table->GetNumberOfColumns(); ++j)
      {
      if (j > 0)
        cerr << ", ";
      cerr << table->GetValue(i, j).ToString();
      }
    cerr << "\n";
    }

  return 0;
}

// ----------------------------------------------------------------------

int
TestPRowQueryToTable_Slave( vtkCommunicator *comm )
{
  VTK_CREATE(vtkPRowQueryToTable, TableReader);
  TableReader->SetCommunicator(comm);
  TableReader->ReadEntireRowOff();

  cerr << "About to execute table reader on slave process "
       << comm->GetLocalProcessId() << ".\n";
  TableReader->Update();

#if !defined(WIN32)
      cerr << "Process " << comm->GetLocalProcessId() << " sleeping for "
     << 5*comm->GetLocalProcessId() << " seconds\n";
      sleep(comm->GetLocalProcessId() * 5);
#endif

  cerr << "After executing table reader, output table has "
       << TableReader->GetOutput()->GetNumberOfRows()
       << " rows on process "
       << comm->GetLocalProcessId() << ".\n";

  cerr << "Field names: ";
  int i;
  vtkTable *table = TableReader->GetOutput();
  for (i = 0; i < table->GetNumberOfColumns(); ++i)
    {
    if (i > 0)
      {
      cerr << ", ";
      }
    cerr << "'" << table->GetColumnName(i) << "'";
    }
  cerr << "\n";
  cerr << "Data:\n";
  for (i = 0; i < table->GetNumberOfRows(); ++i)
    {
    cerr << "Row " << i << ": ";
    for (int j = 0; j < table->GetNumberOfColumns(); ++j)
      {
      if (j > 0)
        cerr << ", ";
      cerr << table->GetValue(i, j).ToString();
      }
    cerr << "\n";
    }

  return 0;
}


// ----------------------------------------------------------------------


int main(int argc, char *argv[])
{
  // This is here to avoid false leak messages from vtkDebugLeaks when
  // using mpich. It appears that the root process which spawns all the
  // main processes waits in MPI_Init() and calls exit() when
  // the others are done, causing apparent memory leaks for any objects
  // created before MPI_Init().

  int mpi_already_open = 0;
  MPI_Initialized(&mpi_already_open);
  if (!mpi_already_open)
    {
    MPI_Init(&argc, &argv);
    }

  vtkMPICommunicator *comm = vtkMPICommunicator::GetWorldCommunicator();
  int retval;

  if (comm->GetLocalProcessId() == 0)
    {
    retval = TestPRowQueryToTable_Master(comm);
    comm->Barrier();
    }
  else
    {
    retval = TestPRowQueryToTable_Slave(comm);
    comm->Barrier();
    }

  comm->Delete();

  MPI_Finalize();
  return retval;
}
