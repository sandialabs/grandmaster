/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkArrayExtentsList.h"
#include "vtkCommand.h"
#include "vtkDenseArray.h"
#include "vtkDistributedArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMPI.h"
#include "vtkMPICommunicator.h"
#include "vtkObjectFactory.h"
#include "vtkPEntropyMatrixWeightingNToN.h"
#include "vtkSmartPointer.h"

#include <stdexcept>
#include <iterator>
#include <numeric>

#if defined(WIN32) && !defined(__MINGW32__)

static inline double log2(double n)
{
  return log(n) / log(2.);
}

#endif // WIN32

///////////////////////////////////////////////////////////////////////////////
// vtkPEntropyMatrixWeightingNToN


vtkStandardNewMacro(vtkPEntropyMatrixWeightingNToN);

vtkPEntropyMatrixWeightingNToN::vtkPEntropyMatrixWeightingNToN() :
  FeatureDimension(0),
  Controller(0)
{
  this->SetNumberOfInputPorts(1);
  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPEntropyMatrixWeightingNToN::~vtkPEntropyMatrixWeightingNToN()
{
  this->SetController(0);
}

void vtkPEntropyMatrixWeightingNToN::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "FeatureDimension: " << this->FeatureDimension << endl;
}

int vtkPEntropyMatrixWeightingNToN::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;
    }

    return 0;
}


int vtkPEntropyMatrixWeightingNToN::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    vtkMPICommunicator* const mpi_communicator = vtkMPICommunicator::SafeDownCast(this->Controller->GetCommunicator());
    if(!mpi_communicator)
      throw std::runtime_error("Process controller must provide an MPI communicator.");

    // Test our preconditions ...
    vtkArrayData* const input_data = vtkArrayData::GetData(inputVector[0]);
    if(!input_data)
      throw std::runtime_error("Missing input vtkArrayData on port 0.");
    if(input_data->GetNumberOfArrays() != 1)
      throw std::runtime_error("Input vtkArrayData must contain exactly one array.");
    vtkTypedArray<double>* const input_array = vtkTypedArray<double>::SafeDownCast(input_data->GetArray(0));
    if(!input_array)
      throw std::runtime_error("Input array must be a vtkTypedArray<double>.");
    if(input_array->GetDimensions() != 2)
      throw std::runtime_error("Input array must be a matrix.");

    vtkIdType feature_dimension;
    vtkIdType object_dimension;
    switch(this->FeatureDimension)
      {
      case 0:
        feature_dimension = 0;
        object_dimension = 1;
        break;
      case 1:
        feature_dimension = 1;
        object_dimension = 0;
        break;
      default:
        throw std::runtime_error("FeatureDimension out-of-bounds.");
      }

    //const vtkIdType global_doc_count = input_array->GetExtent(object_dimension).GetSize();
    const vtkIdType feature_count = input_array->GetExtent(feature_dimension).GetSize();

    // Setup our output ...
    vtkDenseArray<double>* const output_array = vtkDenseArray<double>::New();
    output_array->Resize(feature_count);
    output_array->Fill(0.0);

    vtkArrayData* const output = vtkArrayData::GetData(outputVector);
    output->ClearArrays();
    output->AddArray(output_array);
    output_array->Delete();
    output_array->SetName("entropy_weight");

    int numProcs = this->Controller->GetNumberOfProcesses();

    // Make it happen ...

    this->Controller->GetCommunicator()->Barrier();
    vtkArrayExtentsList extent_list = vtkDistributedArray::AllGatherExtents(this->Controller, input_array);
    vtkArrayExtents global_extents = vtkDistributedArray::GlobalExtents(extent_list);
    const vtkIdType global_doc_count = global_extents[object_dimension].GetSize();

    const double logN = log2(static_cast<double>(global_doc_count));

    // Cache the frequency of each feature across the local documents ...
    this->Controller->GetCommunicator()->Barrier();
    std::vector<double> Fi(feature_count, 0);
    vtkArrayCoordinates coordinates;
    const vtkIdType non_null_count = input_array->GetNonNullSize();
    for(vtkIdType n = 0; n != non_null_count; ++n)
      {
      input_array->GetCoordinatesN(n, coordinates);
      const vtkIdType i = coordinates[feature_dimension];
      const double fij = input_array->GetValueN(n);
      Fi[i] += fij;
      }

    // Gather the frequency of each feature across ALL documents
    this->Controller->GetCommunicator()->Barrier();
    std::vector<double> global_feature_counts(feature_count, 0);
    this->Controller->GetCommunicator()->AllReduce(&Fi[0], &global_feature_counts[0], feature_count, vtkCommunicator::SUM_OP);

    // Compute global feature weights using the local documents ...
    this->Controller->GetCommunicator()->Barrier();
    std::vector<double> local_feature_weights(feature_count, 0);
    for(vtkIdType n = 0; n != non_null_count; ++n)
      {
      input_array->GetCoordinatesN(n, coordinates);
      const vtkIdType i = coordinates[feature_dimension];
      const double fij = input_array->GetValueN(n);
      const double pij = fij / global_feature_counts[i];
      local_feature_weights[i] += (pij * log2(pij));
      }

    // Compute actual global feature weights by summing across processes
    this->Controller->GetCommunicator()->Barrier();
    std::vector<double> global_feature_weights(feature_count, 0);
    this->Controller->GetCommunicator()->AllReduce(&local_feature_weights[0], &global_feature_weights[0], feature_count, vtkCommunicator::SUM_OP);

    // Add 1 to each weight ...
    for(vtkIdType i = 0; i != feature_count; ++i)
      {
      output_array->SetValue(i, global_feature_weights[i]/logN + 1);
      }
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  return 1;
}
