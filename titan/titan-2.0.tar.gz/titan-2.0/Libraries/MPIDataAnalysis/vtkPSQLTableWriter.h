/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkPSQLTableWriter vtkPSQLTableWriter.h <MPIDataAnalysis/vtkPSQLTableWriter.h>
/// \brief Gather columns in a distributed table back to a master node and write into an SQL database
///
///
///  This is a parallel version of vtkSQLTableWriter.  It assumes that
///  you have many nodes that each have parts of a large table that they
///  want to write into a database through a single connection.  As with
///  vtkPRowQueryToTable, you use this filter by setting a vtkSQLQuery
///  instance on one of the processes and leaving it NULL on all the
///  other instances.  Parameters such as TableName, IncludedColumns and
///  ColumnNames must be set identically on all instances.  You must
///  also supply a vtkCommunicator that describes the process group that
///  will participate.
///
///  Upon execution, all instances will send their rows to the master
///  node, which will then insert them into the database.  There are no
///  guarantees on the order in which rows will be inserted.
///
///  All the tables on all the nodes must have the same number of
///  columns with the same names.  However, there are no restrictions on
///  the number of rows that can be inserted by each process.
///
/// \bug
///
///  At the moment this filter sends rows to the master node one at a
///  time.  Depending on MPI's per-transfer overhead and its maximum
///  buffer size there may be a better way to do things.
///
/// \sa
///  vtkSQLTableWriter

#ifndef __vtkPSQLTableWriter_h
#define __vtkPSQLTableWriter_h

#include <titanMPIDataAnalysis.h>
#include <vtkSQLTableWriter.h>
#include <vtkStdString.h>

class vtkCommunicator;
class vtkInformation;
class vtkStringArray;
class vtkSQLQuery;
class vtkTable;
class vtkVariantArray;

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPSQLTableWriter : public vtkSQLTableWriter
{
public:
  vtkTypeMacro(vtkPSQLTableWriter, vtkSQLTableWriter);
  static vtkPSQLTableWriter *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  ///@{
  /// This communicator describes the process group that will be
  /// writing table rows.
  void SetCommunicator(vtkCommunicator *comm);
  vtkGetObjectMacro(Communicator, vtkCommunicator);
  ///@}

  ///@{
  /// Set/get the name of the database table where the results will be stored
  vtkSetStringMacro(TableName);
  vtkGetStringMacro(TableName);
  ///@}

protected:
  vtkPSQLTableWriter();
  ~vtkPSQLTableWriter();

  vtkSetMacro(MasterProcessId, int);
  vtkGetMacro(MasterProcessId, int);

  void WriteData();
  void WriteDataMasterNode();
  void WriteDataSlaveNode();

  /// Collect all rows from other processes and write them into the database
  void WriteRowsFromAllProcesses(vtkTable *exampleTable);

  /// Listen for process P to tell us whether it has another row ready
  bool CheckForRow(int p, int RowsSoFar);

  /// Receive the data for the next row from process P
  void ReceiveRowData(int p, int RowId, vtkVariantArray *data);

  /// Write a row to the database.  The preamble parameter is used in
  /// case we can't use prepared statements and have to write all the
  /// SQL out the hard way.
  void InsertRow(const vtkStdString &preamble, vtkVariantArray *data);

  /// Find out which process has the vtkSQLQuery object set.  If more
  /// than one are set, this function will find the process with the
  /// lowest ID.  This function sets MasterProcessId as a side effect.
  int LocateMasterProcess();

  /// Send all the rows in the given table to the master process.
  void SendRowsToMasterProcess(vtkTable *table);

  /// Tell the master process that there's another row available.
  void AnnounceRowAvailable(int whichRow);

  /// Tell the master process that there are no more rows.
  void AnnounceNoMoreRows(int rowCountTotal);

  /// Send a single row to the master process.
  void SendRowToMasterProcess(vtkVariantArray *data, int RowId);

  vtkCommunicator *Communicator;
  int MasterProcessId;

private:
  vtkPSQLTableWriter(const vtkPSQLTableWriter &);
  void operator=(const vtkPSQLTableWriter &);

};

#endif
