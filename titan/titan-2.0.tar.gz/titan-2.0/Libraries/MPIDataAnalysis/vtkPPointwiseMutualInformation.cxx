/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkArrayCoordinates.h"
#include "vtkCommand.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMPICommunicator.h"
#include "vtkPPointwiseMutualInformation.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkTypedArray.h"

#include <cmath>
#include <algorithm>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// vtkPPointwiseMutualInformation


vtkStandardNewMacro(vtkPPointwiseMutualInformation);

vtkPPointwiseMutualInformation::vtkPPointwiseMutualInformation() :
  DistributedDimension(0),
  Strategy(N_TO_1)
{
}

vtkPPointwiseMutualInformation::~vtkPPointwiseMutualInformation()
{
}

void vtkPPointwiseMutualInformation::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkPPointwiseMutualInformation::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    vtkMPICommunicator* const mpi_communicator = vtkMPICommunicator::SafeDownCast(this->Controller->GetCommunicator());
    if(!mpi_communicator)
      throw std::runtime_error("Process controller must provide an MPI communicator.");

    // Enforce our input preconditions ...
    vtkArrayData* const input_data = vtkArrayData::GetData(inputVector[0]);
    if(!input_data)
      throw std::runtime_error("Missing vtkArrayData on input port 0.");
    if(input_data->GetNumberOfArrays() != 1)
      throw std::runtime_error("vtkArrayData on input port 0 must contain exactly one vtkArray.");
    vtkTypedArray<double>* const input_array = vtkTypedArray<double>::SafeDownCast(input_data->GetArray(0));
    if(!input_array)
      throw std::runtime_error("Unsupported input array type.");
    if(!input_array->GetExtents().ZeroBased())
      throw std::runtime_error("Input array must use zero-based indices.");

    // Create an output array ...
    vtkTypedArray<double>* const output_array = vtkTypedArray<double>::SafeDownCast(input_array->DeepCopy());
    vtkArrayData* const output = vtkArrayData::GetData(outputVector);
    output->ClearArrays();
    output->AddArray(output_array);
    output_array->Delete();

    const vtkIdType dimension_count = input_array->GetDimensions();
    const vtkIdType value_count = input_array->GetNonNullSize();

    if(value_count == 0)
      {
      // Allow for an empty input
      return 1;
      }

    // This is a portable way to compute log base-2 ...
    static const double ln2 = log(2.0);

    // Compute array value sums along each dimension ...
    std::vector<std::vector<double> > dimension_sums(dimension_count);
    for(vtkIdType i = 0; i != dimension_count; ++i)
      {
      if(i == this->DistributedDimension)
        {
        // Add a spot to store the total array sum
        dimension_sums[i].resize(input_array->GetExtent(i).GetSize() + 1, 0.0);
        }
      else
        {
        dimension_sums[i].resize(input_array->GetExtent(i).GetSize(), 0.0);
        }
      }

    vtkArrayCoordinates coordinates;
    double array_sum = 0.0;
    for(vtkIdType n = 0; n != value_count; ++n)
      {
      const double value = input_array->GetValueN(n);
      input_array->GetCoordinatesN(n, coordinates);

      array_sum += value;
      for(vtkIdType i = 0; i != dimension_count; ++i)
        {
        dimension_sums[i][coordinates[i]] += value;
        }
      }

    int dist_dim_size = input_array->GetExtent(this->DistributedDimension).GetSize();

    // Store the total array sum in the last spot of the vector so its sum will
    // also be computed across processors in the call to REDUCE
    dimension_sums[this->DistributedDimension][dist_dim_size] = array_sum;

    // Send local sums to the root node, summing, then broadcast ...
    this->Controller->GetCommunicator()->Barrier();

    std::vector<double> global_sums(dist_dim_size+1, 0);
    if(this->Strategy == N_TO_1)
      {
      this->Controller->GetCommunicator()->Reduce(&dimension_sums[this->DistributedDimension][0], &global_sums[0], dist_dim_size+1, vtkCommunicator::SUM_OP, 0);
      this->Controller->GetCommunicator()->Broadcast(&global_sums[0], dist_dim_size+1, 0);
      }
    else if(this->Strategy == N_TO_N)
      {
      this->Controller->GetCommunicator()->AllReduce(&dimension_sums[this->DistributedDimension][0], &global_sums[0], dist_dim_size+1, vtkCommunicator::SUM_OP);
      }

    // Override the local sums along the distributed dimension with the global ones
    // while also computing a total array sum ...
    this->Controller->GetCommunicator()->Barrier();
    for(int k=0; k<dist_dim_size; ++k)
      {
      dimension_sums[this->DistributedDimension][k] = global_sums[k];
      }

    // Override local array sum with the global one
    array_sum = global_sums[dist_dim_size];

    if(!array_sum)
      throw std::runtime_error("Cannot compute PMI with zero array probability.");
    for(vtkIdType i = 0; i != dimension_count; ++i)
      {
      if(std::count(dimension_sums[i].begin(), dimension_sums[i].end(), 0))
        throw std::runtime_error("Cannot compute PMI with zero dimension sums.");
      }

    // Compute the PMI for each array value ...
    for(vtkIdType n = 0; n != value_count; ++n)
      {
      const double value = input_array->GetValueN(n);
      if(!value)
        {
        output_array->SetValueN(n, 0);
        continue;
        }

      input_array->GetCoordinatesN(n, coordinates);

      double result = value / array_sum;
      for(vtkIdType i = 0; i != dimension_count; ++i)
        {
        result /= (value / dimension_sums[i][coordinates[i]]);
        }

      output_array->SetValueN(n, std::log(result) / ln2);
      }
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  return 1;
}
