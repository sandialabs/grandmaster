/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkPEntropyMatrixWeightingCommunicator.h"

#include <vtkDoubleArray.h>
#include <vtkIntArray.h>
#include <vtkMPICommunicator.h>
#include <vtkMultiProcessController.h>
#include <vtkTable.h>
#include <vtkVariant.h>


///////////////////////////////////////////////////////////////////////////////
// vtkPEntropyMatrixWeightingCommunicator

vtkPEntropyMatrixWeightingCommunicator::vtkPEntropyMatrixWeightingCommunicator(vtkCommunicator* communicator) :
  Communicator(communicator)
{
}

void vtkPEntropyMatrixWeightingCommunicator::Send(const FeatureValues& vals_map, int recipient)
{
  vtkSmartPointer<vtkIntArray> ids = vtkSmartPointer<vtkIntArray>::New();
  ids->SetNumberOfValues(vals_map.size());
  vtkSmartPointer<vtkDoubleArray> values = vtkSmartPointer<vtkDoubleArray>::New();
  values->SetNumberOfValues(vals_map.size());
  FeatureValues::const_iterator iter;
  int count = 0;
  for(iter = vals_map.begin(); iter != vals_map.end(); ++iter)
    {
    ids->SetValue(count, iter->first);
    values->SetValue(count, iter->second);
    count++;
    }

  vtkSmartPointer<vtkTable> table_buffer = vtkSmartPointer<vtkTable>::New();
  table_buffer->AddColumn(ids);
  table_buffer->AddColumn(values);

  this->Communicator->Send(table_buffer, recipient, 0);
}

void vtkPEntropyMatrixWeightingCommunicator::Receive(int sender, FeatureValues& vals_map)
{
  vtkSmartPointer<vtkTable> table_buffer = vtkSmartPointer<vtkTable>::New();
  this->Communicator->Receive(table_buffer, sender, 0);

  for(int i=0; i<table_buffer->GetNumberOfRows(); ++i)
    {
    vals_map.insert(std::make_pair<int, double>(table_buffer->GetValue(0, i).ToInt(), table_buffer->GetValue(1, i).ToDouble()));
    }
}

void vtkPEntropyMatrixWeightingCommunicator::Broadcast(FeatureValues& vals_map, int sender)
{
  vtkSmartPointer<vtkTable> table_buffer = vtkSmartPointer<vtkTable>::New();

  if(sender == this->Communicator->GetLocalProcessId())
    {
    vtkSmartPointer<vtkIntArray> ids = vtkSmartPointer<vtkIntArray>::New();
    ids->SetNumberOfValues(vals_map.size());
    vtkSmartPointer<vtkDoubleArray> values = vtkSmartPointer<vtkDoubleArray>::New();
    values->SetNumberOfValues(vals_map.size());
    FeatureValues::iterator iter;
    int count = 0;
    for(iter = vals_map.begin(); iter != vals_map.end(); ++iter)
      {
      ids->SetValue(count, iter->first);
      values->SetValue(count, iter->second);
      count++;
      }

    table_buffer->AddColumn(ids);
    table_buffer->AddColumn(values);
    }

  this->Communicator->Broadcast(table_buffer, sender);

  if(sender != this->Communicator->GetLocalProcessId())
    {
    for(int i=0; i<table_buffer->GetNumberOfRows(); ++i)
      {
      vals_map.insert(std::make_pair<int, double>(table_buffer->GetValue(0, i).ToInt(), table_buffer->GetValue(1, i).ToDouble()));
      }
    }
}
