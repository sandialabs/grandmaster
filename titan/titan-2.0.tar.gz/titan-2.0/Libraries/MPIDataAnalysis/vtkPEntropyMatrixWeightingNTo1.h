/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkPEntropyMatrixWeightingNTo1 vtkPEntropyMatrixWeightingNTo1.h <MPIDataAnalysis/vtkPEntropyMatrixWeightingNTo1.h>
/// \brief computes a weighting vector for an input matrix.
///
///    Input port 0: (required) A vtkArrayData containing a frequency matrix.
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

#ifndef __vtkPEntropyMatrixWeightingNTo1_h
#define __vtkPEntropyMatrixWeightingNTo1_h

#include <titanMPIDataAnalysis.h>
#include <vtkArrayDataAlgorithm.h>
#include <vtkMultiProcessController.h>

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPEntropyMatrixWeightingNTo1 :
  public vtkArrayDataAlgorithm
{
public:
  static vtkPEntropyMatrixWeightingNTo1* New();
  vtkTypeMacro(vtkPEntropyMatrixWeightingNTo1, vtkArrayDataAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Controls the feature dimension.  Default: 0
  vtkGetMacro(FeatureDimension, int);
  vtkSetMacro(FeatureDimension, int);
  ///@}

  ///@{
  /// Get/Set the parallel controller.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

//BTX
  enum
  {
    VECTOR = 0,
    MAP = 1
  };
//ETX

  ///@{
  /// Specify the type of data structure to use to pass feature counts/weights
  /// between processes.
  vtkSetMacro(DataStructure, int);
  vtkGetMacro(DataStructure, int);
  ///@}

//BTX
protected:
  vtkPEntropyMatrixWeightingNTo1();
  ~vtkPEntropyMatrixWeightingNTo1();

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPEntropyMatrixWeightingNTo1(const vtkPEntropyMatrixWeightingNTo1&); // Not implemented
  void operator=(const vtkPEntropyMatrixWeightingNTo1&);   // Not implemented

  int FeatureDimension;
  int DataStructure;

  vtkMultiProcessController* Controller;
//ETX
};

#endif
