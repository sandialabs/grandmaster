/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkPGenerateIndexArray vtkPGenerateIndexArray.h <MPIDataAnalysis/vtkPGenerateIndexArray.h>
/// \brief ...
///
///  Generates a new vtkIdTypeArray containing zero-base indices.
///
///  vtkGenerateIndexArray simply generates an index array containing
///  monotonically-increasing integers in the range [0, N), where N
///  is appropriately sized for the field type that will store the
///  results.  This mode is useful for generating a unique ID field
///  for datasets that have none.
///

#ifndef __vtkPGenerateIndexArray_h
#define __vtkPGenerateIndexArray_h

#include <titanMPIDataAnalysis.h>
#include "vtkDataObjectAlgorithm.h"

class vtkMultiProcessController;

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPGenerateIndexArray : public vtkDataObjectAlgorithm
{
public:
  static vtkPGenerateIndexArray *New();

  vtkTypeMacro(vtkPGenerateIndexArray, vtkDataObjectAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Set the vtkMultiProcessController to be used for combining filter
  /// results from the individual nodes.
  virtual void SetController(vtkMultiProcessController*);
  vtkGetObjectMacro(Controller,vtkMultiProcessController);
  ///@}

  ///@{
  /// Control the output index array name.  Default: "index".
  vtkSetStringMacro(ArrayName);
  vtkGetStringMacro(ArrayName);
  ///@}

  ///@{
  /// Control the location where the index array will be stored.
  vtkSetMacro(FieldType, int);
  vtkGetMacro(FieldType, int);
  ///@}

  ///@{
  /// Specifies whether the index array should be marked as
  /// pedigree ids.  Default: false.
  vtkSetMacro(PedigreeID, int);
  vtkGetMacro(PedigreeID, int);
  ///@}

//BTX
  enum
  {
    ROW_DATA = 0,
    POINT_DATA = 1,
    CELL_DATA = 2,
    VERTEX_DATA = 3,
    EDGE_DATA = 4
  };
//ETX

protected:
  vtkPGenerateIndexArray();
  ~vtkPGenerateIndexArray();

  virtual int ProcessRequest(
    vtkInformation* request,
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector);

  virtual int RequestDataObject(
    vtkInformation* request,
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

  char* ArrayName;
  int FieldType;
  int PedigreeID;

  vtkMultiProcessController* Controller;

private:
  vtkPGenerateIndexArray(const vtkPGenerateIndexArray&);  // Not implemented.
  void operator=(const vtkPGenerateIndexArray&);  // Not implemented.
};

#endif
