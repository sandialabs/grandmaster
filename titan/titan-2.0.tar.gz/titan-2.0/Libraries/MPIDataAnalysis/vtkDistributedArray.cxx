/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkArray.h>
#include <vtkDistributedArray.h>
#include <vtkMultiProcessController.h>
#include <vtkTryDowncast.h>

#include <iterator>
#include <numeric>

const std::vector<vtkIdType> vtkDistributedArray::AllGatherDimensions(vtkMultiProcessController* controller, vtkArray* local_array)
{
  std::vector<vtkIdType> dimensions(controller->GetNumberOfProcesses(), 0);
  const vtkIdType local_dimensions = local_array->GetDimensions();
  controller->AllGather(&local_dimensions, &dimensions[0], 1);
  return dimensions;
}

const vtkArrayExtentsList vtkDistributedArray::AllGatherExtents(vtkMultiProcessController* controller, vtkArray* local_array)
{
  std::vector<vtkIdType> processor_dimensions = AllGatherDimensions(controller, local_array);

  std::vector<vtkIdType> processor_offsets(processor_dimensions.size(), 0);
  for(vtkIdType i = 1; i < processor_offsets.size(); ++i)
    processor_offsets[i] = processor_offsets[i-1] + processor_dimensions[i];

  const vtkIdType total_dimensions = std::accumulate(processor_dimensions.begin(), processor_dimensions.end(), 0);
  std::vector<vtkIdType> global_begin(total_dimensions, 0);
  std::vector<vtkIdType> global_end(total_dimensions, 0);

  const vtkArrayExtents local_extents = local_array->GetExtents();
  std::vector<vtkIdType> local_begin;
  std::vector<vtkIdType> local_end;
  for(vtkIdType i = 0; i != local_extents.GetDimensions(); ++i)
    {
    local_begin.push_back(local_extents[i].GetBegin());
    local_end.push_back(local_extents[i].GetEnd());
    }

  controller->AllGatherV(&local_begin[0], &global_begin[0], local_begin.size(), &processor_dimensions[0], &processor_offsets[0]);
  controller->AllGatherV(&local_end[0], &global_end[0], local_end.size(), &processor_dimensions[0], &processor_offsets[0]);

  vtkArrayExtentsList global_extents;
  global_extents.SetCount(processor_dimensions.size());
  for(vtkIdType i = 0; i != processor_dimensions.size(); ++i)
    {
    vtkArrayExtents extents;
    extents.SetDimensions(processor_dimensions[i]);
    for(vtkIdType j = 0; j != processor_dimensions[i]; ++j)
      {
      extents[j] = vtkArrayRange(global_begin[j + processor_offsets[i]], global_end[j + processor_offsets[i]]);
      }
    global_extents[i] = extents;
    }

  return global_extents;
}

const vtkArrayExtents vtkDistributedArray::GlobalExtents(const vtkArrayExtentsList& process_extents)
{
  // Sanity check ... every process should have the same number of dimensions ...
  for(vtkIdType process = 0; process != process_extents.GetCount(); ++process)
    {
    if(process_extents[process].GetDimensions() != process_extents[0].GetDimensions())
      {
      vtkGenericWarningMacro(<< "Per-process extents must have a consistent number of dimensions to compute global extents.");
      return vtkArrayExtents();
      }
    }

  // Compute the "union" of the process extents (the smallest set of extents that enclose every process).
  // Note that this computation is a little naive, we're assuming that the global array was partitioned
  // so that there aren't any "gaps" between partitions.
  vtkArrayExtents global_extents;

  if(process_extents.GetCount())
    {
    global_extents = process_extents[0];
    for(vtkIdType process = 1; process != process_extents.GetCount(); ++process)
      {
      vtkArrayExtents a = process_extents[process];
      vtkArrayExtents b;
      for(vtkIdType dimension = 0; dimension != a.GetDimensions(); ++dimension)
        {
        b.Append(
          vtkArrayRange(
            std::min(global_extents[dimension].GetBegin(), a[dimension].GetBegin()),
            std::max(global_extents[dimension].GetEnd(), a[dimension].GetEnd())));
        }
      global_extents = b;
      }
    }
  return global_extents;
}

class vtkDistributedArray::GatherArrayHelper
{
public:
  GatherArrayHelper(vtkMultiProcessController* controller, int destination_process, vtkArray*& result) :
    Controller(controller),
    DestinationProcess(destination_process),
    Result(result)
  {
  }

  template<typename ValueT>
  void operator()(vtkDenseArray<ValueT>* local_array) const
  {
    vtkArrayExtentsList process_extents = vtkDistributedArray::AllGatherExtents(this->Controller, local_array);
    const vtkArrayExtents global_extents = GlobalExtents(process_extents);
    if(global_extents.GetDimensions() == 0)
      return;

    std::vector<ValueT> process_values;
    std::vector<vtkIdType> process_sizes;
    std::vector<vtkIdType> process_offsets;
    process_sizes.resize(process_extents.GetCount());
    process_offsets.resize(process_extents.GetCount());
    for(vtkIdType i = 0; i != process_extents.GetCount(); ++i)
      {
        process_sizes[i] = process_extents[i].GetSize();
        process_offsets[i] = i ? process_offsets[i-1] + process_sizes[i-1] : 0;
      }
    process_values.resize(std::accumulate(process_sizes.begin(), process_sizes.end(), 0));

    this->Controller->GatherV(local_array->GetStorage(), &process_values[0], local_array->GetSize(), &process_sizes[0], &process_offsets[0], this->DestinationProcess);

    if(this->Controller->GetLocalProcessId() != this->DestinationProcess)
      return;

    vtkDenseArray<ValueT>* global_array = vtkDenseArray<ValueT>::New();
    global_array->Resize(GlobalExtents(process_extents));
    global_array->SetName(local_array->GetName());
    for(vtkIdType dimension = 0; dimension != local_array->GetDimensions(); ++dimension)
      {
      global_array->SetDimensionLabel(dimension, local_array->GetDimensionLabel(dimension));
      }

    vtkArrayCoordinates coordinates;
    for(vtkIdType process = 0; process != process_extents.GetCount(); ++process)
      {
      const vtkArrayExtents extents = process_extents[process];
      for(vtkIdType n = 0; n != extents.GetSize(); ++n)
        {
        extents.GetLeftToRightCoordinatesN(n, coordinates);
        global_array->SetValue(coordinates, process_values[process_offsets[process] + n]);
        }
      }

    this->Result = global_array;
  }

/*
  template<typename ValueT>
  void operator()(vtkSparseArray<ValueT>* local_array) const
  {
    vtkArrayExtentsList process_extents = vtkDistributedArray::AllGatherExtents(this->Controller, local_array);
    const vtkArrayExtents global_extents = GlobalExtents(process_extents);
    if(global_extents.GetDimensions() == 0)
      return;

    const vtkIdType local_non_null_size = local_array->GetNonNullSize();
    std::vector<vtkIdType> global_non_null_sizes(this->Controller->GetNumberOfProcesses(), 0);
    this->Controller->Gather(&local_non_null_size, &global_non_null_sizes[0], 1, this->DestinationProcess);

    std::vector<ValueT> process_values;
    std::vector<vtkIdType> process_sizes;
    std::vector<vtkIdType> process_offsets;
    if(this->Controller->GetLocalProcessId() == this->DestinationProcess)
      {
      process_sizes.resize(process_extents.GetCount());
      process_offsets.resize(process_extents.GetCount());
      for(vtkIdType i = 0; i != process_extents.GetCount(); ++i)
        {
        process_sizes[i] = process_extents[i].GetSize();
        process_offsets[i] = i ? process_offsets[i-1] + process_sizes[i-1] : 0;
        }
      process_values.resize(std::accumulate(process_sizes.begin(), process_sizes.end(), 0));
      }

    this->Controller->GatherV(local_array->GetStorage(), &process_values[0], local_array->GetSize(), &process_sizes[0], &process_offsets[0], this->DestinationProcess);

    if(this->Controller->GetLocalProcessId() != this->DestinationProcess)
      return;

    vtkDenseArray<ValueT>* global_array = vtkDenseArray<ValueT>::New();
    global_array->Resize(GlobalExtents(process_extents));
    global_array->SetName(local_array->GetName());
    for(vtkIdType dimension = 0; dimension != local_array->GetDimensions(); ++dimension)
      {
      global_array->SetDimensionLabel(dimension, local_array->GetDimensionLabel(dimension));
      }

    vtkArrayCoordinates coordinates;
    for(vtkIdType process = 0; process != process_extents.GetCount(); ++process)
      {
      const vtkArrayExtents extents = process_extents[process];
      for(vtkIdType n = 0; n != extents.GetSize(); ++n)
        {
        extents.GetLeftToRightCoordinatesN(n, coordinates);
        global_array->SetValue(coordinates, process_values[process_offsets[process] + n]);
        }
      }

    this->Result = global_array;
  }
*/

private:
  vtkMultiProcessController* const Controller;
  const int DestinationProcess;
  vtkArray*& Result;
};

vtkArray* vtkDistributedArray::GatherArray(vtkMultiProcessController* controller, vtkArray* local_array, int destination_process)
{
  vtkArray* result = 0;
  vtkTryDowncast<vtkDenseArray, vtkFloatingPointTypes>(local_array, GatherArrayHelper(controller, destination_process, result));
//  vtkTryDowncast<vtkSparseArray, vtkFloatingPointTypes>(local_array, GatherArrayHelper(controller, destination_process, result));
  return result;
}
