/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkPSQLTableWriter.h"

#include <vtkBitArray.h>
#include <vtkCharArray.h>
#include <vtkCommunicator.h>
#include <vtkInformation.h>
#include <vtkIntArray.h>
#include <vtkObjectFactory.h>
#include <vtkSerializeArrays.h>
#include <vtkSmartPointer.h>
#include <vtkSQLDatabase.h>
#include <vtkSQLQuery.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkVariantArray.h>

#include <vtksys/ios/sstream>

#define VTK_CREATE(type,name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#define VTK_ROW_AVAILABLE 1234
#define VTK_ROW_DATA      2345678


vtkCxxSetObjectMacro(vtkPSQLTableWriter, Communicator, vtkCommunicator);
vtkStandardNewMacro(vtkPSQLTableWriter);

// ----------------------------------------------------------------------

// This is a copy of vtkSQLQuery::EscapeString.  We need it here because slave processes don't have their own query objects to use for escaping.

vtkStdString
SQLGenericEscapeString( const vtkStdString &s, bool addSurroundingQuotes=true )
{
  vtkStdString d;
  if ( addSurroundingQuotes )
    {
    d += '\'';
    }

  for ( vtkStdString::const_iterator it = s.begin(); it != s.end(); ++ it )
    {
    if ( *it == '\'' )
      d += '\''; // Single quotes are escaped by repeating them
    d += *it;
    }

  if ( addSurroundingQuotes )
    {
    d += '\'';
    }
  return d;
}

// ----------------------------------------------------------------------

vtkPSQLTableWriter::vtkPSQLTableWriter()
  : Communicator(NULL),
    MasterProcessId(-1)
{
  this->SetNumberOfInputPorts(1);
}

// ----------------------------------------------------------------------

vtkPSQLTableWriter::~vtkPSQLTableWriter()
{
  this->SetCommunicator(NULL);
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Master process ID: " << this->MasterProcessId << "\n";
  os << indent << "Communicator: ";
  if (this->Communicator)
    {
    os << "\n";
    this->Communicator->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)\n";
    }
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::WriteData()
{
  if (!this->Communicator)
    {
    vtkErrorMacro(<<"There is no communicator.  Cannot write data.");
    return;
    }
  else
    {
    this->LocateMasterProcess();
    if (this->GetMasterProcessId() == this->Communicator->GetLocalProcessId())
      {
      this->WriteDataMasterNode();
      }
    else
      {
      this->WriteDataSlaveNode();
      }
    }
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::WriteDataMasterNode()
{
  // First the sanity checks from the serial version
  vtkTable *input = vtkTable::SafeDownCast(this->GetInput());
  if (!input)
    {
    vtkErrorMacro(<<"Cannot write data: no input!");
    return;
    }

  if (input->GetNumberOfColumns() == 0)
    {
    vtkWarningMacro(<<"Table has no columns.");
    return;
    }

  if (input->GetNumberOfRows() == 0)
    {
    vtkWarningMacro(<<"Table has no rows.");
    return;
    }

  if (this->IncludedColumns && this->IncludedColumns->GetNumberOfTuples() == 0)
    {
    vtkWarningMacro(<<"IncludedColumns array set but does not list any columns to write.");
    return;
    }

  if (this->IncludedColumns && this->ColumnNames &&
      this->IncludedColumns->GetNumberOfTuples() != this->ColumnNames->GetNumberOfTuples())
    {
    vtkWarningMacro(<<"IncludedColumns and ColumnNames arrays have different lengths.");
    return;
    }

  if (!this->Query)
    {
    vtkErrorMacro(<<"Cannot write data: no Query ivar set!");
    return;
    }

  // Now we write our own data.  This stuff requires no network
  // traffic beyond what's necessary to talk to the database itself.
  this->Superclass::WriteData();

  // Now we listen for rows from all the other processes and write
  // them as they come in.
  this->WriteRowsFromAllProcesses(input);
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::WriteRowsFromAllProcesses(vtkTable *exampleTable)
{
  // Query setup first - this covers things like bound parameters and
  // field renaming
  vtksys_ios::ostringstream preamble_buf;
  preamble_buf << "INSERT INTO " << this->TableName << " ( ";
  if (this->ColumnNames)
    {
    for (int col = 0; col < this->ColumnNames->GetNumberOfTuples(); ++col)
      {
      if (col > 0)
        {
        preamble_buf << ", ";
        }
      preamble_buf << this->ColumnNames->GetValue(col);
      }
    }
  else
    {
    for (int col = 0; col < exampleTable->GetNumberOfColumns(); ++col)
      {
      if (col > 0)
        {
        preamble_buf << ", ";
        }
      preamble_buf << exampleTable->GetColumnName(col);
      }
    }
  // terminate the Names list and set up for Values
  preamble_buf << " ) VALUES ( ";

  if (this->UsePreparedStatements)
    {
    vtksys_ios::ostringstream querybuf;
    querybuf << preamble_buf.str();
    int columnCount = exampleTable->GetNumberOfColumns();
    if (this->IncludedColumns)
      {
      columnCount = this->IncludedColumns->GetNumberOfTuples();
      }
    for (int col = 0; col < columnCount; ++col)
      {
      if (col > 0)
        {
        querybuf << ", ";
        }
      querybuf << "?";
      }
    querybuf << " )";

    this->Query->SetQuery(querybuf.str().c_str());
    vtkDebugMacro(<< "MASTER: Prepared query text: "
                  << querybuf.str().c_str());
    }

  vtkStdString preamble = preamble_buf.str();

  // Now we've got the text on hand to do the queries.  Time to listen
  // for rows from all the processes.
  VTK_CREATE(vtkBitArray, NoMoreRows);
  VTK_CREATE(vtkIntArray, RowsReceived);

  NoMoreRows->SetNumberOfTuples(this->Communicator->GetNumberOfProcesses());
  NoMoreRows->FillComponent(0, false);

  RowsReceived->SetNumberOfTuples(this->Communicator->GetNumberOfProcesses());
  RowsReceived->FillComponent(0, 0);

  int DoneCount = 0;

  // This process has already written all of its rows.
  DoneCount = 1;
  NoMoreRows->SetValue(this->Communicator->GetLocalProcessId(), true);

  VTK_CREATE(vtkVariantArray, RowData);
  while (DoneCount < this->Communicator->GetNumberOfProcesses())
    {
    vtkDebugMacro(<<"MASTER: At beginning of loop, "
                  << DoneCount << " of "
                  << this->Communicator->GetNumberOfProcesses()
                  << " processor(s) finished writing.");

    for (int p = 0; p < this->Communicator->GetNumberOfProcesses(); ++p)
      {
      if (NoMoreRows->GetValue(p))
        {
        vtkDebugMacro(<<"MASTER: Skipping process " << p);
        continue; // that node is done sending
        }
      else
        {
        bool rowAvailable = this->CheckForRow(p, RowsReceived->GetValue(p));
        int rowsSoFar = RowsReceived->GetValue(p);
        if (rowAvailable)
          {
          vtkDebugMacro(<<"MASTER: Receiving new row "
                        << rowsSoFar << " from process " << p << ".");
          this->ReceiveRowData(p, rowsSoFar, RowData);
          RowsReceived->SetValue(p, rowsSoFar + 1);

          vtkDebugMacro(<<"MASTER: Inserting new row "
                        << rowsSoFar
                        << " from process " << p << ".");

          this->InsertRow(preamble, RowData);
          }
        else
          {
          vtkDebugMacro(<<"MASTER: Process " << p << " says it has no more rows after sending "
                        << RowsReceived->GetValue(p) << ".");
          ++DoneCount;
          NoMoreRows->SetValue(p, true);
          }
        }
      }
    }

  vtkDebugMacro(<<"MASTER: All processors are done writing.");
}

// ----------------------------------------------------------------------

int
vtkPSQLTableWriter::LocateMasterProcess()
{
  if (this->Communicator == NULL)
    {
    vtkErrorMacro(<<"LocateMasterProcessId: No communicator!  This should never happen.");
    return -1;
    }
  else
    {
    int SendId;
    int RecvId = VTK_INT_MAX;

    vtkCommunicator::StandardOperations op = vtkCommunicator::MIN_OP;
    int MyId = this->Communicator->GetLocalProcessId();

    if (this->Query)
      {
      // I can be the master node
      SendId = MyId;
      }
    else
      {
      SendId = VTK_INT_MAX;
      }

    this->Communicator->AllReduce(&SendId, &RecvId, 1, op);
    vtkDebugMacro( << "Process " << MyId << " believes that master node is "
                   << RecvId );

    this->SetMasterProcessId(RecvId);
    return RecvId;
    }
}

// ----------------------------------------------------------------------

bool
vtkPSQLTableWriter::CheckForRow(int process, int CountSoFar)
{
  int RowAvailable = -1;

  vtkDebugMacro(<<"MASTER: CheckForRow listening for tag "
                << CountSoFar + VTK_ROW_AVAILABLE
                <<" from process "
                << process << ".");

  this->Communicator->Receive(&RowAvailable, 1, process,
                              VTK_ROW_AVAILABLE + CountSoFar);

  if (RowAvailable != 0 && RowAvailable != 1)
    {
    vtkErrorMacro(<<"Shouldn't happen: RowAvailable is "
                  <<RowAvailable << ".  Should be 0 or 1.");
    return false;
    }
  else
    {
    vtkDebugMacro(<<"MASTER: CheckForRow received notification "
                  << RowAvailable
                  <<" from process " << process << ".");
    return RowAvailable;
    }
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::ReceiveRowData(int process,
                                   int row_id,
                                   vtkVariantArray *data)
{
  data->Reset();

  vtkSmartPointer<vtkCharArray> archive = vtkSmartPointer<vtkCharArray>::New();

  vtkDebugMacro(<< "MASTER: Process "
                << this->Communicator->GetLocalProcessId()
                << " reading data for row " << row_id << " with tag "
                << VTK_ROW_DATA + row_id << " from process " << process);

  this->Communicator->Receive(archive, process,
                              VTK_ROW_DATA + row_id);

  vtkSerializeArrays::RestoreVariantArray(archive, data);

  vtkDebugMacro(<<"MASTER: Row " << row_id << " successfully received.");
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::InsertRow(const vtkStdString &preamble,
                              vtkVariantArray *data)
{
  if (this->UsePreparedStatements)
    {
    vtkDebugMacro(<<"MASTER: Prepared statement SQL is "
                  <<this->Query->GetQuery());

    for (int col = 0; col < data->GetNumberOfTuples(); ++col)
      {
      this->Query->BindParameter(col, data->GetValue(col));
      vtkDebugMacro(<<"MASTER: Column " << col
                    <<": binding parameter value "
                    << data->GetValue(col).ToString().c_str());
      }
    bool status = this->Query->Execute();
    if (!status)
      {
      vtkErrorMacro(<<"ERROR: Master process couldn't insert remote row!  Error from database: "
                    << this->Query->GetLastErrorText()
                    << "\n\nQuery text: '"
                    << this->Query->GetQuery() << "'");
      }
    }
  else
    {
    vtksys_ios::ostringstream querybuf;
    querybuf << preamble;

    for (int col = 0; col < data->GetNumberOfTuples(); ++col)
      {
      if (col > 0)
        {
        querybuf << ", ";
        }
      vtkVariant value = data->GetValue(col);
      if (!value.IsValid())
        {
        querybuf << "NULL";
        }
      else if (value.GetType() == VTK_OBJECT)
        {
        vtkWarningMacro(<<"Cannot insert variants of type VTK_OBJECT into a database.  Trying to insert NULL instead.");
        querybuf << "NULL";
        }
      else if (value.GetType() == VTK_STRING)
        {
        querybuf << SQLGenericEscapeString(value.ToString());
        }
      else
        {
        querybuf << value.ToString();
        }
      }
    querybuf << " )";
    vtkDebugMacro(<<"Raw text SQL query: "
                  << querybuf.str().c_str());
    this->Query->SetQuery(querybuf.str().c_str());
    bool status = this->Query->Execute();
    if (!status)
      {
      vtkErrorMacro(<<"ERROR: Master process couldn't insert remote row!  Error from database: "
                    << this->Query->GetLastErrorText());
      }
    }
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::WriteDataSlaveNode()
{
  vtkTable *input = vtkTable::SafeDownCast(this->GetInput());
  vtkTable *writeTable;

  // First, subset the table if necessary.
  if (this->IncludedColumns)
    {
    writeTable = vtkTable::New();
    for (int i = 0; i < this->IncludedColumns->GetNumberOfTuples(); ++i)
      {
      vtkAbstractArray *col = input->GetColumnByName(this->IncludedColumns->GetValue(i).c_str());
      if (!col)
        {
        vtkErrorMacro(<<"Fatal error on process "
                      << this->Communicator->GetLocalProcessId()
                      <<": could not locate column '"
                      << this->IncludedColumns->GetValue(i).c_str()
                      << "' in input table.");
        writeTable->Delete();
        writeTable = NULL;
        }
      else
        {
        writeTable->AddColumn(col);
        }
      }
    }
  else
    {
    writeTable = input;
    writeTable->Register(this);
    }

  // One more round of sanity checks
  if (writeTable->GetNumberOfColumns() == 0)
    {
    vtkErrorMacro(<<"No columns are left after table subsetting.");
    writeTable->Delete();
    writeTable = NULL;
    }

  if (this->ColumnNames &&
      this->ColumnNames->GetNumberOfTuples() != writeTable->GetNumberOfColumns())
    {
    vtkErrorMacro(<<"ColumnNames is set but does not match the number of fields to be written.");
    writeTable->Delete();
    writeTable = NULL;
    }

  this->SendRowsToMasterProcess(writeTable);

  writeTable->Delete();
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::SendRowsToMasterProcess(vtkTable *table)
{
  for (int row = 0; table && row < table->GetNumberOfRows(); ++row)
    {
    vtkDebugMacro(<<"SLAVE: Process "
                  << this->Communicator->GetLocalProcessId()
                  << " announcing row " << row
                  << " of "
                  << table->GetNumberOfRows());
    this->AnnounceRowAvailable(row);
    VTK_CREATE(vtkVariantArray, rowData);
    table->GetRow(row, rowData);
    vtkDebugMacro(<<"SLAVE: Process "
                  << this->Communicator->GetLocalProcessId()
                  <<" sending row " << row
                  << " of "
                  << table->GetNumberOfRows());
    this->SendRowToMasterProcess(rowData, row);
    }
  vtkDebugMacro(<<"SLAVE: Process "
                << this->Communicator->GetLocalProcessId()
                << " done sending rows.");
  this->AnnounceNoMoreRows(table->GetNumberOfRows());
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::AnnounceRowAvailable(int whichRow)
{
  int RowAvailable = 1;
  this->Communicator->Send(&RowAvailable, 1,
                           this->GetMasterProcessId(),
                           VTK_ROW_AVAILABLE + whichRow);
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::AnnounceNoMoreRows(int totalRowCount)
{
  int NoMoreRows = 0;
  this->Communicator->Send(&NoMoreRows, 1,
                           this->GetMasterProcessId(),
                           VTK_ROW_AVAILABLE + totalRowCount);
}

// ----------------------------------------------------------------------

void
vtkPSQLTableWriter::SendRowToMasterProcess(vtkVariantArray *rowData, int RowId)
{
  vtkSmartPointer<vtkCharArray> archive = vtkSmartPointer<vtkCharArray>::New();
  vtkSerializeArrays::SaveVariantArray(rowData, archive);

  vtkDebugMacro(<<"Slave process "
                <<this->Communicator->GetLocalProcessId()
                <<" sending row "
                << RowId
                <<" with tag "
                << VTK_ROW_DATA + RowId << ".");

  this->Communicator->Send(archive, this->GetMasterProcessId(),
                           VTK_ROW_DATA + RowId);
}
