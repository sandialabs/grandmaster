#include <titanJSONInputArchive.h>
#include <titanJSONOutputArchive.h>

#include <boost/serialization/access.hpp>

#include <iostream>

//////////////////////////////////////////////////////////////////////////////////////
// Define some sample data structures that we can try serializing

template<typename A, typename B>
struct record
{
public:
  record()
  {
  }

  record(const A& a_value, const B& b_value) :
    a(a_value),
    b(b_value)
  {
  }

  bool operator==(const record& Other) const
  {
    return a == Other.a && b == Other.b;
  }

  A a;
  B b;

private:
  friend class boost::serialization::access;

  template<typename archive>
  void serialize(archive& Archive, const unsigned int Version)
  {
    Archive & BOOST_SERIALIZATION_NVP(a);
    Archive & BOOST_SERIALIZATION_NVP(b);
  }
};

//////////////////////////////////////////////////////////////////////////////////////////
// Define a test harness that:
//
//  * Serializes a reference data structure
//  * Creates a new instance of the same data structure
//  * Loads the saved representation
//  * Compares the new instance to the original

template<typename T>
void test(const T& Reference)
{
  std::stringstream buffer;
    {
    titanJSONOutputArchive oarchive(buffer);
    oarchive & Reference;
    }

  std::cerr << buffer.str() << std::endl;

  T new_instance;
    {
    titanJSONInputArchive iarchive(buffer);
    iarchive & new_instance;
    }

  if(!(new_instance == Reference))
    throw std::runtime_error("JSON serialization mismatch.");
}

//////////////////////////////////////////////////////////////////////////////////////////
// Try serializing some stuff

int main(int argc, char* argv[])
{
  try
  {
    test(true);
    test(false);

    test(int(1));
    test(double(1.2));

    test(vtkStdString("vtkStdString"));
    test(vtkUnicodeString::from_utf8("vtkUnicodeString"));
    test(std::string("std::string"));

    test(boost::posix_time::second_clock::universal_time());

/*
    test(boost::optional<int>());
    test(boost::optional<int>(1));
*/

    test(std::vector<int>(2, 3));
    test(std::list<double>(3, 4.5));

    std::map<vtkStdString, int> map1;
    map1["foo"] = 1;
    map1["bar"] = 2;
    test(map1);

    std::map<std::string, int> map2;
    map2["foo"] = 1;
    map2["bar"] = 2;
    test(map2);

    test(record<int, double>(5, 6.7));
    test(record<record<int, double>, std::vector<record<int, double> > >(record<int, double>(8, 9.0), std::vector<record<int, double> >(2, record<int, double>(10, 11.2))));

    return 0;
  }
  catch(std::exception& e)
  {
    std::cerr << e.what() << std::endl;
    return 1;
  }
}
