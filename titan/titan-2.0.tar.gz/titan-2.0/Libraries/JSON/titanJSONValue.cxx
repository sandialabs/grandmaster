#include <titanJSONValue.h>

#include <boost/algorithm/string.hpp>

#include <sstream>

static void* null = 0;

titanJSONValue::titanJSONValue() :
  storage(null)
{
}

titanJSONValue::titanJSONValue(bool Value) :
  storage(Value)
{
}

titanJSONValue::titanJSONValue(double Value) :
  storage(Value)
{
}

titanJSONValue::titanJSONValue(const std::string& Value) :
  storage(Value)
{
}

void titanJSONValue::reset()
{
  storage = null;
  array_storage.reset();
  object_storage.reset();
}

titanJSONValue& titanJSONValue::operator=(bool Value)
{
  storage = Value;
  array_storage.reset();
  object_storage.reset();
  return *this;
}

titanJSONValue& titanJSONValue::operator=(double Value)
{
  storage = Value;
  array_storage.reset();
  object_storage.reset();
  return *this;
}

titanJSONValue& titanJSONValue::operator=(const std::string& Value)
{
  storage = Value;
  array_storage.reset();
  object_storage.reset();
  return *this;
}

bool titanJSONValue::operator==(const titanJSONValue& Other) const
{
  return
    storage == Other.storage
    && array_storage == Other.array_storage
    && object_storage == Other.object_storage
    ;
}

bool titanJSONValue::operator!=(const titanJSONValue& Other) const
{
  return !(*this == Other);
}

bool titanJSONValue::is_null() const
{
  return !array_storage && !object_storage && boost::get<void*>(&storage);
}

bool titanJSONValue::is_boolean() const
{
  return !array_storage && !object_storage && boost::get<bool>(&storage);
}

bool titanJSONValue::is_number() const
{
  return !array_storage && !object_storage && boost::get<double>(&storage);
}

bool titanJSONValue::is_string() const
{
  return !array_storage && !object_storage && boost::get<std::string>(&storage);
}

bool titanJSONValue::is_array() const
{
  return array_storage;
}

bool titanJSONValue::is_object() const
{
  return object_storage;
}

titanJSONValue::size_type titanJSONValue::size() const
{
  if(array_storage)
    return array_storage->size();
  else if(object_storage)
    return object_storage->size();
  return 0;
}

void titanJSONValue::push_back(const titanJSONValue& Value)
{
  coerce_array();
  array_storage->push_back(Value);
}

titanJSONValue& titanJSONValue::operator[](size_type Index)
{
  if(!array_storage)
    throw std::runtime_error("Not a JSON array.");
  return (*array_storage)[Index];
}

const titanJSONValue& titanJSONValue::operator[](size_type Index) const
{
  if(!array_storage)
    throw std::runtime_error("Not a JSON array.");
  return (*array_storage)[Index];
}

bool titanJSONValue::has_key(const key_type& Key) const
{
  if(!object_storage)
    return false;
  return object_storage->count(Key) ? true : false;
}

void titanJSONValue::erase_key(const key_type& Key)
{
  if(!object_storage)
    return;
  object_storage->erase(Key);
}

const titanJSONValue& titanJSONValue::get(const key_type& Key) const
{
  if(!object_storage)
    throw std::runtime_error("Not a JSON object.");
  object::const_iterator property = object_storage->find(Key);
  if(property == object_storage->end())
    throw std::runtime_error("Unknown property: " + Key);
  return property->second;
}

const std::string titanJSONValue::get(const key_type& Key, const char* Default) const
{
  if(!object_storage)
    throw std::runtime_error("Not a JSON object.");
  object::const_iterator property = object_storage->find(Key);
  if(property == object_storage->end())
    return Default;
  if(property->second.array_storage || property->second.object_storage)
    throw std::runtime_error("Not a value property: " + Key);
  const std::string* const result = boost::get<std::string>(&property->second.storage);
  if(!result)
    throw std::runtime_error("Wrong property type: " + Key);

  return *result;
}

void titanJSONValue::put(const key_type& Key, bool Value)
{
  coerce_object();
  (*object_storage)[Key] = Value;
}

void titanJSONValue::put(const key_type& Key, double Value)
{
  coerce_object();
  (*object_storage)[Key] = Value;
}

void titanJSONValue::put(const key_type& Key, const char* Value)
{
  coerce_object();
  (*object_storage)[Key] = std::string(Value);
}

void titanJSONValue::put(const key_type& Key, const std::string& Value)
{
  coerce_object();
  (*object_storage)[Key] = Value;
}

void titanJSONValue::put(const key_type& Key, const titanJSONValue& Value)
{
  coerce_object();
  (*object_storage)[Key] = Value;
}

void titanJSONValue::coerce_array()
{
  if(!array_storage)
  {
    storage = null;
    array_storage = array();
    object_storage.reset();
  }
}

void titanJSONValue::coerce_object()
{
  if(!object_storage)
  {
    storage = null;
    array_storage.reset();
    object_storage = object();
  }
}

std::ostream& operator<<(std::ostream& Stream, const titanJSONValue& Value)
{
  write(Stream, Value);
  return Stream;
}

static void skip_whitespace(std::istream& Stream)
{
  while(Stream)
  {
    switch(Stream.peek())
    {
      case ' ':
      case '\n':
      case '\r':
      case '\t':
        Stream.get();
        continue;
    }

    return;
  }
}

static void require_char(std::istream& Stream, const char C)
{
  if(!Stream || Stream.peek() != C)
  {
    std::ostringstream message;
    message << "Expected '" << C << "' at character " << Stream.tellg();
    throw std::runtime_error(message.str());
  }
  Stream.get();
}

static const std::string read_string(std::istream& Stream)
{
  std::string result;

  require_char(Stream, '"');
  for(; Stream && Stream.peek() != '"'; )
  {
    if(Stream.peek() == '\\')
    {
      Stream.get();
      switch(Stream.peek())
      {
        case '\"':
          result += "\"";
          break;
        case '\\':
          result += "\\";
          break;
        case '/':
          result += "/";
          break;
        case 'b':
          result += "\b";
          break;
        case 'f':
          result += "\f";
          break;
        case 'n':
          result += "\n";
          break;
        case 'r':
          result += "\r";
          break;
        case 't':
          result += "\t";
          break;
        default:
        {
          std::ostringstream message;
          message << "Unknown escape '\\" << Stream.peek() << "' at character " << Stream.tellg();
          throw std::runtime_error(message.str());
        }
      }
      Stream.get();
    }
    else
    {
      result += Stream.get();
    }
  }
  require_char(Stream, '"');

  return result;
}

void read(std::string& Stream, titanJSONValue& Tree)
{
  std::istringstream stream(Stream);
  read(stream, Tree);
}

void read(std::istream& Stream, titanJSONValue& Tree)
{
  skip_whitespace(Stream);
  switch(Stream.peek())
  {
    // Starting a null ...
    case 'n':
      require_char(Stream, 'n');
      require_char(Stream, 'u');
      require_char(Stream, 'l');
      require_char(Stream, 'l');
      Tree.reset();
      break;
    // Starting boolean true ...
    case 't':
      require_char(Stream, 't');
      require_char(Stream, 'r');
      require_char(Stream, 'u');
      require_char(Stream, 'e');
      Tree = true;
      break;
    // Starting boolean false ...
    case 'f':
      require_char(Stream, 'f');
      require_char(Stream, 'a');
      require_char(Stream, 'l');
      require_char(Stream, 's');
      require_char(Stream, 'e');
      Tree = false;
      break;
    // Starting a string ...
    case '"':
      Tree = read_string(Stream);
      break;
    // Starting an array ...
    case '[':
      require_char(Stream, '[');
      while(Stream)
      {
        skip_whitespace(Stream);
        if(Stream.peek() == ']')
          break;

        titanJSONValue value;
        read(Stream, value);
        Tree.push_back(value);

        skip_whitespace(Stream);
        if(Stream.peek() == ']')
          break;

        require_char(Stream, ',');
      }
      require_char(Stream, ']');
      break;
    // Starting an object ...
    case '{':
      require_char(Stream, '{');
      while(Stream)
      {
        skip_whitespace(Stream);
        if(Stream.peek() == '}')
          break;

        const std::string name = read_string(Stream);

        skip_whitespace(Stream);
        require_char(Stream, ':');

        titanJSONValue value;
        read(Stream, value);
        Tree.put(name, value);

        skip_whitespace(Stream);
        if(Stream.peek() == '}')
          break;

        require_char(Stream, ',');
      }
      require_char(Stream, '}');
      break;
    // Must be a number ...
    default:
    {
      double value;
      Stream >> value;
      Tree = value;
      break;
    }
  }
}

void write(std::ostream& Stream, const titanJSONValue& Tree)
{
  if(Tree.array_storage)
  {
    const titanJSONValue::array& array = *Tree.array_storage;

    Stream << "[";
    for(titanJSONValue::array::const_iterator element = array.begin(); element != array.end(); ++element)
    {
      if(element != array.begin())
        Stream << ",";
      write(Stream, *element);
    }
    Stream << "]";
  }
  else if(Tree.object_storage)
  {
    const titanJSONValue::object& object = *Tree.object_storage;

    Stream << "{";
    for(titanJSONValue::object::const_iterator element = object.begin(); element != object.end(); ++element)
    {
      if(element != object.begin())
        Stream << ",";
      Stream << "\"" << element->first << "\":";
      write(Stream, element->second);
    }
    Stream << "}";
  }
  else if(boost::get<void*>(&Tree.storage))
  {
    Stream << "null";
  }
  else if(const bool* const value = boost::get<bool>(&Tree.storage))
  {
    Stream << (*value ? "true" : "false");
  }
  else if(const double* const value = boost::get<double>(&Tree.storage))
  {
    Stream << *value;
  }
  else if(const std::string* const value = boost::get<std::string>(&Tree.storage))
  {
    Stream << "\"";
    for(int i = 0; i != value->size(); ++i)
    {
      switch((*value)[i])
      {
        case '"':
          Stream << "\\\"";
          break;
        case '\\':
          Stream << "\\";
          break;
        case '/':
          Stream << "\\/";
          break;
        case '\b':
          Stream << "\\b";
          break;
        case '\f':
          Stream << "\\f";
          break;
        case '\n':
          Stream << "\\n";
          break;
        case '\r':
          Stream << "\\r";
          break;
        case '\t':
          Stream << "\\t";
          break;
        default:
          Stream << (*value)[i];
          break;
      }
    }
    Stream << "\"";
  }
}
