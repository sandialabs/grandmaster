/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkMultiProcessController.h>
#include <vtkObjectFactory.h>
#include <vtkDocumentPerLinePDocumentReaderStrategy.h>
#include <vtkStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/filesystem/v3/operations.hpp>
#include <boost/filesystem.hpp>

#include <vtksys/ios/fstream>
#include <vtksys/ios/sstream>
#include <vtksys/SystemTools.hxx>



vtkStandardNewMacro(vtkDocumentPerLinePDocumentReaderStrategy);

vtkDocumentPerLinePDocumentReaderStrategy::vtkDocumentPerLinePDocumentReaderStrategy()
{
}

vtkDocumentPerLinePDocumentReaderStrategy::~vtkDocumentPerLinePDocumentReaderStrategy()
{
}

void vtkDocumentPerLinePDocumentReaderStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkDocumentPerLinePDocumentReaderStrategy::LoadFiles(
  vtkMultiProcessController* const controller,
  const PathList& files,
  const PathList& directories,
  const PathList& recursive_directories,
  vtkStringArray* uri_array,
  vtkStringArray* contents_array
  )
{
  vtkIdType file_index = 0;
  int start_documents = contents_array->GetNumberOfTuples();

  // Load files ...
  for(PathList::const_iterator file = files.begin(); file != files.end(); ++file)
    {
    const vtkIdType file_processor = file_index++ % controller->GetNumberOfProcesses();
    if(file_processor == controller->GetLocalProcessId())
      {
      this->LoadLocalFile(*file, uri_array, contents_array);
      }
    }

  // Load directories ...
  for(PathList::const_iterator directory = directories.begin(); directory != directories.end(); ++directory)
    {
    boost::filesystem::directory_iterator end;
    for(boost::filesystem::directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(!is_regular_file(file->status()))
        continue;

      const vtkIdType file_processor = file_index++ % controller->GetNumberOfProcesses();
      if(file_processor == controller->GetLocalProcessId())
        {
        this->LoadLocalFile(file->path().string(), uri_array, contents_array);
        }
      }
    }

  // Load recursive directories ...
  for(PathList::const_iterator directory = recursive_directories.begin(); directory != recursive_directories.end(); ++directory)
    {
    boost::filesystem::recursive_directory_iterator end;
    for(boost::filesystem::recursive_directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(!is_regular_file(file->status()))
        continue;

      const vtkIdType file_processor = file_index++ % controller->GetNumberOfProcesses();
      if(file_processor == controller->GetLocalProcessId())
        {
        this->LoadLocalFile(file->path().string(), uri_array, contents_array);
        }
      }
    }

  int end_documents = contents_array->GetNumberOfTuples();

  return (end_documents - start_documents);
}

// ----------------------------------------------------------------------

void vtkDocumentPerLinePDocumentReaderStrategy::LoadLocalFile(
  const vtkStdString& filename,
  vtkStringArray* uri_array,
  vtkStringArray* content_array
  )
{
  // Format the file path as a URI ...
  vtkStdString uri_base = filename;
  // Get rid of leading and trailing whitespace ...
  boost::trim(uri_base);
  // Make Windoze slashes straighten-up and fly right ...
  boost::replace_all(uri_base, "\\", "/");
  // Ensure that Windoze paths are absolute paths ...
  if(uri_base.size() > 1 && uri_base.at(1) == ':')
    uri_base = "/" + uri_base;
  uri_base = "file://" + uri_base;

  vtksys_ios::ifstream infile(filename.c_str(), ios::in | ios::binary);

  if (!infile)
    {
      vtkErrorMacro(<< "Couldn't open file " << filename.c_str()
                    << " for input");
      return;
    }

  bool escape_in_progress = false;
  char last_char=0, next_char=0;
  int line_number = 0;

  vtkStdString this_document;

  while (!infile.eof())
    {
    infile.get(next_char);

    if (escape_in_progress)
      {
      this_document.push_back(last_char);
      this_document.push_back(next_char);
      escape_in_progress = false;
      }
    else if (next_char == '\\')
      {
      escape_in_progress = true;
      }
    else if (next_char == 0x0d || next_char == 0x0a) // CR or LF
      {
      // We're going to accept CR, LF, or CR+LF as delimiters.  That
      // means that if we see a CR we need to find out whether the
      // next character is LF and, if so, eat it.
      if (next_char == 0x0d)
        {
        int upcoming = infile.peek();
        if (upcoming == 0x0a)
          {
          infile.get(next_char);
          }
        }

      // Now we can finish off the document and move on.
      vtksys_ios::ostringstream uri_buf;
      uri_buf << uri_base << ":" << line_number;
      ++line_number;
      uri_array->InsertNextValue(uri_buf.str());
      content_array->InsertNextValue(this_document);
      this_document = vtkStdString();
      }
    else
      {
      // this character is nothing with special value
      this_document.push_back(next_char);
      }
    last_char = next_char;
    }

  // We just hit the end of the file.  It's quite possible that the
  // last character wasn't a newline, in which case we have one last
  // document to include.
  if (this_document.size() > 0)
    {
    vtksys_ios::ostringstream uri_buf;
    uri_buf << uri_base << ":" << line_number;
    uri_array->InsertNextValue(uri_buf.str());
    content_array->InsertNextValue(this_document);
    }
}
