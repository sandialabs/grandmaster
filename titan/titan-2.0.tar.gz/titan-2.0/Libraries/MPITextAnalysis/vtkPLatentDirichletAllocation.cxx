/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

// #define COPIOUS_DEBUG_OUTPUT

#include "vtkPLatentDirichletAllocation.h"
#include "vtkPLatentDirichletAllocationMarkovChain.h"

#include "vtkAbstractArray.h"
#include "vtkArray.h"
#include "vtkArrayData.h"
#include "vtkDenseArray.h"
#include "vtkDoubleArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkIntArray.h"
#include "vtkMinimalStandardRandomSequence.h"
#include "vtkObjectFactory.h"
#include "vtkRandomSequence.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"
#include "vtkMultiProcessController.h"

#include <vtksys/stl/algorithm>
#include <vtksys/stl/set>
#include <vtksys/stl/stdexcept>
#include <vtksys/stl/vector>
#include <vtksys/stl/functional>
#include <assert.h>

#if !defined(VTK_CREATE)
# define VTK_CREATE(type,name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()
#endif


vtkStandardNewMacro(vtkPLatentDirichletAllocation);
vtkCxxSetObjectMacro(vtkPLatentDirichletAllocation, Controller, vtkMultiProcessController);

// ----------------------------------------------------------------------

vtkPLatentDirichletAllocation::vtkPLatentDirichletAllocation()
  : Controller(0),
    GlobalDocumentCount(-1),
    RunningChain(0)
{
  this->SetController(vtkMultiProcessController::GetGlobalController());
}

// ----------------------------------------------------------------------

vtkPLatentDirichletAllocation::~vtkPLatentDirichletAllocation()
{
  this->SetController(0);
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocation::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Multiprocess controller: ";
  if (this->Controller)
    {
    os << "\n";
    this->Controller->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)\n";
    }
}

// ----------------------------------------------------------------------

int
vtkPLatentDirichletAllocation::RequestData(vtkInformation *vtkNotUsed(request),
                                           vtkInformationVector **inVector,
                                           vtkInformationVector *outVector)
{
  vtkArrayData *arrayInput = vtkArrayData::GetData(inVector[0], 0);
  vtkDataObject *savedState = vtkDataObject::GetData(inVector[1], 0);

  try
    {
    vtkArray *termdoc = arrayInput->GetArray(0);
    if (!termdoc)
      {
      throw vtksys_stl::runtime_error("Couldn't retrieve termdoc matrix from input 0");
      }
    this->CollectGlobalDocumentCount(termdoc);

    for (int trial = 0; trial < this->GetNumberOfTrials(); ++trial)
      {
      vtkSmartPointer<vtkPLatentDirichletAllocationMarkovChain> MarkovChain = vtkSmartPointer<vtkPLatentDirichletAllocationMarkovChain>::New();

      this->SetParameters(MarkovChain);

      bool setupStatus = this->SetupMarkovChain(MarkovChain, arrayInput, savedState);
      if (!setupStatus)
      {
      return 0;
      }

      this->RunningChain = MarkovChain;

      this->RunTrial(MarkovChain);
      this->UpdateBestChainState(MarkovChain);

      vtkDebugMacro(<<"Done running trial "
                    << trial + 1 << " of "
                    << this->GetNumberOfTrials() << ".");
      }

    vtkDebugMacro(<<"All iterations finished.\n");

    vtkArrayData *theta_output = this->GetOutput(0);
    vtkArrayData *phi_output = this->GetOutput(1);
    assert(theta_output != 0);
    assert(phi_output != 0);
    assert(this->BestChainState != 0);
    this->SaveThetaPhiMatrices(this->BestChainState, theta_output, phi_output);

    vtkDataObject *state_output = this->GetOutputDataObject(2);
    this->BestChainState->SaveSamplerState(state_output);

    this->RunningChain = 0;
    }
  catch (const vtksys_stl::runtime_error &e)
    {
    vtkErrorMacro(<<"Caught exception in RequestData: " << e.what());
    return 0;
    }

  return 1;
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocation::InitializeCorpus(vtkAbstractLatentDirichletAllocationMarkovChain *sampler,
                                               vtkArray *termDocMatrix)
{
  sampler->BuildCorpus(termDocMatrix);
  sampler->AllocateCacheArrays();
  sampler->InitializeTermTopicAssignments();
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocation::SaveThetaPhiMatrices(vtkAbstractLatentDirichletAllocationMarkovChain *sampler,
                                                    vtkArrayData *theta_output,
                                                    vtkArrayData *phi_output)
{
  assert(sampler != 0);

  vtkArray *theta = sampler->GetDocumentTopicMatrix();
  assert(theta != 0);
  theta_output->AddArray(theta);
  theta->Delete();

  vtkArray *phi = sampler->GetTopicTermMatrix();
  assert(phi != 0);
  phi_output->AddArray(phi);
  phi->Delete();
}

// ----------------------------------------------------------------------

bool
vtkPLatentDirichletAllocation::SetupMarkovChain(
  vtkAbstractLatentDirichletAllocationMarkovChain *chain,
  vtkArrayData *array_input,
  vtkDataObject *saved_state)
{
  if (this->GetDebug())
    {
    chain->DebugOn();
    }
  else
    {
    chain->DebugOff();
    }

  // Set Multi Process Controller
  vtkPLatentDirichletAllocationMarkovChain *downcast = vtkPLatentDirichletAllocationMarkovChain::SafeDownCast(chain);
  if (!downcast)
    {
    vtkErrorMacro(<<"ERROR: Couldn't downcast chain in SetupMarkovChain!");
    return false;
    }

  downcast->SetController(this->Controller);

  chain->SetRandomSequence(this->GetRandomSequence());
  if (saved_state)
    {
    chain->SetInferenceEnabled(this->InferenceEnabled);
    chain->LoadSamplerState(saved_state);
    chain->SetTopicsReadOnly(this->InferenceEnabled);
    }
  else
    {
    chain->SetInferenceEnabled(false);
    }

  try
    {
    vtkArray *term_doc_matrix = array_input->GetArray(0);

    if (!term_doc_matrix)
      {
      throw std::runtime_error("Couldn't retrieve term/document matrix");
      }
    if (saved_state == NULL || this->InferenceEnabled)
      {
      this->InitializeCorpus(chain, term_doc_matrix);
      }
    }
  catch (const vtksys_stl::runtime_error &e)
    {
    vtkErrorMacro(<<"ERROR: " << e.what());
    return false;
    }
  catch (...)
    {
    vtkErrorMacro(<<"ERROR: Unknown exception!");
    return false;
    }
  return true;
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocation::SetParameters(vtkPLatentDirichletAllocationMarkovChain *sampler)
{
  sampler->SetNumberOfTopics(this->GetNumberOfTopics());
  sampler->SetNumberOfGlobalDocuments(this->GlobalDocumentCount);

  if (!this->UserSuppliedParameterValues)
    {
    sampler->GuessParameterValues();
    }
  else
    {
    sampler->SetAlpha(this->GetAlphaInternal());
    sampler->SetBeta(this->GetBetaInternal());
    }
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocation::CollectGlobalDocumentCount(vtkArray *termdoc)
{
  vtksys_stl::set<vtkIdType> local_doc_ids;

  for (int n = 0; n < termdoc->GetNonNullSize(); ++n)
    {
    vtkArrayCoordinates coords;
    termdoc->GetCoordinatesN(n, coords);
    local_doc_ids.insert(coords[1]);
    }

  vtkDebugMacro(<< "Process " << this->Controller->GetLocalProcessId()
                << " owns " << local_doc_ids.size() << " documents");

  int local_doc_count = local_doc_ids.size();
  int global_doc_count = 0;

  this->Controller->AllReduce(&local_doc_count, &global_doc_count, 1,
                              vtkCommunicator::SUM_OP);

  if (this->Controller->GetLocalProcessId() == 0)
    {
    cerr << "Global document count: " << global_doc_count << "\n";
    }

  this->SetGlobalDocumentCount(global_doc_count);
}
