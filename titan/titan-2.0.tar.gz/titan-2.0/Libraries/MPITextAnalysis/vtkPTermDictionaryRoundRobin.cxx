/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMPICommunicator.h"
#include "vtkObjectFactory.h"
#include "vtkPTermDictionaryCommunicator.h"
#include "vtkPTermDictionaryRoundRobin.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"

#include <map>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryRoundRobin


vtkStandardNewMacro(vtkPTermDictionaryRoundRobin);

vtkPTermDictionaryRoundRobin::vtkPTermDictionaryRoundRobin() :
  Controller(0)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");

  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);

  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPTermDictionaryRoundRobin::~vtkPTermDictionaryRoundRobin()
{
  this->SetController(0);
}

void vtkPTermDictionaryRoundRobin::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkPTermDictionaryRoundRobin::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}

int vtkPTermDictionaryRoundRobin::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("Process controller hasn't been set!");

    vtkMPICommunicator* const mpi_communicator = vtkMPICommunicator::SafeDownCast(this->Controller->GetCommunicator());
    if(!mpi_communicator)
      throw std::runtime_error("Process controller must provide an MPI communicator.");

    vtkUnicodeStringArray* const input_term_array = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!input_term_array)
      throw std::runtime_error("Missing input term array.");

    vtkPTermDictionaryCommunicator communicator(this->Controller->GetCommunicator());

    // Compute the set of unique local terms ...
    vtkPTermDictionaryCommunicator::UniqueSortedTerms terms;
    vtkPTermDictionaryCommunicator::ConvertTerms(*input_term_array, terms);

    // Figure-out who we will be sending-to / receiving-from ...
    const int previous_processor = (this->Controller->GetLocalProcessId() + this->Controller->GetNumberOfProcesses() - 1) % this->Controller->GetNumberOfProcesses();
    const int next_processor = (this->Controller->GetLocalProcessId() + 1) % this->Controller->GetNumberOfProcesses();

    vtkPTermDictionaryCommunicator::UniqueSortedTerms send_terms = terms;
    for(int i = 1; i < this->Controller->GetNumberOfProcesses(); ++i)
      {
      vtkPTermDictionaryCommunicator::NoBlockRequest send_request;
      communicator.NoBlockSendTerms(send_terms, next_processor, send_request);

      vtkPTermDictionaryCommunicator::UniqueSortedTerms new_terms;
      communicator.ReceiveTerms(previous_processor, new_terms);

      send_terms.clear();
      for(vtkPTermDictionaryCommunicator::UniqueSortedTerms::const_iterator new_term = new_terms.begin(); new_term != new_terms.end(); ++new_term)
        {
        if(terms.insert(*new_term).second)
          send_terms.insert(*new_term);
        }

      send_request.Wait();
      }

    // Insert terms into the term dictionary ...
    vtkUnicodeStringArray* const output_dictionary = vtkUnicodeStringArray::New();
    output_dictionary->SetName("text");
    vtkPTermDictionaryCommunicator::ConvertTerms(terms, *output_dictionary);

    // Configure our outputs ...
    vtkTable* const output = vtkTable::GetData(outputVector, 0);
    output->AddColumn(output_dictionary);
    output_dictionary->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "Caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "Caught unknown exception." << endl);
    }

  return 0;
}
