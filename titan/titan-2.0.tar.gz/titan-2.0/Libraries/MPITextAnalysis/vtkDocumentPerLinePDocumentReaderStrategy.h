/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkDocumentPerLinePDocumentReaderStrategy_h
#define __vtkDocumentPerLinePDocumentReaderStrategy_h

#include <titanMPITextAnalysis.h>

#include <vtkObject.h>
#include <vtkPDocumentReaderStrategy.h>

/// \class vtkDocumentPerLinePDocumentReaderStrategy vtkDocumentPerLinePDocumentReaderStrategy.h <MPITextAnalysis/vtkDocumentPerLinePDocumentReaderStrategy.h>
/// \brief Does a 'round-robin' distribution of
///  documents across processes.
///
///
///  Concrete implementation of vtkPDocumentReaderStrategy that uses a
///  'round-robin' approach to distribute documents across processes.
///  This approach is fast and does not require any communication, but
///  it can lead to suboptimal load-balancing, since some processors may
///  end up with larger documents than others.
///
/// \sa
///  vtkPDocumentReader
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkDocumentPerLinePDocumentReaderStrategy :
  public vtkPDocumentReaderStrategy
{
public:
  static vtkDocumentPerLinePDocumentReaderStrategy* New();
  vtkTypeMacro(vtkDocumentPerLinePDocumentReaderStrategy, vtkPDocumentReaderStrategy);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
  virtual int LoadFiles(
    vtkMultiProcessController* const controller,
    const PathList& files,
    const PathList& directories,
    const PathList& recursive_directories,
    vtkStringArray* uri_array,
    vtkStringArray* contents_array
    );

protected:
  vtkDocumentPerLinePDocumentReaderStrategy();
  ~vtkDocumentPerLinePDocumentReaderStrategy();

  void LoadLocalFile(
    const vtkStdString& file,
    vtkStringArray* uri_array,
    vtkStringArray* content_array
    );

private:
  vtkDocumentPerLinePDocumentReaderStrategy(const vtkDocumentPerLinePDocumentReaderStrategy &); // Not implemented.
  void operator=(const vtkDocumentPerLinePDocumentReaderStrategy &); // Not implemented.
//ETX
};

#endif // __vtkDocumentPerLinePDocumentReaderStrategy_h
