/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkLDADocumentPipeline.h"

#include "vtkArrayReader.h"
#include "vtkArrayWriter.h"
#include "vtkAssignMimeType.h"
#include "vtkCallbackCommand.h"
#include "vtkDataObject.h"
#include "vtkDataObjectReader.h"
#include "vtkFeatureDictionary.h"
#include "vtkFoldCase.h"
#include "vtkFrequencyMatrix.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMimeTypes.h"
#include "vtkMultiProcessController.h"
#include "vtkObjectFactory.h"
#include "vtkTable.h"
#include "vtkTableReader.h"
#include "vtkTableWriter.h"
#include "vtkTextExtraction.h"
#include "vtkTokenizer.h"
#include "vtkTokenValueFilter.h"

#if defined(VTK_USE_MPI)
#include "vtkPTermDictionaryMapReduce.h"
#endif


#include <vtksys/stl/stdexcept>
#include <assert.h>
// ----------------------------------------------------------------------


vtkStandardNewMacro(vtkLDADocumentPipeline);
#if defined(VTK_USE_MPI)
vtkCxxSetObjectMacro(vtkLDADocumentPipeline, Controller, vtkMultiProcessController);
#endif


// ----------------------------------------------------------------------

void DictionaryFinishedRelay(vtkObject *vtkNotUsed(caller),
                             unsigned long vtkNotUsed(event),
                             void *client_data,
                             void *call_data)
{
  vtkLDADocumentPipeline *pipeline =
    static_cast<vtkLDADocumentPipeline *>(client_data);
  assert(pipeline != 0);

  pipeline->DictionaryBuildFinishedCallback();
}

// ----------------------------------------------------------------------

void TermDocumentMatrixFinishedRelay(vtkObject *vtkNotUsed(caller),
                                     unsigned long vtkNotUsed(event),
                                     void *client_data,
                                     void *call_data)
{
  vtkLDADocumentPipeline *pipeline =
    static_cast<vtkLDADocumentPipeline *>(client_data);
  pipeline->TermDocumentMatrixBuildFinishedCallback();
}

// ----------------------------------------------------------------------

vtkLDADocumentPipeline::vtkLDADocumentPipeline()
  : TermDictionaryInputFilename(0),
    TermDictionaryOutputFilename(0),
    TermDocumentMatrixInputFilename(0),
    TermDocumentMatrixOutputFilename(0)
{
  this->AssignMimeTypes           = vtkSmartPointer<vtkAssignMimeType>::New();
  this->MimeTypeLibrary           = vtkSmartPointer<vtkMimeTypes>::New();
  this->TextExtractor             = vtkSmartPointer<vtkTextExtraction>::New();
  this->FoldCase                  = vtkSmartPointer<vtkFoldCase>::New();
  this->Tokenizer                 = vtkSmartPointer<vtkTokenizer>::New();
  this->StopWordFilter            = vtkSmartPointer<vtkTokenValueFilter>::New();
  this->SerialDictionaryBuilder   = vtkFeatureDictionary::New();
  this->TermDocumentMatrixBuilder = vtkSmartPointer<vtkFrequencyMatrix>::New();
  this->DictionaryReader          = vtkSmartPointer<vtkTableReader>::New();
  this->TermDocumentMatrixReader  = vtkSmartPointer<vtkArrayReader>::New();

  this->SaveDictionaryCommand         = vtkSmartPointer<vtkCallbackCommand>::New();
  this->SaveTermDocumentMatrixCommand = vtkSmartPointer<vtkCallbackCommand>::New();

  this->SaveDictionaryCommand->SetCallback(DictionaryFinishedRelay);
  this->SaveDictionaryCommand->SetClientData(this);

  this->SaveTermDocumentMatrixCommand->SetCallback(TermDocumentMatrixFinishedRelay);
  this->SaveTermDocumentMatrixCommand->SetClientData(this);

  this->SerialDictionaryBuilder->AddObserver(vtkCommand::EndEvent,
                                             this->SaveDictionaryCommand);
  this->TermDocumentMatrixBuilder->AddObserver(vtkCommand::EndEvent,
                                               this->SaveTermDocumentMatrixCommand);

#if defined(VTK_USE_MPI)
  this->Controller = 0;
  this->ParallelDictionaryBuilder =
    vtkSmartPointer<vtkPTermDictionaryMapReduce>::New();
  this->ParallelDictionaryBuilder->AddObserver(vtkCommand::EndEvent,
                                               this->SaveDictionaryCommand);
#endif // VTK_USE_MPI

  this->AssembleInitialPipeline();
}

// ----------------------------------------------------------------------

vtkLDADocumentPipeline::~vtkLDADocumentPipeline()
{
  this->SetTermDictionaryInputFilename(0);
  this->SetTermDictionaryOutputFilename(0);
  this->SetTermDocumentMatrixInputFilename(0);
  this->SetTermDocumentMatrixOutputFilename(0);
#if defined(VTK_USE_MPI)
  this->SetController(0);
#endif
}

// ----------------------------------------------------------------------

int
vtkLDADocumentPipeline::FillInputPortInformation(int port,
                                                 vtkInformation *info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
    return 1;
    }
  else
    {
    return 0;
    }
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::AssembleInitialPipeline()
{
  // The first chunk of the pipeline runs from AssignMimeTypes through
  // DictionaryBuilder.  It will be used if TermDictionaryInput or
  // TermDocumentMatrixInput are not set.
  this->AssignMimeTypes->SetMimeTypes(this->MimeTypeLibrary);

  this->TextExtractor->SetInputArrayToProcess(0, 0, 0,
                                              vtkDataObject::FIELD_ASSOCIATION_ROWS,
                                              "document");
  this->TextExtractor->SetInputArrayToProcess(2, 0, 0,
                                              vtkDataObject::FIELD_ASSOCIATION_ROWS,
                                              "mime_type");
  this->TextExtractor->SetInputArrayToProcess(3, 0, 0,
                                              vtkDataObject::FIELD_ASSOCIATION_ROWS,
                                              "content");
  this->TextExtractor->SetInputConnection(this->AssignMimeTypes->GetOutputPort());
  this->TextExtractor->SetReleaseDataFlag(true);

  this->FoldCase->SetInputArrayToProcess(0, 0, 0,
                                         vtkDataObject::FIELD_ASSOCIATION_ROWS,
                                         "text");
  this->FoldCase->SetResultArray("case_folded_text");
  this->FoldCase->SetInputConnection(this->TextExtractor->GetOutputPort());
  this->FoldCase->SetReleaseDataFlag(true);

  this->Tokenizer->SetInputArrayToProcess(0, 0, 0,
                                          vtkDataObject::FIELD_ASSOCIATION_ROWS,
                                          "document");
  this->Tokenizer->SetInputArrayToProcess(1, 0, 0,
                                          vtkDataObject::FIELD_ASSOCIATION_ROWS,
                                          "case_folded_text");
  this->Tokenizer->AddDroppedDelimiters(vtkTokenizer::Whitespace());
  this->Tokenizer->SetInputConnection(this->FoldCase->GetOutputPort());
  this->Tokenizer->SetReleaseDataFlag(true);

  this->StopWordFilter->SetInputConnection(this->Tokenizer->GetOutputPort());
  this->StopWordFilter->SetReleaseDataFlag(true);

  this->SerialDictionaryBuilder->SetInputConnection(this->StopWordFilter->GetOutputPort());
#if defined(VTK_USE_MPI)
  this->ParallelDictionaryBuilder->SetInputConnection(this->StopWordFilter->GetOutputPort());
#endif

  // The second segment of the pipeline builds the term/document
  // frequency matrix.  It needs the documents and the dictionary as
  // inputs.  The dictionary might come from a file so we'll leave
  // that input unset for now.

  this->TermDocumentMatrixBuilder->SetInputConnection(0, this->StopWordFilter->GetOutputPort());
  // Input 1 is the feature dictionary -- unset for now
  // Input 2 is the document dictionary -- unset until we know whether we're
  // working in serial/parallel

  // Done assembling the pipeline
}

// ----------------------------------------------------------------------

int
vtkLDADocumentPipeline::RequestData(vtkInformation *vtkNotUsed(request),
                                    vtkInformationVector **inVector,
                                    vtkInformationVector *outVector)
{
  try
    {
    // first the usual sanity checks

    // 4 cases to worry about:
    //
    // Here we require that the input be available from the pipeline
    //
    // dictionary from scratch, termdoc from scratch
    // dictionary from scratch, termdoc from file
    // dictionary from file, termdoc from scratch
    //
    // Here it's OK if the pipeline input is empty
    // dictionary from file, termdoc from file

    if (inVector[0] == 0)
      {
      if (this->TermDictionaryInputFilename == 0)
        {
        throw vtksys_stl::runtime_error("No document input available and term dictionary filename is not set!");
        }
      if (this->TermDocumentMatrixInputFilename == 0)
        {
        throw vtksys_stl::runtime_error("No document input available and termdoc matrix filename is not set!");
        }
      }

    // Handle the four cases one by one
    if (this->TermDocumentMatrixInputFilename == 0)
      {
      if (this->TermDictionaryInputFilename == 0)
        {
        // Building everything from scratch
        this->ConnectPipelineForDictionaryBuild();
        }
      else
        {
        // Using a saved dictionary but new documents -- this is not
        // as weird as it seems.  You have to do this when you do
        // inference, for example, to make sure the term IDs match up
        // between old and new documents.

        this->DictionaryReader->SetFileName(this->TermDictionaryInputFilename);
        this->TermDocumentMatrixBuilder->SetInputConnection(
          1, this->DictionaryReader->GetOutputPort()
          );
        }

      // In either case we're using the input document table so we
      // need to hook up the whole pipeline leading to the dictionary builder.
      vtkTable *document_input = vtkTable::GetData(inVector[0]);
      this->AssignMimeTypes->SetInputData(0,document_input);
      }
    else // reading in the term/doc matrix from file
      {
      this->TermDocumentMatrixReader->SetFileName(this->TermDocumentMatrixInputFilename);

      if (this->TermDictionaryInputFilename == 0)
        {
        // building the dictionary from scratch
        vtkWarningMacro(<<" You are using a saved term/document matrix "
                        << "but trying to recalculate the term dictionary.  "
                        << "Are you sure this is what you want?");

        this->ConnectPipelineForDictionaryBuild();
        vtkTable *document_input = vtkTable::GetData(inVector[0]);
        this->AssignMimeTypes->SetInputData(0,document_input);
        }
      else
        {
        // reading in the dictionary as well
        this->DictionaryReader->SetFileName(this->TermDictionaryInputFilename);
        }
      } // done handling all 4 input permutations


    if (this->TermDocumentMatrixInputFilename == 0)
      {
      this->TermDocumentMatrixBuilder->SetInputConnection(2, this->TextExtractor->GetOutputPort());
      }

    vtkArrayData *output_termdoc = this->GetOutput();
    vtkDebugMacro(<<"Beginning internal pipeline execution.");

    // At this point the entire pipeline should be connected.  There
    // are also observers on the dictionary and termdoc builders to
    // write them out to disk after they're computed.  We're good to go.

    if (this->TermDocumentMatrixInputFilename != 0)
      {
      this->TermDocumentMatrixReader->Update();
      output_termdoc->ShallowCopy(this->TermDocumentMatrixReader->GetOutput());

      // special case: what if we've forgotten the term dictionary
      // and need to regenerate it?
      if (this->TermDictionaryInputFilename == 0 &&
          this->TermDictionaryOutputFilename != 0)
        {
        this->ForceDictionaryRebuild();
        }
      }
    else // termdoc matrix being built from scratch
      {
      // Building this matrix will also cause the dictionary to be
      // read or built as needed
      this->TermDocumentMatrixBuilder->Update();
      output_termdoc->ShallowCopy(this->TermDocumentMatrixBuilder->GetOutput());
      }
    // Done retrieving dictionary and term/document matrix
    }
  catch (const vtksys_stl::runtime_error &e)
    {
    vtkErrorMacro(<<"Fatal error: " << e.what());
    return 0;
    }

  return 1;
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::ForceDictionaryRebuild()
{
#if defined(VTK_USE_MPI)
  if (this->Controller != 0)
    {
    vtkDebugMacro(<<"Rebuilding dictionary in parallel");
    this->ParallelDictionaryBuilder->Update();
    }
  else
    {
    vtkDebugMacro(<<"Rebuilding dictionary in serial");
    this->SerialDictionaryBuilder->Update();
    }
#else // not VTK_USE_MPI
  vtkDebugMacro(<<"Rebuilding dictionary in serial because VTK was built "
                <<"with VTK_USE_MPI turned off");
  this->SerialDictionaryBuilder->Update();
#endif
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::ConnectPipelineForDictionaryBuild()
{
#if defined(VTK_USE_MPI)
  if (this->Controller != 0)
    {
    vtkDebugMacro(<<"Building term dictionary "
                  <<"in parallel (using "
                  << this->ParallelDictionaryBuilder->GetClassName()
                  << ") from input documents.");
    this->ParallelDictionaryBuilder->SetController(this->Controller);
    this->ParallelDictionaryBuilder->SetInputConnection(this->StopWordFilter->GetOutputPort());
    this->TermDocumentMatrixBuilder->SetInputConnection(1, this->ParallelDictionaryBuilder->GetOutputPort());
    }
  else // we must be running in serial
    {
    vtkDebugMacro(<<"Building term dictionary "
                  <<"in serial from input documents.");
    this->SerialDictionaryBuilder->SetInputConnection(this->StopWordFilter->GetOutputPort());
    this->TermDocumentMatrixBuilder->SetInputConnection(1, this->SerialDictionaryBuilder->GetOutputPort());
    }
#else // not VTK_PARALLEL
  vtkDebugMacro(<<"VTK_PARALLEL is off.  Building term dictionary "
                <<"in serial from input documents.");
  this->SerialDictionaryBuilder->SetInputConnection(this->StopWordFilter->GetOutputPort());
  this->TermDocumentMatrixBuilder->SetInputConnection(1, this->SerialDictionaryBuilder->GetOutputPort());
#endif // VTK_USE_MPI
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::DictionaryBuildFinishedCallback()
{
    // Before we do anything else, anything at all, we need to remove
    // the observer on EndEvent.  Otherwise we get stuck in an
    // infinite loop that updates the dictionary to prepare for
    // writing, calls this function when it's done, updates the
    // dictionary to prepare for writing... and so on.

#if defined(VTK_USE_MPI)
  this->ParallelDictionaryBuilder->RemoveObserver(this->SaveDictionaryCommand);
#endif
  this->SerialDictionaryBuilder->RemoveObserver(this->SaveDictionaryCommand);

  if (this->TermDictionaryOutputFilename != 0 &&
      this->TermDictionaryInputFilename == 0)
    {
    vtkSmartPointer<vtkTableWriter> writer = vtkSmartPointer<vtkTableWriter>::New();
    writer->SetFileName(this->TermDictionaryOutputFilename);
#if defined(VTK_USE_MPI)
    if (this->Controller)
      {
      if (this->Controller->GetLocalProcessId() == 0)
        {
        writer->SetInputConnection(this->ParallelDictionaryBuilder->GetOutputPort());
        writer->Write();
        }
      else
        {
        this->ParallelDictionaryBuilder->Update();
        }
      }
    else
      {
      writer->SetInputConnection(this->SerialDictionaryBuilder->GetOutputPort());
      writer->Write();
      }
#else // not VTK_USE_MPI
    writer->SetInputConnection(this->SerialDictionaryBuilder->GetOutputPort());
    writer->Write();
#endif
    // Now that that's done we can add the observers back.
    this->SerialDictionaryBuilder->AddObserver(vtkCommand::EndEvent,
                                               this->SaveDictionaryCommand);
#if defined(VTK_USE_MPI)
    this->ParallelDictionaryBuilder->AddObserver(vtkCommand::EndEvent,
                                                 this->SaveDictionaryCommand);
#endif
    }
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::TermDocumentMatrixBuildFinishedCallback()
{
  if (this->TermDocumentMatrixOutputFilename != 0 &&
      this->TermDocumentMatrixInputFilename == 0)
    {
    // As above, the first thing we have to do is disable the observer
    // so we don't get stuck in an infinite loop.
    this->TermDocumentMatrixBuilder->RemoveObserver(
      this->SaveTermDocumentMatrixCommand
      );

    vtkSmartPointer<vtkArrayWriter> writer = vtkSmartPointer<vtkArrayWriter>::New();
    writer->SetInputConnection(this->TermDocumentMatrixBuilder->GetOutputPort());
    writer->Write(this->TermDocumentMatrixOutputFilename);

    this->TermDocumentMatrixBuilder->AddObserver(vtkCommand::EndEvent,
                                                 this->SaveTermDocumentMatrixCommand);
    }
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);

#define GUARD_NULL(thing) ((thing) ? (thing) : "(null)")

  os << indent << "Term dictionary input filename: "
     << GUARD_NULL(this->TermDictionaryInputFilename) << "\n";

  os << indent << "Term dictionary output filename: "
     << GUARD_NULL(this->TermDictionaryOutputFilename) << "\n";

  os << indent << "Term/document matrix input filename: "
     << GUARD_NULL(this->TermDocumentMatrixInputFilename) << "\n";

  os << indent << "Term/document matrix output filename: "
     << GUARD_NULL(this->TermDocumentMatrixOutputFilename) << "\n";

  os << indent << "Mime type discoverer:\n";
  this->AssignMimeTypes->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Mime type library:\n";
  this->MimeTypeLibrary->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Text extractor:\n";
  this->TextExtractor->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Case folder:\n";
  this->FoldCase->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Tokenizer:\n";
  this->Tokenizer->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Stop word filter:\n";
  this->StopWordFilter->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Dictionary builder (serial):\n";
  this->SerialDictionaryBuilder->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Term/document matrix builder:\n";
  this->TermDocumentMatrixBuilder->PrintSelf(os, indent.GetNextIndent());

#if defined(VTK_USE_MPI)
  os << indent << "Dictionary builder (parallel):\n";
  this->ParallelDictionaryBuilder->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Multiprocess controller: ";
  if (this->Controller)
    {
    os << "\n";
    this->Controller->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)";
    }
#endif

  os << indent << "Term/document matrix reader:\n";
  this->TermDocumentMatrixReader->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Term dictionary reader:\n";
  this->DictionaryReader->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Callback command for dictionary:\n";
  this->SaveDictionaryCommand->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Callback command for term/doc matrix:\n";
  this->SaveTermDocumentMatrixCommand->PrintSelf(os, indent.GetNextIndent());
}

// ----------------------------------------------------------------------

vtkMimeTypes *
vtkLDADocumentPipeline::GetMimeTypeLibrary()
{
  return this->MimeTypeLibrary;
}

// ----------------------------------------------------------------------

void
vtkLDADocumentPipeline::CopyTermDictionary(vtkTable *output)
{
  if (this->TermDictionaryInputFilename != 0)
    {
    this->DictionaryReader->Update();
    output->ShallowCopy(this->DictionaryReader->GetOutput());
    }
  else
    {
#if defined(VTK_USE_MPI)
    if (this->Controller != 0)
      {
      this->ParallelDictionaryBuilder->Update();
      output->ShallowCopy(this->ParallelDictionaryBuilder->GetOutput());
      }
    else
      {
      this->SerialDictionaryBuilder->Update();
      output->ShallowCopy(this->SerialDictionaryBuilder->GetOutput());
      }
#else
    this->SerialDictionaryBuilder->Update();
    output->ShallowCopy(this->SerialDictionaryBuilder->GetOutput());
#endif
    }
}

// ----------------------------------------------------------------------

vtkAlgorithmOutput *
vtkLDADocumentPipeline::GetDictionaryOutputPort()
{
  if (this->TermDictionaryInputFilename != 0)
    {
    return this->DictionaryReader->GetOutputPort();
    }
  else
    {
#if defined(VTK_USE_MPI)
    if (this->Controller != 0)
      {
      return this->ParallelDictionaryBuilder->GetOutputPort();
      }
    else
      {
      return this->SerialDictionaryBuilder->GetOutputPort();
      }
#else
    return this->SerialDictionaryBuilder->GetOutputPort();
#endif
    }
}

// ----------------------------------------------------------------------

vtkTokenizer *
vtkLDADocumentPipeline::GetTokenizer()
{
  return this->Tokenizer;
}

// ----------------------------------------------------------------------

vtkTokenValueFilter *
vtkLDADocumentPipeline::GetStopWordFilter()
{
  return this->StopWordFilter;
}
