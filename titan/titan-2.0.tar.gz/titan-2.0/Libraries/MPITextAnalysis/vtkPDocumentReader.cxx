/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkDataSetAttributes.h>
#include <vtkDocumentReader.h>
#include <vtkIdTypeArray.h>
#include <vtkInformation.h>
#include <vtkMultiProcessController.h>
#include <vtkObjectFactory.h>
#include <vtkPDocumentReader.h>
#include <vtkSmartPointer.h>
#include <vtkStdString.h>
#include <vtkStringArray.h>
#include <vtkTable.h>

#include <algorithm>
#include <functional>
#include <iterator>
#include <map>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

#include <vtksys/SystemTools.hxx>

//////////////////////////////////////////////////////////////////////////////
// vtkPDocumentReader::Implementation

class vtkPDocumentReader::Implementation
{
public:
  typedef std::vector<std::vector<vtkStdString> > BucketsT;

  // Each bucket receives (roughly) the same number of documents.  We accomplish
  // this by doing a round-robin distribution of documents to buckets, until we
  // run out of documents.
  void DocumentPartitioning(vtkMultiProcessController* controller, vtkPDocumentReader* self, BucketsT& buckets)
  {
    for(vtkIdType i = 0; i != static_cast<vtkIdType>(this->Files.size()); ++i)
      {
      buckets[i % buckets.size()].push_back(this->Files[i]);
      }
  }

  // Each bucket receives (roughly) the same number of bytes.  This is a variation
  // on bin packing, which is a combinatorial NP hard problem.  Here, we follow a heuristic
  // approach of inserting each file, in descending order of file length, into whichever bucket
  // contains the fewest number of file bytes at that moment.
  void BytePartitioning(vtkMultiProcessController* controller, vtkPDocumentReader* self, BucketsT& buckets)
  {
    // Use processor 0 only to collect file sizes for every file, then broadcast the results to everyone ...
    std::vector<vtkIdType> file_sizes(this->Files.size(), 0);
    if(0 == controller->GetLocalProcessId())
      {
      for(vtkIdType i = 0; i != static_cast<vtkIdType>(this->Files.size()); ++i)
        file_sizes[i] = vtksys::SystemTools::FileLength(this->Files[i]);
      }

    controller->GetCommunicator()->Broadcast(&file_sizes[0], file_sizes.size(), 0);

    // Create a list of files, sorted in order of decreasing length ...
    std::multimap<vtkIdType, vtkIdType, std::greater<vtkIdType> > file_map;
    for(vtkIdType i = 0; i != static_cast<vtkIdType>(this->Files.size()); ++i)
      file_map.insert(std::make_pair(file_sizes[i], i));

    // Create a list of buckets, sorted in order of increasing byte contents ...
    std::multimap<vtkIdType, vtkIdType, std::less<vtkIdType> > bucket_map;
    for(vtkIdType i = 0; i != static_cast<vtkIdType>(buckets.size()); ++i)
      bucket_map.insert(std::make_pair(0, i));

    while(!file_map.empty())
      {
      const vtkIdType file_size = file_map.begin()->first;
      const vtkIdType file = file_map.begin()->second;
      file_map.erase(file_map.begin());

      const vtkIdType bucket_size = bucket_map.begin()->first;
      const vtkIdType bucket = bucket_map.begin()->second;
      bucket_map.erase(bucket_map.begin());

      buckets[bucket].push_back(this->Files[file]);
      bucket_map.insert(std::make_pair(bucket_size + file_size, bucket));
      }
  }

  // Each bucket receives (roughly) the same number of bytes.  This is the same approach as
  // BytePartitioning(), above, but every process generates its own file sizes, leading to
  // lots of I/O contention.
  void ThrashPartitioning(vtkMultiProcessController* controller, vtkPDocumentReader* self, BucketsT& buckets)
  {
    // Create a list of files, sorted in order of decreasing length ...
    std::multimap<vtkIdType, vtkIdType, std::greater<vtkIdType> > file_map;
    for(vtkIdType i = 0; i != static_cast<vtkIdType>(this->Files.size()); ++i)
      file_map.insert(std::make_pair(vtksys::SystemTools::FileLength(this->Files[i]), i));

    // Create a list of buckets, sorted in order of increasing byte contents ...
    std::multimap<vtkIdType, vtkIdType, std::less<vtkIdType> > bucket_map;
    for(vtkIdType i = 0; i != static_cast<vtkIdType>(buckets.size()); ++i)
      bucket_map.insert(std::make_pair(0, i));

    while(!file_map.empty())
      {
      const vtkIdType file_size = file_map.begin()->first;
      const vtkIdType file = file_map.begin()->second;
      file_map.erase(file_map.begin());

      const vtkIdType bucket_size = bucket_map.begin()->first;
      const vtkIdType bucket = bucket_map.begin()->second;
      bucket_map.erase(bucket_map.begin());

      buckets[bucket].push_back(this->Files[file]);
      bucket_map.insert(std::make_pair(bucket_size + file_size, bucket));
      }
  }

  vtkPDocumentReaderStrategy::PathList Files;
  vtkPDocumentReaderStrategy::PathList Directories;
  vtkPDocumentReaderStrategy::PathList RecursiveDirectories;
};

//////////////////////////////////////////////////////////////////////////////
// vtkPDocumentReader


vtkStandardNewMacro(vtkPDocumentReader);

vtkPDocumentReader::vtkPDocumentReader() :
  Internal(new Implementation()),
  Strategy(0),
  Controller(0),
  PartitionDomain(DOCUMENTS)
{
  this->SetController(vtkMultiProcessController::GetGlobalController());

  this->SetNumberOfInputPorts(0);
  this->SetNumberOfOutputPorts(2);
}

vtkPDocumentReader::~vtkPDocumentReader()
{
  this->SetController(0);
  this->SetStrategy(0);
  delete this->Internal;
}

void vtkPDocumentReader::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);

  os << indent << "Files: ";
  std::copy(
    this->Internal->Files.begin(),
    this->Internal->Files.end(),
    std::ostream_iterator<vtkStdString>(os, " "));
  os << "\n";

  os << indent << "Directories: ";
  std::copy(
    this->Internal->Directories.begin(),
    this->Internal->Directories.end(),
    std::ostream_iterator<vtkStdString>(os, " "));
  os << "\n";

  os << indent << "RecursiveDirectories: ";
  std::copy(
    this->Internal->RecursiveDirectories.begin(),
    this->Internal->RecursiveDirectories.end(),
    std::ostream_iterator<vtkStdString>(os, " "));
  os << "\n";

  os << indent << "Strategy: " << (this->Strategy ? "" : "null") << endl;
  if(this->Strategy)
    {
    this->Strategy->PrintSelf(os, indent.GetNextIndent());
    }

  os << indent << "PartitionDomain: " << this->PartitionDomain << "\n";
}

void vtkPDocumentReader::AddFile(const char* file)
{
  if(!file)
    return;

  this->AddFile(vtkStdString(file));
}

void vtkPDocumentReader::AddFile(const vtkStdString& file)
{
  this->Internal->Files.erase(
    std::remove(
      this->Internal->Files.begin(),
      this->Internal->Files.end(),
      file),
    this->Internal->Files.end());
  this->Internal->Files.push_back(file);
  this->Modified();
}

void vtkPDocumentReader::ClearFiles()
{
  this->Internal->Files.clear();
  this->Modified();
}

void vtkPDocumentReader::AddDirectory(const char* directory)
{
  if(!directory)
    return;

  this->AddDirectory(vtkStdString(directory));
}

void vtkPDocumentReader::AddDirectory(const vtkStdString& directory)
{
  this->Internal->Directories.erase(
    std::remove(
      this->Internal->Directories.begin(),
      this->Internal->Directories.end(),
      directory),
    this->Internal->Directories.end());
  this->Internal->Directories.push_back(directory);
  this->Modified();
}

void vtkPDocumentReader::ClearDirectories()
{
  this->Internal->Directories.clear();
  this->Modified();
}

void vtkPDocumentReader::AddRecursiveDirectory(const char* directory)
{
  if(!directory)
    return;

  this->AddRecursiveDirectory(vtkStdString(directory));
}

void vtkPDocumentReader::AddRecursiveDirectory(const vtkStdString& directory)
{
  this->Internal->RecursiveDirectories.erase(
    std::remove(
      this->Internal->RecursiveDirectories.begin(),
      this->Internal->RecursiveDirectories.end(),
      directory),
    this->Internal->RecursiveDirectories.end());
  this->Internal->RecursiveDirectories.push_back(directory);
  this->Modified();
}

void vtkPDocumentReader::ClearRecursiveDirectories()
{
  this->Internal->RecursiveDirectories.clear();
  this->Modified();
}

int vtkPDocumentReader::RequestData(
  vtkInformation* request,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  if(!this->Strategy)
    return this->LegacyRequestData(request, inputVector, outputVector);

  // Setup output arrays ...
  vtkIdTypeArray* const document_array = vtkIdTypeArray::New();
  document_array->SetName("document");

  vtkStringArray* const uri_array = vtkStringArray::New();
  uri_array->SetName("uri");

  vtkStringArray* const content_array = vtkStringArray::New();
  content_array->SetName("content");

  vtkTable* const output_table = vtkTable::GetData(outputVector, 0);
  output_table->AddColumn(document_array);
  output_table->AddColumn(uri_array);
  output_table->AddColumn(content_array);
  output_table->GetRowData()->SetPedigreeIds(document_array);

  document_array->Delete();
  uri_array->Delete();
  content_array->Delete();

  try
    {
    if(!this->Controller)
      throw std::runtime_error("Process controller hasn't been set!");

    if(!this->Strategy)
      throw std::runtime_error("Document partitioning strategy hasn't been set!");

    // Let the partitioning strategy decide what to load locally ...
    const vtkIdType local_document_count =
      this->Strategy->LoadFiles(
        this->Controller,
        this->Internal->Files,
        this->Internal->Directories,
        this->Internal->RecursiveDirectories,
        uri_array,
        content_array
        );

    // Generate globally-unique document identifiers that are contiguous for each process ...
    std::vector<vtkIdType> document_counts(this->Controller->GetNumberOfProcesses(), 0);
    this->Controller->AllGather(&local_document_count, &document_counts[0], 1);

    const vtkIdType processor_offset = std::accumulate(document_counts.begin(), document_counts.begin() + this->Controller->GetLocalProcessId(), 0);
    for(vtkIdType i = 0; i != uri_array->GetNumberOfTuples(); ++i)
      document_array->InsertNextValue(processor_offset + i);

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    }

  // An error occurred, so cleanup everything and return a valid-but-empty table ...
  document_array->Initialize();
  uri_array->Initialize();
  content_array->Initialize();

  return 0;
}

int vtkPDocumentReader::LegacyRequestData(
  vtkInformation* request,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    const int process_id = this->Controller->GetLocalProcessId();
    const int process_count = this->Controller->GetNumberOfProcesses();

    // Partition all our files into a set of "buckets", one bucket per processor ...
    Implementation::BucketsT buckets(process_count);

    switch(this->PartitionDomain)
      {
      case DOCUMENTS:
        this->Internal->DocumentPartitioning(this->Controller, this, buckets);
        break;
      case BYTES:
        this->Internal->BytePartitioning(this->Controller, this, buckets);
        break;
      case THRASH:
        this->Internal->ThrashPartitioning(this->Controller, this, buckets);
        break;
      default:
        throw std::runtime_error("unknown partition strategy type");
      }

    // Send this processor's bucket to a serial reader, generating global document IDs as we go ...
    vtkSmartPointer<vtkDocumentReader> reader = vtkSmartPointer<vtkDocumentReader>::New();

    vtkIdType global_offset = 0;
    for(vtkIdType i = 0; i != process_count; ++i)
      {
      if(i == process_id)
        {
        for(vtkIdType j = 0; j != static_cast<vtkIdType>(buckets[i].size()); ++j)
          {
          reader->AddFile(buckets[i][j], j + global_offset);
          }
        break;
        }

      global_offset += buckets[i].size();
      }

    vtkTable* const output_table = vtkTable::GetData(outputVector, 0);

    reader->Update();

    output_table->ShallowCopy(reader->GetOutput());
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  return 1;
}
