/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkSortedBytePDocumentReaderStrategy_h
#define __vtkSortedBytePDocumentReaderStrategy_h

#include <titanMPITextAnalysis.h>

#include <vtkObject.h>
#include <vtkPDocumentReaderStrategy.h>

/// \class vtkSortedBytePDocumentReaderStrategy vtkSortedBytePDocumentReaderStrategy.h <MPITextAnalysis/vtkSortedBytePDocumentReaderStrategy.h>
/// \brief Distributes documents across
///  processes while trying to load balance based on number of bytes.
///
///  Concrete implementation of vtkPDocumentReaderStrategy that tries to equalize
///  the number of bytes loaded by each process.  This is a variation on bin-packing,
///  which is NP-complete, so we implement a hueristic approach: documents are sorted
///  in order of descending byte size, and each document is assigned to the process
///  which currently has the fewest bytes assigned.
///
///  The only communication is a one-time collection and distribution of document sizes
///  at the beginning of the algorithm.
///
/// \sa
///  vtkPDocumentReader
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkSortedBytePDocumentReaderStrategy :
  public vtkPDocumentReaderStrategy
{
public:
  static vtkSortedBytePDocumentReaderStrategy* New();
  vtkTypeMacro(vtkSortedBytePDocumentReaderStrategy, vtkPDocumentReaderStrategy);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
  virtual int LoadFiles(
    vtkMultiProcessController* const controller,
    const PathList& files,
    const PathList& directories,
    const PathList& recursive_directories,
    vtkStringArray* uri_array,
    vtkStringArray* contents_array
    );

protected:
  vtkSortedBytePDocumentReaderStrategy();
  ~vtkSortedBytePDocumentReaderStrategy();

private:
  vtkSortedBytePDocumentReaderStrategy(const vtkSortedBytePDocumentReaderStrategy &); // Not implemented.
  void operator=(const vtkSortedBytePDocumentReaderStrategy &); // Not implemented.
//ETX
};

#endif // __vtkSortedBytePDocumentReaderStrategy_h
