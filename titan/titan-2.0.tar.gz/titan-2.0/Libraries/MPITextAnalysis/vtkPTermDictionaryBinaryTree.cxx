/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkPTermDictionaryBinaryTree.h"
#include "vtkPTermDictionaryCommunicator.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"

#include <cmath>
#include <map>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryBinaryTree


vtkStandardNewMacro(vtkPTermDictionaryBinaryTree);

vtkPTermDictionaryBinaryTree::vtkPTermDictionaryBinaryTree() :
  Controller(0)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");

  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);

  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPTermDictionaryBinaryTree::~vtkPTermDictionaryBinaryTree()
{
  this->SetController(0);
}

void vtkPTermDictionaryBinaryTree::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkPTermDictionaryBinaryTree::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}

int vtkPTermDictionaryBinaryTree::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("Process controller hasn't been set!");

    vtkUnicodeStringArray* const input_term_array = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!input_term_array)
      throw std::runtime_error("Missing input term array.");

    vtkPTermDictionaryCommunicator communicator(this->Controller->GetCommunicator());

    // Compute the set of unique local terms ...
    vtkPTermDictionaryCommunicator::UniqueSortedTerms terms;
    communicator.ConvertTerms(*input_term_array, terms);

    // Send local terms to the root node using a binary tree ...
    for(int step = 0; ; ++step)
      {
      std::map<int, int> senders;
      std::map<int, int> receivers;

      for(int sender = static_cast<int>(std::pow(2.0, step)), receiver = 0;
          sender < this->Controller->GetNumberOfProcesses();
          sender += static_cast<int>(std::pow(2.0, step + 1)), receiver += static_cast<int>(std::pow(2.0, step + 1)))
        {
        senders[sender] = receiver;
        receivers[receiver] = sender;
        }

      if(senders.empty())
        break;

      if(0 == this->Controller->GetLocalProcessId())
        {
        std::cerr << "step " << step << ": ";
        for(std::map<int, int>::iterator sender = senders.begin(); sender != senders.end(); ++sender)
          std::cerr << sender->first << " -> " << sender->second << " ";
        std::cerr << std::endl;
        }

      if(senders.count(this->Controller->GetLocalProcessId()))
        {
        const int receiver = senders[this->Controller->GetLocalProcessId()];
        communicator.SendTerms(terms, receiver);
        }

      if(receivers.count(this->Controller->GetLocalProcessId()))
        {
        const int sender = receivers[this->Controller->GetLocalProcessId()];
        communicator.ReceiveTerms(sender, terms);
        }
      }

    // Broadcast global terms back to every node ...
    communicator.BroadcastTerms(terms, 0, terms);

    // Insert terms into the term dictionary ...
    vtkUnicodeStringArray* const output_dictionary = vtkUnicodeStringArray::New();
    output_dictionary->SetName("text");
    communicator.ConvertTerms(terms, *output_dictionary);

    // Configure our outputs ...
    vtkTable* const output = vtkTable::GetData(outputVector, 0);
    output->AddColumn(output_dictionary);
    output_dictionary->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "Caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "Caught unknown exception." << endl);
    }

  return 0;
}
