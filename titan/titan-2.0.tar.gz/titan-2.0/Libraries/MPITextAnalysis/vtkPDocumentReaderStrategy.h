/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPDocumentReaderStrategy_h
#define __vtkPDocumentReaderStrategy_h

#include <titanMPITextAnalysis.h>

#include <vtkObject.h>
#include <vector>

class vtkIdTypeArray;
class vtkMultiProcessController;
class vtkStdString;
class vtkStringArray;

/// \class vtkPDocumentReaderStrategy vtkPDocumentReaderStrategy.h <MPITextAnalysis/vtkPDocumentReaderStrategy.h>
/// \brief Abstract interface for an object that can
///  partition documents for parallel text analysis.
///
///  Concrete implementations of vtkPDocumentReaderStrategy implement strategies for
///  partitioning and reading documents into memory across multiple processes.
///
/// \sa
///  vtkPDocumentReader
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPDocumentReaderStrategy :
  public vtkObject
{
public:
  vtkTypeMacro(vtkPDocumentReaderStrategy, vtkObject);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX

  typedef std::vector<vtkStdString> PathList;
  typedef std::vector<vtkIdType> FileSizes;

  ///@{
  /// Implementations should load the given files and directories,
  /// ensuring that each document is loaded on one-and-only-one
  /// process.  Implementations are free to perform as-little or
  /// as-much communication as is necessary to ensure correct
  /// partitioning.  Implementations must append one value to the
  /// uri_array and one value to the content_array for every document
  /// loaded locally.  Further, the document_counts array must be
  /// updated so that it contains the global number of documents loaded
  /// on each processor.  Note that there need not be a one-to-one
  /// correspondance between files and documents, i.e. an
  /// implementation is free to "split" a file into multiple documents
  /// if desired.  See LoadLocalFile() and vtkFileToRawDocumentsStrategy
  /// for information on how to do this.
  virtual int LoadFiles(
    vtkMultiProcessController* const controller,
    const PathList& files,
    const PathList& directories,
    const PathList& recursive_directories,
    vtkStringArray* uri_array,
    vtkStringArray* content_array
    ) = 0;
  ///@}

protected:
  vtkPDocumentReaderStrategy();
  ~vtkPDocumentReaderStrategy();

  ///@{
  /// Convenience function that can be called by implementations to
  /// lookup the sizes of every file contained in the given file and
  /// directory lists.  Note: file sizes for directories will be in the
  /// order returned by boost::filesystem::directory_iterator and
  /// boost::filesystem::recursive_directory_iterator.  Implementations
  /// must iterate over files in the same order for the file_sizes
  /// returned to be meaningful.  This version of LookupFileSizes()
  /// does the same set of lokups on every processor, eliminating the
  /// need for any communication.
  void LookupFileSizes(
    const PathList& files,
    const PathList& directories,
    const PathList& recursive_directories,
    FileSizes& file_sizes
    );
  ///@}

  ///@{
  /// Convenience function that can be called by implementations to
  /// lookup the sizes of every file contained in the given file and
  /// directory lists.  Note: file sizes for directories will be in the
  /// order returned by boost::filesystem::directory_iterator and
  /// boost::filesystem::recursive_directory_iterator.  Implementations
  /// must iterate over files in the same order for the file_sizes
  /// returned to be meaningful.  This version of LookupFileSizes()
  /// performs the lookups on a single processor, then broadcasts the
  /// results to the remaining processors.
  void LookupFileSizes(
    vtkMultiProcessController* const controller,
    const PathList& files,
    const PathList& directories,
    const PathList& recursive_directories,
    FileSizes& file_sizes
    );
  ///@}


  /// Convenience function that can be called by implementations to
  /// load local files.  The default implementation assumes a
  /// one-to-one correspondence between files and documents.  You may
  /// override the function if this is not the case -- for example, if
  /// your files contain one document per line.

  virtual void LoadLocalFile(
    const vtkStdString& file,
    vtkStringArray* uri_array,
    vtkStringArray* content_array
    );

private:
  vtkPDocumentReaderStrategy(const vtkPDocumentReaderStrategy &); // Not implemented.
  void operator=(const vtkPDocumentReaderStrategy &); // Not implemented.
//ETX
};

#endif // __vtkPDocumentReaderStrategy_h
