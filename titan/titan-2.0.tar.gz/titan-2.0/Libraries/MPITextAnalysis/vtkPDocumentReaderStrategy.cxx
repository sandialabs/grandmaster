/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkIdTypeArray.h>
#include <vtkMultiProcessController.h>
#include <vtkPDocumentReaderStrategy.h>
#include <vtkStdString.h>
#include <vtkStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/algorithm/string/trim.hpp>
#include <boost/filesystem/v3/operations.hpp>
#include <boost/filesystem.hpp>

#include <vtksys/ios/fstream>
#include <vtksys/ios/sstream>
#include <vtksys/SystemTools.hxx>



vtkPDocumentReaderStrategy::vtkPDocumentReaderStrategy()
{
}

vtkPDocumentReaderStrategy::~vtkPDocumentReaderStrategy()
{
}

void vtkPDocumentReaderStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

void vtkPDocumentReaderStrategy::LookupFileSizes(
  const PathList& files,
  const PathList& directories,
  const PathList& recursive_directories,
  FileSizes& file_sizes
  )
{
  file_sizes.clear();

  for(PathList::const_iterator file = files.begin(); file != files.end(); ++file)
    {
    file_sizes.push_back(vtksys::SystemTools::FileLength(file->c_str()));
    }
  for(PathList::const_iterator directory = directories.begin(); directory != directories.end(); ++directory)
    {
    boost::filesystem::directory_iterator end;
    for(boost::filesystem::directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(is_directory(file->path()))
        continue;

      file_sizes.push_back(vtksys::SystemTools::FileLength(file->path().string().c_str()));
      }
    }
  for(PathList::const_iterator directory = recursive_directories.begin(); directory != recursive_directories.end(); ++directory)
    {
    boost::filesystem::recursive_directory_iterator end;
    for(boost::filesystem::recursive_directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(is_directory(file->path()))
        continue;

      file_sizes.push_back(vtksys::SystemTools::FileLength(file->path().string().c_str()));
      }
    }
}

void vtkPDocumentReaderStrategy::LookupFileSizes(
  vtkMultiProcessController* const controller,
  const PathList& files,
  const PathList& directories,
  const PathList& recursive_directories,
  FileSizes& file_sizes
  )
{
  vtkIdType file_count = 0;
  file_sizes.clear();

  if(0 == controller->GetLocalProcessId())
    {
    LookupFileSizes(files, directories, recursive_directories, file_sizes);
    file_count = file_sizes.size();
    }
  controller->GetCommunicator()->Broadcast(&file_count, 1, 0);
  if(0 != controller->GetLocalProcessId())
    {
    file_sizes.resize(file_count);
    }
  controller->GetCommunicator()->Broadcast(&file_sizes[0], file_count, 0);
}

void vtkPDocumentReaderStrategy::LoadLocalFile(
  const vtkStdString& file,
  vtkStringArray* uri_array,
  vtkStringArray* content_array
  )
{
  // Format the file path as a URI ...
  vtkStdString uri = file;
  // Get rid of leading and trailing whitespace ...
  boost::trim(uri);
  // Make Windoze slashes straighten-up and fly right ...
  boost::replace_all(uri, "\\", "/");
  // Ensure that Windoze paths are absolute paths ...
  if(uri.size() > 1 && uri.at(1) == ':')
    uri = "/" + uri;
  uri = "file://" + uri;

  vtksys_ios::ifstream file_stream(file.c_str(), ios::in | ios::binary);
  vtksys_ios::stringstream contents;
  contents << file_stream.rdbuf();

  uri_array->InsertNextValue(uri);
  content_array->InsertNextValue(contents.str());
}
