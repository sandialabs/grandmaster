/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkExtractTableColumns.h>
#include <vtkMPIController.h>
#include <vtkPDocumentReader.h>
#include <vtkRoundRobinPDocumentReaderStrategy.h>
#include <vtkSmartPointer.h>
#include <vtkTable.h>
#include <vtkVariant.h>

#include <vtksys/ios/iostream>
#include <vtksys/ios/sstream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  int result = 0;

  vtkSmartPointer<vtkMPIController> controller = vtkSmartPointer<vtkMPIController>::New();
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  try
    {
    if(controller->GetNumberOfProcesses() != 4)
      throw std::runtime_error("Test must be run with exactly 4 processes.");


    vtkSmartPointer<vtkRoundRobinPDocumentReaderStrategy> strategy = vtkSmartPointer<vtkRoundRobinPDocumentReaderStrategy>::New();
    vtkSmartPointer<vtkPDocumentReader> reader = vtkSmartPointer<vtkPDocumentReader>::New();
    reader->SetStrategy(strategy);

    vtkSmartPointer<vtkExtractTableColumns> columns = vtkSmartPointer<vtkExtractTableColumns>::New();
    columns->SetInputConnection(0, reader->GetOutputPort());
    columns->AddColumn("document");
    columns->AddColumn("uri");

    reader->AddFile(titanMPITextAnalysis_SOURCE_DIR "/Data/CSV/authors.csv");
    reader->AddFile(titanMPITextAnalysis_SOURCE_DIR "/Data/CSV/fruit.csv");
    reader->AddFile(titanMPITextAnalysis_SOURCE_DIR "/Data/CSV/publications.csv");
    reader->AddFile(titanMPITextAnalysis_SOURCE_DIR "/Data/CSV/text.csv");
    reader->AddFile(titanMPITextAnalysis_SOURCE_DIR "/Data/CSV/co2emissions.csv");
    columns->Update();
    test_expression(columns->GetOutput());

    for(vtkIdType i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        std::cout << "Process " << controller->GetLocalProcessId() << " of " << controller->GetNumberOfProcesses() << std::endl;
        columns->GetOutput()->Dump(100);
        std::cout << std::flush;
        }
      controller->Barrier();
      }

    switch(controller->GetLocalProcessId())
      {
      case 0:
        test_expression(columns->GetOutput()->GetNumberOfRows() == 2);
        test_expression(columns->GetOutput()->GetValueByName(0, "document").ToInt() == 0);
        test_expression(columns->GetOutput()->GetValueByName(1, "document").ToInt() == 1);
        break;
      case 1:
        test_expression(columns->GetOutput()->GetNumberOfRows() == 1);
        test_expression(columns->GetOutput()->GetValueByName(0, "document").ToInt() == 2);
        break;
      case 2:
        test_expression(columns->GetOutput()->GetNumberOfRows() == 1);
        test_expression(columns->GetOutput()->GetValueByName(0, "document").ToInt() == 3);
        break;
      case 3:
        test_expression(columns->GetOutput()->GetNumberOfRows() == 1);
        test_expression(columns->GetOutput()->GetValueByName(0, "document").ToInt() == 4);
        break;
      }

    reader->ClearFiles();
    reader->AddRecursiveDirectory(titanMPITextAnalysis_SOURCE_DIR "/Data/CSV");
    columns->Update();
    test_expression(columns->GetOutput());

    for(vtkIdType i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        std::cout << "Process " << controller->GetLocalProcessId() << " of " << controller->GetNumberOfProcesses() << std::endl;
        columns->GetOutput()->Dump(100);
        std::cout << std::flush;
        }
      controller->Barrier();
      }

    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    result = 1;
    }

  controller->Finalize();
  return result;
}
