/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

// #define WAIT_FOR_ATTACH


#include <vtkTextAnalysisTest.h>

#include <vtkArrayPrint.h>
#include <vtkArrayWriter.h>
#include <vtkAssignMimeType.h>
#include <vtkDenseArray.h>
#include <vtkForceMimeTypeStrategy.h>
#include <vtkFoldCase.h>
#include <vtkIdTypeArray.h>
#include <vtkMimeTypes.h>
#include <vtkMPIController.h>
#include <vtkNGramExtraction.h>
#include <vtkPDocumentReader.h>
#include <vtkPLatentDirichletAllocation.h>
#include <vtkPTermDictionaryBinaryTree.h>
#include <vtkTextExtraction.h>
#include <vtkTokenization.h>
#include <vtkPassThrough.h>

// MapReduce gets built automatically with VTK when VTK_USE_MPI is on
#include <vtkPTermDictionaryMapReduce.h>

#if defined(WAIT_FOR_ATTACH)
#include <unistd.h>
#endif

#include <vtkPTermDictionaryRoundRobin.h>
#include <vtkSmartPointer.h>
#include <vtkSparseArray.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableWriter.h>
#include <vtkFrequencyMatrix.h>
#include <vtkTokenLengthFilter.h>
#include <vtkTokenValueFilter.h>
#include <vtkUnicodeStringArray.h>

#include <iomanip>
#include <fstream>
#include <limits>
#include <map>
#include <vtksys/ios/sstream>
#include <assert.h>
#include <iterator>
#include <stdexcept>
#include <algorithm>
#include <map>

#define VTK_CREATE(type,name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

static const int TOPIC_COUNT=5;
static const char *APOLLO_11_PATH = "/Data/Apollo11Wikipedia/";
static const int DOCUMENT_COUNT = 11;
static const char *FILENAMES[] = { "introduction.txt",
                                    "naming_and_insignia.txt",
                                    "launch.txt",
                                    "descent.txt",
                                    "before_eva.txt",
                                    "lunar_eva1.txt",
                                    "lunar_eva2.txt",
                                    "ascent1.txt",
                                    "ascent2.txt",
                                    "before_splashdown.txt",
                                    "return_home.txt" };

////////////////////////////////////////////////////////////////
// print top topics - each processor has different documents

typedef std::pair<double, vtkIdType> WeightedId;
typedef std::vector<WeightedId> WeightedIdVector;
typedef std::map<vtkIdType, WeightedIdVector> IdToWeightedIdVectorMap;

struct FirstComponentGreaterThan : public std::binary_function<WeightedId, WeightedId, bool>
{
public:
  bool operator()(const WeightedId &left, const WeightedId &right)
    {
      return (left.first > right.first);
    }
};

void print_top_topics(vtkArrayData *theta_container,
                      vtkMPIController *controller)
{
  IdToWeightedIdVectorMap documents_this_processor;
  vtkArray *theta = theta_container->GetArray(0);

  for (int n = 0; n < theta->GetNonNullSize(); ++n)
    {
    vtkArrayCoordinates coords;
    theta->GetCoordinatesN(n, coords);

    double value = theta->GetVariantValueN(n).ToDouble();

    // We're taking advantage of the fact that map::operator[] will
    // insert a new element if one is not found.
    vtkIdType doc_id = coords[0];
    vtkIdType topic_id = coords[1];
    documents_this_processor[doc_id].push_back(WeightedId(value, topic_id));
    }

  for (int p = 0; p < controller->GetNumberOfProcesses(); ++p)
    {
    controller->Barrier();

    if (p == controller->GetLocalProcessId())
      {
      cout << "Sorting "
           << documents_this_processor.size()
           << " local documents in process " << p << "\n";

      IdToWeightedIdVectorMap::iterator iter;
      for (iter = documents_this_processor.begin();
           iter != documents_this_processor.end();
           ++iter)
        {
        std::sort((*iter).second.begin(),
                     (*iter).second.end(),
                     FirstComponentGreaterThan());

        cout << "Top 5 topics for document " << (*iter).first << ":\n";
        for (int t = 0;
             t < 5 && t < static_cast<int>((*iter).second.size());
             ++t)
          {
          cout << "\tTopic " << (*iter).second[t].second << ": weight "
               << (*iter).second[t].first << "\n";
          }
        }
      } // done printing stuff on this processor
    } // done iterating over all processors
}

////////////////////////////////////////////////////////////////////
// print_top_terms - every processor should have this information

void print_top_terms(vtkArrayData *phi_container,
                      vtkMPIController *controller)
{
  IdToWeightedIdVectorMap terms_this_processor;
  vtkArray *phi = phi_container->GetArray(0);

  for (int n = 0; n < phi->GetNonNullSize(); ++n)
    {
    vtkArrayCoordinates coords;
    phi->GetCoordinatesN(n, coords);

    double value = phi->GetVariantValueN(n).ToDouble();

    // We're taking advantage of the fact that map::operator[] will
    // insert a new element if one is not found.
    vtkIdType term_id = coords[1];
    vtkIdType topic_id = coords[0];
    terms_this_processor[topic_id].push_back(WeightedId(value, term_id));
    }

  for (int p = 0; p < controller->GetNumberOfProcesses(); ++p)
    {
    controller->Barrier();

    if (p == controller->GetLocalProcessId())
      {
      cout << "Sorting "
           << terms_this_processor.size()
           << " topics in process "
           << p << "\n";

      IdToWeightedIdVectorMap::iterator iter;
      for (iter = terms_this_processor.begin();
           iter != terms_this_processor.end();
           ++iter)
        {
        std::sort((*iter).second.begin(),
                     (*iter).second.end(),
                     FirstComponentGreaterThan());

        cout << "Top 5 terms for topic " << (*iter).first << ":\n";
        for (int t = 0;
             t < 5 && t < static_cast<int>((*iter).second.size());
             ++t)
          {
          cout << "\tTerm " << (*iter).second[t].second << ": weight "
               << (*iter).second[t].first << "\n";
          }
        }
      } // done printing stuff on this processor
    } // done iterating over all processors
}

////////////////////////////////////////////////////////////////
// main

int main(int argc, char* argv[])
{
  int error_count = 0;

  vtkSmartPointer<vtkMPIController> controller = vtkSmartPointer<vtkMPIController>::New();
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  int my_pid = controller->GetLocalProcessId();

#if defined(WAIT_FOR_ATTACH)
  if (controller->GetLocalProcessId() == 0)
    {
    printf("PID %d ready for attach\n", getpid());
    fflush(stdout);
    while (i == 0)
      {
      sleep(5);
      }
    }
#endif

  // Setup document input ...
  VTK_CREATE(vtkPDocumentReader, document_reader);
  for(int i = 0; i < DOCUMENT_COUNT; ++i)
    {
    vtksys_ios::ostringstream filename;
    filename << titanTextAnalysis_SOURCE_DIR << APOLLO_11_PATH << FILENAMES[i];
    document_reader->AddFile(filename.str().c_str());
    }

  // Setup document partitioning ...
//  vtkSmartPointer<vtkPDocumentReaderStrategy> reader_strategy;
//  reader_strategy.TakeReference(vtkRoundRobinPDocumentReaderStrategy::New());
//  document_reader->SetStrategy(reader_strategy);

  // Setup mime-type assignment ...
  VTK_CREATE(vtkAssignMimeType, assign_mime_types);
  assign_mime_types->SetInputConnection(0, document_reader->GetOutputPort());
  assign_mime_types->SetDefaultMimeType("text/plain");

  // Setup text extraction ...
  VTK_CREATE(vtkTextExtraction, text_extraction);
  text_extraction->SetInputConnection(0, assign_mime_types->GetOutputPort());

  // Create a "handle" for our document dictionary ...
  VTK_CREATE(vtkPassThrough, document_dictionary);
  document_dictionary->SetInputConnection(0, text_extraction->GetOutputPort());

  // Setup tokenization ...
  VTK_CREATE(vtkTokenization, tokenization);
  tokenization->SetInputConnection(0, document_dictionary->GetOutputPort());

  // Setup feature dictionary creation ...
  vtkSmartPointer<vtkTableAlgorithm> feature_dictionary;
  feature_dictionary.TakeReference(vtkPTermDictionaryMapReduce::New());
  feature_dictionary->SetInputConnection(0, tokenization->GetOutputPort());

  // Setup frequency matrix creation ...
  VTK_CREATE(vtkFrequencyMatrix, frequency_matrix);
  frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PLUS_LOCAL);
  frequency_matrix->SetInputConnection(0, tokenization->GetOutputPort());
  frequency_matrix->SetInputConnection(1, feature_dictionary->GetOutputPort());
  frequency_matrix->SetInputConnection(2, document_dictionary->GetOutputPort());

  // Setup the LDA ...
  VTK_CREATE(vtkPLatentDirichletAllocation, lda);
  lda->SetController(controller);
  lda->SetInputConnection(0, frequency_matrix->GetOutputPort());
  lda->SetBurnInIterations(200);
  lda->SetSamplingIterations(1);
  lda->SetNumberOfTopics(TOPIC_COUNT);

  lda->Update();

  vtkDenseArray<double> *theta = vtkDenseArray<double>::SafeDownCast(lda->GetOutput(0)->GetArray(0));
  vtkDenseArray<double> *phi = vtkDenseArray<double>::SafeDownCast(lda->GetOutput(1)->GetArray(0));

  assert(theta);
  assert(phi);

  vtksys_stl::vector<double> topic_weights(TOPIC_COUNT, 0);
  vtkArrayExtents extents = theta->GetExtents();
  for (int doc_id = extents[0].GetBegin(); doc_id < extents[0].GetEnd(); ++doc_id)
    {
    for (int topic = 0; topic < extents[1].GetSize(); ++topic)
      {
      topic_weights[topic] += theta->GetValue(doc_id, topic);
      }
    }

  cerr << "(P" << my_pid << ") Topic weights across local corpus:\n";
  for (int t = 0; t < TOPIC_COUNT; ++t)
    {
    cerr << "\tTopic " << t << ": " << topic_weights[t] << "\n";
    }
  cerr << "\n";

  vtkTable *dictionaryOutput = vtkTable::SafeDownCast(tokenization->GetOutput());
  vtkUnicodeStringArray *terms = vtkUnicodeStringArray::SafeDownCast(dictionaryOutput->GetColumnByName("text"));

  typedef std::pair<double, vtkUnicodeString> WeightedTerm;
  typedef vtksys_stl::vector<WeightedTerm> WeightedTermVector;

  if (my_pid == 0)
    {
    // Print out the top few words for each topic
    for (int topic = 0; topic < TOPIC_COUNT; ++topic)
      {
      WeightedTermVector weightedTerms;
      for (int termId = 0; termId < phi->GetExtents()[1].GetSize(); ++termId)
        {
        double weight = phi->GetValue(topic, termId);
        weightedTerms.push_back(WeightedTerm(weight, terms->GetValue(termId)));
        }
      sort(weightedTerms.begin(), weightedTerms.end());

      WeightedTermVector::size_type maxIdx = weightedTerms.size() - 1;
      maxIdx = std::max(static_cast<WeightedTermVector::size_type>(5), maxIdx);
      cerr << "Top terms for topic " << topic << ":\n";
      for (int foo = 0; foo < 20; ++foo)
        {
        cerr << "\t" << weightedTerms[maxIdx-foo].second.utf8_str() << " ("
             << weightedTerms[maxIdx-foo].first << ")\n";
        }
      cerr << "\n\n";
      }
    }

  // Print out the ordering of topics for each document
  typedef std::pair<double, vtkIdType> WeightedTopic;
  typedef vtksys_stl::vector<WeightedTopic> WeightedTopicVector;

  extents = theta->GetExtents();
  if (my_pid == 0 || true)
    {
    for (vtkIdType docId = extents[0].GetBegin();
         docId < extents[0].GetEnd();
         ++docId)
      {
      WeightedTopicVector topics;
      for (vtkIdType topic = 0; topic < TOPIC_COUNT; ++topic)
        {
        double weight = theta->GetValue(docId, topic);
        topics.push_back(WeightedTopic(weight, topic));
        }
      sort(topics.begin(), topics.end());
      WeightedTopicVector::size_type maxIdx = topics.size() - 1;
      cerr << "(P" << my_pid
           << ") Topics for document " << docId << " in descending order:\n";
      for (int i = 0; i < TOPIC_COUNT; ++i)
        {
        cerr << "(P" << my_pid << ")\tTopic " << topics[maxIdx - i].second << " ("
             << topics[maxIdx - i].first << ")\n";
        }
      cerr << "\n";
      }
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
