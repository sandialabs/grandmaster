/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkTextExtraction.h>
#include <vtkFoldCase.h>
#include <vtkIdTypeArray.h>
#include <vtkMPIController.h>
#include <vtkPTermDictionaryNToN.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTokenizer.h>
#include <vtkUnicodeStringArray.h>

#include <vtksys/ios/iostream>
#include <vtksys/ios/sstream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

std::ostream& operator<<(std::ostream& stream, const vtkUnicodeString& value)
{
  stream << value.utf8_str();
  return stream;
}

void test_outputs(vtkMPIController* controller, vtkTableAlgorithm* term_dictionary)
{
  term_dictionary->Update();
  if(controller->GetLocalProcessId() == 0)
    term_dictionary->GetOutput(0)->Dump(20);

  vtkUnicodeStringArray* const dictionary = vtkUnicodeStringArray::SafeDownCast(term_dictionary->GetOutput(0)->GetColumnByName("text"));
  test_expression(dictionary);

  test_expression(dictionary->GetNumberOfTuples() == 16);
  test_expression(dictionary->GetValue(0) == vtkUnicodeString::from_utf8("."));
  test_expression(dictionary->GetValue(1) == vtkUnicodeString::from_utf8("brown"));
  test_expression(dictionary->GetValue(15) == vtkUnicodeString::from_utf8("the"));
}

int main(int argc, char* argv[])
{
  int result = 0;

  vtkSmartPointer<vtkMPIController> controller = vtkSmartPointer<vtkMPIController>::New();
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  try
    {
    if(controller->GetNumberOfProcesses() != 2)
      throw std::runtime_error("test requires exactly two processes");

    vtkIdTypeArray* const document_array = vtkIdTypeArray::New();
    document_array->SetName("document");

    vtkStringArray* const uri_array = vtkStringArray::New();
    uri_array->SetName("uri");

    vtkStringArray* const mime_type_array = vtkStringArray::New();
    mime_type_array->SetName("mime_type");

    vtkStringArray* const content_array = vtkStringArray::New();
    content_array->SetName("content");

    switch(controller->GetLocalProcessId())
      {
      case 0:
        document_array->InsertNextValue(0);
        uri_array->InsertNextValue("data:text/plain");
        mime_type_array->InsertNextValue("text/plain");
        content_array->InsertNextValue("The quick brown fox jumped over the lazy dogs.");
        break;

      case 1:
        document_array->InsertNextValue(1);
        uri_array->InsertNextValue("data:text/plain");
        mime_type_array->InsertNextValue("text/plain");
        content_array->InsertNextValue("The rain in Spain falls mainly on the plain.");
        break;
      }

    vtkSmartPointer<vtkTable> documents = vtkSmartPointer<vtkTable>::New();
    documents->AddColumn(document_array);
    documents->AddColumn(uri_array);
    documents->AddColumn(mime_type_array);
    documents->AddColumn(content_array);

    document_array->Delete();
    uri_array->Delete();
    mime_type_array->Delete();
    content_array->Delete();

    vtkSmartPointer<vtkTextExtraction> text_extraction = vtkSmartPointer<vtkTextExtraction>::New();
    text_extraction->SetInputData(0, documents);

    vtkSmartPointer<vtkTokenizer> tokenizer = vtkSmartPointer<vtkTokenizer>::New();
    tokenizer->SetInputConnection(0, text_extraction->GetOutputPort());
    tokenizer->AddDroppedDelimiters(vtkTokenizer::Whitespace());
    tokenizer->AddKeptDelimiters(vtkTokenizer::Punctuation());

    vtkSmartPointer<vtkFoldCase> fold_case = vtkSmartPointer<vtkFoldCase>::New();
    fold_case->SetInputConnection(0, tokenizer->GetOutputPort());

    vtkSmartPointer<vtkPTermDictionaryNToN> term_dictionary = vtkSmartPointer<vtkPTermDictionaryNToN>::New();
    term_dictionary->SetInputConnection(0, fold_case->GetOutputPort());

    term_dictionary->SetGather(true);
    test_outputs(controller, term_dictionary);

    term_dictionary->SetGather(false);
    test_outputs(controller, term_dictionary);
    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    result = 1;
    }

  controller->Finalize();
  return result;
}
