/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkLDADocumentPipeline vtkLDADocumentPipeline.h <MPITextAnalysis/vtkLDADocumentPipeline.h>
/// \brief Convenience class encapsulating the common document preparation filters for LDA
///
///
///   This filter contains the document preparation pipeline for LDA.
///   It expects as its input the output from vtkDocumentReader,
///   vtkDocumentPerLineReader or vtkPDocumentReader.  The outputs are
///   suitable for use as inputs to vtkLatentDirichletAllocation and
///   subclasses.


#ifndef __vtkLDADocumentPipeline_h
#define __vtkLDADocumentPipeline_h

#include <titanMPITextAnalysis.h>
#include "vtkArrayDataAlgorithm.h"
#include "vtkToolkits.h" // needed for VTK_USE_MPI
#include "vtkSmartPointer.h" // for smart pointer ivars

class vtkArrayReader;
class vtkAssignMimeType;
class vtkCallbackCommand;
class vtkFeatureDictionary;
class vtkFoldCase;
class vtkFrequencyMatrix;
class vtkInformation;
class vtkInformationVector;
class vtkMimeTypes;
class vtkMultiProcessController;
class vtkPTermDictionaryMapReduce;
class vtkTable;
class vtkTableReader;
class vtkTextExtraction;
class vtkTokenizer;
class vtkTokenValueFilter;


class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkLDADocumentPipeline : public vtkArrayDataAlgorithm
{
public:
  vtkTypeMacro(vtkLDADocumentPipeline, vtkArrayDataAlgorithm);
  static vtkLDADocumentPipeline *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  ///@{
  /// Set filenames to load all the different tables that get computed.
  /// THESE HAVE NO DEFAULTS.  You must set them if you want them to be
  /// used.
  vtkSetStringMacro(TermDictionaryInputFilename);
  vtkSetStringMacro(TermDocumentMatrixInputFilename);
  vtkGetStringMacro(TermDictionaryInputFilename);
  vtkGetStringMacro(TermDocumentMatrixInputFilename);
  ///@}

  ///@{
  /// Set filenames to save all the different tables that get computed.
  /// THESE HAVE NO DEFAULTS.  You must set them if you want them to be
  /// used.
  vtkSetStringMacro(TermDictionaryOutputFilename);
  vtkSetStringMacro(TermDocumentMatrixOutputFilename);
  vtkGetStringMacro(TermDictionaryOutputFilename);
  vtkGetStringMacro(TermDocumentMatrixOutputFilename);
  ///@}

  vtkMimeTypes *GetMimeTypeLibrary();

  /// Call this method to make a copy of the term dictionary for
  /// external use.  The results will be written into the vtkTable you
  /// supply.
  void CopyTermDictionary(vtkTable *output);

  /// This method will give you the output port from the current
  /// dictionary source.  If TermDictionaryInputFilename is set, this
  /// will be the output port from the dictionary reader; if it is
  /// /not/ set then this will be the output port from the dictionary
  /// builder.  If you call this method and then change the value of
  /// TermDictionaryInputFilename from NULL to something or something
  /// to NULL then you will get undefined behavior.
  vtkAlgorithmOutput *GetDictionaryOutputPort();

  /// Call this function if you want to add custom delimiters to the
  /// tokenizer.
  vtkTokenizer *GetTokenizer();

  /// Call this function if you want to add your own stopwords.
  vtkTokenValueFilter *GetStopWordFilter();

#if defined(VTK_USE_MPI)
  /// If you are using this class in parallel you need to call this
  /// method first.
  void SetController(vtkMultiProcessController *controller);
#endif

  ///@{
  /// Internal callbacks.  Pay no attention to these methods.
  void DictionaryBuildFinishedCallback();
  void TermDocumentMatrixBuildFinishedCallback();
  ///@}

//BTX
protected: // methods
  vtkLDADocumentPipeline();
  ~vtkLDADocumentPipeline();

  int RequestData(vtkInformation *, vtkInformationVector **, vtkInformationVector *);
  int FillInputPortInformation(int port, vtkInformation *info);

  void AssembleInitialPipeline();
  void ConnectPipelineForDictionaryBuild();
  void ForceDictionaryRebuild();

protected: // ivars
#if defined(VTK_USE_MPI)
  vtkMultiProcessController *Controller;
#endif
  char *TermDictionaryInputFilename;
  char *TermDictionaryOutputFilename;

  char *TermDocumentMatrixInputFilename;
  char *TermDocumentMatrixOutputFilename;

  // here are the components of the encapsulated pipeline -- the user
  // won't need to access all of them so we'll expose only the ones
  // that have useful parameters
  vtkSmartPointer<vtkAssignMimeType>            AssignMimeTypes;
  vtkSmartPointer<vtkMimeTypes>                 MimeTypeLibrary;
  vtkSmartPointer<vtkTextExtraction>            TextExtractor;
  vtkSmartPointer<vtkFoldCase>                  FoldCase;
  vtkSmartPointer<vtkTokenizer>                 Tokenizer;
  vtkSmartPointer<vtkTokenValueFilter>          StopWordFilter;
  vtkSmartPointer<vtkFeatureDictionary>         SerialDictionaryBuilder;
  vtkSmartPointer<vtkFrequencyMatrix>           TermDocumentMatrixBuilder;
#if defined(VTK_USE_MPI)
  vtkSmartPointer<vtkPTermDictionaryMapReduce>  ParallelDictionaryBuilder;
#endif

  // These readers will be used in place of the builders when
  // appropriate filenames are available
  vtkSmartPointer<vtkArrayReader>               TermDocumentMatrixReader;
  vtkSmartPointer<vtkTableReader>               DictionaryReader;

  // These two observers listen for the dictionary and term/doc matrix
  // to be finished and, if appropriate, write them to disk
  vtkSmartPointer<vtkCallbackCommand>           SaveDictionaryCommand;
  vtkSmartPointer<vtkCallbackCommand>           SaveTermDocumentMatrixCommand;

private:
  vtkLDADocumentPipeline(const vtkLDADocumentPipeline &);
  void operator=(const vtkLDADocumentPipeline &);
//ETX
};

#endif
