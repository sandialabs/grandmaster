
import os
import sys
import nltk
import email

def processEmail(contents):
    emailMessage = email.message_from_string(contents)

    # Walk the email sections/attachments
    for part in emailMessage.walk():

        # The walk does the work for us, if the part is multipart just continue on to the children
        if (part.is_multipart()):
            continue

        # Get content type and payload
        content_type =  part.get_content_type()
        payload =  part.get_payload(decode=True)

        # Store as an attachment to my document
        payloads = []
        if (len(payload)):
            payloads.append({"content_type":content_type,"content":payload})

    # Okay done with payload processing
    return payloads

def processFiles(root):

    # Grab NLTK stop words..
    stop_words = nltk.corpus.stopwords.words('english')

    for root, dirnames, filenames in os.walk(root):
        for filename in filenames:
            path = os.path.join(root, filename)
            print "processing: ", path
            file = open(path)
            contents = file.read()
            file.close()

            # Okay now process any text/plain contents of the email payloads
            if len(contents) > 0:
                email_payloads = processEmail(contents)
                for payload in email_payloads:
                    if (payload["content_type"] == "text/plain") :

                        # Generate text stats
                        words = nltk.tokenize.word_tokenize(payload["content"])

                        # Put 'good' words into the Frequency Dictionary
                        fdist = nltk.FreqDist()
                        for w in words:
                            if (len(w) > 5 and w.lower() not in stop_words):
                                fdist.inc(w)

                        # Print out a list with counts
                        unique_words = fdist.keys()

                        if (len(unique_words)):
                            w = unique_words[0];
                            word_counts = w + ":" + str(fdist[w]) + " "
                            for w in unique_words[1:5]:
                                if (fdist[w] > 1):
                                    word_counts +=  w + ":" + str(fdist[w]) + "  "
                            print word_counts


                        # Collocation stuff
                        finder = nltk.BigramCollocationFinder.from_words(words, 2)
                        finder.apply_freq_filter(2)
                        finder.apply_word_filter(lambda w: len(w) < 3 or w.lower() in stop_words)
                        bigram_measures = nltk.BigramAssocMeasures()
                        #collocations = finder.nbest(bigram_measures.likelihood_ratio, 5)
                        collocations = finder.nbest(bigram_measures.raw_freq, 5)
                        if (len(collocations)):
                            print collocations



if __name__ == "__main__":
    """ Main entry point of this python script """

    # The script should have a directory argument
    if len(sys.argv) < 2:
        print "Usage: " + sys.argv[0] + "  /path/to/files"
        sys.exit(1)

    # Recursively process the file directory
    root_dir = sys.argv[1]
    processFiles(root_dir)
