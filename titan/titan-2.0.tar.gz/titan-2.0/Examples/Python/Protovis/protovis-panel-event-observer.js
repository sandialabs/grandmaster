
// This is an attempt to implement the Observer Design pattern on Protovis panels
// to allow the panels to exchange user interaction events.  Each Protovis panel
// is both an Observable subject and a potential observer of other Protovis panels.
// When an event is received on an Observable subject Protovis panel, that panel
// will call all registered observer panels notify() methods with the event name, a
// handle to the mark that got the event, and the name of the protovis panel.  Each
// observer panel implements its custom behavior for the event type in its own implementation
// of notify().


// Add a name to each Protovis panel, so it can be referenced by other panels as an
// observable subject.
pv.Panel.prototype.panelName = "";

// List of registered observers on the panel.  When an event is recieved on this panel,
// notify() will be called on each observer panel.
pv.Panel.prototype.__panelObservers = [];

// Bind a jquery callback on window to register each Protovis panel in the list of observable
// subject.
$(window).bind("registerProtovisPanelAsObservableSubject", function (event, panel) {

  if(window.protovisPanelObservableSubjects === undefined) {
    window.protovisPanelObservableSubjects = {};
  }

  window.protovisPanelObservableSubjects[panel.panelName] = panel;

});

// Callback to retrieve an observable subject panel.
$(window).bind("getProtovisPanelObservableSubject", function (event, name) {

  if(window.protovisPanelObservableSubjects[name] === undefined) {
    return(null);
  }
  else {
    return(window.protovisPanelObservableSubjects[name]);
  }

});

// Trigger a jquery event to register this panel as an observable subject with
// name.
pv.Panel.prototype.registerSelfAsObservableSubject = function(Name) {

  this.panelName = Name;
  $(window).trigger("registerProtovisPanelAsObservableSubject", [this]);

}

// Retrieve an observable subject panel with panelName.
pv.Panel.prototype.getPanelObservableSubject = function(panelName) {

  panel = $(window).triggerHandler("getProtovisPanelObservableSubject", [panelName]);

  return panel;

}

// Add an observer to this panel. Observer will have its notify method called
// when this panel recieves an event.
pv.Panel.prototype.registerObserver = function(observer) {
    this.__panelObservers.push(observer);
}

// Unregister an observer.
pv.Panel.prototype.unregisterObserver = function(observer) {
    var i;
    for(k in this.__panelObservers) {
        if(this.__panelObservers[k] == observer) {
            i = k;
        }
    }

    this.__panelObservers.splice(i,1);
}

// Notify all observers with the type of event (click, mouseover, etc) and the Protovis
// mark (Dot, Rule, Bar, etc) that received the event.  Also, pass the name of this
// panel, so observers can select different behaviors for each panel the are observing.
pv.Panel.prototype.notifyObservers = function(event, mark) {

    for(k in this.__panelObservers) {
        this.__panelObservers[k].notify(event, mark, this.panelName);
    }

}

// Default notify implementation does nothing.  Set a custom notify event
// to take an interesting action in your observer panel in response to an
// event received on this panel.
pv.Panel.prototype.notify = function(event, mark, panelName) {


}
