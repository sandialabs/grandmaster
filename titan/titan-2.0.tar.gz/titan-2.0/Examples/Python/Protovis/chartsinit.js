
// The purpose of this JavaScript file is to handle the script
// tag "javascript+protovis+charts" when the method charts.init() is
// called. The script inside the "javascript+protovis+charts" tag
// is loaded and evaluated when charts.init() is called.  The script
// can be specified with src or listed inside of the tag.
//
// The Protovis "javascript+protovis" tag only handles scripts
// listed within the tag itself (ie, does not support src) and
// also does not evaluate the script until window.onload() is
// called.  This is an attempt to get around these two limitations.

var charts = {};

charts.ajaxRequest = HTTP.CreateRequest();

charts.GetJSONData = function (url) {
    charts.ajaxRequest.open("GET", url, false);
    charts.ajaxRequest.setRequestHeader("Accept", "application/json");
    charts.ajaxRequest.send(null);
    return JSON.parse(charts.ajaxRequest.responseText);
};

charts.GetJavaScriptData = function(url)
{
    charts.ajaxRequest.open("GET", url, false);
    charts.ajaxRequest.setRequestHeader("Accept", "text/javascript");
    charts.ajaxRequest.send(null);
    return charts.ajaxRequest.responseText;
}

/**
 * @private Parses a Protovis specification, which may use JavaScript 1.8
 * function expresses, replacing those function expressions with proper
 * functions such that the code can be run by a JavaScript 1.6 interpreter. This
 * hack only supports function expressions (using clumsy regular expressions, no
 * less), and not other JavaScript 1.8 features such as let expressions.
 *
 * @param {string} s a Protovis specification (i.e., a string of JavaScript 1.8
 * source code).
 * @returns {string} a conformant JavaScript 1.6 source code.
 */
  charts.parse = function(js) { // hacky regex support
    var re = new RegExp("function\\s*(\\b\\w+)?\\s*\\([^)]*\\)\\s*", "mg"), m, d, i = 0, s = "";
    while (m = re.exec(js)) {
      var j = m.index + m[0].length;
      if (js.charAt(j) != '{') {
        s += js.substring(i, j) + "{return ";
        i = j;
        for (var p = 0; p >= 0 && j < js.length; j++) {
          var c = js.charAt(j);
          switch (c) {
            case '"': case '\'': {
              while (++j < js.length && (d = js.charAt(j)) != c) {
                if (d == '\\') j++;
              }
              break;
            }
            case '[': case '(': p++; break;
            case ']': case ')': p--; break;
            case ';':
            case ',': if (p == 0) p--; break;
          }
        }
        s += pv.parse(js.substring(i, --j)) + ";}";
        i = j;
      }
      re.lastIndex = j;
    }
    s += js.substring(i);
    return s;
  };

  /**
 * @private Reports the specified error to the JavaScript console. Mozilla only
 * allows logging to the console for privileged code; if the console is
 * unavailable, the alert dialog box is used instead.
 *
 * @param e the exception that triggered the error.
 */
charts.error = function(e) {
  (typeof console == "undefined") ? alert(e) : console.error(e);
};

charts.init = function() {
  charts.$ = {i:0, x:document.getElementsByTagName("script")};
  for (; charts.$.i < charts.$.x.length; charts.$.i++) {
      charts.$.s = charts.$.x[charts.$.i];
      if (charts.$.s.type == "text/javascript+protovis+charts") {
      try {
          // Added code to check for src tag inside of script tag.
          // If found, load the javascript in the src url.
          if(charts.$.s.src) {
            window.eval(charts.parse(charts.GetJavaScriptData(charts.$.s.src)))
          } else {
            window.eval(charts.parse(charts.$.s.text));
          }
      } catch (e) {
          charts.error(e);
      }
      }
  }
  delete charts.$;
};