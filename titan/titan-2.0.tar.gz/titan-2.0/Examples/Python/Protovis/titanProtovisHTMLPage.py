
import os
import urllib

class titanProtovisHTMLPage:
  """The titanProtvisView class produces a Protovis HTML Page.
     See addProtovisJavaScript() and addJSONData() to add Javascript
     Protovis code and JSON data to the output HTML page.  The HTML
     page is written out with the method writeHTMLFile()."""
  def __init__(self):
    self.__Location = os.path.dirname(os.path.realpath(__file__))
    self.__urlLocation = urllib.pathname2url(self.__Location)
    self.__HTMLBodyAttributes = {}
    self.__JSONStrings = {}
    self.__ExternalScripts = []
    self.__ProtovisJavascript = ""
    self.__Width = 500
    self.__Height = 500
    self.__ExternalCSS = []
    self.__CSS = """
          <style type="text/css">
            #fig {
              width: 500px;
              height: 500px;
            }
          </style>
        """
    self.__DIVS = """
         <div id="fig">
         Protovis Figure
         </div>
        """
    self.__Title = "Titan"
    self.__Header = "Titan Protovis"
    self.__OpenBrowser = False
    self.__DebugProtovis = False

  def addHTMLBodyAttributes(self, attrName, attrString):
    """Add attributes to the <body> tag in the HTML data."""
    self.__HTMLBodyAttributes[attrName] = attrString

  def clearHTMLBodyAttribute():
    """Clear the attributes associated with the <body> tag in the HTML data."""
    self.__HTMLBodyAttributes = {}

  def addJSONData(self, varname, JSONString):
    """Variable varname and the JSON data contained in JSONString will
    be available for use in the Protovis code supplied in setProtovisJavaScript()."""
    self.__JSONStrings[varname] = JSONString

  def clearJSONDData(self):
    """Clears all JSON data and variable names."""
    self.__JSONStrings = {}

  def addExternalScript(self, location):
    self.__ExternalScripts.append(location)

  def clearExternalScripts(self):
    self__ExternalScripts = []

  def addExternalCSS(self, location):
    self.__ExternalCSS.append(location)

  def clearExternalCSS(self):
    self__ExternalCSS = []

  def addProtovisJavaScript(self, ProtovisJavaScriptString):
    """This is the JavaScript+Protovis code that will be run inside of the result
    HTML page.  You can reference the JSON data variables specified with addJSONData()
    in the JavaScript+Protovis code.  Appends to any existing JavaScript+Protovis code."""
    self.__ProtovisJavascript += ProtovisJavaScriptString

  def clearProtovisJavaScript(self):
    """Clears all JavaScript+Protovis code."""
    self.__ProtovisJavascript = ""

  def setHeader(self, header):
    """Sets the webpage header on the resulting HTML page."""
    self.__Header = header

  def setDIVS(self, divs):
    """Sets the webpage dividers on the resulting HTML page."""
    self.__DIVS = divs

  def setCSS(self, css):
    """Sets the Cascade style sheet on the resulting HTML page."""
    self.__CSS = css

  def setWidth(self, width):
    """Sets the width of the Protovis view area on the result HTML page."""
    self.__Width = width

  def setHeight(self, height):
    """Sets the height of the Protovis view area on the result HTML page."""
    self.__Height = height

  def setTitle(self, title):
    """Sets the title of the result HTML page."""
    self.__Title = title

  def debugProtovisOn(self):
    """Uses Protovis debug library. Default is off."""
    self.__DebugProtovis = True

  def debugProtovisOff(self):
    """Uses Protovis release library. Default is on."""
    self.__DebugProtovis = False

  def openWebBrowserOn(self):
    """Opens the HTML file written by writeHTMLFile() with the default web browswer."""
    self.__OpenBrowser = True;

  def openWebBrowserOff(self):
    """Turns off web browswer opening of created HTML file. This is the default."""
    self.__OpenBrowser = False;

  def writeHTMLFile(self, filename="TitanProtovisImage.html"):
    """Writes an HTML file with default name TitanProtovisImage.html."""
    f = open(filename,'w')
    f.write('<html>\n')
    f.write('  <head>\n')
    f.write('   <title>' + self.__Title + '</title>\n')
    for css in self.__ExternalCSS:
      f.write('   <link type="text/css" rel="stylesheet" href="'+css+'" />\n');
    f.write('   <script type="text/javascript" src="'+self.__urlLocation+'/http.js"></script>\n')
    f.write('   <script type="text/javascript" src="'+self.__urlLocation+'/json2.js"></script>\n')
    for script in self.__ExternalScripts:
      f.write('   <script type="text/javascript" src="'+script+'"></script>\n')

    if self.__DebugProtovis:
      f.write('   <script type="text/javascript" src="'+self.__urlLocation+'/../../../TPL/JavaScript/protovis-d3.2.js"></script>\n')
    else:
      f.write('   <script type="text/javascript" src="'+self.__urlLocation+'/../../../TPL/JavaScript/protovis-r3.2.js"></script>\n')

    f.write('   <script type="text/javascript" src="'+self.__urlLocation+'/chartsinit.js"></script>\n')
    f.write('   <script type="text/javascript" src="'+self.__urlLocation+'/protovis-panel-event-observer.js"></script>\n')
    f.write('   <script type="text/javascript+protovis+charts">\n')
    fn = open(self.__Location+'/charts.js', 'r')
    f.write(fn.read())
    fn.close()
    f.write('   </script>\n')
    f.write('   <script type="text/javascript">charts.init();</script>\n')
    f.write(' <div id=header>')
    f.write(str(self.__Header))
    f.write(' </div>')
    f.write(str(self.__CSS))
    f.write('  </head>\n')
    f.write('<body %s>\n'%(" ".join(map(lambda k: "%s=\"%s\""%(k, self.__HTMLBodyAttributes[k]), \
                                         self.__HTMLBodyAttributes.keys()))))
    f.write(str(self.__DIVS))
    f.write('  <script type="text/javascript+protovis">\n\n')
    for k, v in self.__JSONStrings.items():
      f.write('    var ' + k +'__JSONString' + ' = ')
      sl = v.split("\n")
      f.write("'")
      for e in sl:
        f.write(e + "\\" + "\n")
      f.write("'")
      f.write('\n')
      f.write('    var ' + k + ' = JSON.parse(' + k + '__JSONString' + ')\n')
    f.write(self.__ProtovisJavascript)
    f.write('  </script>\n')
    f.write('</body>\n')
    f.write('</html>\n')
    f.close()
    if self.__OpenBrowser:
      import webbrowser
      import os
      url = os.path.join(os.path.abspath('.'), filename)
      webbrowser.open_new(url)


if __name__ == "__main__":

  tphp = titanProtovisHTMLPage()
  tphp.addJSONData('d', '[1, 1.2, 1.7, 1.5, 0.7]')

  demo_protovisScript = """
     var vis = new pv.Panel()
       .width(150)
       .height(150);

     vis.add(pv.Rule)
       .data(pv.range(0, 2, .5))
       .bottom(function(d) d * 80 + .5)
      .add(pv.Label);

     vis.add(pv.Bar)
       .data(d)
       .width(20)
       .height(function(d) d * 80)
       .bottom(0)
       .left(function() this.index * 25 + 25)
     .anchor("bottom").add(pv.Label);

     vis.render();
     """

  tphp.addProtovisJavaScript(demo_protovisScript)

  tphp.debugProtovisOn()
  tphp.openWebBrowserOn()
  tphp.writeHTMLFile()
