#
#Titan Pipeline to CouchDB to Web Page
#
import webbrowser
import couchdb
import os, sys, datetime
import json
import mimetypes
from vtk import *
import titan
from titan.HDF5 import *
from titan.Common import *
from titan.ClusteringFilters import *
from titan.Web import *
from titan.DataAnalysis import *
import random

def add_js_attachments(full_path, relative_path, database, document):
    for child in os.listdir(full_path):
        child_path = os.path.join(full_path, child)
        if os.path.isdir(child_path):
            add_attachments(child_path, os.path.join(relative_path, child), database, document)
        else:
            content = open(child_path, "r")
            mime_type = mimetypes.guess_type(child_path)
            database.put_attachment(document, content.read(), filename = os.path.join(relative_path, child).replace("\\", "/"), content_type = mime_type[0])

def printStats(statsFilter):
    sStats = statsFilter.GetOutputDataObject( 1 )
    sPrimary = sStats.GetBlock( 0 )
    sDerived = sStats.GetBlock( 1 )
    sPrimary.Dump( 15 )
    sDerived.Dump( 15 )

# Extra cheese with side of cheese
# This programmable filter output a random subset of rows
specificProcessing = vtkProgrammableFilter()
subset = True;

def subsetRows():
    global subset

    input = specificProcessing.GetInput()
    output = specificProcessing.GetOutput()

    # Copy just the columns names/types
    output.GetRowData().CopyStructure(input.GetRowData())

    # Loop through all the input data and grab some random rows
    for i in range(0, input.GetNumberOfRows()):
        if (not subset or (random.random() > .5)):
            output.InsertNextRow(input.GetRow(i))


specificProcessing.SetExecuteMethod(subsetRows)

# This programmable filter looks at proximity distance to
# compute a 'confidence' metric (using the term loosely)(
confidenceCalc = vtkProgrammableFilter()
def confidence():
    global subset

    input = confidenceCalc.GetInput()
    output = confidenceCalc.GetOutput()

    # Shallow copy input to output
    output.ShallowCopy(input)

    # Create new output array
    confArray = vtkFloatArray()
    confArray.SetName("confidence")
    confArray.SetNumberOfTuples(output.GetNumberOfRows())

    # Get a handle to the proximity arrays
    prox0 = output.GetColumnByName("prox_0")
    prox1 = output.GetColumnByName("prox_1")
    prox2 = output.GetColumnByName("prox_2")

    # Loop through all the vertices setting the degree for the new attribute array
    numRows = output.GetNumberOfRows()
    for i in range(numRows):
        p0 = prox0.GetValue(i)
        p1 = prox1.GetValue(i)
        p2 = prox2.GetValue(i)
        conf = 1.0 - p0/(p0+p1+p2)
        confArray.SetValue(i, conf)

    output.GetRowData().AddArray(confArray)

confidenceCalc.SetExecuteMethod(confidence)

def go():
    global subset

    # Construct the Javascript dir in Titan
    javascript_dir = os.path.join(titan.TITAN_SOURCE_DIR, "TPL/JavaScript")

    # Open up IRIS dataset
    reader = vtkDelimitedTextReader()
    reader.SetHaveHeaders(True)
    reader.SetDetectNumericColumns(True)
    reader.SetFileName("iris.csv")
    reader.Update()

    # Run some stats on the iris data
    # Calculate 5-point cpu statistics (grouped on node_name)
    stats = vtkOrderStatisticsByGroup()
    stats.AddInputConnection(reader.GetOutputPort())
    stats.SetArrayName("Sepal_Length")
    stats.SetGroupArrayName("Class")

    stats2 = vtkOrderStatisticsByGroup()
    stats2.AddInputConnection(reader.GetOutputPort())
    stats2.SetArrayName("Sepal_Width")
    stats2.SetGroupArrayName("Class")

    mergeStats = vtkMergeTables()
    mergeStats.SetInputConnection(0,stats.GetOutputPort())
    mergeStats.SetInputConnection(1,stats2.GetOutputPort())

    # Convert the 'Class' string to a category array
    category = vtkStringToCategory()
    category.SetInputConnection(0, reader.GetOutputPort())
    category.SetInputArrayToProcess(0,0,0,vtkDataObject.FIELD_ASSOCIATION_ROWS, "Class")
    category.SetCategoryArrayName("Ground_Truth")


    # Run K-mean clustering on the iris data
    cluster = vtkClusteringKMeans()
    cluster.SetInputConnection(category.GetOutputPort())
    cluster.AddFeatureColumn("Sepal_Length")
    cluster.AddFeatureColumn("Sepal_Width")
    cluster.AddFeatureColumn("Petal_Length")
    cluster.AddFeatureColumn("Petal_Width")
    cluster.SetK(3) # Number of clusters
    cluster.SetMaxClusterMemberships(3)
    cluster.Update()
    cluster.GetOutput().Dump()

    confidenceCalc.SetInputConnection(cluster.GetOutputPort())
    confidenceCalc.Update()
    confidenceCalc.GetOutput().Dump()

    # Doing a hack on the ground truth and subsetting for training
    specificProcessing.SetInputConnection(confidenceCalc.GetOutputPort())

    # Run perceptron on a subset of the data
    tron = vtkPerceptron()
    tron.SetInputConnection(specificProcessing.GetOutputPort())
    tron.SetGroundTruthArrayName("Ground_Truth")
    tron.AddFeatureColumn("Sepal_Length")
    tron.AddFeatureColumn("Sepal_Width")
    tron.AddFeatureColumn("Petal_Length")
    tron.AddFeatureColumn("Petal_Width")
    tron.SetMode(vtkPerceptron.TRAIN)
    tron.SetDebugPrintLevel(0)
    tron.Update()


    # Now run in 'Classify' mode with all the data
    subset = False;
    specificProcessing.Modified()
    specificProcessing.Update()
    tron.SetMode(vtkPerceptron.CLASSIFY)
    tron.SetDebugPrintLevel(0)


    #
    # Now do all the awesome Web/CouchDB stuff
    #

    # Some web page stuff
    htmlFilename = "SuperKewl.html"
    now = datetime.datetime.now()
    datestring = now.strftime("%Y-%m-%d %H:%M")

    # CouchDB handles  (for remote use couchdb.Server('http://foo.bar:5984/'))
    couch = couchdb.Server('http://localhost:5984')

    # Create the database
    try:
        db = couch["test"]
    except:
        db = couch.create("test")
    # Check if the design doc is already there
    if "_design/test" in db:
        db.delete(db["_design/test"])

    # Create couch design document
    design_doc = {}
    design_doc["_id"] = "_design/test"
    design_doc["created"] = datestring
    design_doc["type"] = "Design Document"
    db.save(design_doc)

    # Now pull in the html, css, and javascript files for a kewl web experience
    add_js_attachments(javascript_dir, "", db, design_doc)
    html_content = open("index.html", "r").read()
    css_content = open("view.css", "r").read()
    db.put_attachment(design_doc, html_content, filename="index.html", content_type="text/html")
    db.put_attachment(design_doc, css_content, filename="view.css", content_type="text/css")


    # Now take the iris data and convert to JSON
    tableWriter = vtkJSONTableWriter()
    tableWriter.WriteToOutputStringOn()
    tableWriter.SetInput(tron.GetOutput())
    tableWriter.Update()
    json_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, json_data, filename="iris.json", content_type="application/json")

    # Now take the iris data statistics and onvert to JSON
    tableWriter.SetInput(mergeStats.GetOutput())
    tableWriter.Update()
    stats_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, stats_data, filename="iris_stats.json", content_type="application/json")

    # Open the browser
    webbrowser.open_new("http://localhost:5984/test/_design/test/index.html")


if __name__ == "__main__":
    import sys, os

    # Arg processing could go here

    # Call the main processing you can use things like sys.argv[1] for args
    go()
    sys.exit(0)