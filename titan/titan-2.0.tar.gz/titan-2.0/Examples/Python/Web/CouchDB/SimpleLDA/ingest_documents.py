from vtk import *
from titan.DataAnalysis import *
from titan.TextAnalysis import *
from titan.MPITextAnalysis import *
from titan.Web import *
import couchdb
import json
import os
import tempfile

reader = vtkDocumentReader()
for file in os.listdir("."):
  reader.AddFile(file)

mime_types = vtkAssignMimeType()
mime_types.SetInputConnection(0, reader.GetOutputPort(0))

text_extraction = vtkTextExtraction()
text_extraction.SetInputConnection(0, mime_types.GetOutputPort(0))

tokenizer = vtkTokenizer()
tokenizer.SetInputConnection(0, text_extraction.GetOutputPort(0))
tokenizer.DropWhitespace()
tokenizer.DropPunctuation()
tokenizer.KeepLogosyllabic()

fold_case = vtkFoldCase()
fold_case.SetInputConnection(0, tokenizer.GetOutputPort(0))

feature_dictionary = vtkFeatureDictionary()
feature_dictionary.SetInputConnection(0, fold_case.GetOutputPort(0))

frequency_matrix = vtkFrequencyMatrix()
frequency_matrix.SetInputConnection(0, fold_case.GetOutputPort(0))
frequency_matrix.SetInputConnection(1, feature_dictionary.GetOutputPort(0))
frequency_matrix.SetInputConnection(2, text_extraction.GetOutputPort(0))

lda = vtkPLatentDirichletAllocation()
lda.SetController(vtkDummyController())
lda.SetInputConnection(0, frequency_matrix.GetOutputPort(0))
lda.SetBurnInIterations(200)
lda.SetSamplingIterations(1)

server = couchdb.Server("http://localhost:5984")
if "lda-test" in server:
  server.delete("lda-test")
database = server.create("lda-test")

if "model" not in database:
  database.save( { "_id" : "model", "type" : "model" } )
model = database["model"]

text_extraction.Update()
document_dictionary = text_extraction.GetOutput()

document_ids = []
for row in range(document_dictionary.GetNumberOfRows()):
  couchdb_document = {
    "type" : "document",
    "uri" : document_dictionary.GetValueByName(row, "uri").ToString(),
    "content" : document_dictionary.GetValueByName(row, "text").ToUnicodeString()
    }
  database.save(couchdb_document)
  document_ids.append(couchdb_document["_id"])

database.put_attachment(model, json.dumps(document_ids), filename="document_map.json", content_type="application/json")

json_writer = vtkJSONTableWriter()
json_writer.SetWriteToOutputString(True)
json_writer.SetFormat(vtkJSONTableWriter.COLUMN)
json_writer.SetInputConnection(0, feature_dictionary.GetOutputPort(0))
json_writer.Write()
database.put_attachment(model, json_writer.GetOutputString(), filename="feature_dictionary.json", content_type="application/json")

json_writer = vtkJSONArrayWriter()
json_writer.SetWriteToOutputString(True)
json_writer.SetInputConnection(0, lda.GetOutputPort(0))
json_writer.Write()
database.put_attachment(model, json_writer.GetOutputString(), filename="theta.json", content_type="application/json")

vtk_writer = vtkArrayWriter()
vtk_writer.SetFileName(tempfile.mktemp())
vtk_writer.SetInputConnection(0, lda.GetOutputPort(0))
vtk_writer.Write()
database.put_attachment(model, open(vtk_writer.GetFileName(), "r").read(), filename="theta.vtk", content_type="application/x-vtk-array")
os.unlink(vtk_writer.GetFileName())

json_writer.SetInputConnection(0, lda.GetOutputPort(1))
json_writer.Write()
database.put_attachment(model, json_writer.GetOutputString(), filename="phi.json", content_type="application/json")
