#!/usr/bin/python

from pprint import pprint
import couchdb
import json
import nltk

server = couchdb.Server("http://localhost:5984")
database = server["lda-test"]
model = database["model"]

cluster_assignments = json.loads(database.get_attachment(model, "cluster_assignments.json").read())

document_map = json.loads(database.get_attachment(model, "document_map.json").read())

clusters = {}
for document_index in range(cluster_assignments["dimension"][0]["begin"], cluster_assignments["dimension"][0]["end"]):
  document_id = document_map[document_index]
  cluster = cluster_assignments["values"][document_index][0]
  if cluster not in clusters:
    clusters[cluster] = ""
  clusters[cluster] += database[document_id]["content"]

ignored_words = nltk.corpus.stopwords.words("english")
cluster_collocations = []
for cluster in clusters:
  finder = nltk.BigramCollocationFinder.from_words(nltk.tokenize.word_tokenize(clusters[cluster]))
  finder.apply_freq_filter(2)
  finder.apply_word_filter(lambda w: len(w) < 3 or w.lower() in ignored_words)
  collocations = finder.nbest(nltk.BigramAssocMeasures().likelihood_ratio, 10)
  print cluster, collocations
  cluster_collocations.append(collocations)

database.put_attachment(model, json.dumps(cluster_collocations), filename="cluster_collocations.json", content_type="application/json")
