from titan.ClusteringFilters import vtkClusteringKMeans
from titan.Web import vtkJSONArrayWriter
from vtk import *
import couchdb
import json
import os
import tempfile

server = couchdb.Server("http://localhost:5984")
database = server["lda-test"]

model = database["model"]

theta_file = tempfile.mktemp()
open(theta_file, "w+b").write(database.get_attachment(model, "theta.vtk").read())

theta = vtkArrayReader()
theta.SetFileName(theta_file)
theta.Update()
os.unlink(theta_file)

cluster = vtkClusteringKMeans()
cluster.SetInputConnection(0, theta.GetOutputPort(0))
cluster.SetVerbose(True)
#cluster.SetObservationDimension(0)
cluster.SetK(10) # Number of clusters
#cluster.SetMaxTrials(1)
#cluster.SetProximity(vtkClusteringKMeans.ProximityEuclidean)
#cluster.SetMaxIterations(1)
#cluster.SetMaxClusterMemberships(1)
#cluster.SetCentroidInitializationMethod(vtkClusteringKMeans.CentroidInitializationRandomlySelectedK)

json_writer = vtkJSONArrayWriter()
json_writer.SetWriteToOutputString(True)
json_writer.SetInputConnection(0, cluster.GetOutputPort(1))
json_writer.Write()
database.put_attachment(model, json_writer.GetOutputString(), filename="cluster_assignments.json", content_type="application/json")
