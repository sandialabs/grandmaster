from titan.Web import *
from titan.ClusteringFilters import *
from vtk import *
import os.path

data_dir = "../../../../VTKData/Data/Infovis/"
if not os.path.exists(data_dir):
  data_dir = "../../../../../VTKData/Data/Infovis/"
csv_file = data_dir + "matrix.csv"

reader = vtkDelimitedTextReader()
reader.SetFileName(csv_file)
reader.SetHaveHeaders(True)
reader.Update()
reader.GetOutput().Dump(10)

toNumeric = vtkStringToNumeric()
toNumeric.SetInputConnection(0, reader.GetOutputPort())

# Convert to column oriented JSON data
toJSON = vtkJSONTableWriter()
toJSON.SetInputConnection(0, toNumeric.GetOutputPort())
toJSON.SetFormat(vtkJSONTableWriter.COLUMN)
toJSON.WriteToOutputStringOn()
toJSON.Update()
jsonData = toJSON.GetOutputString()
print jsonData

# Now back-convert the column data to a vtkTable
jsonToTable = vtkJSONTableReader()
jsonToTable.SetJSONString(jsonData)
jsonToTable.Update()
jsonToTable.GetOutput().Dump(10)

# Convert to row oriented JSON data
toJSONRow = vtkJSONTableWriter()
toJSONRow.SetInputConnection(0, toNumeric.GetOutputPort())
toJSONRow.SetFormat(vtkJSONTableWriter.ROW)
toJSONRow.WriteToOutputStringOn()
toJSONRow.Update()
jsonRowData = toJSONRow.GetOutputString()
print jsonRowData

# Now back-convert the row data to a vtkTable
jsonToTable2 = vtkJSONTableReader()
jsonToTable2.SetJSONString(jsonRowData)
jsonToTable2.SetFormat(vtkJSONTableReader.ROW)
jsonToTable2.Update()
jsonToTable2.GetOutput().Dump(10)

array = vtkTableToArray()
array.SetInputConnection(0, jsonToTable.GetOutputPort())
array.AddColumn("A")
array.AddColumn("B")
array.AddColumn("C")
array.AddColumn("D")
array.AddColumn("E")
array.AddColumn("F")

edges = vtkAdjacencyMatrixToEdgeTable()
edges.SetInputConnection(0, array.GetOutputPort())
edges.SetSourceDimension(0)
edges.SetMinimumThreshold(0.5)

graph = vtkTableToGraph()
graph.SetInputConnection(0, edges.GetOutputPort())
graph.AddLinkVertex("row", "index", False)
graph.AddLinkVertex("column", "index", False)
graph.AddLinkEdge("row", "column")
graph.Update()

edges.GetOutput().Dump(10)

view = vtkGraphLayoutView()
view.AddRepresentationFromInputConnection(graph.GetOutputPort())
view.SetVertexLabelArrayName("label")
view.SetVertexLabelVisibility(True)
view.SetVertexColorArrayName("index")
view.SetColorVertices(True)

view.SetEdgeLabelArrayName("value")
view.SetEdgeLabelVisibility(True)
view.SetEdgeColorArrayName("edge")
view.SetColorEdges(True)
view.SetLayoutStrategyToSimple2D()

theme = vtkViewTheme.CreateNeonTheme()
theme.SetLineWidth(5)
theme.SetPointSize(10)
view.ApplyViewTheme(theme)
view.SetVertexLabelFontSize(18)
view.SetEdgeLabelFontSize(18)
theme.FastDelete()



view.GetRenderWindow().SetSize(600, 600)
view.ResetCamera()
view.Render()
view.GetInteractor().Start()
