#!/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------------
# This source file is part of the Titan Toolkit
#
# Copyright 2010 Sandia Corporation.  Under the terms of Contract
# DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
# retains certain rights in this software.
#
# This source code is released under the New BSD License.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Copyright (c) Sandia Corporation
# See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
#------------------------------------------------------------------------------
from vtk import *
from titan.MTGLGraphAnalysis import *

# create an empty graph
source = vtkRandomGraphSource()
source.SetNumberOfVertices(20)
source.SetStartWithTree(True)
source.SetEdgeProbability(0.042)
source.UseEdgeProbabilityOn()
source.SetIncludeEdgeWeights(True)

# set up a selection
selection = vtkSelectionSource()
selection.SetFieldType(3)        # generate a "vertex" selection
selection.SetContentType(4)     # set content type to indices.
selection.AddID(0, 0)

#-----------------------------------------------------------------
# MTGL Single-Source Shortest Path algorithm
#   - Note: Takes a graph and a selection as inputs.
#   -       The selection must have only one vertex selected.
sssp = vtkMTGLSearchSSSPDeltastepping()
sssp.SetGraphConnection( source.GetOutputPort() )
sssp.SetSelectionConnection( selection.GetOutputPort() )
sssp.SetInputArrayNameEdgeWeights("edge weight")
sssp.SetOutputArrayNameVertexWeights("sssp weights")
sssp.Update()

#-----------------------------------------------------------------
# Set up the graph view
theme = vtkViewTheme.CreateMellowTheme()
theme.SetLineWidth(3)
theme.SetPointSize(8)
theme.SetCellOpacity(1.0)
theme.FastDelete()

view = vtkGraphLayoutView()
view.AddRepresentationFromInputConnection( sssp.GetOutputPort() )
view.SetLayoutStrategyToFast2D()
view.SetVertexLabelFontSize(12)
view.ApplyViewTheme(theme)
view.GetRenderWindow().SetSize(600,600)


#view.SetVertexLabelArrayName("vertex id")
view.SetVertexLabelArrayName("sssp weights")
view.SetVertexLabelVisibility(True)

view.SetVertexColorArrayName("sssp weights")
view.SetColorVertices(True)

view.SetEdgeLabelArrayName("edge weight")
view.SetEdgeLabelVisibility(True)

#view.SetEdgeColorArrayName("edge weight")
#view.SetColorEdges(True)

view.ResetCamera()
view.Render()

# start up the interactor
view.GetInteractor().Start()
