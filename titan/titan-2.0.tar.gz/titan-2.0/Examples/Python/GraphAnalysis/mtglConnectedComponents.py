#!/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------------
# This source file is part of the Titan Toolkit
#
# Copyright 2010 Sandia Corporation.  Under the terms of Contract
# DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
# retains certain rights in this software.
#
# This source code is released under the New BSD License.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Copyright (c) Sandia Corporation
# See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
#------------------------------------------------------------------------------
import sys
import random

from vtk import *
from titan.MTGLGraphAnalysis import *

#
#
if __name__ == "__main__":

    source = None

    source = vtkRandomGraphSource()
    source.SetNumberOfVertices(500)
    source.SetEdgeProbability(0.0025)
    source.UseEdgeProbabilityOn()

    cc = vtkMTGLConnectedComponents()
    cc.SetGraphConnection( source.GetOutputPort() )
    cc.Update()

    #----------------------------------------------------------
    # Draw the graph in a window
    theme = vtkViewTheme.CreateMellowTheme()
    theme.SetLineWidth(2)
    theme.SetPointSize(10)
    theme.SetCellOpacity(1)
    theme.FastDelete()

    view = vtkGraphLayoutView()

    # Setup a couple layout strategies so we can switch
    # them out for comparison
    communityStrat = vtkCommunity2DLayoutStrategy()
    communityStrat.SetCommunityArrayName("component")
    communityStrat.SetCommunityStrength(1.0)
    communityStrat.SetRestDistance(1.0)
    view.SetLayoutStrategy(communityStrat)

    #view.SetLayoutStrategyToSimple2D()
    view.SetVertexLabelFontSize(32)

    view.AddRepresentationFromInputConnection(cc.GetOutputPort())
    view.SetVertexLabelArrayName("vertex id")
    view.SetVertexLabelVisibility(True)

    view.SetVertexColorArrayName("component")
    view.SetColorVertices(True)

    view.ApplyViewTheme(theme)

    view.GetRenderWindow().SetSize(600, 600)
    view.ResetCamera()
    view.Render()

    view.GetInteractor().Start()