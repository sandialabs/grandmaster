The examples in this directory show how to use Lucene from Python. There are quite a few ways to do this PyLucene (which these examples use), LuPy (defunct as far as I know), Jython (allows Python to call Java), and others...

PyLucene can be found here. http://lucene.apache.org/pylucene/

PyLucene uses JCC, JCC is a C++ code generator that produces a C++ object interface wrapping a Java library via Java's Native Interface (JNI). JCC also generates C++ wrappers that conform to Python's C type system making the instances of Java classes directly available to a Python interpreter.

The build isn't great (requires some editing of Makefiles), and is known to be slightly troublesome on windows.

In particular after you SVN checkout pylucene:
% svn checkout http://svn.apache.org/repos/asf/lucene/pylucene pylucene

I recommend you go into tags/pylucene_3_0_3 instead of trunk (I had build problems with extensions.xml, reported to devs).

From there just following the build instructions here:
http://lucene.apache.org/pylucene/documentation/install.html

After doing all that you should be able to run these examples. :)

Running the examples:
1) Index the data:
  % IndexFiles.py My_Files  (or whatever directory you have files in)
or
  % IndexMail.py Enron_Mail  (if you have data that is email)

2) Search the files:
  % SearchFiles.py

This script will ask you for query terms, and return the matching document with text context around the search term.
