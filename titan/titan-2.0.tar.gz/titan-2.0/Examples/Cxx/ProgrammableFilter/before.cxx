#include <ProgrammableFilterConfig.h>

#include <vtkDelimitedTextReader.h>
#include <vtkGenerateIndexArray.h>
#include <vtkSmartPointer.h>
#include <vtkUnicodeStringArray.h>
#include <vtkTable.h>
#include <vtkTokenizer.h>

#include <stdexcept>

int main(int argc, char* argv[])
{
  try
  {
    // Load the external data in CSV format ...
    vtkSmartPointer<vtkDelimitedTextReader> table_reader = vtkSmartPointer<vtkDelimitedTextReader>::New();
    table_reader->SetFileName(SOURCE_DIR "/test.csv");
    table_reader->SetHaveHeaders(true);
    table_reader->SetUnicodeCharacterSet("UTF-8");

    // Generate a per-document identifier for the text pipeline ...
    vtkSmartPointer<vtkGenerateIndexArray> generate_index = vtkSmartPointer<vtkGenerateIndexArray>::New();
    generate_index->SetInputConnection(0, table_reader->GetOutputPort());
    generate_index->SetFieldType(vtkGenerateIndexArray::ROW_DATA);
    generate_index->SetArrayName("document");

    // Execute the reader pipeline and create a copy of the resulting table that we can modify ...
    vtkSmartPointer<vtkTable> table = vtkSmartPointer<vtkTable>::New();
    generate_index->Update();
    table->ShallowCopy(generate_index->GetOutput());

    vtkUnicodeStringArray* const publication = vtkUnicodeStringArray::SafeDownCast(table->GetColumnByName("publication"));
    if(!publication)
      throw std::runtime_error("Missing array 'publication'.");

    vtkUnicodeStringArray* const year = vtkUnicodeStringArray::SafeDownCast(table->GetColumnByName("year"));
    if(!year)
      throw std::runtime_error("Missing array 'year'.");

    // Compute our new column ...
    vtkUnicodeStringArray* const text = vtkUnicodeStringArray::New();
    text->SetName("text");
    for(vtkIdType row = 0; row != table->GetNumberOfRows(); ++row)
    {
      vtkUnicodeString value = year->GetValue(row);
      value += vtkUnicodeString::from_utf8(" ");
      value += publication->GetValue(row);
      text->InsertNextValue(value);
    }

    // Add it to the table ...
    table->AddColumn(text);
    text->Delete();

    // Dump our modified table to the console ...
    table->Dump(20);

    // Feed the table to a tokenization pipeline ...
    vtkSmartPointer<vtkTokenizer> tokenizer = vtkSmartPointer<vtkTokenizer>::New();
    tokenizer->SetInputData(0, table);
    tokenizer->DropWhitespace();

    // Execute the pipeline and dump the output ...
    tokenizer->Update();
    tokenizer->GetOutput()->Dump(20);
  }
  catch(std::exception& e)
  {
    std::cerr << e.what() << std::endl;
  }

  return 0;
}
