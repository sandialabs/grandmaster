#include <ProgrammableFilterConfig.h>

#include <vtkBasicProgrammableFilter.h>
#include <vtkDelimitedTextReader.h>
#include <vtkGenerateIndexArray.h>
#include <vtkSmartPointer.h>
#include <vtkUnicodeStringArray.h>
#include <vtkTable.h>
#include <vtkTokenizer.h>

#include <boost/lexical_cast.hpp>
#include <boost/tr1/functional.hpp>

void generate_text_callback(vtkBasicProgrammableFilter* const filter, const vtkStdString& first_array, const vtkStdString& second_array)
{
  try
  {
    // Get the input table and validate its contents ...
    vtkTable* const table = vtkTable::SafeDownCast(filter->GetInputDataObject(0, 0));
    if(!table) throw std::runtime_error("Missing input table.");
    vtkUnicodeStringArray* const first = vtkUnicodeStringArray::SafeDownCast(table->GetColumnByName(first_array.c_str()));
    if(!first) throw std::runtime_error("Missing array " + first_array);
    vtkUnicodeStringArray* const second = vtkUnicodeStringArray::SafeDownCast(table->GetColumnByName(second_array.c_str()));
    if(!second) throw std::runtime_error("Missing array " + second_array);

    // Setup our output ...
    vtkUnicodeStringArray* const text = vtkUnicodeStringArray::New();
    text->SetName("text");
    for(vtkIdType row = 0; row != table->GetNumberOfRows(); ++row)
    {
      vtkUnicodeString value = first->GetValue(row);
      value += vtkUnicodeString::from_utf8(" ");
      value += second->GetValue(row);
      text->InsertNextValue(value);
    }

    vtkTable::SafeDownCast(filter->GetOutputDataObject(0))->ShallowCopy(table);
    vtkTable::SafeDownCast(filter->GetOutputDataObject(0))->AddColumn(text);
    text->Delete();
  }
  catch(std::exception& e)
  {
    std::cerr << e.what() << std::endl;
  }
}

int main(int argc, char* argv[])
{
  // Load the external data in CSV format ...
  vtkSmartPointer<vtkDelimitedTextReader> table_reader = vtkSmartPointer<vtkDelimitedTextReader>::New();
  table_reader->SetFileName(SOURCE_DIR "/test.csv");
  table_reader->SetHaveHeaders(true);
  table_reader->SetUnicodeCharacterSet("UTF-8");

  // Generate a per-document identifier for the text pipeline ...
  vtkSmartPointer<vtkGenerateIndexArray> generate_index = vtkSmartPointer<vtkGenerateIndexArray>::New();
  generate_index->SetInputConnection(0, table_reader->GetOutputPort());
  generate_index->SetFieldType(vtkGenerateIndexArray::ROW_DATA);
  generate_index->SetArrayName("document");

  // Setup a programmable filter to generate a 'text' field ...
  vtkSmartPointer<vtkBasicProgrammableFilter> generate_text = vtkSmartPointer<vtkBasicProgrammableFilter>::New();
  generate_text->SetNumberOfInputPorts(1);
  generate_text->SetInputDataType(0, "vtkTable");
  generate_text->SetNumberOfOutputPorts(1);
  generate_text->SetOutputDataType(0, "vtkTable");
  generate_text->SetInputConnection(0, generate_index->GetOutputPort());
  generate_text->SetCallback(std::tr1::bind(generate_text_callback, generate_text.GetPointer(), "year", "publication"));

  // Feed the results to a tokenization pipeline ...
  vtkSmartPointer<vtkTokenizer> tokenizer = vtkSmartPointer<vtkTokenizer>::New();
  tokenizer->SetInputConnection(0, generate_text->GetOutputPort());
  tokenizer->DropWhitespace();

  // Execute the pipeline and dump the output ...
  tokenizer->Update();
  vtkTable::SafeDownCast(generate_text->GetOutputDataObject(0))->Dump(20);
  tokenizer->GetOutput()->Dump(20);

  return 0;
}
