// .NAME paratextHeader - manage Windows system differences
// .SECTION Description
// The paratextHeader captures some system differences between Unix
// and Windows operating systems.
/*
 * Copyright 2011 Sandia Corporation.
 * Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
 * license for use of this work by or on behalf of the
 * U.S. Government. Redistribution and use in source and binary forms, with
 * or without modification, are permitted provided that this Notice and any
 * statement of authorship are reproduced on all copies.
 */

#ifndef __paratextHeader_h
#define __paratextHeader_h

#if defined(WIN32)
#if defined(paratext_EXPORTS)
#define PARATEXT_EXPORT __declspec( dllexport )
#else
#define PARATEXT_EXPORT __declspec( dllimport )
#endif
#else
#define PARATEXT_EXPORT
#endif

#endif
