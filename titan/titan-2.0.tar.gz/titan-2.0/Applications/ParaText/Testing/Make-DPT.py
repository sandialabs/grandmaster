#!/usr/bin/python

documents = [[] for i in range(16)]

document = 0
for i in range(4):
  run = 16
  run_repeat = 1
  token = 0
  while run > 0:
    for j in range(run_repeat):
      for k in range(run):
        documents[document % len(documents)].append(chr((token / 26) + ord("A")) + chr((token % 26) + ord("A")) + str(i))
        document = document + 1
      token = token + 1
    run = run / 2
    run_repeat = run_repeat * 2

for i in range(len(documents)):
  print str(" ").join(documents[i])
  file = open(("%03d" % i) + ".txt", "w")
  file.write(str(" ").join(documents[i]))
