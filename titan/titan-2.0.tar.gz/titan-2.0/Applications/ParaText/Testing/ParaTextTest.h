#ifndef ParaTextTest_h
#define ParaTextTest_h

#include <ParaTextTestConfig.h>
#include <paratextHeader.h>

#include <string>
#include <vector>

void PARATEXT_EXPORT launch(const std::string& executable, const std::vector<std::string>& arguments);

#endif // !ParaTextTest_h
