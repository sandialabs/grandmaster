#include <ParaTextTest.h>

#include <vtkArrayReader.h>
#include <vtkDenseArray.h>
#include <vtkSmartPointer.h>

#include <boost/filesystem.hpp>
#include <iostream>
#include <sstream>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  try
    {
    remove(boost::filesystem::path("feature-dictionary.vtk"));
    remove(boost::filesystem::path("frequency-matrix.vtk"));
    remove(boost::filesystem::path("right-singular-vectors.vtk"));
    remove(boost::filesystem::path("weighted-matrix.vtk"));

    std::vector<std::string> arguments;
    arguments.push_back("paratext-lsa");
    arguments.push_back("--directory=" DPT_LOCATION);
    arguments.push_back("--svd-rank=1");
    arguments.push_back("--minimum-feature-document-percent=0.5");
    arguments.push_back("--export-feature-dictionary=feature-dictionary.vtk");
    arguments.push_back("--export-frequency-matrix=frequency-matrix.vtk");
    arguments.push_back("--export-weighted-matrix=weighted-matrix.vtk");
    arguments.push_back("--print-right-singular-vectors=-");
    arguments.push_back("--export-right-singular-vectors=right-singular-vectors.vtk");

    launch(PARATEXT_LOCATION, arguments);

    VTK_CREATE(vtkArrayReader, right_singular_vectors);
    right_singular_vectors->SetFileName("right-singular-vectors.vtk");
    right_singular_vectors->Update();

    test_expression(right_singular_vectors->GetOutput());
    test_expression(right_singular_vectors->GetOutput()->GetNumberOfArrays() == 1);
    vtkDenseArray<double>* const rsv = vtkDenseArray<double>::SafeDownCast(right_singular_vectors->GetOutput()->GetArray(0));
    test_expression(rsv->GetDimensions() == 2);
    test_expression(rsv->GetExtent(0) == vtkArrayRange(0, 1));
    test_expression(rsv->GetExtent(1) == vtkArrayRange(0, 16));

    return 0;
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    return 1;
    }
}
