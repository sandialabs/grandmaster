/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$
  Language:  C++
  Date:      $Date: 2005-06-06 19:49:35 -0600 (Mon, 06 Jun 2005) $
  Version:   $Revision: 4814 $

  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
  license for use of this work by or on behalf of the
  U.S. Government. Redistribution and use in source and binary forms, with
  or without modification, are permitted provided that this Notice and any
  statement of authorship are reproduced on all copies.

=========================================================================*/

#include <TestDriverConfig.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/filesystem.hpp>
#include <boost/program_options.hpp>

#include <cmath>
#include <fstream>
#include <ios>
#include <iostream>
#include <iterator>
#include <sstream>

#include <stdio.h>

///////////////////////////////////////////////////////////////////////////////////////
// early_exit

struct early_exit
{
};

///////////////////////////////////////////////////////////////////////////////////////
// main

int main(int argc, char* argv[])
{
  int error_count = 0;

  try
    {
    // Process command-line arguments ...
    std::vector<boost::filesystem::path> test_data;
    boost::filesystem::path test_directory;
    std::string test_name;
    std::string test_options;
    std::vector<unsigned int> test_processors;
    unsigned int run_count = 0;

    boost::program_options::options_description options("ParaText test driver options", 120);
    options.add_options()
      ("data", boost::program_options::value<std::vector<boost::filesystem::path> >(&test_data), "Individual test data sets.")
      ("dry-run", "Don't actually run any tests.")
      ("help,h", "Prints this help message and exits.")
      ("processors", boost::program_options::value<std::vector<unsigned int> >(&test_processors), "Individual test processor counts.")
      ("run-count", boost::program_options::value<unsigned int>(&run_count), "Number of tests to run.")
      ("test-directory", boost::program_options::value<boost::filesystem::path>(&test_directory), "Top-level directory for storing results.")
      ("test-name", boost::program_options::value<std::string>(&test_name), "Test name (used for labelling).")
      ("test-options", boost::program_options::value<std::string>(&test_options), "Test options to be passed to ParaText.")
      ;

    boost::program_options::variables_map arguments;
    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      std::cout << options << "\n";
      throw early_exit();
      }

    // Sanity-check arguments
    if(!arguments.count("test-directory"))
      throw std::runtime_error("Test directory must be specified.");
    if(!arguments.count("run-count"))
      throw std::runtime_error("Run count must be specified.");
    if(test_data.size() != test_processors.size())
      throw std::runtime_error("Test data and test processor counts must match.");

    for(unsigned int i = 0; i != test_data.size(); ++i)
      {
      if(!exists(test_data[i]))
        throw std::runtime_error("Test data does not exist.");
      }

    // Run the tests ...
    const boost::posix_time::ptime start_time = boost::posix_time::second_clock::local_time();

    std::cout << "*********** Starting Test " << test_name << " ***********" << std::endl;
    std::cerr << "*********** Starting Test " << test_name << " ***********" << std::endl;

    // Generate output directories ...
    if(test_name.size())
      test_directory /= test_name;
    create_directories(test_directory);

    const boost::filesystem::path log_file = test_directory / "log.txt";
    std::ofstream log_stream(log_file.external_file_string().c_str());
    log_stream << "start: " << to_iso_extended_string(start_time) << std::endl;

    // For each datasize / CPU pair ...
    for(unsigned int i = 0; i != test_data.size(); ++i)
      {
      try
        {
        const boost::filesystem::path data_set = test_data[i];
        log_stream << "data: " << data_set << std::endl;

        const unsigned int cpu_count = test_processors[i];
        log_stream << "cpu count: " << cpu_count << std::endl;

        // For each run ...
        for(unsigned int run_index = 0; run_index != run_count; ++run_index)
          {
          // Pre-create the output metric files, so we can add some header information ...
          for(unsigned int cpu_index = 0; cpu_index != cpu_count; ++cpu_index)
            {
            std::ostringstream metric_file;
            metric_file << test_directory << "/" << data_set.leaf() << "-" << cpu_count << "procs-run" << run_index << "-proc" << cpu_index << ".csv";

            std::ofstream metric_stream(metric_file.str().c_str());
            metric_stream << "run_index,cpu_index,cpu_count,component_index,metric_index,value,component,metric,units\n";
            }

          std::ostringstream command_line;
          command_line << VTK_MPIRUN_EXE;
          command_line << " " << VTK_MPI_NUMPROC_FLAG << " " << cpu_count;
          command_line << " " << VTK_MPI_PREFLAGS;
          command_line << PARATEXT_BINARY;
          command_line << " --recursive-directory=" << data_set;
          command_line << " --export-metrics=" << test_directory << "/" << data_set.leaf() << "-%3%procs-run" << run_index << "-proc%2%.csv";
          command_line << " \"--metric-format=" << run_index << ",%2%,%3%,%4%,%5%,%6%,%7%,%8%,%9%\"";
          command_line << " " << test_options;
          command_line << " " << VTK_MPI_POSTFLAGS;

          log_stream << "command: " << command_line.str() << std::endl;

          if(arguments.count("dry-run"))
            continue;

          FILE* process = popen(command_line.str().c_str(), "w");
          if(!process)
            throw std::runtime_error("Error starting test process.");
          pclose(process);
          }
        }
      catch(std::exception& e)
        {
        log_stream << "exception: " << e.what() << std::endl;
        std::cerr << e.what() << std::endl;
        error_count += 1;
        }
      }

    boost::posix_time::ptime end_time = boost::posix_time::second_clock::local_time();
    log_stream << "finish: " << to_iso_extended_string(end_time);
    log_stream << " duration: " << to_simple_string(end_time - start_time);
    log_stream << std::endl;
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << argv[0] << ": " << e.what() << std::endl;
    error_count += 1;
    }

  return error_count;
}
