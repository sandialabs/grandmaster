#include <ParaTextTest.h>

#include <vtkArrayReader.h>
#include <vtkDenseArray.h>
#include <vtkSmartPointer.h>

#include <boost/filesystem.hpp>
#include <iostream>
#include <sstream>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  try
    {
    remove(boost::filesystem::path("left-singular-vectors.vtk"));
    remove(boost::filesystem::path("singular-values.vtk"));
    remove(boost::filesystem::path("right-singular-vectors.vtk"));

    std::vector<std::string> arguments;
    arguments.push_back("paratext-lsa");
    arguments.push_back("--directory=" DPT_LOCATION);
    arguments.push_back("--svd-rank=4");
    arguments.push_back("--export-left-singular-vectors=left-singular-vectors.vtk");
    arguments.push_back("--export-singular-values=singular-values.vtk");
    arguments.push_back("--export-right-singular-vectors=right-singular-vectors.vtk");

    launch(PARATEXT_LOCATION, arguments);

    VTK_CREATE(vtkArrayReader, left_singular_vectors);
    left_singular_vectors->SetFileName("left-singular-vectors.vtk");
    left_singular_vectors->Update();

    test_expression(left_singular_vectors->GetOutput());
    test_expression(left_singular_vectors->GetOutput()->GetNumberOfArrays() == 1);
    vtkDenseArray<double>* const lsv = vtkDenseArray<double>::SafeDownCast(left_singular_vectors->GetOutput()->GetArray(0));
    test_expression(lsv->GetDimensions() == 2);
    test_expression(lsv->GetExtent(0) == vtkArrayRange(0, 124));
    test_expression(lsv->GetExtent(1) == vtkArrayRange(0, 4));

    VTK_CREATE(vtkArrayReader, singular_values);
    singular_values->SetFileName("singular-values.vtk");
    singular_values->Update();

    test_expression(singular_values->GetOutput());
    test_expression(singular_values->GetOutput()->GetNumberOfArrays() == 1);
    vtkDenseArray<double>* const sv = vtkDenseArray<double>::SafeDownCast(singular_values->GetOutput()->GetArray(0));
    test_expression(sv->GetDimensions() == 1);
    test_expression(sv->GetExtent(0) == vtkArrayRange(0, 4));

    VTK_CREATE(vtkArrayReader, right_singular_vectors);
    right_singular_vectors->SetFileName("right-singular-vectors.vtk");
    right_singular_vectors->Update();

    test_expression(right_singular_vectors->GetOutput());
    test_expression(right_singular_vectors->GetOutput()->GetNumberOfArrays() == 1);
    vtkDenseArray<double>* const rsv = vtkDenseArray<double>::SafeDownCast(right_singular_vectors->GetOutput()->GetArray(0));
    test_expression(rsv->GetDimensions() == 2);
    test_expression(rsv->GetExtent(0) == vtkArrayRange(0, 4));
    test_expression(rsv->GetExtent(1) == vtkArrayRange(0, 16));

    return 0;
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    return 1;
    }
}
