#include <ParaTextTest.h>
#include <boost/process.hpp>

void launch(const std::string& executable, const std::vector<std::string>& arguments)
{
  boost::process::context context;
  context.environment = boost::process::self::get_environment();
  context.stdin_behavior = boost::process::close_stream();
  context.stdout_behavior = boost::process::inherit_stream();
  context.stderr_behavior = boost::process::inherit_stream();

  boost::process::child child = boost::process::launch(executable, arguments, context);
  boost::process::status status = child.wait();
  if(!status.exited())
    throw std::runtime_error("child failed");
}
