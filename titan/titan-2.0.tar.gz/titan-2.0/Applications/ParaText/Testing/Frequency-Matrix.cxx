#include <ParaTextTest.h>

#include <vtkArrayReader.h>
#include <vtkSparseArray.h>
#include <vtkSmartPointer.h>

#include <boost/filesystem.hpp>
#include <iostream>
#include <sstream>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  try
    {
    remove(boost::filesystem::path("frequency-matrix.vtk"));

    std::vector<std::string> arguments;
    arguments.push_back("paratext-lsa");
    arguments.push_back("--directory=" DPT_LOCATION);
    arguments.push_back("--export-frequency-matrix=frequency-matrix.vtk");

    launch(PARATEXT_LOCATION, arguments);

    VTK_CREATE(vtkArrayReader, frequency_matrix);
    frequency_matrix->SetFileName("frequency-matrix.vtk");
    frequency_matrix->Update();

    test_expression(frequency_matrix->GetOutput());
    test_expression(frequency_matrix->GetOutput()->GetNumberOfArrays() == 1);
    vtkSparseArray<double>* const array = vtkSparseArray<double>::SafeDownCast(frequency_matrix->GetOutput()->GetArray(0));
    test_expression(array->GetDimensions() == 2);
    test_expression(array->GetExtent(0) == vtkArrayRange(0, 124));
    test_expression(array->GetExtent(1) == vtkArrayRange(0, 16));
    std::cerr << array->GetNonNullSize() << std::endl;
    test_expression(array->GetNonNullSize() == 320);

    return 0;
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    return 1;
    }
}
