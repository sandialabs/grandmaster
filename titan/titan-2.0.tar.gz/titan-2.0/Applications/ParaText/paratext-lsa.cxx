#include <vtkArrayPrint.h>
#include <vtkArrayReader.h>
#include <vtkArrayWriter.h>
#include <vtkAssignMimeType.h>
#include <vtkBoostLogWeighting.h>
#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkDocumentPerLinePDocumentReaderStrategy.h>
#include <vtkFrequencyMatrix.h>
#include <vtkMPIController.h>
#include <vtkNGramExtraction.h>
#include <vtkPassThrough.h>
#include <vtkPDocumentReader.h>
#include <vtkPEntropyMatrixWeightingNTo1.h>
#include <vtkPEntropyMatrixWeightingNToN.h>
#include <vtkPFrequencyMatrixFilter.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkPRowQueryToTable.h>
#include <vtkPTermDictionaryNTo1.h>
#include <vtkPTermDictionaryNToN.h>
#include <vtkPTermDictionaryBinaryTree.h>
#include <vtkPTermDictionaryRoundRobin.h>
#include <vtkPTermDictionaryMapReduce.h>
#include <vtkPipelineGraphSource.h>
#include <vtkRoundRobinPDocumentReaderStrategy.h>
#include <vtkScaleDimension.h>
#include <vtkSmartPointer.h>
#include <vtkSortedBytePDocumentReaderStrategy.h>
#include <vtkSQLDatabase.h>
#include <vtkSQLQuery.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextExtraction.h>
#include <vtkTimerLog.h>
#include <vtkTokenLengthFilter.h>
#include <vtkTokenValueFilter.h>
#include <vtkTokenization.h>
#include <vtkTrilinosSVD.h>
#include <vtkUnsortedBytePDocumentReaderStrategy.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Helper class for managing timing.
class cpu_timer
{
public:
  cpu_timer() :
    start_time(vtkTimerLog::GetCPUTime())
  {
  }

  const double elapsed() const
  {
    return vtkTimerLog::GetCPUTime() - this->start_time;
  }

  void reset()
  {
    this->start_time = vtkTimerLog::GetCPUTime();
  }

private:
  double start_time;
};

class wallclock_timer
{
public:
  wallclock_timer() :
    start_time(vtkTimerLog::GetUniversalTime())
  {
  }

  const double elapsed() const
  {
    return vtkTimerLog::GetUniversalTime() - this->start_time;
  }

  void reset()
  {
    this->start_time = vtkTimerLog::GetUniversalTime();
  }

private:
  double start_time;
};

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  std::map<std::string, int> component_indices;
  std::map<std::string, std::map<std::string, int> > metric_indices;

  int minimum_token_length;
  int maximum_token_length;
  int ngram_length;
  int minimum_feature_document_count;
  double minimum_feature_document_percent;
  int minimum_feature_count;

  std::string database_query;
  std::string database_url;
  std::string default_mime_type;
  std::string document_partition_strategy;
  std::string feature_dictionary_strategy;
  std::string frequency_matrix_strategy;
  std::string import_document_dictionary;
  std::string import_feature_table;
  std::string import_frequency_matrix;
  std::string import_weighted_matrix;
  std::string metric_format;
  std::string pipeline_diagram;
  std::string svd_rank;
  std::string weighting_strategy;
  std::vector<std::string> document_directories;
  std::vector<std::string> document_files;
  std::vector<std::string> file_lists;
  std::vector<std::string> document_recursive_directories;
  std::vector<std::string> export_aggregated_left_singular_vectors;
  std::vector<std::string> export_aggregated_right_singular_vectors;
  std::vector<std::string> export_db_query_result;
  std::vector<std::string> export_document_dictionary;
  std::vector<std::string> export_feature_dictionary;
  std::vector<std::string> export_features;
  std::vector<std::string> export_frequency_matrix;
  std::vector<std::string> export_global_weighting;
  std::vector<std::string> export_left_singular_vectors;
  std::vector<std::string> export_metrics;
  std::vector<std::string> export_right_singular_vectors;
  std::vector<std::string> export_singular_values;
  std::vector<std::string> export_weighted_matrix;
  std::vector<std::string> print_right_singular_vectors;
  std::vector<std::string> stop_words;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};

/// Provides simple variable expansion for a given string, mainly used so we
/// can generate processor-specific filenames when exporting data.
std::string file_string(const program_state& State, const std::string& String)
{
  boost::format format(String);
  format.exceptions(boost::io::all_error_bits ^ boost::io::too_many_args_bit);
  format % to_iso_string(State.timestamp);
  format % State.process_id;
  format % State.process_count;

  return str(format);
}

/// Write a metric to a stream.
template<typename T>
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const T& Value, const std::string& Units, std::ostream& Stream)
{
  State.component_indices.insert(std::make_pair(Component, State.component_indices.size()));
  State.metric_indices.insert(std::make_pair(Component, std::map<std::string, int>()));
  State.metric_indices[Component].insert(std::make_pair(Metric, State.metric_indices[Component].size()));

  boost::format format(State.metric_format);
  format.exceptions(boost::io::all_error_bits ^ boost::io::too_many_args_bit);
  format % to_iso_string(State.timestamp);
  format % State.process_id;
  format % State.process_count;
  format % State.component_indices[Component];
  format % State.metric_indices[Component][Metric];
  format % Component;
  format % Metric;
  format % Value;
  format % Units;

  for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
    {
    if(i == Controller->GetLocalProcessId())
      {
      Stream << str(format) << std::endl;
      }
    Controller->Barrier();
    }
}

/// Write a metric to a variety of possible output locations.
template<typename T>
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const T& Value, const std::string& Units)
{
  for(std::vector<std::string>::const_iterator location = State.export_metrics.begin(); location != State.export_metrics.end(); ++location)
    {
    // Write the metric to stdout ...
    if(*location == "-")
      {
      export_metric<T>(Controller, State, Component, Metric, Value, Units, std::cerr);
      }
    // Write the metric to a file ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str(), std::ios::out | std::ios::app);
      export_metric<T>(Controller, State, Component, Metric, Value, Units, stream);
      }
    }
}

/// Write a metric to a variety of possible output locations.
template<typename T>
void export_metric(vtkMultiProcessController* Controller, program_state& State, vtkObject* Component, const std::string& Metric, const T& Value, const std::string& Units)
{
  export_metric<T>(Controller, State, Component->GetClassName(), Metric, Value, Units);
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, vtkObject* Component, const std::string& Metric, const cpu_timer& Time)
{
  export_metric(Controller, State, Component->GetClassName(), Metric, Time.elapsed(), "seconds");
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const cpu_timer& Time)
{
  export_metric(Controller, State, Component, Metric, Time.elapsed(), "seconds");
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const wallclock_timer& Time)
{
  export_metric(Controller, State, Component, Metric, Time.elapsed(), "seconds");
}

/// Write a table to a variety of possible output locations.
void export_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkTable* Table, const std::vector<std::string>& Locations, const vtkIdType ColumnWidth)
{
  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    // Write the table to stdout ...
    if(*location == "-")
      {
      for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
        {
        if(i == Controller->GetLocalProcessId())
          {
          std::cout << "Process " << i << " of " << Controller->GetNumberOfProcesses() << "\n";
          Table->Dump(ColumnWidth);
          }
        Controller->Barrier();
        }
      }
    // Write the table to a file in VTK ASCII format ...
    else
      {
      VTK_CREATE(vtkTableWriter, table_writer);
      table_writer->SetInputData(0, Table);
      table_writer->SetFileName(file_string(State, *location).c_str());
      table_writer->Write();
      }
    }
}

/// Write an array to a variety of possible output locations.
void export_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkArray* Array, const std::vector<std::string>& Locations)
{
  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    // Write the array to stdout ...
    if(*location == "-")
      {
      for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
        {
        if(i == Controller->GetLocalProcessId())
          {
          std::cout << "Process " << i << " of " << Controller->GetNumberOfProcesses() << "\n";
          vtkArrayWriter::Write(Array, std::cout, false);
          }
        Controller->Barrier();
        }
      }
    // Write the array to a file in VTK ASCII format ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str());
      vtkArrayWriter::Write(Array, stream, false);
      }
    }
}

/// Print an array to a variety of possible output locations.
void print_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkArray* Array, const std::vector<std::string>& Locations)
{
  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    if(*location == "-")
      {
      for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
        {
        if(i == Controller->GetLocalProcessId())
          {
          std::cout << "Process " << i << " of " << Controller->GetNumberOfProcesses() << "\n";
          if(Array->GetDimensions() == 2)
            vtkPrintMatrixFormat(std::cout, vtkTypedArray<double>::SafeDownCast(Array));
          }
        Controller->Barrier();
        }
      }
    // Write the array to a file in VTK ASCII format ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str());
      if(Array->GetDimensions() == 2)
        vtkPrintMatrixFormat(stream, vtkTypedArray<double>::SafeDownCast(Array));
      }
    }
}

/// Aggregate an array and write it to a variety of possible output locations.
void export_aggregated_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkArray* Array, const std::vector<std::string>& Locations)
{
  // Consolidate the distributed array on the local process ...
  vtkSmartPointer<vtkArray> array = vtkSmartPointer<vtkArray>::Take(vtkDistributedArray::GatherArray(Controller, Array, 0));

  if(0 != Controller->GetLocalProcessId())
    return;

  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    // Write the array to stdout ...
    if(*location == "-")
      {
      vtkArrayWriter::Write(array, std::cout, false);
      }
    // Write the array to a file in VTK ASCII format ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str());
      vtkArrayWriter::Write(array, stream, false);
      }
    }
}

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  try
    {
    /// Setup command-line arguments ...

    state.metric_format = "%2%,%|5t|%3%,%|10t|%6%,%|45t|%7%,%|70t|%8%,%|85t|%9%";

    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("database-query", boost::program_options::value<std::string>(&state.database_query), "Specify the database query to use when pulling documents.")
      ("database-url", boost::program_options::value<std::string>(&state.database_url), "Specify the database url for pulling documents.")
      ("default-mime-type", boost::program_options::value<std::string>(&state.default_mime_type)->default_value(""), "Default MIME type for documents whose MIME type isn't detected automatically.")
      ("directory", boost::program_options::value<std::vector<std::string> >(&state.document_directories), "Adds a directory to the list of inputs to be processed.")
      ("export-aggregated-left-singular-vectors", boost::program_options::value<std::vector<std::string> >(&state.export_aggregated_left_singular_vectors), "Writes aggregated left singular vectors to a file.  Use '-' for stdout.")
      ("export-aggregated-right-singular-vectors", boost::program_options::value<std::vector<std::string> >(&state.export_aggregated_right_singular_vectors), "Writes aggregated right singular vectors to a file.  Use '-' for stdout.")
      ("export-db-query-result", boost::program_options::value<std::vector<std::string> >(&state.export_db_query_result), "Writes the results of the database query to a file.  Use '-' for stdout.")
      ("export-document-dictionary", boost::program_options::value<std::vector<std::string> >(&state.export_document_dictionary), "Writes the document dictionary to a file.  Use '-' for stdout.")
      ("export-feature-dictionary", boost::program_options::value<std::vector<std::string> >(&state.export_feature_dictionary), "Writes the feature dictionary to a file.  Use '-' for stdout.")
      ("export-features", boost::program_options::value<std::vector<std::string> >(&state.export_features), "Writes features (tokens) to a file.  Use '-' for stdout.")
      ("export-frequency-matrix", boost::program_options::value<std::vector<std::string> >(&state.export_frequency_matrix), "Writes the frequency matrix to a file.  Use '-' for stdout.")
      ("export-global-weighting", boost::program_options::value<std::vector<std::string> >(&state.export_global_weighting), "Writes the global weighting vector to a VTK file.  Use '-' for stdout.")
      ("export-left-singular-vectors", boost::program_options::value<std::vector<std::string> >(&state.export_left_singular_vectors), "Writes left singular vectors to a file.  Use '-' for stdout.")
      ("export-metrics", boost::program_options::value<std::vector<std::string> >(&state.export_metrics), "Writes execution metrics to a file.  Use '-' for stdout.")
      ("export-right-singular-vectors", boost::program_options::value<std::vector<std::string> >(&state.export_right_singular_vectors), "Writes right singular vectors to a file.  Use '-' for stdout.")
      ("export-singular-values", boost::program_options::value<std::vector<std::string> >(&state.export_singular_values), "Writes singular values to a file.  Use '-' for stdout.")
      ("export-weighted-matrix", boost::program_options::value<std::vector<std::string> >(&state.export_weighted_matrix), "Writes the weighted matrix to a file.  Use '-' for stdout.")
      ("feature-dictionary-strategy", boost::program_options::value<std::string>(&state.feature_dictionary_strategy)->default_value("mr"), "Feature dictionary strategy. Valid values are 'nto1', 'nton', 'rr', 'bt', and 'mr'.")
      ("file,f", boost::program_options::value<std::vector<std::string> >(&state.document_files), "Adds a file to the list of inputs to be processed.")
      ("file-list,l", boost::program_options::value<std::vector<std::string> >(&state.file_lists), "Adds a file containing a line-delimited list of files to the list of inputs to be processed.")
      ("frequency-matrix-strategy", boost::program_options::value<std::string>(&state.frequency_matrix_strategy)->default_value("global+local"), "Frequency matrix strategy. Valid values are 'global+local', 'global', and 'global+presorted'.")
      ("help,h", "Prints this help message and exits.")
      ("import-document-dictionary", boost::program_options::value<std::string>(&state.import_document_dictionary), "Import the document dictionary from a file instead of reading individual documents.")
      ("import-feature-table", boost::program_options::value<std::string>(&state.import_feature_table), "Import the feature table from a file instead of computing it based on input documents.")
      ("import-frequency-matrix", boost::program_options::value<std::string>(&state.import_frequency_matrix), "Import the frequency matrix from a file instead of computing it based on input documents.")
      ("import-weighted-matrix", boost::program_options::value<std::string>(&state.import_weighted_matrix), "Import the weighted matrix from a file instead of computing it based on input documents.")
      ("maximum-token-length", boost::program_options::value<int>(&state.maximum_token_length)->default_value(32), "Specify the maximum allowable token length in characters.")
      ("metric-format", boost::program_options::value<std::string>(&state.metric_format), "Defines the format for output metrics.")
      ("minimum-feature-count", boost::program_options::value<int>(&state.minimum_feature_count)->default_value(0), "Specify the minimum number of times a feature must appear across the entire corpus to be analyzed.")
      ("minimum-feature-document-count", boost::program_options::value<int>(&state.minimum_feature_document_count)->default_value(0), "Specify the minimum number of documents that a feature must appear in to be analyzed.")
      ("minimum-feature-document-percent", boost::program_options::value<double>(&state.minimum_feature_document_percent)->default_value(0), "Specify the minimum percentage of documents that a feature must appear in to be analyzed.")
      ("minimum-token-length", boost::program_options::value<int>(&state.minimum_token_length)->default_value(2), "Specify the minimum allowable token length in characters.")
      ("ngram-length", boost::program_options::value<int>(&state.ngram_length)->default_value(1), "Specify the length of extracted n-grams.")
      ("no-default-stop-words", "Disable the default stop word list. Use --stop-words to provide your own custom stop words.")
      ("partition-strategy", boost::program_options::value<std::string>(&state.document_partition_strategy)->default_value("round-robin"), "Document reader partitioning strategy. Valid values are 'round-robin', 'sorted-bytes', 'unsorted-bytes', and 'document-per-line'.")
      ("pipeline-diagram", boost::program_options::value<std::string>(&state.pipeline_diagram), "Writes a pipeline diagram as a GraphViz dot file.")
      ("print-right-singular-vectors", boost::program_options::value<std::vector<std::string> >(&state.print_right_singular_vectors), "Prints right singular vectors to a file.  Use '-' for stdout.")
      ("recursive-directory", boost::program_options::value<std::vector<std::string> >(&state.document_recursive_directories), "Adds a directory and all its subdirectories to the list of inputs to be processed.")
      ("stop-metrics-at-documents", "Stop metric collection after documents have been ingested.")
      ("stop-metrics-at-feature-dictionary", "Stop metric collection after the feature dictionary has been created.")
      ("stop-metrics-at-frequency-matrix", "Stop metric collection after the frequency matrix has been created.")
      ("stop-metrics-at-weighted-matrix", "Stop metric collection after the weighted matrix has been created.")
      ("stop-words", boost::program_options::value<std::vector<std::string> >(&state.stop_words), "Whitespace-delimited collection of stop words to be ignored during analysis.  Use with --no-default-stop-words if you want to replace, rather than supplement, the builtin stop word list.")
      ("svd-align-factors", "Enable alignment of factors to data to resolve the sign ambiguity problem.")
      ("svd-rank", boost::program_options::value<std::string>(&state.svd_rank)->default_value("auto"), "Specifies the SVD rank as an integer, or 'auto'.")
      ("version", "Prints program version information and exits.")
      ("weighting-strategy", boost::program_options::value<std::string>(&state.weighting_strategy)->default_value("entropy-nto1-sparse"), "Weighting strategy. Valid values are 'entropy-nto1-sparse', 'entropy-nto1-dense', and 'entropy-nton-sparse'.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("file", -1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        std::cout << "Filenames are expanded using printf-like formatting.  Special %n% arguments will be expanded as follows:\n\n";
        std::cout << "  %1% - timestamp in ISO format\n";
        std::cout << "  %2% - process id\n";
        std::cout << "  %3% - process count\n";
        std::cout << "\n";
        std::cout << "Metrics are expanded using printf-like formatting.  Special %n% arguments will be expanded as follows:\n\n";
        std::cout << "  %1% - timestamp in ISO format\n";
        std::cout << "  %2% - process id\n";
        std::cout << "  %3% - process count\n";
        std::cout << "  %4% - component index\n";
        std::cout << "  %5% - metric index\n";
        std::cout << "  %6% - component name\n";
        std::cout << "  %7% - metric name\n";
        std::cout << "  %8% - metric value\n";
        std::cout << "  %9% - metric units\n";
        std::cout << "\n";
        std::cout << "Examples:\n";
        std::cout << "\n";
        std::cout << "paratext-lsa --file A --directory B --export-feature-dictionary=C\n";
        std::cout << "  Loads file A and the contents of directory B, writing a feature-dictionary to file C\n";
        std::cout << "\n";
        std::cout << "mpiexec -np 4 paratext-lsa --recursive-directory D --export-weighted-matrix=E%2%.txt\n";
        std::cout << "  Using four processors, recursively loads the contents of directory D, writing weighted matrix files\n";
        std::cout << "  for each processor, named E0.txt, E1.txt, E2.txt, and E3.txt.\n";
        std::cout << "\n";
        }

      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText version 0.1\n";
      throw early_exit();
      }

    // Setup document input ...
    VTK_CREATE(vtkPDocumentReader, document_reader);
    for(int i = 0; i != state.document_files.size(); ++i)
      {
      document_reader->AddFile(state.document_files[i].c_str());
      }
    for(int i = 0; i != state.document_directories.size(); ++i)
      {
      document_reader->AddDirectory(state.document_directories[i].c_str());
      }
    for(int i = 0; i != state.document_recursive_directories.size(); ++i)
      {
      document_reader->AddRecursiveDirectory(state.document_recursive_directories[i].c_str());
      }
    for(int i = 0; i != state.file_lists.size(); ++i)
      {
      std::ifstream list(state.file_lists[i].c_str());
      std::string file;
      for(std::getline(list, file); list; std::getline(list, file))
        document_reader->AddFile(file.c_str());
      }

    // Setup document partitioning ...
    vtkSmartPointer<vtkPDocumentReaderStrategy> reader_strategy;
    if(state.document_partition_strategy == "round-robin")
      {
      reader_strategy.TakeReference(vtkRoundRobinPDocumentReaderStrategy::New());
      document_reader->SetStrategy(reader_strategy);
      }
    else if(state.document_partition_strategy == "sorted-bytes")
      {
      reader_strategy.TakeReference(vtkSortedBytePDocumentReaderStrategy::New());
      document_reader->SetStrategy(reader_strategy);
      }
    else if(state.document_partition_strategy == "unsorted-bytes")
      {
      reader_strategy.TakeReference(vtkUnsortedBytePDocumentReaderStrategy::New());
      document_reader->SetStrategy(reader_strategy);
      }
    else if(state.document_partition_strategy == "document-per-line")
      {
      reader_strategy.TakeReference(vtkDocumentPerLinePDocumentReaderStrategy::New());
      document_reader->SetStrategy(reader_strategy);
      }
    else
      {
      throw std::runtime_error("Unknown document reader partitioning strategy: " + state.document_partition_strategy);
      }

    // Setup mime-type assignment ...
    VTK_CREATE(vtkAssignMimeType, assign_mime_types);
    assign_mime_types->SetInputConnection(0, document_reader->GetOutputPort());
    assign_mime_types->SetDefaultMimeType(state.default_mime_type.c_str());

    // Setup text extraction ...
    VTK_CREATE(vtkTextExtraction, text_extraction);
    text_extraction->SetInputConnection(0, assign_mime_types->GetOutputPort());

    // Setup optional document dictionary import ...
    VTK_CREATE(vtkTableReader, document_dictionary_reader);
    document_dictionary_reader->SetFileName(file_string(state, state.import_document_dictionary).c_str());

    // Setup optional database import ...
    vtkSmartPointer<vtkPGenerateIndexArray> db_table = vtkSmartPointer<vtkPGenerateIndexArray>::New();
    db_table->SetArrayName("document");
    db_table->SetPedigreeID(true);
    db_table->SetController(controller);

    // Create a "handle" for our document dictionary ...
    VTK_CREATE(vtkPassThrough, document_dictionary);
    if(state.import_document_dictionary.size())
      document_dictionary->SetInputConnection(0, document_dictionary_reader->GetOutputPort());
    else if(state.database_url.size())
      {
      document_dictionary->SetInputConnection(0, db_table->GetOutputPort());
      }
    else
      document_dictionary->SetInputConnection(0, text_extraction->GetOutputPort());

    // Setup optional feature table import ...
    VTK_CREATE(vtkTableReader, feature_table_reader);
    feature_table_reader->SetFileName(file_string(state, state.import_feature_table).c_str());

    // Setup tokenization ...
    VTK_CREATE(vtkTokenization, tokenization);
    tokenization->SetInputConnection(0, document_dictionary->GetOutputPort());
    tokenization->MinimumLengthFilter()->SetBegin(0);
    tokenization->MinimumLengthFilter()->SetEnd(state.minimum_token_length);
    tokenization->MaximumLengthFilter()->SetBegin(state.maximum_token_length);
    tokenization->MaximumLengthFilter()->SetEnd(std::numeric_limits<int>::max());
    tokenization->NGramExtraction()->SetN(state.ngram_length);
    if(arguments.count("no-default-stop-words"))
      tokenization->ValueFilter()->ClearValues();
    for(std::vector<std::string>::const_iterator stop_words = state.stop_words.begin(); stop_words != state.stop_words.end(); ++stop_words)
      {
      boost::tokenizer<> tokenizer(*stop_words);
      for(boost::tokenizer<>::iterator stop_word = tokenizer.begin(); stop_word != tokenizer.end(); ++stop_word)
        {
        tokenization->ValueFilter()->AddValue(vtkUnicodeString::from_utf8(*stop_word));
        }
      }

    // Create a "handle" for our feature table ...
    VTK_CREATE(vtkPassThrough, feature_table);
    if(state.import_feature_table.size())
      feature_table->SetInputConnection(0, feature_table_reader->GetOutputPort());
    else
      feature_table->SetInputConnection(0, tokenization->GetOutputPort());

    // Setup feature dictionary creation ...
    vtkSmartPointer<vtkTableAlgorithm> compute_feature_dictionary;
    if(state.feature_dictionary_strategy == "nto1")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryNTo1::New());
      }
    else if(state.feature_dictionary_strategy == "nton")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryNToN::New());
      }
    else if(state.feature_dictionary_strategy == "rr")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryRoundRobin::New());
      }
    else if(state.feature_dictionary_strategy == "bt")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryBinaryTree::New());
      }
    else if(state.feature_dictionary_strategy == "mr")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryMapReduce::New());
      }
    else
      {
      throw std::runtime_error("Unknown feature dictionary strategy: " + state.feature_dictionary_strategy);
      }
    compute_feature_dictionary->SetInputConnection(0, feature_table->GetOutputPort());

    // Setup a "handle" for the unfiltered feature dictionary ...
    VTK_CREATE(vtkPassThrough, unfiltered_feature_dictionary);
    unfiltered_feature_dictionary->SetInputConnection(0, compute_feature_dictionary->GetOutputPort());

    // Setup frequency matrix creation ...
    VTK_CREATE(vtkFrequencyMatrix, compute_frequency_matrix);
    if(state.frequency_matrix_strategy == "global+local")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PLUS_LOCAL);
      }
    else if(state.frequency_matrix_strategy == "global")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL);
      }
    else if(state.frequency_matrix_strategy == "global+presorted")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PRESORTED);
      }
    else
      {
      throw std::runtime_error("Unknown frequency matrix strategy: " + state.frequency_matrix_strategy);
      }
    compute_frequency_matrix->SetInputConnection(0, feature_table->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(1, unfiltered_feature_dictionary->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(2, document_dictionary->GetOutputPort());

    // Setup optional frequency matrix import ...
    VTK_CREATE(vtkArrayReader, frequency_matrix_reader);
    frequency_matrix_reader->SetFileName(file_string(state, state.import_frequency_matrix).c_str());

    // Setup token frequency filtering ...
    VTK_CREATE(vtkPFrequencyMatrixFilter, frequency_matrix_filter);
    frequency_matrix_filter->SetController(controller);
    frequency_matrix_filter->SetInputConnection(0, unfiltered_feature_dictionary->GetOutputPort());
    if(state.import_frequency_matrix.size())
      frequency_matrix_filter->SetInputConnection(1, frequency_matrix_reader->GetOutputPort());
    else
      frequency_matrix_filter->SetInputConnection(1, compute_frequency_matrix->GetOutputPort());
    frequency_matrix_filter->SetMinimumDocumentCount(state.minimum_feature_document_count);
    frequency_matrix_filter->SetMinimumDocumentPercent(state.minimum_feature_document_percent);
    frequency_matrix_filter->SetMinimumFeatureCount(state.minimum_feature_count);

    // Create a "handle" for our filtered feature dictionary ...
    VTK_CREATE(vtkPassThrough, feature_dictionary);
    feature_dictionary->SetInputConnection(0, frequency_matrix_filter->GetOutputPort(0));

    // Create a "handle" for our filtered frequency matrix ...
    VTK_CREATE(vtkPassThrough, frequency_matrix);
    frequency_matrix->SetInputConnection(0, frequency_matrix_filter->GetOutputPort(1));

    // Setup local weighting ...
    VTK_CREATE(vtkBoostLogWeighting, local_weighting);
    local_weighting->SetInputConnection(0, frequency_matrix->GetOutputPort());
    local_weighting->SetBase(vtkBoostLogWeighting::BASE_2);

    // Setup global weighting ...
    vtkSmartPointer<vtkArrayDataAlgorithm> global_weighting;
    if(state.weighting_strategy == "entropy-nto1-sparse")
      {
      global_weighting.TakeReference(vtkPEntropyMatrixWeightingNTo1::New());
      vtkPEntropyMatrixWeightingNTo1::SafeDownCast(global_weighting)->SetDataStructure(vtkPEntropyMatrixWeightingNTo1::VECTOR);
      }
    else if(state.weighting_strategy == "entropy-nto1-dense")
      {
      global_weighting.TakeReference(vtkPEntropyMatrixWeightingNTo1::New());
      vtkPEntropyMatrixWeightingNTo1::SafeDownCast(global_weighting)->SetDataStructure(vtkPEntropyMatrixWeightingNTo1::MAP);
      }
    else if(state.weighting_strategy == "entropy-nton-sparse")
      {
      global_weighting.TakeReference(vtkPEntropyMatrixWeightingNToN::New());
      }
    else
      {
      throw std::runtime_error("Unknown weighting strategy: " + state.weighting_strategy);
      }
    global_weighting->SetInputConnection(0, frequency_matrix->GetOutputPort());

    VTK_CREATE(vtkScaleDimension, global_scaling);
    global_scaling->SetInputConnection(0, local_weighting->GetOutputPort());
    global_scaling->SetInputConnection(1, global_weighting->GetOutputPort());

    // Setup optional weighted matrix import ...
    VTK_CREATE(vtkArrayReader, weighted_matrix_reader);
    weighted_matrix_reader->SetFileName(file_string(state, state.import_weighted_matrix).c_str());

    // Create a "handle" for our weighted matrix ...
    VTK_CREATE(vtkPassThrough, weighted_matrix);
    if(state.import_weighted_matrix.size())
      weighted_matrix->SetInputConnection(0, weighted_matrix_reader->GetOutputPort());
    else
      weighted_matrix->SetInputConnection(0, global_scaling->GetOutputPort());

    // Setup the SVD ...
    VTK_CREATE(vtkTrilinosSVD, svd);
    svd->SetInputConnection(0, weighted_matrix->GetOutputPort());
    if(state.svd_rank == "auto")
      {
      svd->SetRank(5);
      }
    else
      {
      svd->SetRank(boost::lexical_cast<int>(state.svd_rank));
      }
    svd->SetAlignFactorsToData(arguments.count("svd-align-factors"));

    // Optionally export a pipeline diagram ...
    if(state.pipeline_diagram.size())
      {
      if(0 == state.process_id)
        {
        std::ofstream dot_stream(file_string(state, state.pipeline_diagram).c_str());

        vtkSmartPointer<vtkCollection> sinks = vtkSmartPointer<vtkCollection>::New();
        sinks->AddItem(svd);

        vtkPipelineGraphSource::PipelineToDot(sinks, dot_stream, "ParaText Pipeline");
        }
      }

    // Optionally export execution metrics (implicitly executes the entire pipeline) ...
    bool metrics_started = state.export_metrics.size();
    if(state.import_frequency_matrix.size())
      metrics_started = false;
    if(state.import_weighted_matrix.size())
      metrics_started = false;

    bool metrics_stopped = false;

    cpu_timer total_cpu_time;
    wallclock_timer total_wallclock_time;

    // Measure the document reader ...
    if(metrics_started && !metrics_stopped && !state.import_document_dictionary.size() && !state.database_url.size())
      {
      cpu_timer time;
      document_reader->Update();
      export_metric(controller, state, document_reader, "cpu time", time);

      vtkStringArray* const document_array = vtkStringArray::SafeDownCast(vtkTable::SafeDownCast(document_reader->GetOutputDataObject(0))->GetColumnByName("content"));
      const vtkIdType document_count = document_array->GetNumberOfTuples();

      vtkIdType total_document_bytes = 0;
      vtkIdType minimum_document_bytes = std::numeric_limits<vtkIdType>::max();
      vtkIdType maximum_document_bytes = 0;
      for(vtkIdType i = 0; i != document_count; ++i)
        {
        const vtkIdType document_bytes = document_array->GetValue(i).size();
        total_document_bytes += document_bytes;
        minimum_document_bytes = std::min(minimum_document_bytes, document_bytes);
        maximum_document_bytes = std::max(maximum_document_bytes, document_bytes);
        }

      export_metric(controller, state, document_reader, "local document count", document_count, "documents");
      export_metric(controller, state, document_reader, "total document size", total_document_bytes, "bytes");
      export_metric(controller, state, document_reader, "minimum document size", minimum_document_bytes, "bytes");
      export_metric(controller, state, document_reader, "maximum document size", maximum_document_bytes, "bytes");
      export_metric(controller, state, document_reader, "average document size", document_count ? static_cast<double>(total_document_bytes) / document_count : 0, "bytes");
      }

    // Measure MIME type assignment ...
    if(metrics_started && !metrics_stopped && !state.import_document_dictionary.size() && !state.database_url.size())
      {
      cpu_timer time;
      assign_mime_types->Update();
      export_metric(controller, state, assign_mime_types, "cpu time", time);
      }

    // Measure text extraction ...
    if(metrics_started && !metrics_stopped && !state.import_document_dictionary.size() && !state.database_url.size())
      {
      cpu_timer time;
      text_extraction->Update();
      export_metric(controller, state, text_extraction, "cpu time", time);
      }

    // Measure the document dictionary reader ...
    if(metrics_started && !metrics_stopped && state.import_document_dictionary.size() && !state.database_url.size())
      {
      cpu_timer time;
      document_dictionary_reader->Update();
      export_metric(controller, state, document_dictionary_reader, "cpu time", time);
      }

    // Measure the database ...
    if(state.database_url.size())
      {
  if( !state.database_query.size() )
    {
      std::cerr << "ERROR: A database query is required to utilize a database.\n";
    }

  vtkSmartPointer<vtkPRowQueryToTable> db_query_output = vtkSmartPointer<vtkPRowQueryToTable>::New();
  db_query_output->SetCommunicator(controller->GetCommunicator());

  if(controller->GetLocalProcessId() == 0 )
    {
    vtkSQLDatabase* db = vtkSQLDatabase::CreateFromURL(state.database_url.c_str());
    bool openStatus = db->Open(0);
    if (!openStatus)
      {
        std::cerr << "ERROR: Couldn't connect to database!  Last status message: "
            << db->GetLastErrorText() << "\n";
        db->Print(cerr);
        throw std::runtime_error("ERROR: Couldn't connect to database!\n" );
      }

    vtkSQLQuery* query = db->GetQueryInstance();
    query->SetQuery(state.database_query.c_str());

    db_query_output->SetQuery(query);
    db->Delete();
    query->Delete();
    }

  if(metrics_started && !metrics_stopped)
    {
      //export times to complete database query and table creation.
      cpu_timer time;
      db_query_output->Update();
      export_metric(controller, state, db_query_output, "cpu time", time);
    }
  else
    db_query_output->Update();

  vtkTable* text_table = vtkTable::SafeDownCast(db_query_output->GetOutput());
  if( text_table->GetNumberOfColumns() != 1 )
    {
      throw std::runtime_error("ERROR: Query should return a table with a single column of text.\n");
    }

  cpu_timer time2;
  VTK_CREATE(vtkTable, unicode_table);
  vtkUnicodeStringArray* const unicode_array = vtkUnicodeStringArray::New();
  unicode_array->SetName("text");
  unicode_array->SetNumberOfTuples(text_table->GetNumberOfRows());
  unicode_table->AddColumn(unicode_array);
  unicode_array->Delete();

  vtkStringArray* const text_array = vtkStringArray::SafeDownCast( text_table->GetColumn(0));
  for( vtkIdType i = 0; i != text_table->GetNumberOfRows(); ++i )
    {
      unicode_array->SetValue( i, vtkUnicodeString::from_utf8( text_array->GetValue(i)));
    }

  db_table->SetInputData(0, unicode_table);

  if(metrics_started && !metrics_stopped)
    {
      export_metric(controller, state, unicode_table, "cpu time", time2);
      cpu_timer time;
      db_table->Update();
      export_metric(controller, state, db_table, "cpu time", time);
    }
      }

    // Measure document-related metrics ...
    if(metrics_started && !metrics_stopped)
      {
      document_dictionary->Update();
      vtkUnicodeStringArray* const text_array = vtkUnicodeStringArray::SafeDownCast(vtkTable::SafeDownCast(document_dictionary->GetOutputDataObject(0))->GetColumnByName("text"));
      const vtkIdType document_count = text_array->GetNumberOfTuples();

      vtkIdType total_text_characters = 0;
      vtkIdType total_text_bytes = 0;
      vtkIdType minimum_text_characters = std::numeric_limits<vtkIdType>::max();
      vtkIdType minimum_text_bytes = std::numeric_limits<vtkIdType>::max();
      vtkIdType maximum_text_characters = 0;
      vtkIdType maximum_text_bytes = 0;
      for(vtkIdType i = 0; i != document_count; ++i)
        {
        const vtkIdType text_characters = text_array->GetValue(i).character_count();
        const vtkIdType text_bytes = text_array->GetValue(i).byte_count();
        total_text_characters += text_characters;
        total_text_bytes += text_bytes;
        minimum_text_characters = std::min(minimum_text_characters, text_characters);
        minimum_text_bytes = std::min(minimum_text_bytes, text_bytes);
        maximum_text_characters = std::max(maximum_text_characters, text_characters);
        maximum_text_bytes = std::max(maximum_text_bytes, text_bytes);
        }

      export_metric(controller, state, "Text", "local document count", document_count, "documents");
      export_metric(controller, state, "Text", "total characters", total_text_characters, "characters");
      export_metric(controller, state, "Text", "minimum characters", minimum_text_characters, "characters");
      export_metric(controller, state, "Text", "maximum characters", maximum_text_characters, "characters");
      export_metric(controller, state, "Text", "average characters", document_count ? static_cast<double>(total_text_characters) / document_count : 0, "characters");
      export_metric(controller, state, "Text", "total size", total_text_bytes, "bytes");
      export_metric(controller, state, "Text", "minimum size", minimum_text_bytes, "bytes");
      export_metric(controller, state, "Text", "maximum size", maximum_text_bytes, "bytes");
      export_metric(controller, state, "Text", "average size", document_count ? static_cast<double>(total_text_bytes) / document_count : 0, "bytes");
      }

    // Optionally end metric-generation early ...
    if(arguments.count("stop-metrics-at-documents"))
      metrics_stopped = true;

    // Measure tokenization ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      tokenization->Update();
      export_metric(controller, state, tokenization, "cpu time", time);
      export_metric(controller, state, tokenization, "token count", tokenization->GetTokens()->GetNumberOfRows(), "tokens");
      }

    // Measure feature-dictionary creation ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      feature_dictionary->Update();
      export_metric(controller, state, feature_dictionary, "cpu time", time);
      export_metric(controller, state, feature_dictionary, "unique token count", vtkTable::SafeDownCast(feature_dictionary->GetOutput())->GetNumberOfRows(), "tokens");
      }

    // Optionally end metric-generation early ...
    if(arguments.count("stop-metrics-at-feature-dictionary"))
      metrics_stopped = true;

    // Measure frequency matrix computation ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      compute_frequency_matrix->Update();
      export_metric(controller, state, compute_frequency_matrix, "cpu time", time);
      }

    // Measure frequency matrix filtering ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      frequency_matrix_filter->Update();
      export_metric(controller, state, frequency_matrix_filter, "cpu time", time);
      }

    // Pick-up metric export if frequency matrix import is enabled ...
    if(state.import_frequency_matrix.size())
      metrics_started = state.export_metrics.size();

    // Measure frequency matrix import ...
    if(metrics_started && !metrics_stopped && state.import_frequency_matrix.size())
      {
      cpu_timer time;
      frequency_matrix_reader->Update();
      export_metric(controller, state, frequency_matrix_reader, "cpu time", time);
      }

    // Measure common frequency matrix metrics ...
    if(metrics_started && !metrics_stopped)
      {
      frequency_matrix->Update();
      export_metric(controller, state, "Frequency Matrix", "row count", vtkArrayData::SafeDownCast(frequency_matrix->GetOutput())->GetArray(0)->GetExtent(0).GetSize(), "rows");
      export_metric(controller, state, "Frequency Matrix", "column count", vtkArrayData::SafeDownCast(frequency_matrix->GetOutput())->GetArray(0)->GetExtent(1).GetSize(), "columns");
      export_metric(controller, state, "Frequency Matrix", "non null count", vtkArrayData::SafeDownCast(frequency_matrix->GetOutput())->GetArray(0)->GetNonNullSize(), "values");
      export_metric(controller, state, "Frequency Matrix", "row indices", boost::algorithm::replace_all_copy(boost::lexical_cast<std::string>(vtkArrayData::SafeDownCast(frequency_matrix->GetOutput())->GetArray(0)->GetExtent(0)), ", ", "-"), "indices");
      export_metric(controller, state, "Frequency Matrix", "column indices", boost::algorithm::replace_all_copy(boost::lexical_cast<std::string>(vtkArrayData::SafeDownCast(frequency_matrix->GetOutput())->GetArray(0)->GetExtent(1)), ", ", "-"), "indices");
      }

    // Optionally end metric-generation early ...
    if(arguments.count("stop-metrics-at-frequency-matrix"))
      metrics_stopped = true;

    // Measure local-weighting ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      local_weighting->Update();
      export_metric(controller, state, local_weighting, "cpu time", time);
      }

    // Measure global-weighting ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      global_weighting->Update();
      export_metric(controller, state, global_weighting, "cpu time", time);
      }

    // Measure global-scaling ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      global_scaling->Update();
      export_metric(controller, state, global_scaling, "cpu time", time);
      }

    // Pick-up metric export if weighted matrix import is enabled ...
    if(state.import_weighted_matrix.size())
      metrics_started = state.export_metrics.size();

    // Measure weighted matrix import ...
    if(metrics_started && !metrics_stopped && state.import_weighted_matrix.size())
      {
      cpu_timer time;
      weighted_matrix_reader->Update();
      export_metric(controller, state, weighted_matrix_reader, "cpu time", time);
      }

    // Optionally end metric-generation early ...
    if(arguments.count("stop-metrics-at-weighted-matrix"))
      metrics_stopped = true;

    // Measure the SVD ...
    if(metrics_started && !metrics_stopped)
      {
      cpu_timer time;
      svd->Update();
      export_metric(controller, state, svd, "cpu time", time);
      export_metric(controller, state, svd, "effective rank", svd->GetRank(), "rank");
      }

    // Optionally export the database query ...
    if(state.export_db_query_result.size())
      {
      if(state.database_url.size() && state.database_query.size())
        {
        db_table->Update();
        export_artifact(controller, state, vtkTable::SafeDownCast(db_table->GetOutput()), state.export_db_query_result, 20);
        }
      else
        {
        std::cerr << "ERROR: No database or queries were specified to generate the export.\n";
        }
      }

    // Optionally export the document dictionary ...
    if(state.export_document_dictionary.size())
      {
      cpu_timer time;
      document_dictionary->Update();
      export_artifact(controller, state, vtkTable::SafeDownCast(document_dictionary->GetOutput()), state.export_document_dictionary, 50);
      export_metric(controller, state, "Export Document Dictionary", "cpu time", time);
      }

    // Optionally export features ...
    if(state.export_features.size())
      {
      cpu_timer time;
      tokenization->Update();
      export_artifact(controller, state, tokenization->GetTokens(), state.export_features, 20);
      export_metric(controller, state, "Export Features", "cpu time", time);
      }

    // Optionally export the feature dictionary ...
    if(state.export_feature_dictionary.size())
      {
      cpu_timer time;
      feature_dictionary->Update();
      export_artifact(controller, state, vtkTable::SafeDownCast(feature_dictionary->GetOutput()), state.export_feature_dictionary, 20);
      export_metric(controller, state, "Export Feature Dictionary", "cpu time", time);
      }

    // Optionally export the frequency matrix ...
    if(state.export_frequency_matrix.size())
      {
      cpu_timer time;
      frequency_matrix->Update();
      export_artifact(controller, state, vtkArrayData::SafeDownCast(frequency_matrix->GetOutput())->GetArray(0), state.export_frequency_matrix);
      export_metric(controller, state, "Export Frequency Matrix", "cpu time", time);
      }

    // Optionally export the global weighting vector ...
    if(state.export_global_weighting.size())
      {
      cpu_timer time;
      global_weighting->Update();
      export_artifact(controller, state, vtkArrayData::SafeDownCast(global_weighting->GetOutput())->GetArray(0), state.export_global_weighting);
      export_metric(controller, state, "Export Global Weighting", "cpu time", time);
      }

    // Optionally export the weighted matrix ...
    if(state.export_weighted_matrix.size())
      {
      cpu_timer time;
      weighted_matrix->Update();
      export_artifact(controller, state, vtkArrayData::SafeDownCast(weighted_matrix->GetOutput())->GetArray(0), state.export_weighted_matrix);
      export_metric(controller, state, "Export Weighted Matrix", "cpu time", time);
      }

    // Optionally export the left singular vectors ...
    if(state.export_left_singular_vectors.size())
      {
      cpu_timer time;
      svd->Update();
      export_artifact(controller, state, svd->GetOutput()->GetArray(0), state.export_left_singular_vectors);
      export_metric(controller, state, "Export Left Singular Vectors", "cpu time", time);
      }

    // Optionally export the singular values ...
    if(state.export_singular_values.size())
      {
      cpu_timer time;
      svd->Update();
      export_artifact(controller, state, svd->GetOutput()->GetArray(1), state.export_singular_values);
      export_metric(controller, state, "Export Singular Values", "cpu time", time);
      }

    // Optionally export the right singular vectors ...
    if(state.export_right_singular_vectors.size())
      {
      cpu_timer time;
      svd->Update();
      export_artifact(controller, state, svd->GetOutput()->GetArray(2), state.export_right_singular_vectors);
      export_metric(controller, state, "Export Right Singular Vectors", "cpu time", time);
      }

    // Optionally print the right singular vectors ...
    if(state.print_right_singular_vectors.size())
      {
      cpu_timer time;
      svd->Update();
      print_artifact(controller, state, svd->GetOutput()->GetArray(2), state.print_right_singular_vectors);
      export_metric(controller, state, "Print Right Singular Vectors", "cpu time", time);
      }

    // Optionally export aggregated left singular vectors ...
    if(state.export_aggregated_left_singular_vectors.size())
      {
      cpu_timer time;
      svd->Update();
      export_aggregated_artifact(controller, state, svd->GetOutput()->GetArray(0), state.export_aggregated_left_singular_vectors);
      export_metric(controller, state, "Export Aggregated Left Singular Vectors", "cpu time", time);
      }

    // Optionally export aggregated right singular vectors ...
    if(state.export_aggregated_right_singular_vectors.size())
      {
      cpu_timer time;
      svd->Update();
      export_aggregated_artifact(controller, state, svd->GetOutput()->GetArray(2), state.export_aggregated_right_singular_vectors);
      export_metric(controller, state, "Export Aggregated Right Singular Vectors", "cpu time", time);
      }

    // Export total execution time metrics ...
    export_metric(controller, state, "Totals", "cpu time", total_cpu_time);
    export_metric(controller, state, "Totals", "wallclock time", total_wallclock_time);
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
