#!/usr/bin/python

try:
  import couchdb
  if float(couchdb.__version__) < 0.8:
    raise Exception
except:
  print "The Python couchdb module version 0.8 or greater is required.  Get it from http://packages.python.org/CouchDB/index.html ."
  exit(1)

from optparse import OptionParser
from pprint import pprint
import json
import mimetypes
import os

def add_attachments(full_path, relative_path, database, document):
  for child in os.listdir(full_path):
    if child in [".gitattributes"]:
      continue
    child_path = os.path.join(full_path, child)
    if os.path.isdir(child_path):
      add_attachments(child_path, os.path.join(relative_path, child), database, document)
    else:
      content = open(child_path, "r")
      mime_type = mimetypes.guess_type(child_path)
      database.put_attachment(document, content.read(), filename = os.path.join(relative_path, child).replace("\\", "/"), content_type = mime_type[0])

def add_directory(path, object):
  for child in os.listdir(path):
    if child in ["_attachments",".couchapprc","couchapp.json","language"]:
      continue
    child_path = os.path.join(path, child)
    if os.path.isdir(child_path):
      object[child] = {}
      add_directory(child_path, object[child])
    else:
      try:
        object[os.path.splitext(child)[0]] = unicode(open(child_path, "r").read().strip())
      except Exception as e:
        print child_path, e

def main():
  parser = OptionParser()
  parser.add_option("--host", type="string", dest="host", default="http://localhost:5984", help="Specify the database server host.  Default: %default")
  parser.add_option("--database", type="string", dest="database", default="paratext", help="Specify the database name.  Default: %default")
  parser.add_option("--directory", type="string", dest="directory", default="couchdb", help="Specify the path to the ParaText CouchDB directory.  Default: %default")
  (options, arguments) = parser.parse_args()

  server = couchdb.Server(options.host)
  if server.version() != "1.0.1":
    raise Exception("CouchDB 1.0.1 is required.")

  try:
    database = server[options.database]
  except:
    database = server.create(options.database)

  design = {}
  add_directory(options.directory, design)

  if not design.has_key("_id"):
    raise Exception("Missing _id")

  if design["_id"] in database:
    database.delete(database[design["_id"]])
  database.save(design)

  add_attachments(os.path.join(options.directory, "_attachments"), "", database, design)

  print "Visit your new ParaText instance at " + options.host + "/" + options.database + "/_design/paratext/index.html"

if __name__ == "__main__":
  main()
