#!/opt/local/bin/python

import sys
import json

def main():
  while True:
    request = json.loads(sys.stdin.readline())
    json.dump(request, sys.stderr, indent=4)
    sys.stderr.flush()

    string = json.dumps(request, indent=4)
    body = "<html><body><pre>%s</pre></body></html>" % string.replace("\n", "<br>")
    sys.stdout.write("%s\n" % json.dumps({"body":body}))
    sys.stdout.flush()

if __name__ == "__main__":
  main()
