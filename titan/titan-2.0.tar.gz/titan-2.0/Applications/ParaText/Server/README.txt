PARATEXT SERVER
---------------

You will need an instance of CouchDB 1.0.1 or later, and
the Python couchdb module 0.8 or later.  Once they're
installed and Titan has been built, you will need to add
the configuration directives in

  <build>/Applications/ParaText/Server/paratext.ini

to your CouchDB configuration.  You should be able to do
this by linking or copying paratext.ini into your

  <prefix>/etc/couchdb/local.d

directory, or by manually inserting the contents of
paratext.ini into the

  <prefix>/etc/couchdb/local.ini

file.  Then, with CouchDB running, run the following to
setup the CouchDB ParaText database and application:

  $ python paratext-install.py

Note that this and all other scripts can be run with --help
to see command-line options for CouchDB host, database name,
analysis parameters, etc.

Visit the CouchDb server with a web browser to see the newly
installed ParaText instance.  For instance, if your browser
is on the same machine as the CouchDB instance, the URI will
be:

  http://localhost:5984/paratext/_design/paratext/index.html

To import documents for analysis, use the paratext-import.py
command, for example:

  $ python paratext-import.py /path/to/documents

To create an LSA model, use the paratext-lsa-model.py command:

  $ python paratext-lsa-model.py --name "My Analysis" --svd-rank 25

To perform retrieval using an existing LSA model, use
paratext-lsa-query.py:

  $ python paratext-lsa-query.py --model 12346 --query-text "cats bats rats"

Enjoy!
The ParaText Team
