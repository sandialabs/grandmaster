function(keys, values, rereduce)
{
	return sum(values);
}
