function(doc)
{
  if(doc.type != "document")
    return;

  emit(doc.corpus + "-" + doc.file.uri + "-" + doc._id, doc._rev);
}
