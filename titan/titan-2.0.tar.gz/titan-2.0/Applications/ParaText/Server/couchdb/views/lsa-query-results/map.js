function(doc)
{
  if(doc.type != "lsa-query-results")
    return;

  emit(doc.created + "-" + doc._id, null);
}
