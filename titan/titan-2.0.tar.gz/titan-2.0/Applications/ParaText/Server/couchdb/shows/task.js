function(doc, request)
{
	var mustache = require("lib/mustache");
	var template = this.templates.task;
	var view = doc;
  view._db = request.info.db_name;

	result = new Object();
	result.headers = { "Content-Type" : "text/html" };
	result.body = mustache.to_html(template, view);

	return result;
}
