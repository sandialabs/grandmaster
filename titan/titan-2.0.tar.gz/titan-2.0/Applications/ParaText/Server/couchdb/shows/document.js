function(doc, request)
{
  var text_type = new RegExp("^text\/.*$");

  var mustache = require("lib/mustache");
  var template = this.templates.document;
  var view = doc;
  view._db = request.info.db_name;
  view.show_text = (view._attachments && view._attachments.content && view._attachments.content.length < 1000000 && view._attachments.content.content_type && text_type.test(view._attachments.content.content_type));

  result = new Object();
  result.headers = { "Content-Type" : "text/html" };
  result.body = mustache.to_html(template, view);

  return result;
}
