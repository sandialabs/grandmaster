import couchdb
import nltk

class corpus:
  def __init__(self, host, database, corpus):
    self.server = couchdb.Server(host)
    self.database = self.server[database]
    self.corpus = corpus

  def fileids(self):
    results = []
    for row in self.database.view("paratext/documents"):
      document = self.database[row.id]
      if document["corpus"] != self.corpus:
        continue
      results.append(row.id)
    return results

  def raw(self, fileids=None):
    if fileids is None:
      fileids = self.fileids()
    elif isinstance(fileids, basestring):
      fileids = [fileids]

    result = ""
    for f in fileids:
      result += self.database.get_attachment(self.database[f], "content").read()
    return result

  def words(self, fileids=None):
    return nltk.word_tokenize(self.raw(fileids))
