#!/usr/bin/python

from copy import deepcopy
from datetime import datetime
from optparse import OptionParser
from paratext import iso8601
from subprocess import Popen
from titan.Web import vtkJSONArrayWriter, vtkJSONTableWriter
from urlparse import urlparse
from vtk import vtkArrayReader, vtkTableReader
import couchdb
import json
import os
import tempfile
import shutil
import sys
import threading

class worker(threading.Thread):
  def __init__(self, options):
    threading.Thread.__init__(self)
    self.options = options
    self.server = couchdb.Server(options.host)
    self.database = self.server[options.database]

  def run(self):
    self.task = {"_id":self.server.uuids(1)[0],"type":"task","description":"Generate LSA model","started":iso8601.now(),"status":"Starting."}
    self.database.save(self.task)

    self.task["status"] = "Creating work area."
    self.database.save(self.task)

    temp_dir_path = tempfile.mkdtemp()

    file_list_path = os.path.join(temp_dir_path, "files")
    feature_dictionary_path = os.path.join(temp_dir_path, "feature-dictionary")
    frequency_matrix_path = os.path.join(temp_dir_path, "frequency-matrix")
    global_weighting_path = os.path.join(temp_dir_path, "global-weighting")
    weighted_matrix_path = os.path.join(temp_dir_path, "weighted-matrix")
    lsv_path = os.path.join(temp_dir_path, "left-singular-vectors")
    sv_path = os.path.join(temp_dir_path, "singular-values")
    rsv_path = os.path.join(temp_dir_path, "right-singular-vectors")
    metric_path = os.path.join(temp_dir_path, "metrics")

    self.task["status"] = "Generating file list."
    self.database.save(self.task)

    file_list = open(file_list_path, "w")
    document_list = []
    for row in self.database.view("paratext/documents"):
      document = self.database[row.id]
      if document["corpus"] != self.options.corpus:
        continue
      document_list.append(row.id)
      uri = urlparse(document["file"]["uri"])
      if uri.scheme != "file":
        continue
      file_list.write(uri.path + "\n")
    file_list.close()

    self.task["status"] = "Generating model."
    self.database.save(self.task)

    paratext_command = ["paratext-lsa",
      "--file-list", file_list_path,
      "--partition-strategy", self.options.partition_strategy,
      "--default-mime-type", self.options.default_mime_type,
      "--maximum-token-length", self.options.maximum_token_length,
      "--minimum-token-length", self.options.minimum_token_length,
      "--ngram-length", self.options.ngram_length,
      "--minimum-feature-document-count", self.options.minimum_feature_document_count,
      "--minimum-feature-document-percent", self.options.minimum_feature_document_percent,
      "--minimum-feature-count", self.options.minimum_feature_count,
      "--frequency-matrix-strategy", self.options.frequency_matrix_strategy,
      "--svd-rank", self.options.svd_rank,
      "--export-feature-dictionary", feature_dictionary_path,
      "--export-frequency-matrix", frequency_matrix_path,
      "--export-global-weighting", global_weighting_path,
      "--export-weighted-matrix", weighted_matrix_path,
      "--export-left-singular-vectors", lsv_path,
      "--export-singular-values", sv_path,
      "--export-right-singular-vectors", rsv_path,
      "--export-metrics", metric_path
      ]

    sys.stderr.write(str(paratext_command))
    sys.stderr.flush()

    paratext = Popen(paratext_command)
    paratext.wait()

    self.task["status"] = "Storing model."
    self.database.save(self.task)

    model = {"_id":self.server.uuids(1)[0],"type":"lsa-model","created":iso8601.now()}
    model["name"] = self.options.name
    model["partition-strategy"] = self.options.partition_strategy
    model["default-mime-type"] = self.options.default_mime_type
    model["maximum-token-length"] = self.options.maximum_token_length
    model["minimum-token-length"] = self.options.minimum_token_length
    model["ngram-length"] = self.options.ngram_length
    model["minimum-feature-document-count"] = self.options.minimum_feature_document_count
    model["minimum-feature-document-percent"] = self.options.minimum_feature_document_percent
    model["minimum-feature-count"] = self.options.minimum_feature_count
    model["frequency-matrix-strategy"] = self.options.frequency_matrix_strategy
    model["svd-rank"] = self.options.svd_rank

    self.database.save(model)
    self.database.put_attachment(model, json.dumps(document_list), filename="document-list.json", content_type="application/json")
    self.database.put_attachment(model, open(file_list_path, "r").read(), filename="file-list.txt", content_type="text/plain")
    self.database.put_attachment(model, open(feature_dictionary_path, "r").read(), filename="feature-dictionary.vtk", content_type="application/x-vtk-table")
    self.database.put_attachment(model, open(frequency_matrix_path, "r").read(), filename="frequency-matrix.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(model, open(global_weighting_path, "r").read(), filename="global-weighting.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(model, open(weighted_matrix_path, "r").read(), filename="weighted-matrix.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(model, open(lsv_path, "r").read(), filename="left-singular-vectors.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(model, open(sv_path, "r").read(), filename="singular-values.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(model, open(rsv_path, "r").read(), filename="right-singular-vectors.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(model, open(metric_path, "r").read(), filename="metrics.csv", content_type="text/csv")

    reader = vtkTableReader()
    writer = vtkJSONTableWriter()
    writer.SetInputConnection(reader.GetOutputPort())
    writer.SetWriteToOutputString(True)
    writer.SetFormat(1)

    reader.SetFileName(feature_dictionary_path)
    writer.Write()
    self.database.put_attachment(model, writer.GetOutputString(), filename="feature-dictionary.json", content_type="application/json")

    reader = vtkArrayReader()
    writer = vtkJSONArrayWriter()
    writer.SetInputConnection(reader.GetOutputPort())
    writer.SetWriteToOutputString(True)

    reader.SetFileName(frequency_matrix_path)
    writer.Write()
    self.database.put_attachment(model, writer.GetOutputString(), filename="frequency-matrix.json", content_type="application/json")

    reader.SetFileName(weighted_matrix_path)
    writer.Write()
    self.database.put_attachment(model, writer.GetOutputString(), filename="weighted-matrix.json", content_type="application/json")

    reader.SetFileName(lsv_path)
    writer.Write()
    self.database.put_attachment(model, writer.GetOutputString(), filename="left-singular-vectors.json", content_type="application/json")

    reader.SetFileName(sv_path)
    writer.Write()
    self.database.put_attachment(model, writer.GetOutputString(), filename="singular-values.json", content_type="application/json")

    reader.SetFileName(rsv_path)
    writer.Write()
    self.database.put_attachment(model, writer.GetOutputString(), filename="right-singular-vectors.json", content_type="application/json")

    self.task["status"] = "Removing work area."
    self.database.save(self.task)

    shutil.rmtree(temp_dir_path)

    self.task["finished"] = iso8601.now()
    self.task["status"] = "Finished."
    self.database.save(self.task)

def map_option(request, name, option):
  if request["query"].has_key(name):
    return request["query"][name]
  else:
    return option

def main():
  parser = OptionParser()
  parser.add_option("--corpus", type="string", dest="corpus", default="", help="Specify the corpus to analyze.  Default: %default")
  parser.add_option("--database", type="string", dest="database", default="paratext", help="Specify the database name.  Default: %default")
  parser.add_option("--default-mime-type", type="string", dest="default_mime_type", default="text/plain", help="Specify the default mime type.  default: %default")
  parser.add_option("--frequency-matrix-strategy", type="string", dest="frequency_matrix_strategy", default="global+presorted", help="Specify the frequency matrix strategy.  default: %default")
  parser.add_option("--host", type="string", dest="host", default="http://localhost:5984", help="Specify the database server host.  Default: %default")
  parser.add_option("--maximum-token-length arg", dest="maximum_token_length", default="32", help="Specify the maximum allowable token length in characters.  Default: %default")
  parser.add_option("--minimum-feature-count", dest="minimum_feature_count", default="0", help="Specify the minimum number of times a feature must appear across the entire corpus to be analyzed.  Default: %default")
  parser.add_option("--minimum-feature-document-count", dest="minimum_feature_document_count", default="0", help="Specify the minimum number of documents that a feature must appear in to be analyzed.  Default: %default")
  parser.add_option("--minimum-feature-document-percent", dest="minimum_feature_document_percent", default="0", help="Specify the minimum percentage of documents that a feature must appear in to be analyzed.  Default: %default")
  parser.add_option("--minimum-token-length arg", dest="minimum_token_length", default="2", help="Specify the minimum allowable token length in characters.  Default: %default")
  parser.add_option("--name", type="string", dest="name", default="LSA Model", help="Specify a human-readable model name.  Default: %default")
  parser.add_option("--ngram-length", dest="ngram_length", default="1", help="Specify the length of extracted n-grams.  Default: %default")
  parser.add_option("--partition-strategy", dest="partition_strategy", default="round-robin", help="Specify the document partitioning strategy.  Default: %default")
  parser.add_option("--server", action="store_true", dest="server", default=False, help="Serve CouchDB requests instead of executing immediately.  Default: %default")
  parser.add_option("--svd-rank", type="string", dest="svd_rank", default="5", help="SVD rank.  Default: %default")
  (options, arguments) = parser.parse_args()

  if options.server:
    while True:
      line = sys.stdin.readline()
      if len(line) == 0:
        break
      request = json.loads(line)

      request_options = deepcopy(options)
      request_options.host = "http://" + request["headers"]["Host"]
      request_options.database = request["info"]["db_name"]
      request_options.corpus = map_option(request, "corpus", request_options.corpus)
      request_options.frequency_matrix_strategy = map_option(request, "frequency-matrix-strategy", request_options.frequency_matrix_strategy)
      request_options.partition_strategy = map_option(request, "partition-strategy", request_options.partition_strategy)
      request_options.default_mime_type = map_option(request, "default-mime-type", request_options.default_mime_type)
      request_options.maximum_token_length = map_option(request, "maximum-token-length", request_options.maximum_token_length)
      request_options.minimum_feature_count = map_option(request, "minimum-feature-count", request_options.minimum_feature_count)
      request_options.minimum_feature_document_count = map_option(request, "minimum-feature-document-count", request_options.minimum_feature_document_count)
      request_options.minimum_feature_document_percent = map_option(request, "minimum-feature-document-percent", request_options.minimum_feature_document_percent)
      request_options.minimum_token_length = map_option(request, "minimum-token-length", request_options.minimum_token_length)
      request_options.name = map_option(request, "name", request_options.name)
      request_options.ngram_length = map_option(request, "ngram-length", request_options.ngram_length)
      request_options.svd_rank = map_option(request, "svd-rank", request_options.svd_rank)

      worker(request_options).start() # Change "start" to "run" to serialize requests

      response = {"code":202, "json":{"ok":True, "message":"Computing LSA model."}}
      sys.stdout.write("%s\n" % json.dumps(response))
      sys.stdout.flush()
  else:
    worker(options).start()

if __name__ == "__main__":
  main()
