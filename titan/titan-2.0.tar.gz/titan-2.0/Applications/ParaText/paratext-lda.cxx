#include <vtkArrayReader.h>
#include <vtkArrayWriter.h>
#include <vtkAssignMimeType.h>
#include <vtkBoostLogWeighting.h>
#include "vtkCleanupNonUTF8TextExtractionStrategy.h"
#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkDocumentPerLinePDocumentReaderStrategy.h>
#include <vtkFrequencyMatrix.h>
#include <vtkMPIController.h>
#include <vtkNGramExtraction.h>
#include <vtkPassThrough.h>
#include <vtkPDocumentReader.h>
#include <vtkPEntropyMatrixWeightingNTo1.h>
#include <vtkPEntropyMatrixWeightingNToN.h>
#include <vtkPFrequencyMatrixFilter.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkPLatentDirichletAllocation.h>
#include <vtkPRowQueryToTable.h>
#include <vtkPTermDictionaryNTo1.h>
#include <vtkPTermDictionaryNToN.h>
#include <vtkPTermDictionaryBinaryTree.h>
#include <vtkPTermDictionaryRoundRobin.h>
#include <vtkPTermDictionaryMapReduce.h>
#include <vtkRoundRobinPDocumentReaderStrategy.h>
#include <vtkScaleDimension.h>
#include <vtkSmartPointer.h>
#include <vtkSortedBytePDocumentReaderStrategy.h>
#include <vtkSQLDatabase.h>
#include <vtkSQLQuery.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkTextExtraction.h>
#include <vtkTimerLog.h>
#include <vtkTokenLengthFilter.h>
#include <vtkTokenization.h>
#include <vtkUnsortedBytePDocumentReaderStrategy.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>

#include <boost/program_options/errors.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

#define MEASURE_STAGE(filter)             \
  { \
  cpu_timer filter##_cpu_time; \
  wallclock_timer filter##_wallclock_time; \
  filter->Update(); \
  if (metrics_enabled) \
    { \
    export_metric(controller, state, filter, "cpu time", filter##_cpu_time); \
    export_metric(controller, state, filter, "wallclock time", filter##_wallclock_time); \
    } \
  }

// ----------------------------------------------------------------------

/// Helper class for managing timing.
class cpu_timer
{
public:
  cpu_timer() :
    start_time(vtkTimerLog::GetCPUTime())
  {
  }

  const double elapsed() const
  {
    return vtkTimerLog::GetCPUTime() - this->start_time;
  }

  void reset()
  {
    this->start_time = vtkTimerLog::GetCPUTime();
  }

private:
  double start_time;
};

class wallclock_timer
{
public:
  wallclock_timer() :
    start_time(vtkTimerLog::GetUniversalTime())
  {
  }

  const double elapsed() const
  {
    return vtkTimerLog::GetUniversalTime() - this->start_time;
  }

  void reset()
  {
    this->start_time = vtkTimerLog::GetUniversalTime();
  }

private:
  double start_time;
};

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  std::map<std::string, int> component_indices;
  std::map<std::string, std::map<std::string, int> > metric_indices;

  int minimum_token_length;
  int maximum_token_length;
  int minimum_feature_count;
  int minimum_feature_document_count;
  double minimum_feature_document_percent;
  int ngram_length;
  std::string database_query;
  std::string database_url;
  std::string default_mime_type;
  std::string document_partition_strategy;
  std::string feature_dictionary_strategy;
  std::string frequency_matrix_strategy;
  std::string import_document_dictionary;
  std::string import_filtered_frequency_matrix;
  std::string import_unfiltered_frequency_matrix;
  std::string import_filtered_feature_dictionary;
  std::string import_unfiltered_feature_dictionary;
  std::string metric_format;
  std::string pipeline_diagram;
  std::string lda_topics;
  std::string lda_alpha;
  std::string lda_beta;
  std::string top_topics;
  std::string top_terms_per_topic;
  std::string burn_in_iterations;
  std::string sampling_iterations;
  std::vector<std::string> columns_to_export;
  std::vector<std::string> document_directories;
  std::vector<std::string> document_files;
  std::vector<std::string> file_lists;
  std::vector<std::string> document_recursive_directories;
  std::vector<std::string> export_aggregated_theta;
  std::vector<std::string> export_aggregated_phi;
  std::vector<std::string> export_db_query_result;
  std::vector<std::string> export_document_dictionary;
  std::vector<std::string> export_unfiltered_feature_dictionary;
  std::vector<std::string> export_filtered_feature_dictionary;
  std::vector<std::string> export_features;
  std::vector<std::string> export_unfiltered_frequency_matrix;
  std::vector<std::string> export_filtered_frequency_matrix;
  std::vector<std::string> export_metrics;
  std::vector<std::string> export_selected_columns;
  std::vector<std::string> export_theta;
  std::vector<std::string> export_phi;
  std::vector<std::string> export_top_topics;
  std::vector<std::string> export_top_terms_per_topic;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};

/// Provides simple variable expansion for a given string, mainly used so we
/// can generate processor-specific filenames when exporting data.
std::string file_string(const program_state& State, const std::string& String)
{
  boost::format format(String);
  format.exceptions(boost::io::all_error_bits ^ boost::io::too_many_args_bit);
  format % to_iso_string(State.timestamp);
  format % State.process_id;
  format % State.process_count;

  return str(format);
}

/// Write a metric to a stream.
template<typename T>
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const T& Value, const std::string& Units, std::ostream& Stream)
{
  State.component_indices.insert(std::make_pair(Component, State.component_indices.size()));
  State.metric_indices.insert(std::make_pair(Component, std::map<std::string, int>()));
  State.metric_indices[Component].insert(std::make_pair(Metric, State.metric_indices[Component].size()));

  boost::format format(State.metric_format);
  format.exceptions(boost::io::all_error_bits ^ boost::io::too_many_args_bit);
  format % to_iso_string(State.timestamp);
  format % State.process_id;
  format % State.process_count;
  format % State.component_indices[Component];
  format % State.metric_indices[Component][Metric];
  format % Component;
  format % Metric;
  format % Value;
  format % Units;

  for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
    {
    if(i == Controller->GetLocalProcessId())
      {
      Stream << str(format) << std::endl;
      }
    Controller->Barrier();
    }
}



// ----------------------------------------------------------------------



/// Write a metric to a variety of possible output locations.
template<typename T>
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const T& Value, const std::string& Units)
{
  for(std::vector<std::string>::const_iterator location = State.export_metrics.begin(); location != State.export_metrics.end(); ++location)
    {
    // Write the metric to stdout ...
    if(*location == "-")
      {
      export_metric<T>(Controller, State, Component, Metric, Value, Units, std::cerr);
      }
    // Write the metric to a file ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str(), std::ios::out | std::ios::app);
      export_metric<T>(Controller, State, Component, Metric, Value, Units, stream);
      }
    }
}

/// Write a metric to a variety of possible output locations.
template<typename T>
void export_metric(vtkMultiProcessController* Controller, program_state& State, vtkObject* Component, const std::string& Metric, const T& Value, const std::string& Units)
{
  export_metric<T>(Controller, State, Component->GetClassName(), Metric, Value, Units);
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, vtkObject* Component, const std::string& Metric, const cpu_timer& Time)
{
  export_metric(Controller, State, Component->GetClassName(), Metric, Time.elapsed(), "seconds");
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const cpu_timer& Time)
{
  export_metric(Controller, State, Component, Metric, Time.elapsed(), "seconds");
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, const std::string& Component, const std::string& Metric, const wallclock_timer& Time)
{
  export_metric(Controller, State, Component, Metric, Time.elapsed(), "seconds");
}

/// Write a metric to a variety of possible output locations.
void export_metric(vtkMultiProcessController* Controller, program_state& State, vtkObject* Component, const std::string& Metric, const wallclock_timer& Time)
{
  export_metric(Controller, State, Component->GetClassName(), Metric, Time.elapsed(), "seconds");
}


// ----------------------------------------------------------------------



/// Write a table to a variety of possible output locations.
void export_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkTable* Table, const std::vector<std::string>& Locations, const vtkIdType ColumnWidth)
{
  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    // Write the table to stdout ...
    if(*location == "-")
      {
      for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
        {
        if(i == Controller->GetLocalProcessId())
          {
          std::cout << "Process " << i << " of " << Controller->GetNumberOfProcesses() << "\n";
          Table->Dump(ColumnWidth);
          }
        Controller->Barrier();
        }
      }
    // Write the table to a file in VTK ASCII format ...
    else
      {
      VTK_CREATE(vtkTableWriter, table_writer);
      table_writer->SetInputData(0, Table);
      table_writer->SetFileName(file_string(State, *location).c_str());
      table_writer->Write();
      }
    }
}



// ----------------------------------------------------------------------



/// Write an array to a variety of possible output locations.
void export_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkArray* Array, const std::vector<std::string>& Locations)
{
  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    // Write the array to stdout ...
    if(*location == "-")
      {
      for(vtkIdType i = 0; i != Controller->GetNumberOfProcesses(); ++i)
        {
        if(i == Controller->GetLocalProcessId())
          {
          std::cout << "Process " << i << " of " << Controller->GetNumberOfProcesses() << "\n";
          vtkArrayWriter::Write(Array, std::cout, false);
          }
        Controller->Barrier();
        }
      }
    // Write the array to a file in VTK ASCII format ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str());
      vtkArrayWriter::Write(Array, stream, false);
      }
    }
}



// ----------------------------------------------------------------------



/// Aggregate an array and write it to a variety of possible output locations.
void export_aggregated_artifact(vtkMultiProcessController* Controller, const program_state& State, vtkArray* Array, const std::vector<std::string>& Locations)
{
  // Consolidate the distributed array on the local process ...
  vtkSmartPointer<vtkArray> array = vtkSmartPointer<vtkArray>::Take(vtkDistributedArray::GatherArray(Controller, Array, 0));

  if(0 != Controller->GetLocalProcessId())
    return;

  for(std::vector<std::string>::const_iterator location = Locations.begin(); location != Locations.end(); ++location)
    {
    // Write the array to stdout ...
    if(*location == "-")
      {
      vtkArrayWriter::Write(array, std::cout, false);
      }
    // Write the array to a file in VTK ASCII format ...
    else
      {
      std::ofstream stream(file_string(State, *location).c_str());
      vtkArrayWriter::Write(array, stream, false);
      }
    }
}

// ----------------------------------------------------------------------

void
export_frequency_matrix_statistics(vtkMPIController *controller,
                                   program_state &state,
                                   vtkArray *matrix,
                                   const char *matrix_name)
{
  export_metric(controller, state, matrix_name, "row count", matrix->GetExtent(0).GetSize(), "rows");
  export_metric(controller, state, matrix_name, "column count", matrix->GetExtent(1).GetSize(), "columns");
  export_metric(controller, state, matrix_name, "non-null values", matrix->GetNonNullSize(), "values");
  export_metric(controller, state, matrix_name, "row indices", boost::algorithm::replace_all_copy(boost::lexical_cast<std::string>(matrix->GetExtent(0)), ", ", "-"), "indices");
  export_metric(controller, state, matrix_name, "column indices", boost::algorithm::replace_all_copy(boost::lexical_cast<std::string>(matrix->GetExtent(1)), ", ", "-"), "indices");
}


// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  VTK_CREATE(vtkTable, saved_filtered_feature_dictionary);

  try
    {
    /// Setup command-line arguments ...

    state.metric_format = "%2%,%|5t|%3%,%|10t|%6%,%|45t|%7%,%|70t|%8%,%|85t|%9%";

    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("database-query", boost::program_options::value<std::string>(&state.database_query), "Specify the database query to use when pulling documents.  Must contain EXACTLY ONE string column named 'contents', EXACTLY ONE string column named 'uri', and anything else you want.")
      ("database-url", boost::program_options::value<std::string>(&state.database_url), "Specify the database url for pulling documents.")
      ("directory", boost::program_options::value<std::vector<std::string> >(&state.document_directories), "Adds a directory to the list of inputs to be processed.")
      ("default-mime-type", boost::program_options::value<std::string>(&state.default_mime_type)->default_value("text/plain"), "Default MIME type for documents whose MIME type isn't detected automatically.")
      ("export-db-query-result", boost::program_options::value<std::vector<std::string> >(&state.export_db_query_result), "Writes the results of the database query to a file.  Use '-' for stdout.")
      ("export-document-dictionary", boost::program_options::value<std::vector<std::string> >(&state.export_document_dictionary), "Writes the document dictionary to a file.  Use '-' for stdout.")
      ("export-unfiltered-feature-dictionary", boost::program_options::value<std::vector<std::string> >(&state.export_unfiltered_feature_dictionary), "Writes the feature dictionary (before token frequency filtering) to a file.  Use '-' for stdout.")
      ("export-filtered-feature-dictionary", boost::program_options::value<std::vector<std::string> >(&state.export_filtered_feature_dictionary), "Writes the feature dictionary (after token frequency filtering) to a file.  Use '-' for stdout.")
      ("export-features", boost::program_options::value<std::vector<std::string> >(&state.export_features), "Writes features (tokens) to a file.  Use '-' for stdout.")
      ("export-unfiltered-frequency-matrix", boost::program_options::value<std::vector<std::string> >(&state.export_unfiltered_frequency_matrix), "Writes the frequency matrix (before token frequency filtering) to a file.  Use '-' for stdout.")
      ("export-filtered-frequency-matrix", boost::program_options::value<std::vector<std::string> >(&state.export_filtered_frequency_matrix), "Writes the frequency matrix (after token frequency filtering) to a file.  Use '-' for stdout.")
      ("export-metrics", boost::program_options::value<std::vector<std::string> >(&state.export_metrics), "Writes execution metrics to a file.  Use '-' for stdout.")
      ("export-selected-columns", boost::program_options::value<std::vector<std::string> >(&state.export_selected_columns), "Writes the selected dictionary columns to a file.  Use '-' for stdout.  Use '--select-dictionary-column' to identify columns to write.")
      ("export-aggregated-theta", boost::program_options::value<std::vector<std::string> >(&state.export_aggregated_theta), "Writes entire theta matrix to a file.  Use '-' for stdout.")
      ("export-theta", boost::program_options::value<std::vector<std::string> >(&state.export_theta), "Writes theta to a file.  Use '-' for stdout.")
      ("export-aggregated-phi", boost::program_options::value<std::vector<std::string> >(&state.export_aggregated_phi), "Writes entire phi matrix to a single file.  Use '-' for stdout.")
      ("export-phi", boost::program_options::value<std::vector<std::string> >(&state.export_phi), "Writes phi to a file.  Use '-' for stdout.")
      ("export-top-topics", boost::program_options::value<std::vector<std::string> >(&state.export_top_topics), "Writes the top topics to the file specified.")
      ("export-top-terms-per-topic", boost::program_options::value<std::vector<std::string> >(&state.export_top_terms_per_topic), "Writes the top terms per topic to the file specified.")
      ("feature-dictionary-strategy", boost::program_options::value<std::string>(&state.feature_dictionary_strategy)->default_value("mr"), "Feature dictionary strategy. Valid values are 'nto1', 'nton', 'rr', 'bt', and 'mr'.")
      ("file,f", boost::program_options::value<std::vector<std::string> >(&state.document_files), "Adds a file to the list of inputs to be processed.")
      ("file-list,l", boost::program_options::value<std::vector<std::string> >(&state.file_lists), "Adds a file containing a line-delimited list of files to the list of inputs to be processed.")
      ("frequency-matrix-strategy", boost::program_options::value<std::string>(&state.frequency_matrix_strategy)->default_value("global+local"), "Frequency matrix strategy. Valid values are 'global+local', global+presorted, and 'global'.")
      ("help,h", "Prints this help message and exits.")
      ("import-document-dictionary", boost::program_options::value<std::string>(&state.import_document_dictionary), "Import the document dictionary from a file instead of reading individual documents.")
      ("import-unfiltered-feature-dictionary", boost::program_options::value<std::string>(&state.import_unfiltered_feature_dictionary), "Read feature dictionary (before token frequency filtering) from a file.")
      ("import-filtered-feature-dictionary", boost::program_options::value<std::string>(&state.import_filtered_feature_dictionary), "Read feature dictionary (after token frequency filtering) from a file.")
      ("import-unfiltered-frequency-matrix", boost::program_options::value<std::string>(&state.import_unfiltered_frequency_matrix), "Import the frequency matrix from a file instead of computing it based on input documents.  Token frequency filtering will still be performed.  You must also use --import-unfiltered-feature-dictionary.")
      ("import-filtered-frequency-matrix", boost::program_options::value<std::string>(&state.import_filtered_frequency_matrix), "Import the frequency matrix from a file instead of computing it based on input documents.  Token frequency filtering will NOT be performed.  You must also use --import-filtered-feature-dictionary.")
      ("maximum-token-length", boost::program_options::value<int>(&state.maximum_token_length)->default_value(32), "Specify the maximum allowable token length in characters.")
      ("metric-format", boost::program_options::value<std::string>(&state.metric_format), "Defines the format for output metrics.")
      ("minimum-feature-count", boost::program_options::value<int>(&state.minimum_feature_count)->default_value(0), "Specify the minimum number of times a feature must appear across the entire corpus to be analyzed.")
      ("minimum-feature-document-count", boost::program_options::value<int>(&state.minimum_feature_document_count)->default_value(0), "Specify the minimum number of documents that a feature must appear in to be analyzed.")
      ("minimum-feature-document-percent", boost::program_options::value<double>(&state.minimum_feature_document_percent)->default_value(0), "Specify the minimum percentage of documents that a feature must appear in to be analyzed.")
      ("minimum-token-length", boost::program_options::value<int>(&state.minimum_token_length)->default_value(2), "Specify the minimum allowable token length in characters.")
      ("ngram-length", boost::program_options::value<int>(&state.ngram_length)->default_value(1), "Specify the length of extracted n-grams.")
      ("partition-strategy", boost::program_options::value<std::string>(&state.document_partition_strategy)->default_value("round-robin"), "Document reader partitioning strategy. Valid values are 'round-robin', 'sorted-bytes', and 'unsorted-bytes'.")
      ("pipeline-diagram", boost::program_options::value<std::string>(&state.pipeline_diagram), "Writes a pipeline diagram as a GraphViz dot file.")
      ("recursive-directory", boost::program_options::value<std::vector<std::string> >(&state.document_recursive_directories), "Adds a directory and all its subdirectories to the list of inputs to be processed.")
      ("select-dictionary-column", boost::program_options::value<std::vector<std::string> >(&state.columns_to_export), "Select a column from the document dictionary to be written out to a file.  Can be specified multiple times.  Use '--export-selected-columns' to specify the destination.")
      ("lda-topics", boost::program_options::value<std::string>(&state.lda_topics)->default_value("auto"), "Specifies the number of topics to be used as an integer, or 'auto'.")
      ("lda-alpha", boost::program_options::value<std::string>(&state.lda_alpha)->default_value("auto"), "Specifies the alpha value to be used by lda, or 'auto'.")
      ("lda-beta", boost::program_options::value<std::string>(&state.lda_beta)->default_value("auto"), "Specifies the beta value to be used by lda, or 'auto'.")
      ("top-topics", boost::program_options::value<std::string>(&state.top_topics)->default_value("auto"), "Specifies the number of top topics to be written as an integer, or 'auto'.")
      ("top-terms-per-topic", boost::program_options::value<std::string>(&state.top_terms_per_topic)->default_value("auto"), "Specifies the number of terms per topics to be written as an integer, or 'auto'.")
      ("burn-in-iterations", boost::program_options::value<std::string>(&state.burn_in_iterations)->default_value("auto"), "Specifies the number of burn-in iterations for LDA (integer, or 'auto').")
      ("sampling-iterations", boost::program_options::value<std::string>(&state.sampling_iterations)->default_value("auto"), "Specifies the number of sampling iterations for LDA (integer, or 'auto').")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("file", -1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        std::cout << "Filenames are expanded using printf-like formatting.  Special %n% arguments will be expanded as follows:\n\n";
        std::cout << "  %1% - timestamp in ISO format\n";
        std::cout << "  %2% - process id\n";
        std::cout << "  %3% - process count\n";
        std::cout << "\n";
        std::cout << "Metrics are expanded using printf-like formatting.  Special %n% arguments will be expanded as follows:\n\n";
        std::cout << "  %1% - timestamp in ISO format\n";
        std::cout << "  %2% - process id\n";
        std::cout << "  %3% - process count\n";
        std::cout << "  %4% - component index\n";
        std::cout << "  %5% - metric index\n";
        std::cout << "  %6% - component name\n";
        std::cout << "  %7% - metric name\n";
        std::cout << "  %8% - metric value\n";
        std::cout << "  %9% - metric units\n";
        std::cout << "\n";
        std::cout << "Examples:\n";
        std::cout << "\n";
        std::cout << "paratext-lda --file A --directory B --export-feature-dictionary=C\n";
        std::cout << "  Loads file A and the contents of directory B, writing a feature-dictionary to file C\n";
        std::cout << "\n";
        std::cout << "mpiexec -np 4 paratext-lda --recursive-directory D --export-theta=E%2%.txt\n";
        std::cout << "  Using four processors, recursively loads the contents of directory D, writing theta files\n";
        std::cout << "  for each processor, named E0.txt, E1.txt, E2.txt, and E3.txt.\n";
        std::cout << "\n";
        }

      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText version 0.1\n";
      throw early_exit();
      }

    // First we're going to set up the pipeline objects.  Then we'll
    // make all the connections.  Only after that's done will we go
    // back and configure the various filters.  This is all to keep
    // the code easy to read.

    // ---------- Input Filters
    // These handle reading documents from files
    VTK_CREATE(vtkPDocumentReader, document_reader);
    vtkSmartPointer<vtkPDocumentReaderStrategy> reader_strategy;
    VTK_CREATE(vtkAssignMimeType, assign_mime_types);
    VTK_CREATE(vtkTextExtraction, text_extraction);

    // These are for reading documents from a database
    VTK_CREATE(vtkPRowQueryToTable, database_query_reader);
    database_query_reader->SetCommunicator( controller->GetCommunicator() );
    VTK_CREATE(vtkPGenerateIndexArray, database_document_labeler);

    // This is in case we read our documents from a pre-saved file
    VTK_CREATE(vtkTableReader, document_dictionary_reader);

    // This is a convenience placeholder -- a common endpoint for the
    // document importers

    // Placeholder for the output of a database query or document
    // reader
//    vtkSmartPointer<vtkAlgorithm> raw_document_dictionary;
    VTK_CREATE(vtkPassThrough, raw_document_dictionary);

    // -------- Document Processing Filters -------
    // This is a metafilter that tokenizes, filters on length,
    // and removes stop words
    VTK_CREATE(vtkTokenization, tokenization);
    // We'll fill this in with one of several algorithms
    vtkSmartPointer<vtkTableAlgorithm> compute_feature_dictionary;
    VTK_CREATE(vtkTableReader, unfiltered_feature_dictionary_reader);
//    vtkSmartPointer<vtkAlgorithm> unfiltered_feature_dictionary;
    VTK_CREATE(vtkPassThrough, unfiltered_feature_dictionary);
    VTK_CREATE(vtkTableReader, filtered_feature_dictionary_reader);
//    vtkSmartPointer<vtkAlgorithm> filtered_feature_dictionary;
    VTK_CREATE(vtkPassThrough, filtered_feature_dictionary);

    // Compute frequency matrix from scratch
    VTK_CREATE(vtkFrequencyMatrix, compute_frequency_matrix);
    // Read precomputed frequency matrix
    VTK_CREATE(vtkArrayReader, unfiltered_frequency_matrix_reader);
    VTK_CREATE(vtkArrayReader, filtered_frequency_matrix_reader);
    // Another common endpoint to make things simple
//    vtkSmartPointer<vtkAlgorithm> unfiltered_frequency_matrix;
    VTK_CREATE(vtkPassThrough, unfiltered_frequency_matrix);

    // -------- Token Frequency Filtering ---------
    // Remove tokens that occur in too few documents or too few times
    // overall
    VTK_CREATE(vtkPFrequencyMatrixFilter, token_frequency_filter);
//    vtkSmartPointer<vtkAlgorithm> filtered_frequency_matrix;
    VTK_CREATE(vtkPassThrough, filtered_frequency_matrix);

    // -------- Text Processing -------------------
    // LDA engine
    VTK_CREATE(vtkPLatentDirichletAllocation, lda);


    // ------------------------------------------------------------
    //
    // User-Selectable Strategies
    //
    // ------------------------------------------------------------

    // First we have to fill in the document reader and feature
    // dictionary creation strategies

    if(state.document_partition_strategy == "round-robin")
      {
      reader_strategy.TakeReference(vtkRoundRobinPDocumentReaderStrategy::New());
      }
    else if(state.document_partition_strategy == "sorted-bytes")
      {
      reader_strategy.TakeReference(vtkSortedBytePDocumentReaderStrategy::New());
      }
    else if(state.document_partition_strategy == "unsorted-bytes")
      {
      reader_strategy.TakeReference(vtkUnsortedBytePDocumentReaderStrategy::New());
      }
    else if(state.document_partition_strategy == "document-per-line")
      {
      reader_strategy.TakeReference(vtkDocumentPerLinePDocumentReaderStrategy::New());
      }
    else
      {
      throw std::runtime_error("Unknown document reader partitioning strategy: " + state.document_partition_strategy);
      }

    if(state.feature_dictionary_strategy == "nto1")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryNTo1::New());
      }
    else if(state.feature_dictionary_strategy == "nton")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryNToN::New());
      }
    else if(state.feature_dictionary_strategy == "rr")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryRoundRobin::New());
      }
    else if(state.feature_dictionary_strategy == "bt")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryBinaryTree::New());
      }
    else if(state.feature_dictionary_strategy == "mr")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryMapReduce::New());
      }
    else
      {
      throw std::runtime_error("Unknown feature dictionary strategy: " + state.feature_dictionary_strategy);
      }


    // ------------------------------------------------------------
    //
    // Pipeline Connection
    //
    // ------------------------------------------------------------


    // Now we can go about hooking up the rest of the pipeline.  We're
    // going to do the individual pipeline segments and then at the
    // end hook up the placeholders that depend on which data source
    // has been chosen.
    document_reader->SetStrategy(reader_strategy);
    assign_mime_types->SetInputConnection(0, raw_document_dictionary->GetOutputPort());
    text_extraction->SetInputConnection(0, assign_mime_types->GetOutputPort());
    database_document_labeler->SetInputConnection(0, database_query_reader->GetOutputPort());
    tokenization->SetInputConnection(0, text_extraction->GetOutputPort());
    compute_feature_dictionary->SetInputConnection(0, tokenization->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(0, tokenization->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(1, unfiltered_feature_dictionary->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(2, text_extraction->GetOutputPort());

    token_frequency_filter->SetInputConnection(0, unfiltered_feature_dictionary->GetOutputPort());
    token_frequency_filter->SetInputConnection(1, unfiltered_frequency_matrix->GetOutputPort());
    lda->SetInputConnection(0, filtered_frequency_matrix->GetOutputPort());

    if (state.import_document_dictionary.size())
      {
      raw_document_dictionary->SetInputConnection(0, document_dictionary_reader->GetOutputPort());
      }
    else if (state.database_url.size())
      {
      raw_document_dictionary->SetInputConnection(0, database_document_labeler->GetOutputPort());
      }
    else // reading documents from files
      {
      raw_document_dictionary->SetInputConnection(0, document_reader->GetOutputPort());
      }

    if (state.import_unfiltered_feature_dictionary.size())
      {
      unfiltered_feature_dictionary->SetInputConnection(0, unfiltered_feature_dictionary_reader->GetOutputPort(0));
      }
    else
      {
      unfiltered_feature_dictionary->SetInputConnection(0, compute_feature_dictionary->GetOutputPort(0));
      }

    if (state.import_filtered_feature_dictionary.size())
      {
      filtered_feature_dictionary->SetInputConnection(0, filtered_feature_dictionary_reader->GetOutputPort());
      }
    else
      {
      filtered_feature_dictionary->SetInputConnection(0, token_frequency_filter->GetOutputPort(0));
      }

    if (state.import_unfiltered_frequency_matrix.size())
      {
      unfiltered_frequency_matrix->SetInputConnection(0, unfiltered_frequency_matrix_reader->GetOutputPort());
      }
    else
      {
      unfiltered_frequency_matrix->SetInputConnection(0, compute_frequency_matrix->GetOutputPort());
      }

    if (state.import_filtered_frequency_matrix.size())
      {
      filtered_frequency_matrix->SetInputConnection(0, filtered_frequency_matrix_reader->GetOutputPort());
      }
    else
      {
      filtered_frequency_matrix->SetInputConnection(0, token_frequency_filter->GetOutputPort(1));
      }

    // ------------------------------------------------------------
    //
    // Pipeline Configuration
    //
    // ------------------------------------------------------------

//    text_extraction->ClearStrategies();
//    VTK_CREATE(vtkCleanupNonUTF8TextExtractionStrategy, text_strategy);
    vtkCleanupNonUTF8TextExtractionStrategy *text_strategy =
      vtkCleanupNonUTF8TextExtractionStrategy::New();
    text_extraction->PrependStrategy(text_strategy);
    text_strategy->Delete();

    // We want most of these to release their data automatically.
    // There are only a few (the placeholder endpoints, and not even
    // all of those) where we want it to happen differently.
    document_reader->SetReleaseDataFlag(1);
    assign_mime_types->SetReleaseDataFlag(1);
    text_extraction->SetReleaseDataFlag(1);
    database_query_reader->SetReleaseDataFlag(1);
    database_document_labeler->SetReleaseDataFlag(1);
    document_dictionary_reader->SetReleaseDataFlag(1);
    raw_document_dictionary->SetReleaseDataFlag(1);
    tokenization->SetReleaseDataFlag(1);
    compute_feature_dictionary->SetReleaseDataFlag(1);
    unfiltered_feature_dictionary_reader->SetReleaseDataFlag(1);
    filtered_feature_dictionary_reader->SetReleaseDataFlag(1);
    compute_frequency_matrix->SetReleaseDataFlag(1);
    unfiltered_frequency_matrix_reader->SetReleaseDataFlag(1);
    filtered_frequency_matrix_reader->SetReleaseDataFlag(1);
    token_frequency_filter->SetReleaseDataFlag(1);
    lda->SetReleaseDataFlag(1);

#if 0
    unfiltered_feature_dictionary->SetDeepCopyInput(1);
    filtered_feature_dictionary->SetDeepCopyInput(1);
    unfiltered_frequency_matrix->SetDeepCopyInput(1);
    filtered_frequency_matrix->SetDeepCopyInput(1);
#endif

    database_document_labeler->SetController(controller);
    token_frequency_filter->SetController(controller);
    lda->SetController(controller);

    // Set up all the places for reading documents
    for(int i = 0; i != state.document_files.size(); ++i)
      {
      document_reader->AddFile(state.document_files[i].c_str());
      }
    for(int i = 0; i != state.document_directories.size(); ++i)
      {
      document_reader->AddDirectory(state.document_directories[i].c_str());
      }
    for(int i = 0; i != state.document_recursive_directories.size(); ++i)
      {
      document_reader->AddRecursiveDirectory(state.document_recursive_directories[i].c_str());
      }
    for(int i = 0; i != state.file_lists.size(); ++i)
      {
      std::ifstream list(state.file_lists[i].c_str());
      std::string file;
      for(std::getline(list, file); list; std::getline(list, file))
        document_reader->AddFile(file.c_str());
      }

    assign_mime_types->SetDefaultMimeType(state.default_mime_type.c_str());
    document_dictionary_reader->SetFileName(file_string(state, state.import_document_dictionary).c_str());
    database_document_labeler->SetArrayName("document");
    database_document_labeler->SetPedigreeID(true);
    tokenization->MinimumLengthFilter()->SetBegin(0);
    tokenization->MinimumLengthFilter()->SetEnd(state.minimum_token_length);
    tokenization->MaximumLengthFilter()->SetBegin(state.maximum_token_length);
    tokenization->MaximumLengthFilter()->SetEnd(std::numeric_limits<int>::max());
    tokenization->NGramExtraction()->SetN(state.ngram_length);
    if(state.frequency_matrix_strategy == "global+local")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PLUS_LOCAL);
      }
    else if(state.frequency_matrix_strategy == "global+presorted")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PRESORTED);
      }
    else if(state.frequency_matrix_strategy == "global")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL);
      }
    else
      {
      throw std::runtime_error("Unknown frequency matrix strategy: " + state.frequency_matrix_strategy);
      }
    unfiltered_frequency_matrix_reader->SetFileName(file_string(state, state.import_unfiltered_frequency_matrix).c_str());
    filtered_frequency_matrix_reader->SetFileName(file_string(state, state.import_filtered_frequency_matrix).c_str());

    unfiltered_feature_dictionary_reader->SetFileName(file_string(state, state.import_unfiltered_feature_dictionary).c_str());
    filtered_feature_dictionary_reader->SetFileName(file_string(state, state.import_filtered_feature_dictionary).c_str());

    lda->SetBurnInIterations(200);
    lda->SetSamplingIterations(1);
    if(state.lda_topics == "auto")
      {
      lda->SetNumberOfTopics(10);
      }
    else
      {
      lda->SetNumberOfTopics(boost::lexical_cast<int>(state.lda_topics));
      }

    if(state.lda_alpha != "auto")
      {
      lda->SetAlpha(boost::lexical_cast<double>(state.lda_alpha));
      }

    if(state.lda_beta != "auto")
      {
      lda->SetBeta(boost::lexical_cast<double>(state.lda_beta));
      }

    if(state.burn_in_iterations != "auto")
      {
      lda->SetBurnInIterations(boost::lexical_cast<double>(state.burn_in_iterations));
      }

    if(state.sampling_iterations != "auto")
      {
      lda->SetSamplingIterations(boost::lexical_cast<double>(state.sampling_iterations));
      }


    // ------------------------------------------------------------
    //
    // Pipeline Execution
    //
    // ------------------------------------------------------------


    bool metrics_enabled = state.export_metrics.size();
    cpu_timer total_cpu_time;
    wallclock_timer total_wallclock_time;

    // Quick sanity checks before we go any farther: if the user wants
    // to import a frequency matrix there must also be a corresponding
    // feature dictionary
    if (state.import_filtered_frequency_matrix.size() != 0 &&
        state.import_filtered_feature_dictionary.size() == 0)
      {
      throw std::runtime_error("You must specify --import-filtered-feature-dictionary when you use --import-filtered-frequency-matrix.");
      }
    if (state.import_unfiltered_frequency_matrix.size() != 0 &&
        state.import_unfiltered_feature_dictionary.size() == 0)
      {
      throw std::runtime_error("You must specify --import-unfiltered-feature-dictionary when you use --import-unfiltered-frequency-matrix.");
      }

    // --------------------------------------------------
    // Reading Inputs
    // --------------------------------------------------

    // Check for the biggest shortcut: the user wants to skip straight
    // to loading the filtered frequency matrix
    if (state.import_filtered_frequency_matrix.size() == 0)
      {
      // Second biggest shortcut: skip straight to the unfiltered
      // frequency matrix.
      if (state.import_unfiltered_frequency_matrix.size() == 0)
        {
        // Okay, we're not doing that: we must at least be loading
        // some documents.
        if (state.import_document_dictionary.size())
          {
          MEASURE_STAGE(document_dictionary_reader);
          }
        else
          {
          if (state.database_url.size())
            {
            if (controller->GetLocalProcessId() == 0)
              {
              vtkSQLDatabase *db = vtkSQLDatabase::CreateFromURL(state.database_url.c_str());
              bool openStatus = db->Open(0);
              if (!openStatus)
                {
                std::ostringstream msgbuf;
                msgbuf << "ERROR: Couldn't connect to database! "
                       << "Last status message: "
                       << db->GetLastErrorText() << "\n";
                throw std::runtime_error(msgbuf.str());
                }

              vtkSQLQuery *query = db->GetQueryInstance();
              query->SetQuery(state.database_query.c_str());
              database_query_reader->SetQuery(query);
              db->Delete();
              query->Delete();
              }
            MEASURE_STAGE(database_query_reader);
            if (state.export_db_query_result.size())
              {
              cpu_timer cpu_time;
              wallclock_timer wallclock_time;
              export_artifact(controller, state, database_query_reader->GetOutput(), state.export_db_query_result, 50);
              if (metrics_enabled)
                {
                export_metric(controller, state, "Export Database Query Results", "cpu time", cpu_time);
                export_metric(controller, state, "Export Database Query Results", "wallclock time", wallclock_time);
                }
              }
            }
          else
            {
            // we must be reading the documents from individual files
            MEASURE_STAGE(document_reader);
            }
          // These two stages happen whether we read from a database or
          // from files
          MEASURE_STAGE(assign_mime_types);
          MEASURE_STAGE(text_extraction);
          // Done extracting text from documents
          }

        // Pause here -- does the user want to export the document
        // dictionary?  This is silly if it's being read from a file but
        // we'll permit it anyway
        if (state.export_document_dictionary.size())
          {
          if (state.import_document_dictionary.size() &&
              controller->GetLocalProcessId() == 0)
            {
            // This is not illegal per se but does seem to waste work
            // since you've already got the file on disk.
            std::cerr << "NOTE: You specified both --import-document-dictionary and --export-document-dictionary.  Are you sure you meant to do this?\n";
            }
          cpu_timer cpu_time;
          wallclock_timer wallclock_time;
          export_artifact(controller, state, vtkTable::SafeDownCast(text_extraction->GetOutput()), state.export_document_dictionary, 100);
          if (metrics_enabled)
            {
            export_metric(controller, state, "Export Document Dictionary", "cpu time", cpu_time);
            export_metric(controller, state, "Export Document Dictionary", "wallclock time", wallclock_time);
            }
          }

        // --------------------------------------------------
        // Collect Document Statistics
        // --------------------------------------------------
        if (metrics_enabled)
          {
          vtkTable *document_table = text_extraction->GetOutput();
          vtkStringArray *text_array = vtkStringArray::SafeDownCast(document_table->GetColumnByName("content"));
          if (!text_array)
            {
            vtksys_ios::ostringstream msgbuf;
            msgbuf << "Couldn't retrieve document contents column from document dictionary!  Columns present ("
                   << document_table->GetNumberOfColumns() << ") are ";
            for (int i = 0; i < document_table->GetNumberOfColumns(); ++i)
              {
              msgbuf << "'" << document_table->GetColumn(i)->GetName() << "' ";
              }
            throw std::runtime_error(msgbuf.str());
            }
          // okay, everything's there, we can go ahead and collect statistics!
          const vtkIdType document_count = text_array->GetNumberOfTuples();
          vtkIdType total_document_bytes = 0;
          vtkIdType minimum_document_bytes = std::numeric_limits<vtkIdType>::max();
          vtkIdType maximum_document_bytes = 0;
          for(vtkIdType i = 0; i != document_count; ++i)
            {
            const vtkIdType document_bytes = text_array->GetValue(i).size();
            total_document_bytes += document_bytes;
            minimum_document_bytes = std::min(minimum_document_bytes, document_bytes);
            maximum_document_bytes = std::max(maximum_document_bytes, document_bytes);
            }
          export_metric(controller, state, document_reader, "local document count", document_count, "documents");
          export_metric(controller, state, document_reader, "total document size", total_document_bytes, "bytes");
          export_metric(controller, state, document_reader, "minimum document size", minimum_document_bytes, "bytes");
          export_metric(controller, state, document_reader, "maximum document size", maximum_document_bytes, "bytes");
          export_metric(controller, state, document_reader, "average document size", document_count ? static_cast<double>(total_document_bytes) / document_count : 0, "bytes");
          // Done printing document statistics
          }

        // Now we can get back to the work of processing the
        // documents.
        MEASURE_STAGE(tokenization);
        if (metrics_enabled)
          {
          export_metric(controller, state, tokenization, "token count", tokenization->GetTokens()->GetNumberOfRows(), "tokens");
          }

        if (state.export_features.size())
          {
          tokenization->Update();
          cpu_timer cpu_time;
          wallclock_timer wallclock_time;
          export_artifact(controller, state, tokenization->GetTokens(), state.export_features, 20);
          if (metrics_enabled)
            {
            export_metric(controller, state, "Export Features", "cpu time", cpu_time);
            export_metric(controller, state, "Export Features", "wallclock time", wallclock_time);
            }
          }

        if (state.import_unfiltered_feature_dictionary.size())
          {
          MEASURE_STAGE(unfiltered_feature_dictionary_reader);
          }
        else
          {
          MEASURE_STAGE(compute_feature_dictionary);
          }

        // This will also call unfiltered_feature_dictionary->Update()
        MEASURE_STAGE(compute_frequency_matrix);
        }
      else
        {
        // The user wants to import the unfiltered frequency matrix
        // and go through the filtering stages anyway.
        MEASURE_STAGE(unfiltered_feature_dictionary_reader);
        MEASURE_STAGE(unfiltered_frequency_matrix_reader);
        }

      // Force the placeholder filters to pick up their contents
      unfiltered_feature_dictionary->Update();
      unfiltered_frequency_matrix->Update();

      // At this point we have the (unfiltered) feature dictionary.
      // Export it if the user wants.  As before, print a warning if
      // we've been asked to do something silly.
      if (state.export_unfiltered_feature_dictionary.size())
        {
        if (state.import_unfiltered_feature_dictionary.size())
          {
          cerr << "NOTE: You specified both --import-unfiltered-feature-dctionary "
               << "and --export-unfiltered-feature-dictionary.  This might not "
               << "be what you want -- the output will be just like the input.\n";
          }
        cpu_timer cpu_time;
        wallclock_timer wallclock_time;
        export_artifact(controller, state,
                        vtkTable::SafeDownCast(unfiltered_feature_dictionary->GetOutput()),
                        state.export_unfiltered_feature_dictionary, 20);
        if (metrics_enabled)
          {
          export_metric(controller, state, "Export Unfiltered Feature Dictionary", "cpu time", cpu_time);
          export_metric(controller, state, "Export Unfiltered Feature Dictionary", "cpu time", cpu_time);
          }
        }

      if (state.export_unfiltered_frequency_matrix.size() || metrics_enabled)
        {
        unfiltered_frequency_matrix->Update();
        export_frequency_matrix_statistics(controller, state,
                                           vtkArrayData::SafeDownCast(unfiltered_frequency_matrix->GetOutput())->GetArray(0),
                                           "Unfiltered Frequency Matrix");


        if (state.export_unfiltered_frequency_matrix.size())
          {
          if (state.import_unfiltered_frequency_matrix.size())
            {
            cerr << "NOTE: You specified both --import-unfiltered-frequency_matrix "
                 << "and --export-unfiltered-frequency-matrix.  This might not "
                 << "be what you want -- the output will be just like the input.\n";
            }
          cpu_timer cpu_time;
          wallclock_timer wallclock_time;
          unfiltered_frequency_matrix->Update();
          export_artifact(controller, state, vtkArray::SafeDownCast(vtkArrayData::SafeDownCast(unfiltered_frequency_matrix->GetOutput())->GetArray(0)), state.export_unfiltered_frequency_matrix);
          if (metrics_enabled)
            {
            export_metric(controller, state, "Export Unfiltered Frequency Matrix", "cpu time", cpu_time);
            export_metric(controller, state, "Export Unfiltered Frequency Matrix", "wallclock time", wallclock_time);
            }
          }
        }

      // Now that we've got the unfiltered frequency matrix and document
      // dictionary, run them through the token frequency filter
      MEASURE_STAGE(token_frequency_filter);
      }
    else
      {
      // The user asked us to import the filtered frequency matrix and
      // feature dictionary.  That's going to save so much time.
      // Let's go out for pizza!
      MEASURE_STAGE(filtered_frequency_matrix_reader);
      MEASURE_STAGE(filtered_feature_dictionary_reader);
      }

    // Force the filtered feature dictionary and frequency matrix to
    // be picked up in the passthrough filters
    filtered_feature_dictionary->Update();
    filtered_frequency_matrix->Update();

    saved_filtered_feature_dictionary->DeepCopy(vtkTable::SafeDownCast(filtered_feature_dictionary->GetOutput()));

    // Now we can print statistics on the filtered frequency matrix and save it if desired
    if (state.export_filtered_feature_dictionary.size())
      {
      if (state.import_unfiltered_feature_dictionary.size())
        {
        cerr << "NOTE: You specified both --import-filtered-feature-dctionary "
             << "and --export-filtered-feature-dictionary.  This might not "
             << "be what you want -- the output will be just like the input.\n";
        }
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      export_artifact(controller, state, saved_filtered_feature_dictionary,  state.export_filtered_feature_dictionary, 20);
      if (metrics_enabled)
        {
        export_metric(controller, state, "Export Filtered Feature Dictionary", "cpu time", cpu_time);
        export_metric(controller, state, "Export Filtered Feature Dictionary", "wallclock time", wallclock_time);
        }
      }

    if (metrics_enabled)
      {
      export_frequency_matrix_statistics(controller, state,
                                         vtkArrayData::SafeDownCast(filtered_frequency_matrix->GetOutput())->GetArray(0),
                                         "Filtered Frequency Matrix");
      }

    if (state.export_filtered_frequency_matrix.size())
      {
      if (state.import_filtered_frequency_matrix.size())
        {
        cerr << "NOTE: You specified both --import-filtered-frequency_matrix "
             << "and --export-filtered-frequency-matrix.  This might not "
             << "be what you want -- the output will be just like the input.\n";
        }
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      export_artifact(controller, state, vtkArray::SafeDownCast(vtkArrayData::SafeDownCast(filtered_frequency_matrix->GetOutput())->GetArray(0)), state.export_filtered_frequency_matrix);
      if (metrics_enabled)
        {
        export_metric(controller, state, "Export Filtered Frequency Matrix", "cpu time", cpu_time);
        export_metric(controller, state, "Export Filtered Frequency Matrix", "wallclock time", wallclock_time);
        }
      }

    // At this point we've finished the entire pipeline that results
    // in a filtered term/document frequency matrix.  Whew.  What a
    // mess that was.

    // --------------------------------------------------
    // LDA Execution
    // --------------------------------------------------

    MEASURE_STAGE(lda);
    if (metrics_enabled)
      {
      export_metric(controller, state, lda, "Number of Topics", lda->GetNumberOfTopics(), "topics");
      }

    // Optionally export the theta values
    if(state.export_theta.size())
      {
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      export_artifact(controller, state, lda->GetOutput(0)->GetArray(0), state.export_theta);
      if (metrics_enabled)
        {
        export_metric(controller, state, "Export Theta", "cpu time", cpu_time);
        export_metric(controller, state, "Export Theta", "wallclock time", wallclock_time);
        }
      }

    if (state.export_aggregated_theta.size())
      {
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      export_aggregated_artifact(controller, state, lda->GetOutput(0)->GetArray(0), state.export_aggregated_theta);
      if (metrics_enabled)
        {
        export_metric(controller, state, "Export Aggregated Theta", "cpu time", cpu_time);
        export_metric(controller, state, "Export Aggregated Theta", "wallclock time", wallclock_time);
        }
      }

    // Optionally export the phi matrix
    if(state.export_phi.size())
      {
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      export_artifact(controller, state, lda->GetOutput(1)->GetArray(0), state.export_phi);
      if (metrics_enabled)
        {
        export_metric(controller, state, "Export Phi", "cpu time", cpu_time);
        export_metric(controller, state, "Export Phi", "wallclock time", wallclock_time);
        }
      }

    // Hint: the phi matrix is actually the same across all processors
    // so we don't actually have to aggregate it here.
    if (state.export_aggregated_phi.size())
      {
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      if (controller->GetLocalProcessId() == 0)
        {
        cerr << "NOTE: Phi matrix is the same across all processors so "
             << "--export-aggregated-phi will just write the copy on "
             << "process 0\n";
        export_artifact(controller, state, lda->GetOutput(1)->GetArray(0), state.export_aggregated_phi);
        }
        if (metrics_enabled)
          {
          export_metric(controller, state, "Export Aggregated Phi", "cpu time", cpu_time);
          export_metric(controller, state, "Export Aggregated Phi", "wallclock time", wallclock_time);
          }
      }

    if(state.export_top_topics.size())
      {
      cerr << "WARNING: --export-top-topics hasn't been debugged recently!\n";
      cpu_timer time;
      lda->Update();
      int topic_count = state.top_topics == "auto" ? 10 : boost::lexical_cast<int>(state.top_topics);

      //vtkTextAnalysisUtilities::SaveTopTopicsTable(theta,
      //                                              reader_id_array,
      //                                              reader_uri_array,
      //                                              arguments.TopTopicsCount,
      //                                              arguments.TopTopicsOutput);

      vtkTextAnalysisUtilities::SaveTopTopicsTable( lda->GetOutput(0)->GetArray(0), NULL, NULL, topic_count, state.export_top_topics[0].c_str());
      //export_artifact(controller, state, lda->GetOutput(0)->GetArray(0), state.export_phi);
      export_metric(controller, state, "Export Top Topics", "cpu time", time);
      }


    if(state.export_top_terms_per_topic.size())
      {
      lda->Update();
      int term_count = state.top_terms_per_topic == "auto" ? 10 : boost::lexical_cast<int>(state.top_terms_per_topic);
      cpu_timer cpu_time;
      wallclock_timer wallclock_time;
      for (std::vector<std::string>::size_type i = 0; i < state.export_top_terms_per_topic.size(); ++i)
        {
        vtkTextAnalysisUtilities::SaveTopTermsTable( lda->GetOutput(1)->GetArray(0), vtkUnicodeStringArray::SafeDownCast(saved_filtered_feature_dictionary->GetColumnByName("text")), term_count, file_string(state, state.export_top_terms_per_topic[i].c_str()));
        }

      if (metrics_enabled)
        {
        export_metric(controller, state, "Export Top Terms per Topic", "cpu time", cpu_time);
        export_metric(controller, state, "Export Top Terms per Topic", "wallclock time", wallclock_time);
        }
      }

    if (metrics_enabled)
      {
      // Export total execution time metrics ...
      export_metric(controller, state, "Total Execution Time", "cpu time", total_cpu_time);
      export_metric(controller, state, "Total Execution Time", "wallclock time", total_wallclock_time);
      }
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
