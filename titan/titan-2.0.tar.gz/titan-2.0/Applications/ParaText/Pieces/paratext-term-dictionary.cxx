#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkMPIController.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkPTermDictionaryNTo1.h>
#include <vtkPTermDictionaryNToN.h>
#include <vtkPTermDictionaryBinaryTree.h>
#include <vtkPTermDictionaryRoundRobin.h>
#include <vtkPTermDictionaryMapReduce.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  bool        write_tables_as_ascii;
  std::string document_token_table_filename;
  std::string dictionary_filename;
  std::string feature_dictionary_strategy;
  std::string export_metrics;

};

/// Used for quiet early termination of the program.
struct early_exit
{
};

// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  try
    {
    /// Setup command-line arguments

    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("ascii-output", "Write output tables as ASCII instead of compressed binary format")
      ("document-token-table", boost::program_options::value<std::string>(&state.document_token_table_filename), "Filename for the table of tokenized documents (input)")
      ("dictionary-table", boost::program_options::value<std::string>(&state.dictionary_filename), "Filename for the term dictionary (output)")
      ("dictionary-strategy", boost::program_options::value<std::string>(&state.feature_dictionary_strategy)->default_value("mr"), "Feature dictionary strategy. Valid values are 'nto1', 'nton', 'rr', 'bt', and 'mr'.  You don't need to change this unless you are testing performance.")
      ("export-metrics", boost::program_options::value<std::string>(&state.export_metrics), "Writes execution metrics to a file.  Use '-' for stdout.")
      ("help,h", "Prints this help message and exits.")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("document-token-table", 1);
    positional_options.add("dictionary-table", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(&std::cout);
        }
      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText Suite version 0.2\n";
      throw early_exit();
      }

    if (arguments.count("ascii-output"))
      {
      state.write_tables_as_ascii = true;
      }
    else
      {
      state.write_tables_as_ascii = false;
      }

    // Check to make sure we have our required arguments
    bool can_continue = true;
    if (arguments.count("document-token-table") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must supply a filename for the input document token tables!\n";
      }
    if (arguments.count("dictionary-table") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must supply a filename for the output term dictionary!\n";
      }
    if (!can_continue)
      {
      throw early_exit();
      }

    VTK_CREATE(vtkTableReader, token_table_reader);
    VTK_CREATE(vtkTableWriter, dictionary_writer);
    if (state.write_tables_as_ascii)
      {
      dictionary_writer->SetFileTypeToASCII();
      }
    else
      {
      dictionary_writer->SetFileTypeToBinary();
      }

    // We'll fill this in with one of several algorithms
    vtkSmartPointer<vtkTableAlgorithm> compute_feature_dictionary;

    // Fill in the feature dictionary creation strategy
    if(state.feature_dictionary_strategy == "nto1")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryNTo1::New());
      }
    else if(state.feature_dictionary_strategy == "nton")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryNToN::New());
      }
    else if(state.feature_dictionary_strategy == "rr")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryRoundRobin::New());
      }
    else if(state.feature_dictionary_strategy == "bt")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryBinaryTree::New());
      }
    else if(state.feature_dictionary_strategy == "mr")
      {
      compute_feature_dictionary.TakeReference(vtkPTermDictionaryMapReduce::New());
      }
    else
      {
      throw std::runtime_error("Unknown feature dictionary strategy: " + state.feature_dictionary_strategy);
      }

    // Instrument everything for timing
    VTK_CREATE(vtkParaTextMetricReporter, reporter);
    ParaTextCommon::AttachTimer(token_table_reader, reporter);
    ParaTextCommon::AttachTimer(dictionary_writer, reporter);
    ParaTextCommon::AttachTimer(compute_feature_dictionary, reporter);

    compute_feature_dictionary->SetInputConnection(token_table_reader->GetOutputPort());
    dictionary_writer->SetInputConnection(compute_feature_dictionary->GetOutputPort());

    token_table_reader->SetFileName(ParaTextCommon::FormatFileName(state.document_token_table_filename).c_str());
    dictionary_writer->SetFileName(ParaTextCommon::FormatFileName(state.dictionary_filename).c_str());

    // Set up metric reporting
    std::ostream* MetricDestination = 0;
    if (arguments.count("export-metrics"))
      {
      if (state.export_metrics == "-")
        {
        MetricDestination = &std::cout;
        reporter->SetDestination(&std::cout);
        }
      else
        {
        MetricDestination = new std::ofstream(ParaTextCommon::FormatFileName(state.export_metrics).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(MetricDestination);
        }
      }

    ParaTextCommon::CPUTimer cpu_timer;
    ParaTextCommon::WallClockTimer wall_clock_timer;

    dictionary_writer->Write();

    if (MetricDestination != 0)
      {
      reporter->ReportMetric("Total Execution Time", "CPU time", cpu_timer.elapsed(), "seconds");
      reporter->ReportMetric("Total Execution Time", "Wall clock time", wall_clock_timer.elapsed(), "seconds");
      }

    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
