#include <vtkMPIController.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkTokenizer.h>
#include <vtkUnicodeStringArray.h>

#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"
#include "vtkParaTextExecutionTimer.h"

#include <boost/algorithm/string/replace.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()


/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  std::string document_table_filename;
  std::string token_table_filename;
  std::string export_metrics;
  bool write_tables_as_ascii;

};

/// Used for quiet early termination of the program.
struct early_exit
{
};


// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();
  state.write_tables_as_ascii = false;

  try
    {
    /// Setup command-line arguments ...

    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("ascii-output", "Write token tables in ASCII format instead of compressed binary")
      ("document-table", boost::program_options::value<std::string>(&state.document_table_filename), "File containing a table of documents to be tokenized (input)")
      ("export-metrics", boost::program_options::value<std::string>(&state.export_metrics), "Writes execution metrics to a file.  Use '-' for stdout.")
      ("help,h", "Prints this help message and exits.")
      ("token-table", boost::program_options::value<std::string>(&state.token_table_filename), "Filename for tokenized documents (output)")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("document-table", 1);
    positional_options.add("token-table", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(& std::cout);
        }
      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        {
        std::cout << "ParaText Suite version 0.2\n";
        }
      throw early_exit();
      }

    if (arguments.count("ascii-output"))
      {
      state.write_tables_as_ascii = true;
      }

    // Check to see that we have the arguments we require
    bool can_continue = true;

    if (arguments.count("document-table") == 0)
      {
      std::cerr << "ERROR: You must supply a filename for the input document table.\n";
      can_continue = false;
      }
    if (arguments.count("token-table") == 0)
      {
      std::cerr << "ERROR: You must supply a filename for the output token table.\n";
      can_continue = false;
      }
    if (can_continue == false)
      {
      throw early_exit();
      }

    // --------------------------------------------------

    // First we're going to set up the pipeline objects.  Then we'll
    // make all the connections.  Only after that's done will we go
    // back and configure the various filters.  This is all to keep
    // the code easy to read.

    VTK_CREATE(vtkTableReader, document_table_reader);
    VTK_CREATE(vtkTokenizer, tokenizer);
    VTK_CREATE(vtkTableWriter, token_table_writer);
    if (state.write_tables_as_ascii)
      {
      token_table_writer->SetFileTypeToASCII();
      }
    else
      {
      token_table_writer->SetFileTypeToBinary();
      }

    VTK_CREATE(vtkParaTextMetricReporter, reporter);

    tokenizer->SetInputConnection(document_table_reader->GetOutputPort());
    token_table_writer->SetInputConnection(tokenizer->GetOutputPort());

    ParaTextCommon::AttachTimer(document_table_reader, reporter);
    ParaTextCommon::AttachTimer(tokenizer, reporter);
    ParaTextCommon::AttachTimer(token_table_writer, reporter);

    std::string input_filename = ParaTextCommon::FormatFileName(state.document_table_filename);
    std::string output_filename = ParaTextCommon::FormatFileName(state.token_table_filename);

    document_table_reader->SetFileName(input_filename.c_str());
    token_table_writer->SetFileName(output_filename.c_str());
    tokenizer->AddDroppedDelimiters(vtkTokenizer::Punctuation());
    tokenizer->AddDroppedDelimiters(vtkTokenizer::Whitespace());

    std::ostream* MetricDestination = 0;
    if (arguments.count("export-metrics"))
      {
      if (state.export_metrics == "-")
        {
        MetricDestination = &std::cout;
        reporter->SetDestination(&std::cout);
        }
      else
        {
        MetricDestination = new std::ofstream(ParaTextCommon::FormatFileName(state.export_metrics).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(MetricDestination);
        }
      }

    ParaTextCommon::CPUTimer cpu_timer;
    ParaTextCommon::WallClockTimer wall_clock_timer;

    token_table_writer->Write();

    if (MetricDestination != 0)
      {
      reporter->ReportMetric("Total Execution Time", "CPU time", cpu_timer.elapsed(), "seconds");
      reporter->ReportMetric("Total Execution Time", "Wall clock time", wall_clock_timer.elapsed(), "seconds");
      }
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
