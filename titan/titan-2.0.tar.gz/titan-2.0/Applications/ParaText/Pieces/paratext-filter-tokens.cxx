#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkFoldCase.h>
#include <vtkMPIController.h>
#include <vtkNGramExtraction.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkTextExtraction.h>
#include <vtkTimerLog.h>
#include <vtkTokenLengthFilter.h>
#include <vtkTokenValueFilter.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"
#include "vtkParaTextExecutionTimer.h"

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  int minimum_token_length;
  int maximum_token_length;
  int ngram_length;
  std::string export_metrics;
  std::string input_token_table_filename;
  std::string output_token_table_filename;
  std::vector<std::string> stop_list_filenames;

  bool write_tables_as_ascii;
  bool print_status_messages;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};

// ----------------------------------------------------------------------

void
load_stop_list(const std::string& filename, vtkTokenValueFilter* stop_word_filter)
{
  std::ifstream infile(ParaTextCommon::FormatFileName(filename).c_str());
  std::vector<std::string> all_stop_words;
  std::string stopword;

  while (std::getline(infile, stopword))
    {
    all_stop_words.push_back(stopword);
    }

  for (std::vector<std::string>::iterator iter = all_stop_words.begin();
       iter != all_stop_words.end();
       ++iter)
    {
    stop_word_filter->AddValue(vtkUnicodeString::from_utf8((*iter).c_str()));
    }
}

// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  vtkMPIController* controller = vtkMPIController::New();
//  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  try
    {
    /// Setup command-line arguments

    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("ascii-output", "Write output tables as ASCII instead of compressed binary format")
      ("input-token-table", boost::program_options::value<std::string>(&state.input_token_table_filename), "Unfiltered token table (input)")
      ("output-token-table", boost::program_options::value<std::string>(&state.output_token_table_filename), "Filtered token table (output) - contains filtered documents")
      ("export-metrics", boost::program_options::value<std::string>(&state.export_metrics), "Filename for execution statistics.  Use '-' for stdout.")
      ("maximum-token-length", boost::program_options::value<int>(&state.maximum_token_length)->default_value(32), "Specify the maximum allowable token length in characters.")
      ("minimum-token-length", boost::program_options::value<int>(&state.minimum_token_length)->default_value(2), "Specify the minimum allowable token length in characters.")
      ("ngram-length", boost::program_options::value<int>(&state.ngram_length)->default_value(1), "Specify the length of extracted n-grams.")
      ("stop-list", boost::program_options::value< std::vector<std::string> >(&state.stop_list_filenames), "File containing stop words, one per line.  Can be specified multiple times.")
      ("verbose", boost::program_options::value<bool>(&state.print_status_messages)->default_value(false), "Print status messages during execution")
      ("help,h", "Prints this help message and exits.")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;
    boost::program_options::positional_options_description positional_options;
    positional_options.add("input-token-table", 1);
    positional_options.add("output-token-table", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(&std::cout);
        }
      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText Suite version 0.2\n";
      throw early_exit();
      }

    if (arguments.count("ascii-output"))
      {
      state.write_tables_as_ascii = true;
      }
    else
      {
      state.write_tables_as_ascii = false;
      }

    // Make sure we have all the required arguments
    bool can_continue = true;
    if (arguments.count("input-token-table") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must supply a filename for the input token table.\n";
      }
    if (arguments.count("output-token-table") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must supply a filename for the output (filtered) token table.\n";
      }
    if (!can_continue)
      {
      throw early_exit();
      }

    VTK_CREATE(vtkParaTextMetricReporter, reporter);

    VTK_CREATE(vtkTableReader, token_reader);
    VTK_CREATE(vtkTableWriter, token_writer);
    if (state.write_tables_as_ascii)
      {
      token_writer->SetFileTypeToASCII();
      }
    else
      {
      token_writer->SetFileTypeToBinary();
      }

    VTK_CREATE(vtkTokenLengthFilter, minimum_length_filter);
    VTK_CREATE(vtkTokenLengthFilter, maximum_length_filter);
    VTK_CREATE(vtkNGramExtraction, ngram_extraction);
    VTK_CREATE(vtkFoldCase, fold_case);
    VTK_CREATE(vtkTokenValueFilter, remove_stop_words);

    ParaTextCommon::AttachTimer(token_reader, reporter);
    ParaTextCommon::AttachTimer(token_writer, reporter);
    ParaTextCommon::AttachTimer(minimum_length_filter, reporter);
    ParaTextCommon::AttachTimer(maximum_length_filter, reporter);
    ParaTextCommon::AttachTimer(ngram_extraction, reporter);
    ParaTextCommon::AttachTimer(fold_case, reporter);
    ParaTextCommon::AttachTimer(remove_stop_words, reporter);

    minimum_length_filter->SetInputConnection(token_reader->GetOutputPort());
    maximum_length_filter->SetInputConnection(minimum_length_filter->GetOutputPort());
    ngram_extraction->SetInputConnection(maximum_length_filter->GetOutputPort());
    fold_case->SetInputConnection(ngram_extraction->GetOutputPort());
    remove_stop_words->SetInputConnection(fold_case->GetOutputPort());
    token_writer->SetInputConnection(remove_stop_words->GetOutputPort());

    // Configure all the filters
    token_reader->SetFileName(ParaTextCommon::FormatFileName(state.input_token_table_filename).c_str());
    token_writer->SetFileName(ParaTextCommon::FormatFileName(state.output_token_table_filename).c_str());

    minimum_length_filter->SetBegin(0);
    minimum_length_filter->SetEnd(state.minimum_token_length + 1);

    maximum_length_filter->SetBegin(state.maximum_token_length);
    maximum_length_filter->SetEnd(std::numeric_limits<int>::max());

    ngram_extraction->SetN(state.ngram_length);

    if (state.print_status_messages)
      {
      std::cout << "Token minimum length: " << state.minimum_token_length << "\n"
                << "Token maximum length: " << state.maximum_token_length << "\n"
                << "N-gram size: " << state.ngram_length << "\n"
                << "Input file: " << ParaTextCommon::FormatFileName(state.input_token_table_filename) << "\n"
                << "Output file: " << ParaTextCommon::FormatFileName(state.output_token_table_filename) << "\n";
      }

    // Load and install stop words
    std::vector< std::string >::const_iterator iter;
    for (iter = state.stop_list_filenames.begin();
         iter != state.stop_list_filenames.end();
         ++iter)
      {
      if (*iter == "default")
        {
        if (state.print_status_messages)
          {
          std::cout << "Adding default stop list\n";
          }
        remove_stop_words->AddStopWordValues();
        }
      else
        {
        if (state.print_status_messages)
          {
          std::cout << "Adding stop words from file "
                    << ParaTextCommon::FormatFileName(*iter) << "\n";
          }
        load_stop_list(*iter, remove_stop_words);
        }
      }

    // Set up metric reporting
    std::ostream* MetricDestination = 0;
    if (arguments.count("export-metrics"))
      {
      if (state.export_metrics == "-")
        {
        MetricDestination = &std::cout;
        reporter->SetDestination(&std::cout);
        }
      else
        {
        MetricDestination = new std::ofstream(ParaTextCommon::FormatFileName(state.export_metrics).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(MetricDestination);
        }
      }

    ParaTextCommon::CPUTimer cpu_timer;
    ParaTextCommon::WallClockTimer wall_clock_timer;

    token_writer->Write();

    if (MetricDestination != 0)
      {
      reporter->ReportMetric("Total Execution Time", "CPU time", cpu_timer.elapsed(), "seconds");
      reporter->ReportMetric("Total Execution Time", "Wall clock time", wall_clock_timer.elapsed(), "seconds");
      }
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
//  std::cout << "Finalizing MPI controller.\n";
  controller->Finalize();
  controller->Delete();
  return error_count;
}
