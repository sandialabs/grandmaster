/*=========================================================================

  Program:   Visualization Toolkit
  Module:    ParaTextCallbacks.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2012 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
  -------------------------------------------------------------------------*/

#include "vtkParaTextMetricReporter.h"
#include "ParaTextCommon.h"

#include <vtkAlgorithm.h>
#include <vtkArrayData.h>
#include <vtkArray.h>
#include <vtkCallbackCommand.h>
#include <vtkFrequencyMatrix.h>
#include <vtkMultiProcessController.h>
#include <vtkObject.h>
#include "vtkParaTextExecutionTimer.h"
#include "vtkParaTextMetricReporter.h"
#include <vtkSmartPointer.h>
#include <vtkTimerLog.h>

#include <boost/lexical_cast.hpp>
#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <string>

#ifndef VTK_CREATE
# define VTK_CREATE(type,name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()
#endif

namespace ParaTextCommon {

void
ExportFrequencyMatrixStatistics_Callback(vtkObject* caller,
                                         unsigned long int event,
                                         void* vtkNotUsed(callData),
                                         void* clientData)
{
  vtkFrequencyMatrix* matrix_generator = static_cast<vtkFrequencyMatrix*>(caller);
  vtkParaTextMetricReporter* reporter = static_cast<vtkParaTextMetricReporter*>(clientData);

  vtkArray* matrix = vtkArrayData::SafeDownCast(matrix_generator->GetOutput(0))->GetArray(0);
  reporter->ReportMetric("term/doc frequency matrix",
                         "row count",
                         matrix->GetExtent(0).GetSize(), "rows");
  reporter->ReportMetric("term/doc frequency matrix",
                         "column count",
                         matrix->GetExtent(1).GetSize(), "columns");
  reporter->ReportMetric("term/doc frequency matrix",
                         "non-null values",
                         matrix->GetNonNullSize(),
                         "values");
  reporter->ReportMetric("term/doc frequency matrix",
                         "row indices",
                         boost::algorithm::replace_all_copy(boost::lexical_cast<std::string>(matrix->GetExtent(0)), ", ", "-"), "indices");
  reporter->ReportMetric("term/doc frequency matrix",
                         "column indices",
                         boost::algorithm::replace_all_copy(boost::lexical_cast<std::string>(matrix->GetExtent(1)), ", ", "-"), "indices");
}

// ----------------------------------------------------------------------

std::string
FormatFileName(const std::string& pattern)
{
  vtkMultiProcessController* controller = vtkMultiProcessController::GetGlobalController();
  int my_process_id = 0;
  int process_count = 1;
  boost::posix_time::ptime timestamp;

  if (controller)
    {
    my_process_id = controller->GetLocalProcessId();
    process_count = controller->GetNumberOfProcesses();
    }

  boost::format format(pattern);
  format.exceptions(boost::io::all_error_bits ^ boost::io::too_many_args_bit);
  format % to_iso_string(timestamp);
  format % my_process_id;
  format % process_count;
  return str(format);
}

// ----------------------------------------------------------------------

std::ostream*
OpenMetricDestination(const std::string& filename_pattern)
{
  if (filename_pattern == "-")
    {
    return & (std::cout);
    }
  else
    {
    std::string filename = FormatFileName(filename_pattern);
    return new std::ofstream(filename.c_str());
    }
}

// ----------------------------------------------------------------------


void
PrintFormattingOptions(std::ostream* destination)
{
  *destination << "Filenames are expanded using printf-like formatting.  Special %n% arguments will be expanded as follows:\n\n";
  *destination << "  %1% - timestamp in ISO format\n";
  *destination << "  %2% - process id\n";
  *destination << "  %3% - process count\n";
  *destination << "\n";
  *destination << "Metrics are expanded using printf-like formatting.  Special %n% arguments will be expanded as follows:\n\n";
  *destination << "  %1% - timestamp in ISO format\n";
  *destination << "  %2% - process id\n";
  *destination << "  %3% - process count\n";
  *destination << "  %4% - component name\n";
  *destination << "  %5% - metric name\n";
  *destination << "  %6% - metric value\n";
  *destination << "  %7% - metric units\n";
  *destination << "\n";
  *destination << "Examples:\n";
  *destination << "\n";
  *destination << "paratext-lda --file A --directory B --export-feature-dictionary=C\n";
  *destination << "  Loads file A and the contents of directory B, writing a feature-dictionary to file C\n";
  *destination << "\n";
  *destination << "mpiexec -np 4 paratext-lda --recursive-directory D --export-theta=E%2%.txt\n";
  *destination << "  Using four processors, recursively loads the contents of directory D, writing theta files\n";
  *destination << "  for each processor, named E0.txt, E1.txt, E2.txt, and E3.txt.\n";
  *destination << "\n";
}

// ----------------------------------------------------------------------

void
AddCallback(vtkObject* source, unsigned long int event_type, vtkEventCallback callback)
{
  VTK_CREATE(vtkCallbackCommand, command);
  command->SetCallback(callback);
  command->SetClientData(source);
  source->AddObserver(event_type, command);
}

// ----------------------------------------------------------------------

void
AttachTimer(vtkAlgorithm* filter, vtkParaTextMetricReporter* reporter)
{
  VTK_CREATE(vtkParaTextExecutionTimer, timer);
  timer->SetFilter(filter);
  timer->SetMetricReporter(reporter);
}

// ----------------------------------------------------------------------

  /// Helper classes for managing timing.
CPUTimer::CPUTimer() :
  start_time(vtkTimerLog::GetCPUTime())
{
}

const double CPUTimer::elapsed() const
{
  return vtkTimerLog::GetCPUTime() - this->start_time;
}

void CPUTimer::reset()
{
  this->start_time = vtkTimerLog::GetCPUTime();
}

WallClockTimer::WallClockTimer() :
  start_time(vtkTimerLog::GetUniversalTime())
{
}

const double WallClockTimer::elapsed() const
{
  return vtkTimerLog::GetUniversalTime() - this->start_time;
}

void WallClockTimer::reset()
{
  this->start_time = vtkTimerLog::GetUniversalTime();
}


//
//
//

}; // closes namespace paratext

//
//
//
