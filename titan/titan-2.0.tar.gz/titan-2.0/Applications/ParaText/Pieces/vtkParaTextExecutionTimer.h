/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkParaTextExecutionTimer.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2012 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
  -------------------------------------------------------------------------*/

// .NAME vtkParaTextExecutionTimer - Time filter execution in ParaText and report the results
//
// .SECTION Description
//
// This object is intended for use in ParaText.  It attaches to a
// vtkAlgorithm and times its execution (i.e. the time between
// StartEvent and EndEvent).  The result is reported as a ParaText
// metric using vtkParaTextMetricReporter.
//
// .SECTION See Also
//
// vtkExecutionTimer

#ifndef __vtkParaTextExecutionTimer_h
#define __vtkParaTextExecutionTimer_h

#include "vtkExecutionTimer.h"

class vtkParaTextMetricReporter;

class vtkParaTextExecutionTimer : public vtkExecutionTimer
{
public:
  vtkTypeMacro(vtkParaTextExecutionTimer, vtkExecutionTimer);
  static vtkParaTextExecutionTimer* New();
  void PrintSelf(ostream& os, vtkIndent indent);

  void SetMetricReporter(vtkParaTextMetricReporter* reporter);
  vtkGetObjectMacro(MetricReporter, vtkParaTextMetricReporter);

protected:
  vtkParaTextExecutionTimer();
  ~vtkParaTextExecutionTimer();

  vtkParaTextMetricReporter* MetricReporter;

  // Override from superclass - this is where we do the reporting
  void TimerFinished();

private:
  vtkParaTextExecutionTimer(const vtkParaTextExecutionTimer&);
  void operator=(const vtkParaTextExecutionTimer&);
};

#endif
