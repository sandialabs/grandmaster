#include <vtkArrayReader.h>
#include <vtkArrayWriter.h>
#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkFrequencyMatrix.h>
#include <vtkMPIController.h>
#include <vtkPFrequencyMatrixFilter.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkScaleDimension.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  // filenames for inputs
  std::string token_table_filename;
  std::string term_dictionary_filename;
  std::string document_id_filename;

  // filename for output
  std::string frequency_matrix_filename;
  std::string aggregate_frequency_matrix_filename;

  std::string frequency_matrix_strategy;

  std::string export_metrics;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};

// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  try
    {
    /// Setup command-line arguments

    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("token-table", boost::program_options::value<std::string>(&state.token_table_filename), "Table containing tokenized documents (input)")
      ("term-dictionary", boost::program_options::value<std::string>(&state.term_dictionary_filename), "Table containing dictionary of all terms in documents (input)")
      ("document-id-table", boost::program_options::value<std::string>(&state.document_id_filename), "Table containing a 'document' column with IDs of all documents in the corpus")
      ("frequency-matrix", boost::program_options::value<std::string>(&state.frequency_matrix_filename), "Filename for computed frequency matrix (output)")
      ("frequency-matrix-strategy", boost::program_options::value<std::string>(&state.frequency_matrix_strategy)->default_value("global+local"), "Frequency matrix strategy. Valid values are 'global+local', global+presorted, and 'global'.  You do not need to change this unless you're testing performance.")
      ("write-aggregate-frequency-matrix", boost::program_options::value<std::string>(&state.aggregate_frequency_matrix_filename), "Collect the frequency matrix onto one processor and write it to a file.  NOTE: When you use this, be certain that your system has enough memory to hold the whole thing!")
      ("export-metrics", boost::program_options::value<std::string>(&state.export_metrics), "Write execution statistics to this file.  Use '-' for stdout.")
      ("help,h", "Prints this help message and exits.")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("token-table", 1);
    positional_options.add("term-dictionary", 1);
    positional_options.add("document-id-table", 1);
    positional_options.add("frequency-matrix", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(&std::cout);
        }
      throw early_exit();
      }
    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        {
        std::cout << "ParaText Suite version 0.2\n";
        }
      throw early_exit();
      }

    VTK_CREATE(vtkParaTextMetricReporter, reporter);

    VTK_CREATE(vtkTableReader, token_table_reader);
    VTK_CREATE(vtkTableReader, document_id_table_reader);
    VTK_CREATE(vtkTableReader, dictionary_reader);
    VTK_CREATE(vtkFrequencyMatrix, compute_frequency_matrix);
    VTK_CREATE(vtkArrayWriter, frequency_matrix_writer);

    ParaTextCommon::AttachTimer(token_table_reader, reporter);
    ParaTextCommon::AttachTimer(document_id_table_reader, reporter);
    ParaTextCommon::AttachTimer(dictionary_reader, reporter);
    ParaTextCommon::AttachTimer(compute_frequency_matrix, reporter);
    ParaTextCommon::AttachTimer(frequency_matrix_writer, reporter);

    // ------------------------------------------------------------
    //
    // Pipeline Connection
    //
    // ------------------------------------------------------------

    compute_frequency_matrix->SetInputConnection(0, token_table_reader->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(1, dictionary_reader->GetOutputPort());
    compute_frequency_matrix->SetInputConnection(2, document_id_table_reader->GetOutputPort());
    frequency_matrix_writer->SetInputConnection(compute_frequency_matrix->GetOutputPort());

    if(state.frequency_matrix_strategy == "global+local")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PLUS_LOCAL);
      }
    else if(state.frequency_matrix_strategy == "global+presorted")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL_PRESORTED);
      }
    else if(state.frequency_matrix_strategy == "global")
      {
      compute_frequency_matrix->SetLookup(vtkFrequencyMatrix::GLOBAL);
      }
    else
      {
      throw std::runtime_error("Unknown frequency matrix strategy: " + state.frequency_matrix_strategy);
      }

    token_table_reader->SetFileName(ParaTextCommon::FormatFileName(state.token_table_filename).c_str());
    dictionary_reader->SetFileName(ParaTextCommon::FormatFileName(state.term_dictionary_filename).c_str());
    document_id_table_reader->SetFileName(ParaTextCommon::FormatFileName(state.document_id_filename).c_str());
    frequency_matrix_writer->SetFileName(ParaTextCommon::FormatFileName(state.frequency_matrix_filename).c_str());

    // ------------------------------------------------------------
    //
    // Pipeline Execution
    //
    // ------------------------------------------------------------

    // Set up metric reporting
    std::ostream* MetricDestination = 0;
    if (arguments.count("export-metrics"))
      {
      if (state.export_metrics == "-")
        {
        MetricDestination = &std::cout;
        reporter->SetDestination(&std::cout);
        }
      else
        {
        MetricDestination = new std::ofstream(ParaTextCommon::FormatFileName(state.export_metrics).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(MetricDestination);
        }
      }

    ParaTextCommon::CPUTimer cpu_timer;
    ParaTextCommon::WallClockTimer wall_clock_timer;

    frequency_matrix_writer->Write();

    if (MetricDestination != 0)
      {
      reporter->ReportMetric("Total Execution Time", "CPU time", cpu_timer.elapsed(), "seconds");
      reporter->ReportMetric("Total Execution Time", "Wall clock time", wall_clock_timer.elapsed(), "seconds");
      }
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
