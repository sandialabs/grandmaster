#include <vtkArrayReader.h>
#include <vtkArrayWriter.h>
#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkFrequencyMatrix.h>
#include <vtkMPIController.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkPLatentDirichletAllocation.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  std::string frequency_matrix_filename;
  std::string theta_filename;
  std::string phi_filename;

  int lda_num_topics;
  std::string lda_alpha;
  std::string lda_beta;

  int burn_in_iterations;
  int sampling_iterations;

  std::string export_metrics;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};


// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  VTK_CREATE(vtkTable, saved_filtered_feature_dictionary);

  try
    {
    /// Setup command-line arguments
    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("frequency-matrix", boost::program_options::value<std::string>(&state.frequency_matrix_filename), "Filename containing term/doc frequency matrix")
      ("alpha", boost::program_options::value<std::string>(&state.lda_alpha)->default_value("auto"), "Alpha hyperparameter for LDA (values should be between 0 and 1 or 'auto')")
      ("beta", boost::program_options::value<std::string>(&state.lda_beta)->default_value("auto"), "Beta hyperparameter for LDA (values should be between 0 and 1 or 'auto')")
      ("num-topics", boost::program_options::value<int>(&state.lda_num_topics)->default_value(10), "Number of topics for LDA model (values below 200 are best)")
      ("burn-in-iterations", boost::program_options::value<int>(&state.burn_in_iterations)->default_value(200), "Specifies the number of burn-in iterations for LDA (integer).")
      ("sampling-iterations", boost::program_options::value<int>(&state.sampling_iterations)->default_value(1), "Specifies the number of sampling iterations for LDA (integer).")

      ("theta", boost::program_options::value<std::string>(&state.theta_filename), "Filename for LDA Theta matrix (doc/topic weights)")
      ("phi", boost::program_options::value<std::string>(&state.phi_filename), "Filename for LDA Phi matrix (topic/term weights)")

      ("export-metrics", boost::program_options::value<std::string>(&state.export_metrics), "Writes execution metrics to a file.  Use '-' for stdout.")
      ("help,h", "Prints this help message and exits.")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("frequency-matrix", 1);
    positional_options.add("theta", 1);
    positional_options.add("phi", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(&std::cout);
        }
      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText Suite version 0.2\n";
      throw early_exit();
      }

    // Check for the mandatory arguments
    bool can_continue = true;
    if (arguments.count("frequency-matrix") == 0)
      {
      std::cerr << "ERROR: You must supply a filename for the frequency matrix (input)\n";
      can_continue = false;
      }
    if (arguments.count("theta") == 0)
      {
      std::cerr << "ERROR: You must supply a filename for the theta matrix (output)\n";
      can_continue = false;
      }
    if (arguments.count("phi") == 0)
      {
      std::cerr << "ERROR: You must supply a filename for the phi matrix (output)\n";
      can_continue = false;
      }
    if (!can_continue)
      {
      throw early_exit();
      }

    // --------------------------------------------------
    //
    // Pipeline Construction
    //
    // --------------------------------------------------

    VTK_CREATE(vtkParaTextMetricReporter, reporter);

    VTK_CREATE(vtkArrayReader, frequency_matrix_reader);
    VTK_CREATE(vtkPLatentDirichletAllocation, lda_engine);
    VTK_CREATE(vtkArrayWriter, theta_writer);
    VTK_CREATE(vtkArrayWriter, phi_writer);

    lda_engine->SetInputConnection(frequency_matrix_reader->GetOutputPort());
    theta_writer->SetInputConnection(lda_engine->GetOutputPort(0));
    phi_writer->SetInputConnection(lda_engine->GetOutputPort(1));

    ParaTextCommon::AttachTimer(frequency_matrix_reader, reporter);
    ParaTextCommon::AttachTimer(lda_engine, reporter);
    ParaTextCommon::AttachTimer(theta_writer, reporter);
    ParaTextCommon::AttachTimer(phi_writer, reporter);

    // --------------------------------------------------
    //
    // Pipeline Configuration
    //
    // --------------------------------------------------

    frequency_matrix_reader->SetFileName(ParaTextCommon::FormatFileName(state.frequency_matrix_filename).c_str());
    phi_writer->SetFileName(ParaTextCommon::FormatFileName(state.phi_filename).c_str());
    theta_writer->SetFileName(ParaTextCommon::FormatFileName(state.theta_filename).c_str());

    if (state.lda_alpha != "auto")
      {
      double alpha = boost::lexical_cast<double>(state.lda_alpha);
      lda_engine->SetAlpha(alpha);
      }
    if (state.lda_beta != "auto")
      {
      double beta = boost::lexical_cast<double>(state.lda_beta);
      lda_engine->SetBeta(beta);
      }

    lda_engine->SetNumberOfTopics(state.lda_num_topics);
    lda_engine->SetBurnInIterations(state.burn_in_iterations);
    lda_engine->SetSamplingIterations(state.sampling_iterations);

    // --------------------------------------------------
    //
    // Metric reporting setup
    //
    // --------------------------------------------------

        std::ostream* MetricDestination = 0;
    if (arguments.count("export-metrics"))
      {
      if (state.export_metrics == "-")
        {
        MetricDestination = &std::cout;
        reporter->SetDestination(&std::cout);
        }
      else
        {
        MetricDestination = new std::ofstream(ParaTextCommon::FormatFileName(state.export_metrics).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(MetricDestination);
        }
      }

    ParaTextCommon::CPUTimer cpu_timer;
    ParaTextCommon::WallClockTimer wall_clock_timer;

    // --------------------------------------------------
    //
    // Run!
    //
    // --------------------------------------------------

    // This first call will trigger the LDA engine when the pipeline
    // updates itself
    theta_writer->Write();
    phi_writer->Write();

    if (MetricDestination != 0)
      {
      reporter->ReportMetric("Total Execution Time", "CPU time", cpu_timer.elapsed(), "seconds");
      reporter->ReportMetric("Total Execution Time", "Wall clock time", wall_clock_timer.elapsed(), "seconds");
      }
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
