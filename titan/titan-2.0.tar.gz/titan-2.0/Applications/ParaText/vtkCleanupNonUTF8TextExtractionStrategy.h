/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkCleanupNonUTF8TextExtractionStrategy.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/

// .NAME vtkCleanupNonUTF8TextExtractionStrategy - text extraction strategy that works with text/* data, trying UTF-8 first and then falling back to ASCII.
//
// .SECTION Description
//
// Concrete implementation of vtkTextExtractionStrategy that works
// with text/* MIME types.  vtkCleanupNonUTF8TextExtractionStrategy
// trivially converts the contents of the given resource into text.
// First it tries to convert the text from utf-8.  If that fails, it
// replaces all the high-bit characters with 'x' and then tries again.
// This is guaranteed to succeed.
//
// It is intended mainly as a "strategy of last resort", since more
// sophisticated strategies may wish to parse-out structured content.
//
// Generates a single "TEXT" tag that incorporates the entire text content.
//
// .SECTION See Also
// vtkTextExtraction, vtkTextExtractionStrategy.
//
// Developed by Andy Wilson (atwilso@sandia.gov) based on
// vtkPlainTextExtractionStrategy by Timothy M. Shead
// (tshead@sandia.gov) at Sandia National Laboratories.

#ifndef _vtkCleanupNonUTF8TextExtractionStrategy_h
#define _vtkCleanupNonUTF8TextExtractionStrategy_h

#include <vtkTextExtractionStrategy.h>

class  vtkCleanupNonUTF8TextExtractionStrategy :
  public vtkTextExtractionStrategy
{
public:
  static vtkCleanupNonUTF8TextExtractionStrategy* New();
  vtkTypeMacro(vtkCleanupNonUTF8TextExtractionStrategy, vtkTextExtractionStrategy);
  void PrintSelf(ostream& os, vtkIndent indent);

  virtual bool Extract(
    const vtkIdType document,
    const vtkStdString& uri,
    const vtkStdString& mime_type,
    const vtkTypeUInt8* content_begin,
    const vtkTypeUInt8* content_end,
    vtkUnicodeString& text,
    vtkIdTypeArray* tag_document,
    vtkIdTypeArray* tag_begin,
    vtkIdTypeArray* tag_end,
    vtkStringArray* tag_type);

protected:
  vtkCleanupNonUTF8TextExtractionStrategy();
  virtual ~vtkCleanupNonUTF8TextExtractionStrategy();

private:
  vtkCleanupNonUTF8TextExtractionStrategy(const vtkCleanupNonUTF8TextExtractionStrategy&); //Not implemented.
  void operator=(const vtkCleanupNonUTF8TextExtractionStrategy&); //Not implemented.
};

#endif // !_vtkCleanupNonUTF8TextExtractionStrategy_h
