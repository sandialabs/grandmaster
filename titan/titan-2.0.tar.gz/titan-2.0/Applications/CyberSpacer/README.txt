CYBER SPACER
------------

To run CyberSpacer will need the following:

  - Python
  - Qt
  - PyQt
  - SIP
  - Titan with SIP python wrapping turned on for VTK
    with the VTK_WRAP_PYTHON_SIP option
  - Pypcap, which requires pcap or winpcap

To build:

  python build.py

To run, first make sure that the following are in your PYTHONPATH:

  - titan-build-dir/TPL/VTK/Wrapping/Python
  - titan-build-dir/lib

then:

  python main.py interface-name

To determine an appropriate interface name for your machine, run ifconfig.
Note that you may need to run main.py as an administrator, which also requires
having PYTHONPATH set up correctly in your admin environment. The script
example-startup-script shows how to do this, though you need to change the path
to what is appropriate for your machine, then perform "sudo
./example-startup-script".

If the program is failing due to timeouts, you may need to patch
pypcap as follows:

===================================================================
--- pcap_ex.c   (revision 102)
+++ pcap_ex.c   (working copy)
@@ -238,7 +238,7 @@
 #else
        static u_char *__pkt;
        static struct pcap_pkthdr __hdr;
-       struct timeval tv = { 1, 0 };
+       struct timeval tv = { 100, 0 };
        fd_set rfds;
        int fd, n;
===================================================================

Questions/Problems?
-------------------
We welcome your feedback. Please join the list
titan-users@public.kitware.com by visiting:

  http://public.kitware.com/cgi-bin/mailman/listinfo/titan-users

Enjoy!
The CyberSpacer Team
