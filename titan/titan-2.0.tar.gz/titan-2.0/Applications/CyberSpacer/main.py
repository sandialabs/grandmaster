import dpkt
import pcap
import Queue
import sys
import threading

from PyQt4.QtGui import QApplication
from mainwindow import MainWindow

class pcap_thread(threading.Thread):
  def __init__(self, name, q):
    threading.Thread.__init__(self)
    self.q = q
    self.pc = pcap.pcap(name=name, immediate=True)

  def run(self):
    try:
      for ts, pkt in self.pc:
        q.put((ts, dpkt.ethernet.Ethernet(pkt)))
    except KeyboardInterrupt:
      sys.exit(1)

if __name__=='__main__':
  q = Queue.Queue()
  t = pcap_thread(sys.argv[1], q)
  t.start()

  app = QApplication(sys.argv)

  window = MainWindow(q)
  window.show()

  sys.exit(app.exec_())
