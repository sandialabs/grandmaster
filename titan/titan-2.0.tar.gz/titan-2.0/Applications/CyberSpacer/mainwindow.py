from PyQt4.QtCore import *
from PyQt4.QtGui import *
from PyQt4.QtWebKit import *
import Queue
import dpkt
import time
import math
import vtk

from ui_mainwindow import Ui_MainWindow

class MainWindow(QMainWindow, Ui_MainWindow):

  def init_comm_table(self):
    if not self.comm_table:
      self.comm_table = vtk.vtkTable()
      self.src = vtk.vtkStringArray()
      self.src.SetName('src')
      self.comm_table.AddColumn(self.src)
      self.dst = vtk.vtkStringArray()
      self.dst.SetName('dst')
      self.comm_table.AddColumn(self.dst)
      self.time = vtk.vtkIntArray()
      self.time.SetName('time')
      self.comm_table.AddColumn(self.time)
    else:
      self.src.SetNumberOfTuples(0)
      self.dst.SetNumberOfTuples(0)
      self.time.SetNumberOfTuples(0)

    # Start with a bogus event
    cur_time = int(time.time())
    self.src.InsertNextValue('127.0.0.1')
    self.dst.InsertNextValue('127.0.0.1')
    self.time.InsertNextValue(cur_time)
    self.insert_amount(cur_time, 0)
    self.comm_table.Modified()

  def init_ip_table(self):
    self.ip_table = vtk.vtkTable()
    self.ip_subnet = []
    self.ip_label = vtk.vtkStringArray()
    self.ip_label.SetName('addr')
    self.ip_table.GetRowData().SetPedigreeIds(self.ip_label)
    self.ip_subnet = vtk.vtkIntArray()
    self.ip_subnet.SetName('subnet 0')
    self.ip_table.AddColumn(self.ip_subnet)

    # Add 127.0.0.1 to start
    self.add_ip('\x7f\x00\x00\x01')

  def init_hist_table(self):
    self.hist_table = vtk.vtkTable()

    self.hist_time = vtk.vtkIntArray()
    self.hist_time.SetName("Time")
    self.hist_time.InsertNextValue(0)
    self.hist_time.InsertNextValue(1)
    self.hist_table.AddColumn(self.hist_time)

    self.hist_traffic = vtk.vtkIntArray()
    self.hist_traffic.SetName("Traffic")
    self.hist_traffic.InsertNextValue(0)
    self.hist_traffic.InsertNextValue(0)
    self.hist_table.AddColumn(self.hist_traffic)

  def __init__(self, q, parent = None):

    QMainWindow.__init__(self, parent)
    self.setupUi(self)
    self.q = q
    self.min_time = int(time.time())

    self.hist_table = None
    self.comm_table = None
    self.ip_table = None

    self.init_hist_table()
    self.init_comm_table()
    self.init_ip_table()

    # Make tree of IP addresses
    self.to_tree = vtk.vtkTableToTreeFilter()
    self.to_tree.SetInput(self.ip_table)
    self.subnet0 = vtk.vtkGroupLeafVertices()
    self.subnet0.SetInputArrayToProcess(0, 0, 0, vtk.vtkDataObject.VERTEX, 'subnet 0');
    self.subnet0.SetInputArrayToProcess(1, 0, 0, vtk.vtkDataObject.VERTEX, 'addr');
    self.subnet0.SetInputConnection(self.to_tree.GetOutputPort())

    # Make graph of communications
    self.to_graph = vtk.vtkTableToGraph()
    self.to_graph.SetInput(self.comm_table)
    self.to_graph.AddLinkVertex('src', 'addr', False)
    self.to_graph.AddLinkVertex('dst', 'addr', False)
    self.to_graph.AddLinkEdge('src', 'dst')
    self.to_graph.SetDirected(True)

    # Collect communications
    self.stream = vtk.vtkStreamGraph()
    self.stream.SetInputConnection(self.to_graph.GetOutputPort())
    self.stream.SetEdgeWindowArrayName('time')
    self.stream.UseEdgeWindowOn()
    self.stream.SetEdgeWindow(10)

    # Make tree ring with bundled edges
    self.view = vtk.vtkTreeRingView()
    self.view.SetTreeFromInputConnection(self.subnet0.GetOutputPort())
    self.view.SetGraphFromInputConnection(self.stream.GetOutputPort())
    self.view.Update()
    self.view.GetRepresentation().SetAreaLabelArrayName('addr')
    self.view.GetRepresentation().AreaLabelVisibilityOn()
    self.view.GetRepresentation().SetAreaColorArrayName('subnet 0')
    #self.view.GetRepresentation().SetAreaColorArrayName('')
    self.view.GetRepresentation().SetGraphSplineType(vtk.vtkSplineGraphEdges.BSPLINE, 0)
    self.view.GetRepresentation().SetGraphBundlingStrength(0.5)
    self.view.ResetCamera()

    # Build categorical lookup table
    category20_colors = [
      0x1f77b4, 0xaec7e8, 0xff7f0e, 0xffbb78, 0x2ca02c,
      0x98df8a, 0xd62728, 0xff9896, 0x9467bd, 0xc5b0d5,
      0x8c564b, 0xc49c94, 0xe377c2, 0xf7b6d2, 0x7f7f7f,
      0xc7c7c7, 0xbcbd22, 0xdbdb8d, 0x17becf, 0x9edae5 ];
    lut = vtk.vtkLookupTable()
    lut.SetRampToLinear()
    lut.SetRange(0, 255)
    lut.SetNumberOfTableValues(256)
    lut.Build()
    for i in range(256):
      c = category20_colors[i%20]
      lut.SetTableValue(i, (c >> 16)/255.0, ((c >> 8) % 256)/255.0, (c % 256)/255.0, 1.0)

    # Setup view parameters
    theme = vtk.vtkViewTheme()
    theme.SetBackgroundColor(1, 1, 1)
    theme.SetBackgroundColor2(1, 1, 1)
    #theme.SetPointOpacity(0)
    theme.GetPointTextProperty().SetColor(0, 0, 0)
    theme.SetCellColor(0, 0, 0)
    theme.SetCellOpacity(0.05)
    theme.SetSelectedCellColor(0, 0, 0)
    theme.SetSelectedCellOpacity(0.05)
    theme.SetLineWidth(2)
    theme.SetPointLookupTable(lut)
    self.view.ApplyViewTheme(theme)
    self.view.GetRenderWindow().LineSmoothingOn()
    self.view.Update()

    # Put tree ring view in Qt UI
    w = vtk.QVTKWidget()
    w.SetRenderWindow(self.view.GetRenderWindow())
    self.ring_container.layout().addWidget(w)

    # Load page when IP is selected
    def selection_changed(rep, evt):
      sel = rep.GetAnnotationLink().GetCurrentSelection()
      if sel and sel.GetNumberOfNodes() > 0 and sel.GetNode(0).GetSelectionList().GetNumberOfTuples() > 0:
        ip = sel.GetNode(0).GetSelectionList().GetValue(0)
        url = 'http://' + ip + '/'
        self.web_view.setUrl(QUrl(url))
        self.url_edit.setText(url)
    self.view.GetRepresentation().AddObserver(vtk.vtkCommand.SelectionChangedEvent, selection_changed)

    # Load page when URL box changes
    def url_text_changed():
      self.web_view.setUrl(QUrl(self.url_edit.text()))
    self.connect(self.url_edit, SIGNAL('returnPressed()'), url_text_changed)

    # Make chart view of network activity over time
    self.chart_view = vtk.vtkContextView()
    self.chart_view.GetRenderWindow().LineSmoothingOn()
    self.chart = vtk.vtkChartXY()
    self.chart.GetAxis(vtk.vtkAxis.LEFT).SetTitle('Traffic (bytes)')
    self.chart.GetAxis(vtk.vtkAxis.BOTTOM).SetTitle('Time (seconds)')
    self.chart_view.GetScene().AddItem(self.chart)

    self.line = self.chart.AddPlot(vtk.vtkChart.LINE)
    self.line.SetInput(self.hist_table, 0, 1)
    self.line.SetColor(31, 119, 180, 255)
    self.line.SetWidth(1.0)

    # Put chart view in Qt UI
    chart_widget = vtk.QVTKWidget()
    chart_widget.SetRenderWindow(self.chart_view.GetRenderWindow())
    self.chart_container.layout().addWidget(chart_widget)

    # Update views every 1/2 second
    self.timer = QTimer()
    QObject.connect(self.timer, SIGNAL("timeout()"), self.update)
    self.timer.start(500)

  def show(self):
    QMainWindow.show(self)
    self.view.Render()
    self.chart_view.Render()

  def add_ip(self, ip):
    parts = map(ord, ip)
    addr = '.'.join(map(str, parts))
    if self.ip_label.LookupValue(addr) < 0:
      self.ip_subnet.InsertNextValue(parts[0])
      self.ip_label.InsertNextValue(addr)
      self.ip_table.Modified()

  def ip_to_str(self, ip):
    parts = map(ord, ip)
    return '.'.join(map(str, parts))

  def insert_amount(self, time, amt):
    ind = time - self.min_time
    while self.hist_time.GetNumberOfTuples() <= ind:
      self.hist_time.InsertNextValue(self.hist_time.GetNumberOfTuples())
      self.hist_traffic.InsertNextValue(0)
    self.hist_traffic.SetValue(ind, self.hist_traffic.GetValue(ind) + amt)
    self.hist_table.Modified()

  def update(self):

    self.init_comm_table()

    while not self.q.empty():
      try:
        o = self.q.get_nowait()
        t = int(o[0])
        pkt = o[1]
        if isinstance(pkt.data, dpkt.ip.IP):
          self.add_ip(pkt.data.src)
          self.add_ip(pkt.data.dst)
          src_str = self.ip_to_str(pkt.data.src)
          dst_str = self.ip_to_str(pkt.data.dst)
          #print src_str, dst_str, len(pkt.data)
          if self.src.GetNumberOfTuples() < 100:
            self.src.InsertNextValue(src_str)
            self.dst.InsertNextValue(dst_str)
            self.time.InsertNextValue(t)
          self.insert_amount(t, len(pkt.data))
      except Queue.Empty:
        pass

    self.view.Render()
    self.chart.RecalculateBounds()
    self.chart_view.Render()
    #t1 = vtk.vtkTable()
    #t1.SetRowData(self.stream.GetOutput().GetEdgeData())
    #t1.Dump(20)
    #t2 = vtk.vtkTable()
    #t2.SetRowData(self.subnet0.GetOutput().GetVertexData())
    #t2.Dump(10)
