#include <TableToSparseArrayConfig.h>

#include <vtkArrayData.h>
#include <vtkArrayWriter.h>
#include <vtkBasicProgrammableFilter.h>
#include <vtkDelimitedTextReader.h>
#include <vtkSmartPointer.h>
#include <vtkSparseArray.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkArrayData.h>

#include <boost/lexical_cast.hpp>
#include <boost/tr1/functional.hpp>

#include <map>
#include <iostream>

void convert_table(vtkBasicProgrammableFilter* const filter)
{
  try
  {
    // Get the input table and validate its contents ...
    vtkTable* const table = vtkTable::SafeDownCast(filter->GetInputDataObject(0, 0));
    if(!table) throw std::runtime_error("Missing input table.");
    vtkStringArray* const city = vtkStringArray::SafeDownCast(table->GetColumnByName("city"));
    if(!city) throw std::runtime_error("Missing city array.");
    vtkStringArray* const precipitation = vtkStringArray::SafeDownCast(table->GetColumnByName("precipitation"));
    if(!precipitation) throw std::runtime_error("Missing precipitation array.");
    vtkStringArray* const cuisine = vtkStringArray::SafeDownCast(table->GetColumnByName("cuisine"));
    if(!cuisine) throw std::runtime_error("Missing cuisine array.");
    // Note: delimited text reader output is all strings by default, so we will convert values as we iterate ...
    vtkStringArray* const value = vtkStringArray::SafeDownCast(table->GetColumnByName("value"));
    if(!value) throw std::runtime_error("Missing value array.");

    // Setup the output array ...
    vtkSparseArray<double>* const array = vtkSparseArray<double>::New();
    vtkArrayData::SafeDownCast(filter->GetOutputDataObject(0))->AddArray(array);
    array->Delete();

    // Setup hard-coded mappings from enumerated values to array indices ...
    std::map<vtkStdString, vtkIdType> city_map;
    city_map.insert(std::make_pair("Albuquerque", city_map.size()));
    city_map.insert(std::make_pair("Chicago", city_map.size()));
    city_map.insert(std::make_pair("San Jose", city_map.size()));
    city_map.insert(std::make_pair("Taos", city_map.size()));

    std::map<vtkStdString, vtkIdType> precipitation_map;
    precipitation_map.insert(std::make_pair("high", precipitation_map.size()));
    precipitation_map.insert(std::make_pair("low", precipitation_map.size()));
    precipitation_map.insert(std::make_pair("moderate", precipitation_map.size()));

    std::map<vtkStdString, vtkIdType> cuisine_map;
    cuisine_map.insert(std::make_pair("meaty", cuisine_map.size()));
    cuisine_map.insert(std::make_pair("modern", cuisine_map.size()));
    cuisine_map.insert(std::make_pair("spicy", cuisine_map.size()));

    // Populate the array ...
    array->Resize(0, 0, 0);
    vtkArrayCoordinates coordinates(0, 0, 0);
    for(vtkIdType row = 0; row != table->GetNumberOfRows(); ++row)
    {
      coordinates[0] = city_map[city->GetValue(row)];
      coordinates[1] = precipitation_map[precipitation->GetValue(row)];
      coordinates[2] = cuisine_map[cuisine->GetValue(row)];
      array->AddValue(coordinates, boost::lexical_cast<double>(value->GetValue(row)));
    }
    array->SetExtentsFromContents();
  }
  catch(std::exception& e)
  {
    std::cerr << e.what() << std::endl;
  }
}

int main(int argc, char* argv[])
{
  // Load the external data in CSV format ...
  vtkSmartPointer<vtkDelimitedTextReader> table_reader = vtkSmartPointer<vtkDelimitedTextReader>::New();
  table_reader->SetFileName(SOURCE_DIR "/test.csv");
  table_reader->SetHaveHeaders(true);

  // Setup a programmable filter to map enumerated values to indices in a sparse array ...
  vtkSmartPointer<vtkBasicProgrammableFilter> table_to_sparse = vtkSmartPointer<vtkBasicProgrammableFilter>::New();
  table_to_sparse->SetNumberOfInputPorts(1);
  table_to_sparse->SetInputDataType(0, "vtkTable");
  table_to_sparse->SetNumberOfOutputPorts(1);
  table_to_sparse->SetOutputDataType(0, "vtkArrayData");
  table_to_sparse->SetInputConnection(0, table_reader->GetOutputPort());
  table_to_sparse->SetCallback(std::tr1::bind(convert_table, table_to_sparse.GetPointer()));

  // Dump the input table to the console ...
  table_reader->Update();
  table_reader->GetOutput()->Dump(20);

  // Dump the output array to the console ...
  table_to_sparse->Update();
  vtkArrayWriter::Write(vtkArrayData::SafeDownCast(table_to_sparse->GetOutputDataObject(0))->GetArray(0), std::cout);

  return 0;
}
