from vtk import *
from titan import *
import os.path

 # Construct the data dir in Titan
data_dir = os.path.join(TITAN_SOURCE_DIR, "Data")

sqlite_file = data_dir + "/SQLite/SmallEmailTest.db"

database = vtkSQLDatabase.CreateFromURL("sqlite://" + sqlite_file)
database.Open("")

query = database.GetQueryInstance()
query.SetQuery("select Name, Job, Age from employee")

queryToTable = vtkRowQueryToTable()
queryToTable.SetQuery(query)
queryToTable.Update()

T = queryToTable.GetOutput()

print "Query Results:"
T.Dump(12)

query.FastDelete()
database.FastDelete()