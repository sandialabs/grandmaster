#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------------
# This source file is part of the Titan Toolkit
#
# Copyright 2010 Sandia Corporation.  Under the terms of Contract
# DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
# retains certain rights in this software.
#
# This source code is released under the New BSD License.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Copyright (c) Sandia Corporation
# See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
#------------------------------------------------------------------------------

# Description:
# This script exercises the titanMTGLSubgraphIsomorphism filter
# from titan/Libraries/MTGLGraphAnalysis by implementing the first example from
# the MTGL tutorial that can be found at:
#        https://software.sandia.gov/trac/mtgl/wiki/SubgraphIsomorphism
import sys
import time

from vtk import *
from titan.MTGLGraphAnalysis import *

# vtkSNL isn't generally accessible, we should handle things
# gracefully if it's not available.
have_vtksnl = True
try:
    from vtksnl import *
except ImportError:
    have_vtksnl = False

draw_graphs    = True
gen_undirected = False

graph_number = 2

## -----------------------------------------------------------------------------
##
##  populate a graph
##
## -----------------------------------------------------------------------------
def generate_graph(G, V, E):

    # Add Vertices
    for i in range(len(V)):
        G.AddVertex()

    # vertex Ids
    vertexIdArray = vtkIdTypeArray()
    vertexIdArray.SetName("vertex_id")
    vertexIdArray.SetNumberOfTuples(len(V))
    for i in range(len(V)):
        vertexIdArray.SetValue(i, i)
    G.GetVertexData().AddArray(vertexIdArray)

    # vertex colors
    vertexColorArray = vtkIdTypeArray()
    vertexColorArray.SetName("vertex_color")
    vertexColorArray.SetNumberOfTuples(len(V))
    for i in range(len(V)):
        vertexColorArray.SetValue(i, V[i])
    G.GetVertexData().AddArray(vertexColorArray)

    # edges
    for i in range(len(E)):
        s = E[i][0]
        t = E[i][1]
        G.AddGraphEdge(s,t)

    edgeIdArray = vtkIdTypeArray()
    edgeIdArray.SetName("edge_id")
    edgeIdArray.SetNumberOfTuples(len(E))
    for i in range(len(E)):
        edgeIdArray.SetValue(i, i)
    G.GetEdgeData().AddArray(edgeIdArray)

    # edge colors
    edgeColorArray = vtkIdTypeArray()
    edgeColorArray.SetName("edge_color")
    edgeColorArray.SetNumberOfTuples(len(E))
    for i in range(len(E)):
        edgeColorArray.SetValue(i, E[i][2])
    G.GetEdgeData().AddArray(edgeColorArray)

    # pedigree ids
    G.GetVertexData().SetPedigreeIds( vertexIdArray );
    G.GetEdgeData().SetPedigreeIds( edgeIdArray );

    #print Gsrc


## -----------------------------------------------------------------------------
##
## MAIN
##
## -----------------------------------------------------------------------------
if __name__ == "__main__":

    ## -------------------------------------------------------------------------
    ##
    ##  Create 'Big' Graph
    ##
    ## -------------------------------------------------------------------------
    verts = None
    edges = None

    # graph 1 matches the graph in the MTGL tutorial
    if graph_number == 1:
        verts = [(1), (2), (3), (2), (3), (1)]
        edges = [(1,0,1), (2,0,2), (1,2,3), (2,3,3), (3,4,3), (3,5,1), (4,5,2),]

    # graph 2 adds some vertices and edges to the example.
    elif graph_number==2:
        verts = [(1), (2), (3), (2), (3), (1), (8), (5), (3)]
        edges = [(1,0,1), (2,0,2), (1,2,3), (2,3,3), (3,4,3), (3,5,1), (4,5,2),
                 (2,6,4), (3,6,4), (6,7,9), (6,8,6), (7,8,4) ]
    Gsrc = None
    if gen_undirected:
        Gsrc = vtkMutableUndirectedGraph()
    else:
        Gsrc = vtkMutableDirectedGraph()
    generate_graph(Gsrc, verts, edges)

    ## -------------------------------------------------------------------------
    ##
    ##  Create 'Target' Graph
    ##
    ## -------------------------------------------------------------------------
    verts_t = [(1),(2),(3)]
    edges_t = [(1,0,1),(2,0,2),(1,2,3)]
    Gtarg2 = vtkMutableUndirectedGraph()
    generate_graph(Gtarg2, verts_t, edges_t)

    Gtarg = None
    if gen_undirected:
        Gtarg = vtkMutableUndirectedGraph()
    else:
        Gtarg = vtkMutableDirectedGraph()
    generate_graph(Gtarg, verts_t, edges_t)

    ## -------------------------------------------------------------------------
    ##
    ## Create 'Walk'
    ##
    ## -------------------------------------------------------------------------
    walkTable = None
    if have_vtksnl:
        trgWalk = vtkGraphEdgeWalkToTable()
        trgWalk.SetGraphConnection( Gtarg2.GetProducerPort() )
        trgWalk.SetStartVertexId(0)
        trgWalk.SetEdgeWalkColumnName("graph_walk")
        trgWalk.Update()
        walkTable = trgWalk.GetOutput()
    else:
        walk_vec = [0,0,1,2,2,1,0]
        trgWalk = vtkTable()
        trgWalkCol = vtkIdTypeArray()
        trgWalkCol.SetName("graph_walk")
        for i in walk_vec:
            trgWalkCol.InsertNextValue( i )
        trgWalk.AddColumn(trgWalkCol)
        walkTable = trgWalk



    print "Dump generated walk table"
    walkTable.Dump(10)

    ## -------------------------------------------------------------------------
    ##
    ##  MTGLSubgraphIsomorphism
    ##
    ## -------------------------------------------------------------------------
    subg_iso = vtkMTGLSubgraphIsomorphism()
    subg_iso.SetBigGraphConnection( Gsrc.GetProducerPort() )
    subg_iso.SetTargetGraphConnection( Gtarg.GetProducerPort() )
    subg_iso.SetWalkTableConnection( walkTable.GetProducerPort() )

    subg_iso.SetGraphVertexAttribute("vertex_color")
    subg_iso.SetGraphEdgeAttribute("edge_color")

    subg_iso.SetTargetVertexAttribute("vertex_color")
    subg_iso.SetTargetEdgeAttribute("edge_color")

    subg_iso.SetWalkTableColumnName("graph_walk")

    subg_iso.SetSubgraphComponentArrayName("subgraph")

    subg_iso.Update()

    if draw_graphs:
        ## -----------------------------------------------------------------
        ##
        ## Theme settings
        ##
        ## -----------------------------------------------------------------
        theme = vtkViewTheme.CreateOceanTheme()
        theme.SetVertexLabelColor(.2, .2, .2)
        theme.SetEdgeLabelColor(.2, .2, .2)


        ## -----------------------------------------------------------------
        ##
        ## View 1: Graph View ('Big' graph)
        ##
        ## -----------------------------------------------------------------
        view = vtkGraphLayoutView()
        view.AddRepresentationFromInputConnection(subg_iso.GetOutputPort())
        view.SetLayoutStrategyToSimple2D()
        view.ApplyViewTheme(theme)
        view.GetRenderWindow().SetSize(400, 400)

        view.SetVertexLabelArrayName("vertex_id")
        #view.SetVertexLabelArrayName("subgraph")
        view.SetVertexLabelVisibility(True)

        #view.SetVertexColorArrayName("vertex_color")
        view.SetVertexColorArrayName("subgraph")
        view.SetColorVertices(True)

        #view.SetEdgeLabelArrayName("edge_id")
        view.SetEdgeLabelArrayName("edge_color")
        #view.SetEdgeLabelArrayName("subgraph")
        view.SetEdgeLabelVisibility(True)

        #view.SetEdgeColorArrayName("edge_color")
        view.SetEdgeColorArrayName("subgraph")
        view.SetColorEdges(True)

        view.ResetCamera()
        view.Render()


        ## -----------------------------------------------------------------
        ##
        ## View 2: Graph View ('Target' graph)
        ##
        ## -----------------------------------------------------------------
        view2 = vtkGraphLayoutView()
        view2.AddRepresentationFromInputConnection(Gtarg.GetProducerPort())
        view2.SetLayoutStrategyToFast2D()
        view2.ApplyViewTheme(theme)
        view2.GetRenderWindow().SetSize(400, 400)

        view2.SetVertexLabelArrayName("vertex_id")
        view2.SetVertexLabelVisibility(True)

        view2.SetVertexColorArrayName("vertex_color")
        view2.SetColorVertices(True)

        #view2.SetEdgeLabelArrayName("edge_id")
        view2.SetEdgeLabelArrayName("edge_color")
        view2.SetEdgeLabelVisibility(True)

        view2.SetEdgeColorArrayName("edge_color")
        view2.SetColorEdges(True)

        view2.ResetCamera()
        view2.Render()


        ## -----------------------------------------------------------------
        ##
        ## Start up the interactor
        ##
        ## -----------------------------------------------------------------
        theme.FastDelete()
        view2.GetInteractor().Start()
