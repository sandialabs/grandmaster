#!/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------------
# This source file is part of the Titan Toolkit
#
# Copyright 2010 Sandia Corporation.  Under the terms of Contract
# DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
# retains certain rights in this software.
#
# This source code is released under the New BSD License.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Copyright (c) Sandia Corporation
# See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
#------------------------------------------------------------------------------

import sys
import random

from vtk import *
from titan.MTGLGraphAnalysis import *

def createVtkGraphLayoutView(viewGraph,
                             width, height,
                             viewThemeType = None,
                             layoutStrategy="Fast 2D",
                             vertexLabelArrayName=None,
                             vertexColorArrayName=None,
                             edgeLabelArrayName=None,
                             edgeColorArrayName=None,
                             enabledEdgesArrayName=None,
                             enableEdgesByArray=False,
                             enabledVerticesArrayName=None,
                             enableVerticesByArray=False):

    view  = vtkGraphLayoutView()
    theme = vtkViewTheme.CreateMellowTheme()
    view.AddRepresentationFromInputConnection(viewGraph.GetOutputPort())
    if vertexLabelArrayName:
        view.SetVertexLabelArrayName(vertexLabelArrayName)
        view.SetVertexLabelVisibility(True)
    if vertexColorArrayName:
        view.SetVertexColorArrayName(vertexColorArrayName)
        view.SetColorVertices(True)

    view.SetLayoutStrategyToFast2D()
    view.SetVertexLabelFontSize(12)
    theme.SetLineWidth(2)
    theme.SetPointSize(8)
    theme.SetCellOpacity(1.0)
    view.ApplyViewTheme(theme)
    theme.FastDelete()
    view.GetRenderWindow().SetSize(width,height)
    view.ResetCamera()
    view.Render()
    return view

#
#
if __name__ == "__main__":
    source = vtkRandomGraphSource()
    source.SetNumberOfVertices(20)
    source.SetStartWithTree(True)
    source.SetEdgeProbability(0.042)
    source.UseEdgeProbabilityOn()

    # set up a selection
    selection = vtkSelectionSource()
    selection.SetFieldType(vtkSelectionNode.VERTEX)        # generate a "vertex" selection 3
    #selection.SetContentType(4)     # set content type to indices.  4
    selection.AddID(0, 0)
    selection.AddID(0, 9)

    ST = vtkMTGLSelectionFilterST()
    ST.SetGraphConnection(source.GetOutputPort())
    ST.SetInputConnection(0, selection.GetOutputPort())
    ST.Update()

    selectionList = ST.GetOutput().GetNode(0).GetSelectionList()
    for i in range(selectionList.GetNumberOfTuples()):
        print "ST Node %d:"%(i), selectionList.GetValue(i)


    G = vtkExtractSelectedGraph()
    G.AddInputConnection(source.GetOutputPort())
    G.SetSelectionConnection(ST.GetOutputPort())
    G.Update()

    view = createVtkGraphLayoutView(G, 600, 600,
                                    vertexLabelArrayName="vertex id",
                                    vertexColorArrayName="vertex id")

    view2 = createVtkGraphLayoutView(source, 600, 600,
                                    vertexLabelArrayName="vertex id",
                                    vertexColorArrayName="vertex id")
    view.GetInteractor().Start()
