#!/usr/bin/env python
# -*- coding: utf-8 -*-

#------------------------------------------------------------------------------
# This source file is part of the Titan Toolkit
#
# Copyright 2010 Sandia Corporation.  Under the terms of Contract
# DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
# retains certain rights in this software.
#
# This source code is released under the New BSD License.
#------------------------------------------------------------------------------

#------------------------------------------------------------------------------
# Copyright (c) Sandia Corporation
# See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
#------------------------------------------------------------------------------

import sys
import random

from vtk import *
from titan.MTGLGraphAnalysis import *

#
#
if __name__ == "__main__":
    source = vtkRandomGraphSource()
    source.SetNumberOfVertices(40)
    source.SetStartWithTree(True)
    source.SetEdgeProbability(0.042)
    source.UseEdgeProbabilityOn()

    # set up a selection
    selection = vtkSelectionSource()
    selection.SetFieldType(3)        # generate a "vertex" selection
    #selection.SetContentType(4)     # set content type to indices.
    selection.AddID(0, 0)
    selection.AddID(0, 30)
    selection.AddID(0, 21)
    selection.AddID(0, 28)

    ST = vtkMTGLSelectionFilterMultiST()
    ST.SetGraphConnection(source.GetOutputPort())
    ST.SetInputConnection(0, selection.GetOutputPort())
    ST.Update()

    selectionList = ST.GetOutput().GetNode(0).GetSelectionList()
    for i in range(selectionList.GetNumberOfTuples()):
        print "ST Node %d:"%(i), selectionList.GetValue(i)

    G = vtkExtractSelectedGraph()
    G.AddInputConnection(source.GetOutputPort())
    G.SetSelectionConnection(ST.GetOutputPort())
    G.Update()

    #----------------------------------------------------------
    # Draw the graph in a window
    theme = vtkViewTheme.CreateMellowTheme()
    theme.SetLineWidth(4)
    theme.SetPointSize(10)
    theme.SetCellOpacity(1)
    theme.FastDelete()

    view = vtkGraphLayoutView()
    view.AddRepresentationFromInputConnection(G.GetOutputPort())
    view.SetVertexLabelArrayName("vertex id")
    view.SetVertexLabelVisibility(True)
    view.SetVertexColorArrayName("vertex id")
    view.SetColorVertices(True)
    view.SetLayoutStrategyToSimple2D()
    view.SetVertexLabelFontSize(20)

    view.ApplyViewTheme(theme)

    view.GetRenderWindow().SetSize(600, 600)
    view.ResetCamera()
    view.Render()

    # Also want to see the original graph
    view2 = vtkGraphLayoutView()
    view2.AddRepresentationFromInputConnection(source.GetOutputPort())
    view2.SetVertexLabelArrayName("vertex id")
    view2.SetVertexLabelVisibility(True)
    view2.SetVertexColorArrayName("vertex id")
    view2.SetColorVertices(True)
    view2.SetLayoutStrategyToSimple2D()
    view2.SetVertexLabelFontSize(20)

    view2.ApplyViewTheme(theme)

    view2.GetRenderWindow().SetSize(600, 600)
    view2.ResetCamera()
    view2.Render()

    view.GetInteractor().Start()
