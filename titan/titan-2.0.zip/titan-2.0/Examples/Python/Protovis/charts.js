

charts.AddNodeLinkChart = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':400,
    'bottom':50,
    'left':50,
    'right':50,
    'top':50,
    'panel':null,
    'data':null,
    'label':'label',
    'spring_length':10,
    'icons':null,
    'iconwidth':32,
    'iconheight':32,
    'nodesize':null,
    'linksize':null,
    'linkcolor':null,
    'linkcolorvalue':'count',
    'canvas':null,
    'clickCallback':function() { }
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  var label = args['label'];
  var spring_length = args['spring_length'];
  var linkcolorvalue = args['linkcolorvalue'];
  var icons = args['icons'];
  var iconwidth = args['iconwidth'];
  var iconheight = args['iconheight'];

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  // Create the graph
  var graph = args['panel'].add(pv.Layout.Force);
  var nodes = graph.nodes(args['data'].vertices);
  var links = graph.links(args['data'].edges);


  // Variable node size
  if (!args['nodesize']) {
    args['nodesize']= pv.Scale.linear(args['data'].vertices, function(d) d.VertexDegree).range(40, 400);
  }

  // Variable link size
  if (!args['linksize']) {
    args['linksize']= pv.Scale.log(args['data'].edges, function(d) d.count).range(4, 6);
  }

  // Link color
  if (!args['linkcolor']) {
    args['linkcolor']= pv.Scale.log(args['data'].edges, function(d) d.count).range("#88F", "#F88");
  }

  // Links
  lines = graph.link.add(pv.Line);
  lines.lineWidth(function(d, p) args['linksize'](p.count));
  lines.strokeStyle(function(d, p) args['linkcolor'](p.count));

  // Nodes or Icons
  if (!args['icons']) {
    graph.node.add(pv.Dot)
      .size(function(d) args['nodesize'](d.VertexDegree))
      .fillStyle(pv.Colors.category19().by(pv.index))
      .strokeStyle("rgba(0,0,0,.5)")
      .lineWidth(1)
      .event("mousedown", pv.Behavior.drag())
    .anchor("right").add(pv.Label)
      .font("bold 12px Calibri")
      .textStyle("rgb(60,60,120)")
      .text(function(d) d.label);

  } else {
    node = graph.node.add(pv.Panel)
        .fillStyle("rgba(0,0,0,0)")
        .strokeStyle("rgba(0,0,0,0)")
        .width(iconwidth)
        .height(iconheight)
        .left(function(d) d.x - iconwidth/2)
        .top(function(d) d.y - iconheight/2)
        .event("mousedown", pv.Behavior.drag())
      .add(pv.Image)
        .url(function(d) icons[d.icon]);

      node.anchor("right").add(pv.Label)
        .font("bold 12px Calibri")
        .textStyle("rgb(60,60,120)")
        .text(function(d) d.label);
  }

  // Bound on container
  graph.bound(true);
  graph.springLength(spring_length);
  graph.chargeConstant(-1000);
  graph.chargeMaxDistance(500);

  return args['panel'];

}

charts.AddMatrixDiagram = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':400,
    'bottom':10,
    'left':80,
    'right':10,
    'top':80,
    'panel':null,
    'data':null,
    'directed':true,
    'label':'label',
    'colorrange':null,
    'colorvalue':'count',
    'canvas':null,
    'clickCallback':function() { }
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  label = args['label'];
  colorvalue = args['linkcolorvalue'];
  directed = args['directed'];

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  // Element color
  if (!args['colorrange']) {
    args['colorrange']= pv.Scale.linear(1, 2).range("#88F", "#F88");
  }

  // Temp
  var color = pv.Colors.category19().by(function(d) d.group);

  // Make Matrix
  var matrix = args['panel'].add(pv.Layout.Matrix)
    .nodes(args['data'].vertices)
    .links(args['data'].edges)
    .directed(directed);
    //.sort(function(a, b) a.label > b.label);

  // Color the matrix elements
  matrix.link.add(pv.Bar)
    .fillStyle(function(l) l.linkValue ? args['colorrange'](l.linkValue) : "rgba(155,155,155,.25)")
    .antialias(false)
    .lineWidth(1);

  // Matrix labels
  matrix.label.add(pv.Label)
    .text(function(d) d.label)
    .textStyle("rgb(60,60,120)")
    .font("bold 12px Calibri");

  return args['panel'];

}

/*
  var layout = vis.add(pv.Layout.Matrix)
    .nodes(miserables.nodes)
    .links(miserables.links)
    .sort(function(a, b) b.group - a.group);

layout.link.add(pv.Bar)
    .fillStyle(function(l) l.linkValue
        ? ((l.targetNode.group == l.sourceNode.group)
        ? color(l.sourceNode) : "#555") : "#eee")
    .antialias(false)
    .lineWidth(1);

layout.label.add(pv.Label)
    .textStyle(color);
*/

charts.AddArcDiagram = function(args) {

  args = args || {};

  var default_args = {
    'width':500,
    'height':200,
    'bottom':20,
    'left':50,
    'right':50,
    'top':20,
    'panel':null,
    'data':null,
    'canvas':null,
    'clickCallback':function() { }
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  // Create the graph
  var graph = args['panel'].add(pv.Layout.Arc);
  var nodes = graph.nodes(args['data'].vertices);
  var links = graph.links(args['data'].edges);

  // Links.
  lines = graph.link.add(pv.Line);
  lines.lineWidth(function(d, p) 5 + p.Edges_Aggregated*.01);
  lines.strokeStyle("rgba(80, 80, 125, 0.5)");

  // Nodes.
  node = graph.node.add(pv.Dot)
    .size(function(d) d.Verts_Aggregated*10+50)
    .fillStyle(pv.Colors.category19().by(pv.index))
    .event("mousedown", pv.Behavior.drag())
    .event("click", args['clickCallback'])
    .strokeStyle("rgb(60,60,120)")
  .anchor("center").add(pv.Label)
    .font(function(d) 14 + "px calibri")
    .text(function(d) "Community " + d.community);


  return args['panel'];

  }

charts.AddIndentedTree = function(args) {

  args = args || {};

  var default_args = {
    'width':500,
    'height':200,
    'bottom':20,
    'left':20,
    'right':0,
    'top':0,
    'panel':null,
    'data':null,
    'canvas':null,
    'clickCallback':function() { }
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  // Temporary data
  var root = pv.dom(args['data'])
    .root("webClusters")
    .sort(function(a, b) pv.naturalOrder(a.nodeName, b.nodeName));

  // Recursively compute the package sizes.
  root.visitAfter(function(n) {
    if (n.firstChild) {
      n.nodeValue = pv.sum(n.childNodes, function(n) n.nodeValue);
    }
  });


  var layout = args['panel'].add(pv.Layout.Indent)
    .nodes(function() root.nodes())
    .depth(12)
    .breadth(12);

  layout.link.add(pv.Line);

  var node = layout.node.add(pv.Panel)
    .top(function(n) n.y - 6)
    .height(12)
    .right(6)
    .strokeStyle(null)
    .events("all")
    .event("mousedown", toggle);

  node.anchor("left").add(pv.Dot)
    .strokeStyle("#1f77b4")
    .fillStyle(function(n) n.toggled ? "#1f77b4" : n.firstChild ? "#aec7e8" : "#ff7f0e")
    .title(function t(d) d.parentNode ? (t(d.parentNode) + "." + d.nodeName) : d.nodeName)
  .anchor("right").add(pv.Label)
    .text(function(n) n.nodeName);

  node.anchor("right").add(pv.Label)
    .textStyle(function(n) n.firstChild || n.toggled ? "#aaa" : "#000")
    .text(function(n) (n.nodeValue) + " Blogs");

  args['panel'].render();

  // Toggles the selected node, then updates the layout.
  function toggle(n) {
    n.toggle(pv.event.altKey);
    return layout.reset().root;
  }

  return args['panel']
}


charts.AddBoxPlot = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':200,
    'bottom':50,
    'left':70,
    'right':20,
    'top':20,
    'panel':null,
    'data':null,
    'xscale':null,
    'yscale':null,
    'ylog':true,
    'color':null,
    'fontcolor':null,
    'canvas':null,
    'beamwidth':2,
    'xaxislabel':null,
    'yaxislabel':null,
    'xlabelangle':0,
    'fill':function(d) d.Median > .5 ? "#aec7e8" : "#ffbb78",
    'xkey':'x',
    'ykey':'y',
    'panelObservableSubjectName':null,
    'panelSubjectsToObserve':null,
    'notifyMethodImplementation':null
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  var x = args['xkey'];
  var y = args['ykey'];
  var beamwidth = args['beamwidth'];
  var xlabelangle = args['xlabelangle'];

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  if(!args['xscale']) {
      args['xscale'] = pv.Scale.ordinal(args['data'], function(d) d[x]).splitBanded(0, args['width'], 4/5)
  }

  if(!args['yscale']) {
    if (args['ylog']) {
      args['yscale'] = pv.Scale.log(args['data'], function(d) d[y]).range(0, args['height']);
    } else {
      args['yscale'] = pv.Scale.linear(args['data'], function(d) d[y]).range(0, args['height']);
    }
    args['yscale'].nice();
  }

  if(!args['labelsize']) {
    args['labelsize'] = (function(d) 12);
  }

  if(!args['color']) {
    args['color'] = "rgba(150,150,150,.5)";
  }

  if(!args['fontcolor']) {
    args['fontcolor'] = "rgb(60,60,120)";
  }


  // Y-axis and ticks.
  args['panel'].add(pv.Rule)
    .data(args['yscale'].ticks())
    .bottom(args['yscale'])
    .strokeStyle("#ccc")
    .visible(function() !(this.index % 2))
  .anchor("left").add(pv.Label)
    .text(function(d) d.toPrecision(2))
    .font("12px Calibri")
    .visible(function() {
       if(args['ylog']) {return !(this.index % 4)}
       else return 1});

  // Y-axis label
  if(args['yaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['yaxislabel']])
      .left(-45)
      .bottom(args['height']/2)
      .font("bold 20px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center")
      .textAngle(-Math.PI/2);
  }

  // X-axis label
  if(args['xaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['xaxislabel']])
      .bottom(-45)
      .left(args['width']/2)
      .font("bold 20px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center");
  }

  // Add a panel for each data point
  s = args['xscale'].range().band / 2;
  var points = args['panel'].add(pv.Panel)
      .data(args['data'])
      .left(function(d) args['xscale'](d[x]))
      .width(s * 2);

  // Add the group id label
  points.anchor("bottom").add(pv.Label)
      .textBaseline("top")
      .text(function(d) d[x])
      .font("10px Calibri")
      .textAngle(xlabelangle);

  // Add the range line
  points.add(pv.Rule)
      .left(s)
      .lineWidth(beamwidth)
      .bottom(function(d) args['yscale'](d.Minimum))
      .height(function(d) args['yscale'](d.First_Quartile) - args['yscale'](d.Minimum));
  points.add(pv.Rule)
      .left(s)
      .lineWidth(beamwidth)
      .bottom(function(d) args['yscale'](d.Third_Quartile))
      .height(function(d) args['yscale'](d.Maximum) - args['yscale'](d.Third_Quartile));

  // Add the min and max indicators
  points.add(pv.Rule)
      .data(function(d) [d.Minimum, d.Maximum])
      .bottom(args['yscale'])
      .left(s / 2)
      .lineWidth(beamwidth)
      .width(s);

  // Add the upper/lower quartile ranges
  points.add(pv.Bar)
      .bottom(function(d) args['yscale'](d.First_Quartile))
      .height(function(d) {
         var height = args['yscale'](d.Third_Quartile) - args['yscale'](d.First_Quartile);
         return height < 1 ? (4) : height;})
      .fillStyle(args['fill'])
      .strokeStyle('black')
      .lineWidth(1)
      .antialias(false);

  // Add the median line
  points.add(pv.Rule)
      .bottom(function(d) args['yscale'](d.Median));

  // Register panel as observable subject.  Can be observed by other Protovis panels.
  if(args['panelObservableSubjectName']) {
    args['panel'].registerSelfAsObservableSubject(args['panelObservableSubjectName']);
  }

  // Sign up to observe other Protovis panels.  Notify() will be called on this panel
  // for any events recieved on these panels.
  if(args['panelSubjectsToObserve']) {
    for(k in args['panelSubjectsToObserve']) {
      s = args['panel'].getPanelObservableSubject(args['panelSubjectsToObserve'][k]);
      s.registerObserver(args['panel']);
    }
  }

  // Notify method implementation that will be called when any observed panels
  // recieve events on their contained Protovis marks.
  if(args['notifyMethodImplementation']) {
    args['panel'].notify = args['notifyMethodImplementation'];
  }

  return args['panel'];

}


charts.AddAreaChart = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':200,
    'bottom':30,
    'left':40,
    'right':20,
    'top':20,
    'panel':null,
    'data':null,
    'xscale':null,
    'yscale':null,
    'data2':null,
    'yscale2':null,
    'xlog':false,
    'ylog':false,
    'color':null,
    'color2':null,
    'fontcolor':null,
    'canvas':null,
    'xaxislabel':null,
    'yaxislabel':null,
    'yaxislabel2':null,
    'xkey':'x',
    'ykey':'y',
    'date_format':'%m/%y',
    'fill1':true,
    'fill2':false,
    'linewidth':1,
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  var x = args['xkey'];
  var y = args['ykey'];
  var width = args['width'];
  var height = args['height'];

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  if(!args['xscale']) {
    if (args['xlog']) {
      args['xscale'] = pv.Scale.log(args['data'], function(d) d[x]).range(0,width);
    } else {
      args['xscale'] = pv.Scale.linear(args['data'], function(d) d[x]).range(0,width);
    }
    args['xscale'].nice();
  }

  var y_base = 0;
  var y_scale_range = 0;
  var y_axis2_skip = 2;
  if(args['mirror']) {
    var y_base = height/4;
    var y_scale_range = -y_base;
    var y_axis2_skip = 4;
  }


  if(!args['yscale']) {
    if (args['ylog']) {
      args['yscale'] = pv.Scale.log(args['data'], function(d) d[y]).range(0, height);
      args['yscale2'] = pv.Scale.log(args['data2'], function(d) d[y]).range(0, height);
    } else {
      args['yscale'] = pv.Scale.linear(args['data'], function(d) d[y]).range(y_base, height);
      args['yscale2'] = pv.Scale.linear(args['data2'], function(d) d[y]).range(0, y_scale_range);
    }
    args['yscale'].nice();
  }

  if(!args['labelsize']) {
    args['labelsize'] = (function(d) 12);
  }

  if(!args['color']) {
    args['color'] = "rgba(180,180,150,.5)";
  }

  if(!args['color2']) {
    args['color2'] = "rgba(180,150,150,.5)";
  }

  if(!args['fontcolor']) {
    args['fontcolor'] = "rgb(60,60,120)";
  }



  // Y-axis and ticks.
  y_axis = args['panel'].add(pv.Rule)
    .data(args['yscale'].ticks())
    .bottom(args['yscale'])
    .strokeStyle(function(d) d ? "#ccc" : "#000")
    .visible(function() !(this.index % 2))
  .anchor("left").add(pv.Label)
    .font("12px Calibri")
    .text(function(d) d.toPrecision(2));

  // Y-axis2 and ticks.
  if (args['data2']) {

    if (args['mirror']) {
      y_axis2 = args['panel'].add(pv.Rule)
        .data(args['yscale2'].ticks())
        .bottom(function(d) y_base + args['yscale2'](d))
    .strokeStyle("#ccc")
        .visible(function() !(this.index % y_axis2_skip))
      .anchor("right").add(pv.Label)
        .left(args['width'])
        .text(function(d) d.toPrecision(2));

    } else {

    var data_min = pv.min(args['data2'],function(d) d[y]);
    var data_max = pv.max(args['data2'],function(d) d[y]);
    var data_range = data_max-data_min;
    var num_ticks = args['yscale'].ticks().length;

    y_axis.anchor("right").add(pv.Label)
      .left(width+20)
      .font("12px Calibri")
      .text(function() {
        var data2_value = data_min + this.index/num_ticks*data_range;
        return data2_value.toPrecision(2);
      });
    }
  }


  // Y-axis label
  if(args['yaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['yaxislabel']])
      .left(-25)
      .bottom(height/2)
      .font("bold 14px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center")
      .textAngle(-Math.PI/2);
  }

  // Y-axis2 label
  if(args['yaxislabel2']) {
    args['panel'].add(pv.Label)
      .data(args['yaxislabel2'])
      .left(width+40)
      .bottom(height/2)
      .font("bold 14px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center")
      .textAngle(-Math.PI/2);
  }

  // X-axis and ticks.
  args['panel'].add(pv.Rule)
    .data(args['xscale'].ticks())
    .left(args['xscale'])
    .strokeStyle("#ccc")
    .textAlign("center")
  .anchor("bottom").add(pv.Label)
    .text(pv.Format.date(args['date_format']))  // Fixme: This needs to support non-dates
    .font("12px Calibri")
    .visible(function() {
       if(args['xlog']) return !(this.index % 4)
       else return !(this.index % 2)
    });

   // X-axis label
  if(args['xaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['xaxislabel']])
      .bottom(-30)
      .left(args['width']/2)
      .font("bold 14px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center");
  }

  // Add the area chart
  var i = -1;
  var color = new pv.color(args['color']);
  if (!args['fill1']) color = color.alpha(0);
  var area1 = args['panel'].add(pv.Area)
    .data(args['data'])
    .bottom(y_base)
    .left(function(d) args['xscale'](d[x]))
    .height(function(d) args['yscale'](d[y])-y_base)
    .fillStyle(color);
  var line1 = area1.anchor("top").add(pv.Line)
    .strokeStyle(color.darker().alpha(1))
    .lineWidth(args['linewidth']);

  // The mouseover dots and label.
  area1.add(pv.Dot)
    .visible(function() i >= 0)
    .data(function(d) [args['data'][i]])
    .bottom(function(d) args['yscale'](d[y])-y_base)
    .fillStyle(color.darker().alpha(1))
    .strokeStyle('none')
    .size(20)
    .lineWidth(1)
  .add(pv.Dot)
    .left(10)
    .top(20)
  .anchor("right").add(pv.Label)
    .text(function(d) d[y].toFixed(2));

  // Add the second chart
  var i2 = -1;
  var color2 = new pv.color(args['color2']);
  if (!args['fill2']) color2 = color2.alpha(0);
  if (args['data2']) {
    var area2 = args['panel'].add(pv.Area)
      .data(args['data2'])
      .bottom(y_base)
      .left(function(d) args['xscale'](d[x]))
      .height(function(d) args['yscale2'](d[y]))
      .fillStyle(color2);
    var line2 = area2.anchor("top").add(pv.Line)
      .strokeStyle(color2.darker().alpha(1))
      .lineWidth(args['linewidth']);

    // Just a delinator between top/bottom series
    args['panel'].add(pv.Rule)
      .bottom(y_base)
      .strokeStyle("#000")
      .lineWidth(1.5);

    // The mouseover dots and label.
    area2.add(pv.Dot)
      .visible(function() i2 >= 0)
      .data(function(d) [args['data2'][i2]])
      .bottom(function(d) args['yscale2'](d[y]))
      .fillStyle(color2.darker().alpha(1))
      .strokeStyle('none')
      .size(20)
      .lineWidth(1)
    .add(pv.Dot)
      .left(10)
      .bottom(10)
    .anchor("right").add(pv.Label)
      .text(function(d) d[y].toFixed(2));
  }

  // An invisible bar to capture events (without flickering).
  args['panel'].add(pv.Bar)
    .fillStyle("rgba(0,0,0,.001)")
    .event("mouseout", function() {
        i = -1;
        return args['panel'];
      })
    .event("mousemove", function() {
        var mx = args['xscale'].invert(args['panel'].mouse().x);
        i = pv.search(args['data'].map(function(d) d[x]), mx);
        i = i < 0 ? (-i - 2) : i;

        if (args['data2']) {
          var mx2 = args['xscale'].invert(args['panel'].mouse().x);
          i2 = pv.search(args['data2'].map(function(d) d[x]), mx2);
          i2 = i2 < 0 ? (-i2 - 2) : i2;
        }

        return args['panel'];
      });

  return args['panel'];
}

charts.AddStackedChart = function(args) {

  args = args || {};

  var default_args = {
      'width':400,
      'height':200,
      'bottom':50,
      'left':70,
      'right':20,
      'top':20,
      'panel':null,
      'data':null,
      'xlog':false,
      'ylog':false,
      'color':null,
      'fontcolor':null,
      'canvas':null,
      'xaxislabel':null,
      'yaxislabel':null,
      'yaxislabel2':null,
      'xkey':'x',
      'ykey':'y',
      'fill1':true,
      'layerKey':null,
      'date_format':'%m/%y'
      }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  var x = args['xkey'];
  var y = args['ykey'];
  var layerKey = args['layerKey'];
  var width = args['width'];
  var height = args['height'];

  if(!args['panel']) {
  args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }


  if(!args['xscale']) {
    if (args['xlog']) {
      args['xscale'] = pv.Scale.log(args['data'], function(d) d[x]).range(0,args['width']);
    } else {
      args['xscale'] = pv.Scale.linear(args['data'], function(d) d[x]).range(0,args['width']);
    }
    args['xscale'].nice();
  }

  if(!args['yscale']) {
    if (args['ylog']) {
      args['yscale'] = pv.Scale.log(args['data'], function(d) d[y]).range(0, height);
    } else {
      args['yscale'] = pv.Scale.linear(args['data'], function(d) d[y]).range(0, height);
    }
    args['yscale'].nice();
  }

  if(!args['labelsize']) {
    args['labelsize'] = (function(d) 12);
  }

  if(!args['color']) {
    args['color'] = "rgba(150,150,150,.5)";
  }

  if(!args['fontcolor']) {
    args['fontcolor'] = "rgb(60,60,120)";
  }


  // X-axis and ticks.
  args['panel'].add(pv.Rule)
     .data(args['xscale'].ticks())
     .left(args['xscale'])
     .strokeStyle("#ccc")
     .textAlign("center")
     //.visible(function() !(this.index % 2))
  .anchor("bottom").add(pv.Label)
    .text(pv.Format.date(args['date_format']))  // Fixme: This needs to support non-dates
    .visible(function() {
       if(args['xlog']) {return !(this.index % 4)}
       else return 1});

  // X-axis label
  if(args['xaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['xaxislabel']])
      .bottom(-45)
      .left(args['width']/2)
      .font("bold 20px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center");
  }

  // Y-axis and ticks.
  args['panel'].add(pv.Rule)
     .data(args['yscale'].ticks())
     .bottom(args['yscale'])
     .strokeStyle(function(d) d ? "#ccc" : "#000")
     .visible(function() !(this.index % 2))
   .anchor("left").add(pv.Label)
    .text(function(d) d.toPrecision(2));

  // Y-axis label
  if(args['yaxislabel']) {
    args['panel'].add(pv.Label)
        .data([args['yaxislabel']])
        .left(-45)
        .bottom(args['height']/2)
        .font("bold 20px Calibri")
        .textStyle(args['fontcolor'])
        .textAlign("center")
        .textAngle(-Math.PI/2);
  }


  args['panel'].add(pv.Layout.Stack)
    .layers(function() pv.nest(args['data'])
        .key(function(d) d[layerKey])
        .entries())
    .values(function(d) d.values)
    //.order("inside-out")
    //.offset("wiggle")
    .x(function(d) args['xscale'](d[x]))
    .y(function(d) args['yscale'](d[y]))
    .bottom(0)
  .layer.add(pv.Area)
    .fillStyle(pv.Colors.category19().by(pv.parent))

  return args['panel'];
}

charts.AddScatterPlot = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':200,
    'bottom':50,
    'left':70,
    'right':20,
    'top':20,
    'xlog':false,
    'ylog':false,
    'date_format':null,
    'panel':null,
    'data':null,
    'radius':40,
    'xscale':null,
    'yscale':null,
    'color':null,
    'fontcolor':null,
    'canvas':null,
    'datalabel':null,
    'xaxislabel':null,
    'yaxislabel':null,
    'xkey':'x',
    'ykey':'y',
    'panzoom':false,
    'panelObservableSubjectName':null,
    'panelSubjectsToObserve':null,
    'notifyMethodImplementation':null
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  var x = args['xkey'];
  var y = args['ykey'];
  var radius = args['radius'];


  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  if(!args['xscale']) {
    if (args['xlog']) {
      args['xscale'] = pv.Scale.log(args['data'], function(d) d[x]).range(0,args['width']);
    } else {
      args['xscale'] = pv.Scale.linear(args['data'], function(d) d[x]).range(0,args['width']);
    }
    args['xscale'].nice(5);
  }

  if(!args['yscale']) {
    if (args['ylog']) {
      args['yscale'] = pv.Scale.log(args['data'], function(d) d[y]).range(0, args['height']);
    } else {
      args['yscale'] = pv.Scale.linear(args['data'], function(d) d[y]).range(0, args['height']);
    }
    args['yscale'].nice();
  }

  if(!args['color']) {
    if (args['ylog']) {
      var color_scale = pv.Scale.log(args['data'], function(d) d[y]).range("rgba(80,140,80,.2)", "rgba(250,64,64,1)");
      args['color'] = function(d) color_scale(d[y]);
    } else {
      var color_scale = pv.Scale.linear(args['data'], function(d) d[y]).range("green", "red");
      args['color'] = function(d) color_scale(d[y]);
    }
  }

  if(!args['labelsize']) {
    args['labelsize'] = pv.Scale.linear(args['data'], function(d) d[y]).range(8, 20);
  }

  if(!args['fontcolor']) {
    args['fontcolor'] = "rgb(60,60,120)";
  }

  // Y-axis and ticks.
  args['panel'].add(pv.Rule)
    .data(function() args['yscale'].ticks())
    .bottom(function(d) Math.round(args['yscale'](d)) - .5)
    .strokeStyle("#ccc")
    .visible(function() !(this.index % 2))
  .anchor("left").add(pv.Label)
    .text(function(d) d.toPrecision(2))
    .font("12px Calibri")
    .visible(function() {
       if(args['ylog']) {return !(this.index % 4)}
       else return 1});

  // Y-axis label
  if(args['yaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['yaxislabel']])
      .left(-45)
      .bottom(args['height']/2)
      .font("bold 20px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center")
      .textAngle(-Math.PI/2);
  }

  // X-axis and ticks.
  x_axis = args['panel'].add(pv.Rule)
    .data(function() args['xscale'].ticks())
    .left(function(d) Math.round(args['xscale'](d)) - .5)
    .strokeStyle("#ccc")
    .textAlign("center")
  label = x_axis.anchor("bottom").add(pv.Label)
    .textAlign("center")
    .font("12px Calibri")
    .visible(function() {
       if(args['xlog']) {return !(this.index % 2)}
       else return 1});

  if (args['date_format']) {
    label.text(pv.Format.date(args['date_format']));
  } else {
    label.text(function(d) d.toPrecision(2));
  }



  // X-axis label
  if(args['xaxislabel']) {
    args['panel'].add(pv.Label)
      .data([args['xaxislabel']])
      .bottom(-45)
      .left(args['width']/2)
      .font("bold 20px Calibri")
      .textStyle(args['fontcolor'])
      .textAlign("center");
  }

  function labelSize(d) {
    var size = Math.sqrt(d[y])*.5;
    if (size<8) return 0;
    else return size;
  }


  // Add the dots
  args['panel'].add(pv.Panel)
    .overflow('hidden')
    .data(args['data'])
  .add(pv.Dot)
    .size(radius)
    .left(function(d) args['xscale'](d[x]))
    .bottom(function(d) args['yscale'](d[y]))
    .title(function(d) d.hostname)
    .fillStyle(args['color'])
    .strokeStyle(function()this.fillStyle().darker().darker())
    .lineWidth(1)
    .event('mouseover', function()
           {
            args['panel'].notifyObservers('mouseover', this);
            return this.fillStyle('yellow');
           })
    .event('mouseout', function(d)
           {
            args['panel'].notifyObservers('mouseout', this);
            return this.fillStyle(args['color']);
           })
    .title(function(d) d[args['datalabel']])
  .anchor("right").add(pv.Label)
    .text(function(d) d.hostname)
    .font(function(d) args['labelsize'](d[y]) + "px Calibri")
    //.font(function(d) labelSize(d) + "px Calibri")
    .textStyle(args['fontcolor']);

  var w = args['width'];
  var h = args['height'];
  var xmin = args['xscale'].domain()[0];
  var xmax = args['xscale'].domain()[1];
  var xsize = xmax-xmin;
  if (args['xlog']) {
    xmin = log10(xmin);
    xmax = log10(xmax);
    xsize = log10(xsize);
  }
  var ymin = args['yscale'].domain()[0];
  var ymax = args['yscale'].domain()[1];
  var ysize = ymax-ymin;
  if (args['ylog']) {
    ymin = log10(ymin);
    ymax = log10(ymax);
    ysize = log10(ysize);
  }

  if (args['panzoom'])
    {
    /* Use an invisible panel to capture pan & zoom events. */
    args['panel'].add(pv.Panel)
      .events("all")
      .event("mousedown", pv.Behavior.pan())
      .event("mousewheel", pv.Behavior.zoom())
      .event("pan", transform)
      .event("zoom", transform);
    }

  function exp10(x) {
    return Math.pow(10, x);
  }

  function log10(x) {
    return Math.log(x) / Math.LN10;
  }

  /** Update the x- and y-scale domains per the new transform. */
  function transform() {
    var t = this.transform().invert();
    var xviewmin = t.x/w * xsize + xmin;
    var xviewmax = t.x/w * xsize + xmax + (t.k - 1)*xsize;
    if (args['xlog']) {
      xviewmin = exp10(xviewmin);
      xviewmax = exp10(xviewmax);
    }
    args['xscale'].domain(xviewmin, xviewmax);
    var yviewmin = -t.y/h * ysize + ymin;
    var yviewmax = -t.y/h * ysize + ymax + (t.k - 1)*ysize;
    if (args['ylog']) {
      yviewmin = exp10(yviewmin);
      yviewmax = exp10(yviewmax);
    }
    args['yscale'].domain(yviewmin, yviewmax);
    args['panel'].render();
  }

  // Register panel as observable subject.  Can be observed by other Protovis panels.
  if(args['panelObservableSubjectName']) {
    args['panel'].registerSelfAsObservableSubject(args['panelObservableSubjectName']);
  }

  // Sign up to observe other Protovis panels.  Notify() will be called on this panel
  // for any events recieved on these panels.
  if(args['panelSubjectsToObserve']) {
    for(k in args['panelSubjectsToObserve']) {
      s = args['panel'].getPanelObservableSubject(args['panelSubjectsToObserve'][k]);
      s.registerObserver(args['panel']);
    }
  }

  // Notify method implementation that will be called when any observed panels
  // recieve events on their contained Protovis marks.
  if(args['notifyMethodImplementation']) {
    args['panel'].notify = args['notifyMethodImplementation'];
  }

  return args['panel'];

  }



charts.AddColumnChart = function(args) {

  args = args || {};

  var default_args = {
    'width':250,
    'height':400,
    'bottom':20,
    'left':20,
    'right':5,
    'top':5,
    'panel':null,
    'data':null,
    'xscale':null,
    'yscale':null,
    'color':"rgba(255,255,255,.3)",
    'canvas':null
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  if(!args['data']) {
    args['data'] = pv.range(10).map(Math.random);
  }

  if(!args['xscale']) {
    args['xscale'] = pv.Scale.ordinal(args['data']).splitBanded(0, args['width'], 4/5);
  }

  if(!args['yscale']) {
    args['yscale'] = pv.Scale.linear(args['data'], function(d) d).range(0, args['height']);
  }

  // Y-axis and ticks.
  args['panel'].add(pv.Rule)
    .data(args['yscale'].ticks())
    .visible(function() !(this.index % 2))
    .bottom(function(d) Math.round(args['yscale'](d)) - .5)
    .strokeStyle("#ccc")
  .anchor("left").add(pv.Label)
    .text(function(d) d.toFixed());

  var bar = args['panel'].add(pv.Bar)
    .data(args['data'])
    .left(function(d) args['xscale'](d))
    .width(args['xscale'].range().band)
    .bottom(0)
    .height(function(d) args['yscale'](d));

  return args['panel'];

  }

charts.AddLineChart = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':200,
    'bottom':20,
    'left':20,
    'right':10,
    'top':5,
    'panel':null,
    'data':null,
    'xscale':null,
    'yscale':null,
    'color':"rgba(80,120,120,.5)",
    'canvas':null
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  if(!args['data']) {
    args['data'] = pv.range(0, 10, .1).map(function(x) {
      return {x: x, y: Math.cos(x) + Math.random() * .5 + 2}
  });
  }

  if(!args['xscale']) {
    args['xscale'] = pv.Scale.linear(args['data'], function(d) d.x).range(0,args['width']);
    args['xscale'].nice();
  }

  if(!args['yscale']) {
    args['yscale'] = pv.Scale.linear(args['data'], function(d) d.y).range(0, args['height']);
    args['yscale'].nice();
  }

  // Y-axis and ticks.
  args['panel'].add(pv.Rule)
    .data(args['yscale'].ticks())
    .visible(function() !(this.index % 2))
    .bottom(function(d) Math.round(args['yscale'](d)) - .5)
    .strokeStyle("#ccc")
  .anchor("left").add(pv.Label)
    .text(function(d) d.toFixed(1));

  // X-axis and ticks.
  args['panel'].add(pv.Rule)
    .data(args['xscale'].ticks())
    .left(function(d) Math.round(args['xscale'](d)) - .5)
    .visible(function(d) d > 0)
    .strokeStyle("#ccc")
  .anchor("bottom").add(pv.Label)
    .text(function(d) d.toFixed());

  args['panel'].add(pv.Line)
    .data(args['data'])
    .left(function(d) args['xscale'](d.x))
    .bottom(function(d) args['yscale'](d.y))
    .strokeStyle(args['color'])
    .lineWidth(3);

  return args['panel'];

  }

charts.AddBulletChart = function(args) {

  args = args || {};

  var default_args = {
    'width':400,
    'height':200,
    'bottom':20,
    'left':20,
    'right':10,
    'top':5,
    'panel':null,
    'data':null,
    'canvas':null
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top'])
      .margin(20);
  }

  var format = pv.Format.number();

  var bullet = args['panel'].add(pv.Layout.Bullet)
      .data(args['data'])
      .orient("left")
      .ranges(function(d) d.ranges)
      .measures(function(d) d.measures)
      .markers(function(d) d.markers);

  bullet.range.add(pv.Bar);
  bullet.measure.add(pv.Bar);

  bullet.marker.add(pv.Dot)
      .shape("triangle")
      .fillStyle("white");

  bullet.tick.add(pv.Rule)
    .anchor("bottom").add(pv.Label)
      .text(bullet.x.tickFormat);

  bullet.anchor("left").add(pv.Label)
      .font("bold 12px sans-serif")
      .textAlign("right")
      .textBaseline("center")
      .text(function(d) d.title);

  return args['panel'];
}


charts.AddLegend = function(args) {

  args = args || {};

  var default_args = {
    'width':200,
    'height':100,
    'bottom':20,
    'left':20,
    'right':10,
    'top':5,
    'size':14,
    'panel':null,
    'data':null,
    'canvas':null
  }

  for(var index in default_args) {
    if(typeof args[index] == "undefined") args[index] = default_args[index];
  }

  if(!args['panel']) {
    args['panel'] = new pv.Panel()
      .canvas(args['canvas'])
      .width(args['width'])
      .height(args['height'])
      .bottom(args['bottom'])
      .left(args['left'])
      .right(args['right'])
      .top(args['top']);
  }

  var c = pv.Colors.category19();

  args['panel'].add(pv.Bar)
      .data(args['data'])
      .bottom(function(d) this.index * (args['size']+3))
      .left(5)
      .height(args['size'])
      .width(args['size'])
      .lineWidth(null)
      .fillStyle(function(d) c(d))
    .anchor("right").add(pv.Label)
      .textAlign("left")
      .text(function(d) d)
      .font("12px Calibri");

  return args['panel'];
}
