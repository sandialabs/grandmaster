#
# Titan Example for the Perceptron filter
#

from vtk import *
from titan.DataAnalysis import *
import sys
import random

# Extra cheese with side of cheese
subsetRowsFilter = vtkProgrammableFilter()

def subsetRows():
    input = subsetRowsFilter.GetInput()
    output = subsetRowsFilter.GetOutput()

    # Copy just the columns names/types
    output.GetRowData().CopyStructure(input.GetRowData())

    # Loop through all the input data and grab some random rows
    for i in range(0, input.GetNumberOfRows()):
        if (random.random() > .5):
            output.InsertNextRow(input.GetRow(i))

subsetRowsFilter.SetExecuteMethod(subsetRows)


if __name__ == "__main__":
    """ Main entry point of this python script """

    #
    # Load our training from a CSV files
    #
    reader1 = vtkDelimitedTextReader()
    reader1.SetHaveHeaders(True)
    reader1.SetDetectNumericColumns(True)
    reader1.SetFileName("iris.csv")

    # Convert the 'Class' string to a category array
    category = vtkStringToCategory()
    category.SetInputConnection(0, reader1.GetOutputPort())
    category.SetInputArrayToProcess(0,0,0,vtkDataObject.FIELD_ASSOCIATION_ROWS, "Class")
    category.SetCategoryArrayName("Ground_Truth")

    subsetRowsFilter.SetInputConnection(0, category.GetOutputPort())


    # Put processed data into the perceptron
    tron = vtkPerceptron()
    tron.SetInputConnection(subsetRowsFilter.GetOutputPort())
    tron.SetGroundTruthArrayName("Ground_Truth")
    tron.AddFeatureColumn("Sepal_Length")
    tron.AddFeatureColumn("Sepal_Width")
    tron.AddFeatureColumn("Petal_Length")
    tron.AddFeatureColumn("Petal_Width")
    tron.SetMode(vtkPerceptron.TRAIN)
    tron.SetMaxTrainingPasses(1000)
    tron.SetDebugPrintLevel(0)
    tron.Update()


    #
    # Now load our test data from a CSV files
    #
    reader2 = vtkDelimitedTextReader()
    reader2.SetFieldDelimiterCharacters(",")
    reader2.SetHaveHeaders(True)
    reader2.SetDetectNumericColumns(True)
    reader2.SetFileName("iris.csv")
    category.SetInputConnection(0, reader2.GetOutputPort())

    # Rerun the perceptron on the test data
    tron.SetMode(vtkPerceptron.CLASSIFY)
    tron.SetDebugPrintLevel(0)
    tron.Update()


    # All done
    sys.exit(0)
