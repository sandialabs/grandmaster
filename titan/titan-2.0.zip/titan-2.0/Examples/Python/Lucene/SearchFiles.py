"""
This script is loosely based on the Lucene (java implementation) demo class
org.apache.lucene.demo.SearchFiles.  I made some mods to support the
desplay of the document score and also the snippet of text in which the
search term matched.
"""

import re
from lucene import *


def find_indexes(pattern,string):
    for m in re.finditer(pattern, string,re.IGNORECASE):
        yield m.start(0)


def run(searcher, analyzer):
    while True:
        print
        print "Hit enter with no input to quit."
        command = raw_input("Query:")
        if command == '':
            return

        print
        print "Searching for:", command
        query = QueryParser(Version.LUCENE_CURRENT, "contents", analyzer).parse(command)
        scoreDocs = searcher.search(query, 50).scoreDocs
        print "%s total matching documents." % len(scoreDocs)

        # Create a highlighter so you can get the text fragment later
        highlighter = Highlighter(QueryScorer(query))
        highlighter.setTextFragmenter(SimpleFragmenter(50))


        for scoreDoc in scoreDocs:
            doc = searcher.doc(scoreDoc.doc)
            print "------------------------------------------------------"
            print 'path:', doc.get("path"), 'score:', scoreDoc.score
            contents = doc.get("contents")
            tokenStream = analyzer.tokenStream("content",StringReader(contents))
            snippets = highlighter.getBestFragments(tokenStream, contents,5)
            output = ""
            for frag in snippets:
                output += "\n..." + frag + "...\n"
            print output

if __name__ == '__main__':
    STORE_DIR = "index"
    initVM()
    print 'lucene', VERSION
    directory = SimpleFSDirectory(File(STORE_DIR))
    searcher = IndexSearcher(directory, True)
    analyzer = StandardAnalyzer(Version.LUCENE_CURRENT)
    run(searcher, analyzer)
    searcher.close()


    '''
    Storage code for processing snippets in other ways

    # This code is old school array slices to get precisely around your search term
    for index in find_indexes(command, contents):
         snippet = contents[index-50:index+50]
         print snippet
    print
    '''
