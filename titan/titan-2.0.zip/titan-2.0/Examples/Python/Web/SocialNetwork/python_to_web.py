#
# Titan Pipeline to Web Page
#

import os, sys, datetime, webbrowser, re
from vtk import *
import titan
from titan.HDF5 import *
from titan.Common import *
from titan.Web import *

def go():

    # Open the base html page
    html_file = open("index.html")
    html_string = html_file.read()

    htmlFilename = "SuperKewl.html"

    now = datetime.datetime.now()
    datestring = now.strftime("%Y-%m-%d %H:%M")
    header_text = "<b>Topic:</b> Email network analysis<br>"
    header_text += "<b>Date:</b> " + datestring

    # Open database
    data_dir = titan.TITAN_SOURCE_DIR + "/Data/SQLite/"
    sqlite_file = data_dir + "SmallEmailTest.db"

    # Construct a graph from database tables (yes very tricky)
    databaseToGraph = vtkSQLDatabaseGraphSource()
    databaseToGraph.SetURL("sqlite://" + sqlite_file)
    databaseToGraph.SetEdgeQuery("select * from emails")
    databaseToGraph.SetVertexQuery("select * from employee")
    databaseToGraph.AddLinkVertex("from", "Name", False)
    databaseToGraph.AddLinkVertex("to", "Name", False)
    databaseToGraph.AddLinkEdge("from", "to")


    # Compute vertex degree and centrality
    degree = vtkVertexDegree()
    degree.SetInputConnection(databaseToGraph.GetOutputPort())
    centrality = vtkBoostBrandesCentrality ()
    centrality.SetInputConnection(degree.GetOutputPort())


    # Take the graph and convert to JSON
    graphWriter = vtkJSONGraphWriter()
    graphWriter.SetInput(centrality.GetOutput())
    graphWriter.Update()
    graph_data = graphWriter.GetJSONString()


    # Pull off the vertex table
    toTable = vtkDataObjectToTable()
    toTable.SetInputConnection(centrality.GetOutputPort())
    toTable.SetFieldType(vtkDataObjectToTable.VERTEX_DATA)

    # Calculate 5-point statistics
    stats = vtkDescriptiveStatistics()
    stats.AddInputConnection(toTable.GetOutputPort())
    stats.AddColumn("VertexDegree")
    stats.AddColumn("centrality")
    stats.AddColumn("Age")
    stats.Update()

    # Take the table and convert to JSON
    tableWriter = vtkJSONTableWriter()
    tableWriter.SetInput(stats.GetOutputDataObject(1).GetBlock(0)) # yeah, don't get me started
    tableWriter.WriteToOutputStringOn()
    tableWriter.Update()
    table_data = tableWriter.GetOutputString()

    # Construct the Javascript dir in Titan
    javascript_dir = os.path.join(titan.TITAN_SOURCE_DIR, "TPL/JavaScript")

    # Now replace {{ }} strings in the html with 'dynamic' values
    mustaches = re.compile(r'\{\{([^\t\n\r\f]*?)\}\}')
    fields = mustaches.findall( html_string )
    for field in fields:
        html_string = html_string.replace("{{%s}}"%(field), eval(field))


    # Write html file and open it
    f = open(htmlFilename,'w')
    f.write(html_string)
    f.close()
    url = os.path.join(os.path.abspath('.'), htmlFilename)
    webbrowser.open_new(url)


if __name__ == "__main__":
    import sys, os

    # Call the main processing you can use things like sys.argv[1] for args
    go()
