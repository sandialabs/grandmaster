#
# Titan Pipeline to Web Page
#

import os, sys, datetime, webbrowser, re, random
from vtk import *
from titan import *
from titan.HDF5 import *
from titan.Common import *
from titan.Web import *
from titan.DataAnalysis import *

# Extra cheese with side of cheese


def _subsetRows(_filter):
    """
    """
    _input  = _filter.GetInput()
    _output = _filter.GetOutput()

    # Copy just the columns names/types
    _output.GetRowData().CopyStructure(_input.GetRowData())

    # Loop through all the input data and grab some random rows
    labelArray = _input.GetRowData().GetAbstractArray("label")
    outLabelArray = _output.GetRowData().GetAbstractArray("label")
    for i in range(0, _input.GetNumberOfRows()):
        label = labelArray.GetValue(i)
        if (label == "smurf."):
            if (random.random() < .000180):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "neptune."):
            if (random.random() < .000466):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "back."):
            if (random.random() < .0226):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "teardrop."):
            if (random.random() < .0512):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "pod."):
            if (random.random() < .2):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "normal."):
            if (random.random() < .0005):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "satan."):
            if (random.random() < .03):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "ipsweep."):
            if (random.random() < .04):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "portsweep."):
            if (random.random() < .048):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "nmap."):
            if (random.random() < .216):
                _output.InsertNextRow(_input.GetRow(i))
        elif (label == "warezclient."):
            if (random.random() < .05):
                _output.InsertNextRow(_input.GetRow(i))
        else:
            outindex = _output.InsertNextRow(_input.GetRow(i))
            #outLabelArray.SetValue(outindex,"bad")

subsetRowsFilter  = vtkProgrammableFilter()
subsetRowsFilter2 = vtkProgrammableFilter()
subsetRowsFilter3 = vtkProgrammableFilter()

def subsetRows():
    print "Subsetting training set..."
    _subsetRows(subsetRowsFilter)

def subsetRows2():
    print "Subsetting validation set..."
    _subsetRows(subsetRowsFilter2)

def subsetRows3():
    print "Subsetting testing set..."
    _subsetRows(subsetRowsFilter3)

subsetRowsFilter.SetExecuteMethod(subsetRows)
subsetRowsFilter2.SetExecuteMethod(subsetRows2)
subsetRowsFilter3.SetExecuteMethod(subsetRows3)


def go():

    print "Reading training set."
    training_set_reader = vtkDelimitedTextReader()
    training_set_reader.SetHaveHeaders(True)
    training_set_reader.SetDetectNumericColumns(True)
    training_set_reader.SetFileName("kdd_reduced.csv")
    training_set_reader.Update()

    print "Reading full observations (validation/testing)."
    observations_reader = vtkDelimitedTextReader()
    observations_reader.SetHaveHeaders(True)
    observations_reader.SetDetectNumericColumns(True)
    observations_reader.SetFileName("kdd_preprocessed.csv")
    observations_reader.Update()


    # Open the base html page
    html_file = open("index.html")
    html_string = html_file.read()

    htmlFilename = "SuperKewl.html"

    now = datetime.datetime.now()
    datestring = now.strftime("%Y-%m-%d %H:%M")
    header_text = "<b>Topic:</b> KDD 99 Cyber Intrusion Data<br>"
    header_text += "<b>Date:</b> " + datestring

    # Construct the data dir in Titan
    data_dir = os.path.join(TITAN_SOURCE_DIR, "Data")

    sqlite_file = data_dir + "/SQLite/kdd99.sqlite"

    database = vtkSQLDatabase.CreateFromURL("sqlite://" + sqlite_file)
    database.Open("")

    print "Querying the database."
    # Pull the data fields from the database
    vertex_query = database.GetQueryInstance()
#    vertex_query.SetQuery("select * from kddcup where dst_bytes != 0 and src_bytes != 0")
    vertex_query.SetQuery("select * from kddcup")

    print "Converting query results to table format.."
    vertex_table = vtkRowQueryToTable()
    vertex_table.SetQuery(vertex_query)
    vertex_table.Update()
    vertex_query.FastDelete()

    print "Creating validation and testing sets"
    # Create validation set and truth table
    subsetRowsFilter2.SetInputConnection(observations_reader.GetOutputPort())
    subsetRowsFilter2.Update()

    val_truth = vtkCategoryToBitVector()
    val_truth.SetInputConnection(0,subsetRowsFilter2.GetOutputPort())
    val_truth.SetCategoryColumn("label")
    val_truth.Update()

    subsetRowsFilter3.SetInputConnection(observations_reader.GetOutputPort())
    subsetRowsFilter3.Update()

    # Create testing set and truth table
    test_truth = vtkCategoryToBitVector()
    test_truth.SetInputConnection(0,subsetRowsFilter3.GetOutputPort())
    test_truth.SetCategoryColumn("label")
    test_truth.Update()

    # Run some stats on the network data
    # Calculate 5-point statistics (grouped on label)
    print "Calculating 5-point statistics.."
    stats = vtkOrderStatisticsByGroup()
    stats.SetInputConnection(subsetRowsFilter2.GetOutputPort())
    stats.SetArrayName("dst_bytes_normF")
    stats.SetGroupArrayName("label")

    # Don't get me started
    to_num = vtkStringToNumeric()
    to_num.SetInputConnection(stats.GetOutputPort())

    # Take the table and convert to JSON
    tableWriter = vtkJSONTableWriter()
    tableWriter.SetInputConnection(to_num.GetOutputPort())
    tableWriter.WriteToOutputStringOn()
    tableWriter.Update()
    table_data = tableWriter.GetOutputString()

    stats2 = vtkOrderStatisticsByGroup()
    stats2.SetInputConnection(subsetRowsFilter2.GetOutputPort())
    stats2.SetArrayName("src_bytes_normF")
    stats2.SetGroupArrayName("label")

    # Don't get me started
    to_num = vtkStringToNumeric()
    to_num.SetInputConnection(stats2.GetOutputPort())

    # Take the table and convert to JSON
    tableWriter.SetInputConnection(to_num.GetOutputPort())
    tableWriter.WriteToOutputStringOn()
    tableWriter.Update()
    table_data2 = tableWriter.GetOutputString()

    # Train the Multi-Layer Perceptron
    tron = vtkMultiLayerPerceptron()
    tron.SetVerbose(True)
    tron.SetMode(vtkMultiLayerPerceptron.TRAIN)
    tron.SetMaxTrainingPasses(2000)
    tron.SetValidationStepSize(100) # The number of iterations between validation
    tron.SetNumberOfHiddenNodesPerLayer(23)

    tron.SetErrorThreshold(.1)
    tron.SetLearningRate(.2)
    tron.SetMomentumValue(.9)
    tron.SetBatchSize(1)

#    tron.SetWeightAssignment(vtkMultiLayerPerceptron.NGUYEN_WIDROW)
#    tron.SetBiasWeightAssignment(vtkMultiLayerPerceptron.NGUYEN_WIDROW)

    tron.SetInputConnection(0, training_set_reader.GetOutputPort())
    tron.SetInputConnection(1, training_set_reader.GetOutputPort())
    tron.SetInputConnection(2, subsetRowsFilter2.GetOutputPort())
    tron.SetInputConnection(3, val_truth.GetOutputPort())


    tron.AddFeatureColumn("duration_normF")
    tron.AddFeatureColumn("src_bytes_normF")
    tron.AddFeatureColumn("dst_bytes_normF")
    tron.AddFeatureColumn("land_normF")
    tron.AddFeatureColumn("wrong_fragment_normF")
    tron.AddFeatureColumn("urgent_normF")
    tron.AddFeatureColumn("hot_normF")
    tron.AddFeatureColumn("num_failed_logins_normF")
    tron.AddFeatureColumn("logged_in_normF")
    tron.AddFeatureColumn("num_compromised_normF")
    tron.AddFeatureColumn("root_shell_normF")
    tron.AddFeatureColumn("su_attempted_normF")
    tron.AddFeatureColumn("num_root_normF")
    tron.AddFeatureColumn("num_file_creations_normF")
    tron.AddFeatureColumn("num_shells_normF")
    tron.AddFeatureColumn("num_access_files_normF")
    tron.AddFeatureColumn("num_outbound_cmds_normF")
    tron.AddFeatureColumn("is_guest_login_normF")
    tron.AddFeatureColumn("count_normF")
    tron.AddFeatureColumn("srv_count_normF")
    tron.AddFeatureColumn("serror_rate_normF")
    tron.AddFeatureColumn("srv_serror_rate_normF")
    tron.AddFeatureColumn("rerror_rate_normF")
    tron.AddFeatureColumn("srv_rerror_rate_normF")
    tron.AddFeatureColumn("same_srv_rate_normF")
    tron.AddFeatureColumn("diff_srv_rate_normF")
    tron.AddFeatureColumn("srv_diff_host_rate_normF")
    tron.AddFeatureColumn("dst_host_count_normF")
    tron.AddFeatureColumn("dst_host_srv_count_normF")
    tron.AddFeatureColumn("dst_host_same_srv_rate_normF")
    tron.AddFeatureColumn("dst_host_diff_srv_rate_normF")
    tron.AddFeatureColumn("dst_host_same_src_port_rate_normF")
    tron.AddFeatureColumn("dst_host_srv_diff_host_rate_normF")
    tron.AddFeatureColumn("dst_host_serror_rate_normF")
    tron.AddFeatureColumn("dst_host_srv_serror_rate_normF")
    tron.AddFeatureColumn("dst_host_rerror_rate_normF")
    tron.AddFeatureColumn("dst_host_srv_rerror_rate_normF")
    tron.AddFeatureColumn("protocol_type_numeric_normF")
    tron.AddFeatureColumn("service_numeric_normF")
    tron.AddFeatureColumn("flag_numeric_normF")

    tron.AddTruthColumn("back.")
    tron.AddTruthColumn("buffer_overflow.")
    tron.AddTruthColumn("ftp_write.")
    tron.AddTruthColumn("guess_passwd.")
    tron.AddTruthColumn("imap.")
    tron.AddTruthColumn("ipsweep.")
    tron.AddTruthColumn("land.")
    tron.AddTruthColumn("loadmodule.")
    tron.AddTruthColumn("multihop.")
    tron.AddTruthColumn("neptune.")
    tron.AddTruthColumn("nmap.")
    tron.AddTruthColumn("normal.")
    tron.AddTruthColumn("perl.")
    tron.AddTruthColumn("phf.")
    tron.AddTruthColumn("pod.")
    tron.AddTruthColumn("portsweep.")
    tron.AddTruthColumn("rootkit.")
    tron.AddTruthColumn("satan.")
    tron.AddTruthColumn("smurf.")
    tron.AddTruthColumn("spy.")
    tron.AddTruthColumn("teardrop.")
    tron.AddTruthColumn("warezclient.")
    tron.AddTruthColumn("warezmaster.")

    tron.SetErrorCalculationMethod(vtkMultiLayerPerceptron.ERROR_CALC_AVG_MAX)

    tron.Update()



    # Transform the output values to a discrete class
    bit2cat = vtkBitVectorToCategory()
    bit2cat.SetInputConnection(0,tron.GetOutputPort(1))
    bit2cat.Update()

    # Append the classifications to the output vector
    bit2cat.GetOutput().GetColumn(0).SetName("mlp")
    tron.GetOutput().AddColumn(bit2cat.GetOutput().GetColumn(0))

    val_truth_writer = vtkDelimitedTextWriter()
    val_truth_writer.SetFileName("kdd_val_truth.csv")
    val_truth_writer.SetInput(val_truth.GetOutput())
    val_truth_writer.Update()

    prediction_writer = vtkDelimitedTextWriter()
    prediction_writer.SetFileName("kdd_val_prediction.csv")
    prediction_writer.SetInput(tron.GetOutput(1))
    prediction_writer.Update()

    error_writer = vtkDelimitedTextWriter()
    error_writer.SetFileName("kdd_val_error.csv")
    error_writer.SetInput(tron.GetOutput(5))
    error_writer.Update()

    bit2cat = vtkBitVectorToCategory()
    bit2cat.SetInputConnection(0,tron.GetOutputPort(1))
    bit2cat.Update()

    prediction_bit_writer = vtkDelimitedTextWriter()
    prediction_bit_writer.SetFileName("kdd_val_prediction_bit.csv")
    prediction_bit_writer.SetInput(bit2cat.GetOutput())
    prediction_bit_writer.Update()

    # Take the perceptron output and convert to JSON
    tableWriter.SetInputConnection(tron.GetOutputPort())
    tableWriter.WriteToOutputStringOn()
    tableWriter.Update()
    tron_data = tableWriter.GetOutputString()

    # Okay now evaluate some percentage of the data
    tron.SetInputConnection(0,subsetRowsFilter3.GetOutputPort())
    tron.SetInputConnection(1,test_truth.GetOutputPort())

    tron.SetMode(vtkMultiLayerPerceptron.TEST)


    # Transform the output values to a discrete class
    bit2cat = vtkBitVectorToCategory()
    bit2cat.SetInputConnection(0,tron.GetOutputPort(1))
    bit2cat.Update()




    # Append the classifications to the output vector
    bit2cat.GetOutput().GetColumn(0).SetName("mlp")
    tron.GetOutput().AddColumn(bit2cat.GetOutput().GetColumn(0))


    # Take the perceptron output and convert to JSON
    tableWriter.SetInputConnection(tron.GetOutputPort())
    tableWriter.WriteToOutputStringOn()
    tableWriter.Update()
    tron_data2 = tableWriter.GetOutputString()


    # Construct the Javascript dir in Titan
    javascript_dir = os.path.join(TITAN_SOURCE_DIR, "TPL/JavaScript")

    # Now replace {{ }} strings in the html with 'dynamic' values
    mustaches = re.compile(r'\{\{([^\t\n\r\f]*?)\}\}')
    fields = mustaches.findall( html_string )
    for field in fields:
        html_string = html_string.replace("{{%s}}"%(field), eval(field))


    # Write html file and open it
    f = open(htmlFilename,'w')
    f.write(html_string)
    f.close()
    url = os.path.join(os.path.abspath('.'), htmlFilename)
    webbrowser.open_new(url)

    # Done with the database
    #database.FastDelete()


if __name__ == "__main__":
    import sys, os

    # Call the main processing you can use things like sys.argv[1] for args
    go()
