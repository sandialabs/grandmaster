#
# Titan Pipeline to Web Page
#

import os, sys, datetime, webbrowser, re, random
from vtk import *
from titan import *
from titan.HDF5 import *
from titan.Common import *
from titan.ClusteringFilters import *
from titan.Web import *
from titan.DataAnalysis import *
import math

# Extra cheese with side of cheese


def go():
    # Construct the data dir in Titan
    data_dir = os.path.join(TITAN_SOURCE_DIR, "Data")

    sqlite_file = data_dir + "/SQLite/kdd99.sqlite"

    database = vtkSQLDatabase.CreateFromURL("sqlite://" + sqlite_file)
    database.Open("")




    # Pull the data fields from the database
    vertex_query = database.GetQueryInstance()
    vertex_query.SetQuery("select * from kddcup")

    print "Reading data."
    vertex_table_filter = vtkRowQueryToTable()
    vertex_table_filter.SetQuery(vertex_query)
    vertex_query.FastDelete()
    vertex_table_filter.Update()

    kdd_table = vertex_table_filter.GetOutput()

    print "Coverting categories to numeric"
    print "Converting Protocol."
    protocol_type =vtkStringToCategory()
    protocol_type.SetInputConnection(vertex_table_filter.GetOutputPort())
    protocol_type.SetInputArrayToProcess(0,0,0,vtkDataObject.FIELD_ASSOCIATION_ROWS, "protocol_type")
    protocol_type.SetCategoryArrayName("protocol_type_numeric")
    protocol_type.Update()

    print "Converting Service."
    service =vtkStringToCategory()
    service =vtkStringToCategory()
    service.SetInputConnection(protocol_type.GetOutputPort())
    service.SetInputArrayToProcess(0,0,0,vtkDataObject.FIELD_ASSOCIATION_ROWS, "service")
    service.SetCategoryArrayName("service_numeric")
    service.Update()

    print "Converting Flag."
    flag =vtkStringToCategory()
    flag.SetInputConnection(service.GetOutputPort())
    flag.SetInputArrayToProcess(0,0,0,vtkDataObject.FIELD_ASSOCIATION_ROWS, "flag")
    flag.SetCategoryArrayName("flag_numeric")
    flag.Update()

    #flag.GetOutput().Dump(10)

    num_original = flag.GetOutput().GetNumberOfColumns()

    print "Normalizing"
    normF=vtkNormalizeTableFeatures()
    normF.SetInput(flag.GetOutput())
    normF.Update()


    norm_table = normF.GetOutput()

    print "Removing original columns."
    for i in range(num_original-4):
        norm_table.RemoveColumn(0)

    norm_table.RemoveColumnByName("protocol_type_numeric")
    norm_table.RemoveColumnByName("service_numeric")
    norm_table.RemoveColumnByName("flag_numeric")



    norm_writer = vtkDelimitedTextWriter()
    norm_writer.SetFileName("kdd_preprocessed.csv")
    norm_writer.SetInput(norm_table)
    norm_writer.Update()



    observation_table = norm_table

    # Just so we can take advantage of SQL query for now
    print "Querying labels.."
    class_query = database.GetQueryInstance()
    class_query.SetQuery("select distinct label from kddcup")
    class_table_filter = vtkRowQueryToTable()
    class_table_filter.SetQuery(class_query)
    class_table_filter.Update()
    class_query.FastDelete()

    class_table = class_table_filter.GetOutput()

    num = observation_table.GetNumberOfColumns()

#    original_label_array = observation_table.GetColumnByName("label")

    print "Preparing output table.."
    final_output_table = vtkTable()
    final_output_table.DeepCopy(observation_table)
    final_output_table.RemoveColumnByName("label")
    final_output_table.RemoveColumnByName("is_host_login_normF")
    final_output_table.SetNumberOfRows(0)

    final_output_table.Dump(11)

    centroid_label_array= vtkStringArray()
    centroid_label_array.SetName("label")

    for label_index in range(class_table.GetNumberOfRows()):

      # Extract rows from the observation table that contain the label specified by "label_index"
      etr=vtkExtractTableRows()
      etr.SetInput(observation_table)
      etr.AddMatch("label",class_table.GetValue(label_index,0).ToString())
      etr.Update()

      print "Clustering ", etr.GetOutput().GetNumberOfRows(), " observations of class ", class_table.GetValue(label_index,0)

      # Cluster only those observations of the specified class
      cluster = vtkClusteringKMeans()
      cluster.SetInputConnection(etr.GetOutputPort())

      cluster.SetCentroidInitializationMethod(vtkClusteringKMeans.CentroidInitializationKKZ)

      cluster.SetCentroidGenerator(vtkClusteringKMeans.Mean)
      cluster.SetMaxIterations(10000)

      cluster.AddFeatureColumn("duration_normF")
      cluster.AddFeatureColumn("src_bytes_normF")
      cluster.AddFeatureColumn("dst_bytes_normF")
      cluster.AddFeatureColumn("land_normF")
      cluster.AddFeatureColumn("wrong_fragment_normF")
      cluster.AddFeatureColumn("urgent_normF")
      cluster.AddFeatureColumn("hot_normF")
      cluster.AddFeatureColumn("num_failed_logins_normF")
      cluster.AddFeatureColumn("logged_in_normF")
      cluster.AddFeatureColumn("num_compromised_normF")
      cluster.AddFeatureColumn("root_shell_normF")
      cluster.AddFeatureColumn("su_attempted_normF")
      cluster.AddFeatureColumn("num_root_normF")
      cluster.AddFeatureColumn("num_file_creations_normF")
      cluster.AddFeatureColumn("num_shells_normF")
      cluster.AddFeatureColumn("num_access_files_normF")
      cluster.AddFeatureColumn("num_outbound_cmds_normF")
      #host login shows no variation, so it can be omitted
      #cluster.AddFeatureColumn("is_host_login_normF")
      cluster.AddFeatureColumn("is_guest_login_normF")
      cluster.AddFeatureColumn("count_normF")
      cluster.AddFeatureColumn("srv_count_normF")
      cluster.AddFeatureColumn("serror_rate_normF")
      cluster.AddFeatureColumn("srv_serror_rate_normF")
      cluster.AddFeatureColumn("rerror_rate_normF")
      cluster.AddFeatureColumn("srv_rerror_rate_normF")
      cluster.AddFeatureColumn("same_srv_rate_normF")
      cluster.AddFeatureColumn("diff_srv_rate_normF")
      cluster.AddFeatureColumn("srv_diff_host_rate_normF")
      cluster.AddFeatureColumn("dst_host_count_normF")
      cluster.AddFeatureColumn("dst_host_srv_count_normF")
      cluster.AddFeatureColumn("dst_host_same_srv_rate_normF")
      cluster.AddFeatureColumn("dst_host_diff_srv_rate_normF")
      cluster.AddFeatureColumn("dst_host_same_src_port_rate_normF")
      cluster.AddFeatureColumn("dst_host_srv_diff_host_rate_normF")
      cluster.AddFeatureColumn("dst_host_serror_rate_normF")
      cluster.AddFeatureColumn("dst_host_srv_serror_rate_normF")
      cluster.AddFeatureColumn("dst_host_rerror_rate_normF")
      cluster.AddFeatureColumn("dst_host_srv_rerror_rate_normF")
      cluster.AddFeatureColumn("protocol_type_numeric_normF")
      cluster.AddFeatureColumn("service_numeric_normF")
      cluster.AddFeatureColumn("flag_numeric_normF")

      num_rows = etr.GetOutput().GetNumberOfRows();
      K = max(min(int(round(math.log(num_rows)*2,0)),num_rows-1),1)

      cluster.SetK(K) # Number of clusters
      cluster.SetMaxClusterMemberships(1)
      cluster.Update()


      # Convert the centroid array to a table
      att = vtkArrayToTable()
      att.SetInputConnection(0,cluster.GetOutputPort(2))
      att.Update()


      centroid_table = att.GetOutput()
#      centroid_table.Dump(15)
#      print centroid_table.GetNumberOfColumns()
#      print final_output_table.GetNumberOfColumns()

      for column_index in range(final_output_table.GetNumberOfColumns()):
#        print column_index
#        print final_output_table.GetColumnName(column_index)
        centroid_table.GetColumn(column_index).SetName(final_output_table.GetColumnName(column_index))

      centroid_table.Dump(11)

      for centroid_index in range(centroid_table.GetNumberOfRows()):
        centroid_label_array.InsertNextValue(class_table.GetValue(label_index,0).ToString())



      merge=vtkMergeTables()
      merge.SetInput(final_output_table)
      merge.SetInput(1,centroid_table)
      merge.Update()

      final_output_table = merge.GetOutput()

    print "Final table:"
    final_output_table.Dump(11)

    label_table = vtkTable()
    label_table.AddColumn(centroid_label_array)


    print "Converting Label category to BitVector."
    label_vector =vtkCategoryToBitVector()
    label_vector.SetInput(label_table)
    label_vector.SetCategoryColumn("label")
    label_vector.Update()

    for i in range(label_vector.GetOutput().GetNumberOfColumns()):
        final_output_table.AddColumn(label_vector.GetOutput().GetColumn(i))


    centroid_writer = vtkDelimitedTextWriter()
    centroid_writer.SetFileName("kdd_reduced.csv")
    centroid_writer.SetInput(final_output_table)
    centroid_writer.Update()

    # Done with the database
    # database.FastDelete()


if __name__ == "__main__":
    import sys, os

    # Call the main processing you can use things like sys.argv[1] for args
    go()
