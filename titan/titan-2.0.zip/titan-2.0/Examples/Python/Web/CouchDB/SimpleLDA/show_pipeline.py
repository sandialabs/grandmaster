from vtk import *
from titan.DataAnalysis import *
from titan.TextAnalysis import *
from titan.MPITextAnalysis import *

reader = vtkDocumentReader()

mime_types = vtkAssignMimeType()
mime_types.SetInputConnection(0, reader.GetOutputPort(0))

text_extraction = vtkTextExtraction()
text_extraction.SetInputConnection(0, mime_types.GetOutputPort(0))

tokenizer = vtkTokenizer()
tokenizer.SetInputConnection(0, text_extraction.GetOutputPort(0))

fold_case = vtkFoldCase()
fold_case.SetInputConnection(0, tokenizer.GetOutputPort(0))

feature_dictionary = vtkFeatureDictionary()
feature_dictionary.SetInputConnection(0, fold_case.GetOutputPort(0))

frequency_matrix = vtkFrequencyMatrix()
frequency_matrix.SetInputConnection(0, fold_case.GetOutputPort(0))
frequency_matrix.SetInputConnection(1, feature_dictionary.GetOutputPort(0))
frequency_matrix.SetInputConnection(2, text_extraction.GetOutputPort(0))

lda = vtkPLatentDirichletAllocation()
lda.SetController(vtkDummyController())
lda.SetInputConnection(0, frequency_matrix.GetOutputPort(0))

pipeline = vtkPipelineGraphSource()
pipeline.AddSink(lda)

view = vtkGraphLayoutView()
view.AddRepresentationFromInputConnection(pipeline.GetOutputPort(0))
view.SetVertexLabelArrayName("class_name")
view.SetVertexLabelVisibility(True)
view.SetLayoutStrategyToForceDirected()
view.GetRenderWindow().SetSize(600, 600)
view.Render()
view.GetInteractor().Start()
