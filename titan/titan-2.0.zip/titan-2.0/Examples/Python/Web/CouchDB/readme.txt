In order to run these examples you'll need to have either a local or networked CouchDB setup.
You can install CouchDB from http://www.couchbase.com/downloads.

For questions please contact the Titan users email list
http://public.kitware.com/cgi-bin/mailman/listinfo/titan-users
