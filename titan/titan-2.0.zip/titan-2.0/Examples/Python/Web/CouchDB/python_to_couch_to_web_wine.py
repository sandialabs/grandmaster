#
#Titan Pipeline to CouchDB to Web Page
#
import webbrowser
import couchdb
import os, sys, datetime
import json
import mimetypes
from vtk import *
import titan
from titan.HDF5 import *
from titan.Common import *
from titan.ClusteringFilters import *
from titan.Web import *
from titan.DataAnalysis import *
import random

def add_js_attachments(full_path, relative_path, database, document):
    for child in os.listdir(full_path):
        child_path = os.path.join(full_path, child)
        if os.path.isdir(child_path):
            add_attachments(child_path, os.path.join(relative_path, child), database, document)
        else:
            content = open(child_path, "r")
            mime_type = mimetypes.guess_type(child_path)
            database.put_attachment(document, content.read(), filename = os.path.join(relative_path, child).replace("\\", "/"), content_type = mime_type[0])

def printStats(statsFilter):
    sStats = statsFilter.GetOutputDataObject( 1 )
    sPrimary = sStats.GetBlock( 0 )
    sDerived = sStats.GetBlock( 1 )
    sPrimary.Dump( 15 )
    sDerived.Dump( 15 )

# Extra cheese with side of cheese
specificProcessing = vtkProgrammableFilter()

def shuffleRows():

    input = specificProcessing.GetInput()
    output = specificProcessing.GetOutput()

    # Deep Copy the input to the output
    output.DeepCopy(input)

    # Loop through all the rows randomly shuffling
    num_rows = output.GetNumberOfRows();
    i = num_rows-1;
    row = vtkVariantArray()
    while i > 0:
        index = int(random.random() * i)
        row.DeepCopy(output.GetRow(i))
        output.SetRow(i,output.GetRow(index))
        output.SetRow(index,row)
        i=i-1


specificProcessing.SetExecuteMethod(shuffleRows)


def go():
    global subset

    # Construct the Javascript dir in Titan
    javascript_dir = os.path.join(titan.TITAN_SOURCE_DIR, "TPL/JavaScript")

    # Open up wine dataset
    reader = vtkDelimitedTextReader()
    reader.SetHaveHeaders(True)
    reader.SetDetectNumericColumns(True)
    reader.SetFileName("wine.csv")
    reader.Update()

    # Run some stats on the wine data
    # Calculate 5-point cpu statistics (grouped on node_name)
    stats = vtkOrderStatisticsByGroup()
    stats.AddInputConnection(reader.GetOutputPort())
    stats.SetArrayName("Alcohol")
    stats.SetGroupArrayName("Class")

    stats2 = vtkOrderStatisticsByGroup()
    stats2.AddInputConnection(reader.GetOutputPort())
    stats2.SetArrayName("Malic_acid")
    stats2.SetGroupArrayName("Class")

    mergeStats = vtkMergeTables()
    mergeStats.SetInputConnection(0,stats.GetOutputPort())
    mergeStats.SetInputConnection(1,stats2.GetOutputPort())


    # Run K-mean clustering on the wine data
    cluster = vtkClusteringKMeans()
    cluster.SetInputConnection(0,reader.GetOutputPort())
    cluster.AddFeatureColumn("Alcohol")
    cluster.AddFeatureColumn("Malic_acid")
    cluster.AddFeatureColumn("Ash")
    cluster.AddFeatureColumn("Flavanoids")
    cluster.SetK(3); # Number of clusters
    cluster.Update()

    # Doing a hack to shuffle data for training
    specificProcessing.SetInputConnection(cluster.GetOutputPort())

    # Run perceptron on a subset of the data
    tron = vtkPerceptron()
    tron.SetInputConnection(specificProcessing.GetOutputPort())
    tron.SetGroundTruthArrayName("Class")
    tron.AddFeatureColumn("Alcohol")
    tron.AddFeatureColumn("Malic_acid")
    tron.AddFeatureColumn("Ash")
    tron.AddFeatureColumn("Flavanoids")
    tron.SetMode(vtkPerceptron.TRAIN)
    tron.SetDebugPrintLevel(0)
    tron.Update()

    # Now run in 'Classify' mode with all the data
    subset = False;
    specificProcessing.Modified()
    specificProcessing.Update()
    tron.SetMode(vtkPerceptron.CLASSIFY)
    tron.SetDebugPrintLevel(0)


    #
    # Now do all the awesome Web/CouchDB stuff
    #

    # Some web page stuff
    htmlFilename = "SuperKewl.html"
    now = datetime.datetime.now()
    datestring = now.strftime("%Y-%m-%d %H:%M")

    # CouchDB handles  (for remote use couchdb.Server('http://foo.bar:5984/'))
    couch = couchdb.Server('http://localhost:5984')

    # Create the database
    try:
        db = couch["wine"]
    except:
        db = couch.create("wine")
    # Check if the design doc is already there
    if "_design/wine" in db:
        db.delete(db["_design/wine"])

    # Create couch design document
    design_doc = {}
    design_doc["_id"] = "_design/wine"
    design_doc["created"] = datestring
    design_doc["type"] = "Design Document"
    db.save(design_doc)

    # Now pull in the html, css, and javascript files for a kewl web experience
    add_js_attachments(javascript_dir, "", db, design_doc)
    html_content = open("index_wine.html", "r").read()
    css_content = open("view.css", "r").read()
    db.put_attachment(design_doc, html_content, filename="index.html", content_type="text/html")
    db.put_attachment(design_doc, css_content, filename="view.css", content_type="text/css")


    # Now take the wine data and convert to JSON
    tableWriter = vtkJSONTableWriter()
    tableWriter.WriteToOutputStringOn()
    tableWriter.SetInput(tron.GetOutput())
    tableWriter.Update()
    json_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, json_data, filename="wine.json", content_type="application/json")

    # Now take the wine data statistics and onvert to JSON
    tableWriter.SetInput(mergeStats.GetOutput())
    tableWriter.Update()
    stats_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, stats_data, filename="wine_stats.json", content_type="application/json")

    # Open the browser
    webbrowser.open_new("http://localhost:5984/wine/_design/wine/index.html")


if __name__ == "__main__":
    import sys, os

    # Arg processing could go here

    # Call the main processing you can use things like sys.argv[1] for args
    go()
    sys.exit(0)