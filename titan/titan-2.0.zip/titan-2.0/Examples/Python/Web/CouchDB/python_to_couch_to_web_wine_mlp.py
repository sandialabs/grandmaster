#
#Titan Pipeline to CouchDB to Web Page
#
import webbrowser
import couchdb
import os, sys, datetime
import json
import mimetypes
from vtk import *
import titan
from titan.HDF5 import *
from titan.Common import *
from titan.ClusteringFilters import *
from titan.Web import *
from titan.DataAnalysis import *
import random

def add_js_attachments(full_path, relative_path, database, document):
    for child in os.listdir(full_path):
        child_path = os.path.join(full_path, child)
        if os.path.isdir(child_path):
            add_attachments(child_path, os.path.join(relative_path, child), database, document)
        else:
            content = open(child_path, "r")
            mime_type = mimetypes.guess_type(child_path)
            database.put_attachment(document, content.read(), filename = os.path.join(relative_path, child).replace("\\", "/"), content_type = mime_type[0])

def printStats(statsFilter):
    sStats = statsFilter.GetOutputDataObject( 1 )
    sPrimary = sStats.GetBlock( 0 )
    sDerived = sStats.GetBlock( 1 )
    sPrimary.Dump( 15 )
    sDerived.Dump( 15 )

# Extra cheese with side of cheese
specificProcessing = vtkProgrammableFilter()
subset = True;

def subsetRows():
    global subset

    input = specificProcessing.GetInput()
    output = specificProcessing.GetOutput()

    # Copy just the columns names/types
    output.GetRowData().CopyStructure(input.GetRowData())

    # Loop through all the input data and grab some random rows
    for i in range(0, input.GetNumberOfRows()):
        if (not subset or (random.random() > .5)):
            output.InsertNextRow(input.GetRow(i))

specificProcessing.SetExecuteMethod(subsetRows)


def go():
    global subset

    # Construct the Javascript dir in Titan
    javascript_dir = os.path.join(titan.TITAN_SOURCE_DIR, "TPL/JavaScript")

    # Open up wine dataset
    reader = vtkDelimitedTextReader()
    reader.SetHaveHeaders(True)
    reader.SetDetectNumericColumns(True)
    reader.SetFileName("wine.csv")
    reader.Update()

    # Run some stats on the wine data
    # Calculate 5-point cpu statistics (grouped on node_name)
    stats = vtkOrderStatisticsByGroup()
    stats.AddInputConnection(reader.GetOutputPort())
    stats.SetArrayName("Alcohol")
    stats.SetGroupArrayName("Class")

    stats2 = vtkOrderStatisticsByGroup()
    stats2.AddInputConnection(reader.GetOutputPort())
    stats2.SetArrayName("Malic_acid")
    stats2.SetGroupArrayName("Class")

    mergeStats = vtkMergeTables()
    mergeStats.SetInputConnection(0,stats.GetOutputPort())
    mergeStats.SetInputConnection(1,stats2.GetOutputPort())


    # Run K-mean clustering on the wine data
    cluster = vtkClusteringKMeans()
    cluster.SetInputConnection(0,reader.GetOutputPort())
    cluster.AddFeatureColumn("Alcohol")
    cluster.AddFeatureColumn("Malic_acid")
    cluster.AddFeatureColumn("Ash")
    cluster.AddFeatureColumn("Flavanoids")
    cluster.SetK(3); # Number of clusters
    cluster.Update()

    # Doing a hack to shuffle data for training
    specificProcessing.SetInputConnection(cluster.GetOutputPort())

    normF=vtkNormalizeTableFeatures()
    normF.SetInputConnection(0,specificProcessing.GetOutputPort())

    obs_truth = vtkCategoryToBitVector()
    obs_truth.SetInputConnection(0,normF.GetOutputPort())
    obs_truth.SetCategoryColumn("Class")
    obs_truth.Update()

    # Run perceptron on a subset of the data
    tron = vtkMultiLayerPerceptron()
    tron.SetInputConnection(normF.GetOutputPort())
    tron.SetInputConnection(1,obs_truth.GetOutputPort())

    tron.AddFeatureColumn("Alcohol_normF")
    tron.AddFeatureColumn("Malic_acid_normF")
    tron.AddFeatureColumn("Ash_normF")
    tron.AddFeatureColumn("Alcalinity_of_ash_normF")
    tron.AddFeatureColumn("Magnesium_normF")
    tron.AddFeatureColumn("Total_phenols_normF")
    tron.AddFeatureColumn("Flavanoids_normF")
    tron.AddFeatureColumn("Nonflavanoid_phenols_normF")
    tron.AddFeatureColumn("Proanthocyanins_normF")
    tron.AddFeatureColumn("Color_intensity_normF")
    tron.AddFeatureColumn("Hue_normF")
    tron.AddFeatureColumn("OD280_OD315_normF")
    tron.AddFeatureColumn("Proline_normF")

    tron.SetMaxTrainingPasses(1000)
    tron.SetValidationStepSize(10) # The number of iterations between validation
    tron.SetNumberOfHiddenNodesPerLayer(18)
    tron.SetVerbose(True)
    tron.SetMode(vtkMultiLayerPerceptron.TRAIN)

    tron.SetErrorThreshold(.1)
    tron.SetMomentumValue(1)
    tron.SetDebugPrintLevel(0)

    tron.Update()

    # Now run in 'TEST' mode with all the data
    subset = False;
    specificProcessing.Modified()
    specificProcessing.Update()
    tron.SetMode(vtkMultiLayerPerceptron.TEST)
    tron.SetDebugPrintLevel(0)

    # Transform the output values to a discrete class
    bit2cat = vtkBitVectorToCategory()
    bit2cat.SetInputConnection(0,tron.GetOutputPort(1))
    bit2cat.Update()

    # Append the classifications to the output vector
    bit2cat.GetOutput().GetColumn(0).SetName("mlp")
    tron.GetOutput().AddColumn(bit2cat.GetOutput().GetColumn(0))

    tron.GetOutput().Dump()

    #
    # Now do all the awesome Web/CouchDB stuff
    #

    # Some web page stuff
    htmlFilename = "SuperKewl.html"
    now = datetime.datetime.now()
    datestring = now.strftime("%Y-%m-%d %H:%M")

    # CouchDB handles  (for remote use couchdb.Server('http://foo.bar:5984/'))
    couch = couchdb.Server('http://localhost:5984')

    # Create the database
    try:
        db = couch["wine"]
    except:
        db = couch.create("wine")
    # Check if the design doc is already there
    if "_design/wine" in db:
        db.delete(db["_design/wine"])

    # Create couch design document
    design_doc = {}
    design_doc["_id"] = "_design/wine"
    design_doc["created"] = datestring
    design_doc["type"] = "Design Document"
    db.save(design_doc)

    # Now pull in the html, css, and javascript files for a kewl web experience
    add_js_attachments(javascript_dir, "", db, design_doc)
    html_content = open("index_wine.html", "r").read()
    css_content = open("view.css", "r").read()
    db.put_attachment(design_doc, html_content, filename="index.html", content_type="text/html")
    db.put_attachment(design_doc, css_content, filename="view.css", content_type="text/css")


    # Now take the wine data and convert to JSON
    tableWriter = vtkJSONTableWriter()
    tableWriter.WriteToOutputStringOn()
    tableWriter.SetInput(tron.GetOutput())
    tableWriter.Update()
    json_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, json_data, filename="wine.json", content_type="application/json")

    # Now take the wine data statistics and onvert to JSON
    tableWriter.SetInput(mergeStats.GetOutput())
    tableWriter.Update()
    stats_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, stats_data, filename="wine_stats.json", content_type="application/json")

    # Open the browser
    webbrowser.open_new("http://localhost:5984/wine/_design/wine/index.html")


if __name__ == "__main__":
    import sys, os

    # Arg processing could go here

    # Call the main processing you can use things like sys.argv[1] for args
    go()
    sys.exit(0)