#
#Titan Pipeline to CouchDB to Web Page
#
import webbrowser
import couchdb
import os, sys, datetime
import json
import mimetypes
from vtk import *
import titan
from titan.HDF5 import *
from titan.Common import *
from titan.ClusteringFilters import *
from titan.Web import *
from titan.DataAnalysis import *
import random

def add_js_attachments(full_path, relative_path, database, document):
    for child in os.listdir(full_path):
        child_path = os.path.join(full_path, child)
        if os.path.isdir(child_path):
            add_attachments(child_path, os.path.join(relative_path, child), database, document)
        else:
            content = open(child_path, "r")
            mime_type = mimetypes.guess_type(child_path)
            database.put_attachment(document, content.read(), filename = os.path.join(relative_path, child).replace("\\", "/"), content_type = mime_type[0])

def printStats(statsFilter):
    sStats = statsFilter.GetOutputDataObject( 1 )
    sPrimary = sStats.GetBlock( 0 )
    sDerived = sStats.GetBlock( 1 )
    sPrimary.Dump( 15 )
    sDerived.Dump( 15 )

# Extra cheese with side of cheese
# This programmable filter output a random subset of rows
subsetRowsFilter = vtkProgrammableFilter()
subsetRowsFilter2 = vtkProgrammableFilter()
subset = True;

def _subsetRows(_filter):
    global subset

    _input = _filter.GetInput()
    _output = _filter.GetOutput()

    # Copy just the columns names/types
    _output.GetRowData().CopyStructure(_input.GetRowData())

    # Loop through all the input data and grab some random rows
    for i in range(0, _input.GetNumberOfRows()):
        if (not subset or (random.random() > .5)):
            _output.InsertNextRow(_input.GetRow(i))


def subsetRows():
    print "Subsetting rows..."

    _subsetRows(subsetRowsFilter)

def subsetRows2():
    print "Subsetting rows 2..."

    _subsetRows(subsetRowsFilter2)

subsetRowsFilter.SetExecuteMethod(subsetRows)
subsetRowsFilter2.SetExecuteMethod(subsetRows2)

# This programmable filter looks at proximity distance to
# compute a 'confidence' metric (using the term loosely)(
confidenceCalc = vtkProgrammableFilter()
def confidence():
    global subset

    input = confidenceCalc.GetInput()
    output = confidenceCalc.GetOutput()

    # Shallow copy input to output
    output.ShallowCopy(input)

    # Create new output array
    confArray = vtkFloatArray()
    confArray.SetName("confidence")
    confArray.SetNumberOfTuples(output.GetNumberOfRows())

    # Get a handle to the proximity arrays
    prox0 = output.GetColumnByName("prox_0")
    prox1 = output.GetColumnByName("prox_1")
    prox2 = output.GetColumnByName("prox_2")

    # Loop through all the vertices setting the degree for the new attribute array
    numRows = output.GetNumberOfRows()
    for i in range(numRows):
        p0 = prox0.GetValue(i)
        p1 = prox1.GetValue(i)
        p2 = prox2.GetValue(i)
        conf = 1.0 - p0/(p0+p1+p2)
        confArray.SetValue(i, conf)

    output.GetRowData().AddArray(confArray)

confidenceCalc.SetExecuteMethod(confidence)

def go():
    global subset

    # Construct the Javascript dir in Titan
    javascript_dir = os.path.join(titan.TITAN_SOURCE_DIR, "TPL/JavaScript")

    # Open up IRIS dataset
    reader = vtkDelimitedTextReader()
    reader.SetHaveHeaders(True)
    reader.SetDetectNumericColumns(True)
    reader.SetFileName("iris.csv")
    reader.Update()

    # Run some stats on the iris data
    # Calculate 5-point cpu statistics (grouped on node_name)
    stats = vtkOrderStatisticsByGroup()
    stats.AddInputConnection(reader.GetOutputPort())
    stats.SetArrayName("Sepal_Length")
    stats.SetGroupArrayName("Class")

    stats2 = vtkOrderStatisticsByGroup()
    stats2.AddInputConnection(reader.GetOutputPort())
    stats2.SetArrayName("Sepal_Width")
    stats2.SetGroupArrayName("Class")

    mergeStats = vtkMergeTables()
    mergeStats.SetInputConnection(0,stats.GetOutputPort())
    mergeStats.SetInputConnection(1,stats2.GetOutputPort())

    # Convert the 'Class' string to a category array
    category = vtkStringToCategory()
    category.SetInputConnection(0, reader.GetOutputPort())
    category.SetInputArrayToProcess(0,0,0,vtkDataObject.FIELD_ASSOCIATION_ROWS, "Class")
    category.SetCategoryArrayName("Ground_Truth")

    # Run K-mean clustering on the iris data
    cluster = vtkClusteringKMeans()
    cluster.SetInputConnection(reader.GetOutputPort())
    cluster.AddFeatureColumn("Sepal_Length")
    cluster.AddFeatureColumn("Sepal_Width")
    cluster.AddFeatureColumn("Petal_Length")
    cluster.AddFeatureColumn("Petal_Width")
    cluster.SetK(3) # Number of clusters
    cluster.SetMaxClusterMemberships(3)
    #cluster.SetCentroidGenerator(vtkClusteringKMeans.Medoid)
    cluster.Update()
    cluster.GetOutput().Dump()

    confidenceCalc.SetInputConnection(cluster.GetOutputPort())
    confidenceCalc.Update()
    confidenceCalc.GetOutput().Dump()

    # Doing a hack on the ground truth and subsetting for training and testing
    subsetRowsFilter.SetInputConnection(confidenceCalc.GetOutputPort())
    subsetRowsFilter2.SetInputConnection(confidenceCalc.GetOutputPort())

    # Run perceptron on a subset of the data
    normF=vtkNormalizeTableFeatures()
    normF.SetInputConnection(0,subsetRowsFilter.GetOutputPort())
    normF.AddFeatureColumn("Sepal_Length")
    normF.AddFeatureColumn("Sepal_Width")
    normF.AddFeatureColumn("Petal_Length")
    normF.AddFeatureColumn("Petal_Width")
    normF.Update()
    print "Training Set"
    normF.GetOutput().Dump()
    print

    validation_normF=vtkNormalizeTableFeatures()
    validation_normF.SetInputConnection(0,subsetRowsFilter2.GetOutputPort())
    validation_normF.AddFeatureColumn("Sepal_Length")
    validation_normF.AddFeatureColumn("Sepal_Width")
    validation_normF.AddFeatureColumn("Petal_Length")
    validation_normF.AddFeatureColumn("Petal_Width")
    validation_normF.Update()
    print "Validation Set"
    validation_normF.GetOutput().Dump()
    print

    obs_truth = vtkCategoryToBitVector()
    obs_truth.SetInputConnection(0,normF.GetOutputPort())
    obs_truth.SetCategoryColumn("Class")
    obs_truth.Update()

    val_truth = vtkCategoryToBitVector()
    val_truth.SetInputConnection(0,validation_normF.GetOutputPort())
    val_truth.SetCategoryColumn("Class")
    val_truth.Update()

    tron = vtkMultiLayerPerceptron()
    tron.SetInputConnection(normF.GetOutputPort())
    tron.SetInputConnection(1,obs_truth.GetOutputPort())
    tron.SetInputConnection(2,validation_normF.GetOutputPort())
    tron.SetInputConnection(3,val_truth.GetOutputPort())
    tron.SetValidationStepSize(100) # The number of iterations between validation
    tron.AddFeatureColumn("Sepal_Length_normF")
    tron.AddFeatureColumn("Sepal_Width_normF")
    tron.AddFeatureColumn("Petal_Length_normF")
    tron.AddFeatureColumn("Petal_Width_normF")

    unique_table = obs_truth.GetOutput(0)
    for col_index in range(unique_table.GetNumberOfColumns()):
        column = unique_table.GetColumn(col_index)
        tron.AddTruthColumn(column.GetName())

    tron.SetMode(vtkMultiLayerPerceptron.TRAIN)
    tron.SetVerbose(True)
    tron.SetErrorThreshold(.1)
    tron.SetMomentumValue(.8)
    tron.SetDebugPrintLevel(0)

    tron.Update()


    # Now run in 'TEST' mode with all the data
    subset = False;
    subsetRowsFilter.Modified()
    subsetRowsFilter.Update()

    print "Normalizing"
    normF.Update()

    print "Evaluating entire set"
    tron.SetInputConnection(normF.GetOutputPort())
    tron.SetMode(vtkMultiLayerPerceptron.TEST)
    tron.Update()
    tron.SetDebugPrintLevel(0)



    bit2cat = vtkBitVectorToCategory()
    bit2cat.SetInputConnection(0,tron.GetOutputPort(1))
    bit2cat.Update()


    bit2cat.GetOutput().GetColumn(0).SetName("mlp")

    tron.GetOutput().AddColumn(bit2cat.GetOutput().GetColumn(0))
    tron.GetOutput().Dump()

    #
    # Now do all the awesome Web/CouchDB stuff
    #

    # Some web page stuff
    htmlFilename = "SuperKewl.html"
    now = datetime.datetime.now()
    datestring = now.strftime("%Y-%m-%d %H:%M")

    # CouchDB handles  (for remote use couchdb.Server('http://foo.bar:5984/'))
    couch = couchdb.Server('http://localhost:5984')

    # Create the database
    try:
        db = couch["test"]
    except:
        db = couch.create("test")
    # Check if the design doc is already there
    if "_design/test" in db:
        db.delete(db["_design/test"])

    # Create couch design document
    design_doc = {}
    design_doc["_id"] = "_design/test"
    design_doc["created"] = datestring
    design_doc["type"] = "Design Document"
    db.save(design_doc)

    # Now pull in the html, css, and javascript files for a kewl web experience
    add_js_attachments(javascript_dir, "", db, design_doc)
    html_content = open("index.html", "r").read()
    css_content = open("view.css", "r").read()
    db.put_attachment(design_doc, html_content, filename="index.html", content_type="text/html")
    db.put_attachment(design_doc, css_content, filename="view.css", content_type="text/css")


    # Now take the iris data and convert to JSON
    tableWriter = vtkJSONTableWriter()
    tableWriter.WriteToOutputStringOn()
    tableWriter.SetInput(tron.GetOutput())
    tableWriter.Update()
    json_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, json_data, filename="iris.json", content_type="application/json")

    # Now take the iris data statistics and onvert to JSON
    tableWriter.SetInput(mergeStats.GetOutput())
    tableWriter.Update()
    stats_data = tableWriter.GetOutputString()

    # Store JSON as an attachment to my document
    db.put_attachment(design_doc, stats_data, filename="iris_stats.json", content_type="application/json")

    # Open the browser
    webbrowser.open_new("http://localhost:5984/test/_design/test/index.html")


if __name__ == "__main__":
    import sys, os

    # Arg processing could go here

    # Call the main processing you can use things like sys.argv[1] for args
    go()
    sys.exit(0)