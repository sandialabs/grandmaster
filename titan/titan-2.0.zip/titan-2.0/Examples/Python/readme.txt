Hi. Running the Titan Python examples should be straight forward,
but you will need to set up both your PATH and PYTHONPATH environment variables.

Please go to this page for the most recent instructions.

http://public.kitware.com/titan-docs/installation.html
