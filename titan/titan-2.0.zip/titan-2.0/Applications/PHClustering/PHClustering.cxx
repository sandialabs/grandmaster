#include "vtkMPIController.h"

#include "vtkArrayReader.h"
#include "vtkArrayToTable.h"
#include "vtkPPHClustering.h"
#include "vtkTable.h"
#include "vtkTableWriter.h"

#include "vtkDistributedArray.h"

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New ();

int main (int argc, char *argv[])
{
  int proc = 0;
  int nprocs = 1;

  vtkMPIController* ctrl = vtkMPIController::New ();

  if (argc < 2)
    {
    cerr << "Format: " << argv[0] << " theta_file[s]\n";
    ctrl->Delete ();
    return 1;
    }

  ctrl->Initialize (&argc, &argv);
  vtkMultiProcessController::SetGlobalController (ctrl);

  proc = ctrl->GetLocalProcessId ();
  nprocs = ctrl->GetNumberOfProcesses ();

  vtkTable *finalTable;

  int numFiles = argc - 1;
  if (numFiles < nprocs)
    {
    // scatter split regime
    int processPerFile = numFiles / nprocs;
    int index = proc / processPerFile;
    int offset = proc % processPerFile;
    }
  else if (numFiles > nprocs)
    {
    // combine regime
    int filesPerProcess = numFiles / nprocs;
    int fileOffset = proc * filesPerProcess;

    // last process may go over via rounding.
    if ((fileOffset + filesPerProcess) > numFiles)
      {
      filesPerProcess = numFiles - fileOffset;
      }

    /* TODO combine the multiple files into a single output
    for (int i = 0; i < filesPerProcess; i ++)
      {
      VTK_CREATE (vtkArrayReader, reader);
      reader->SetFileName (argv[1 + fileOffset + i]);
      }
    */
    }
  else
    {
    cerr << "reading file " << argv[proc + 1] << endl;
    VTK_CREATE (vtkArrayReader, reader);
    reader->SetFileName (argv[proc + 1]);
    VTK_CREATE (vtkArrayToTable, a2t);
    a2t->SetInputConnection (reader->GetOutputPort ());
    a2t->Update ();
    finalTable = a2t->GetOutput ();
    finalTable->Register (0);
    }

  if (proc == 0)
    {
    cerr << "running the cluster" << endl;
    }
  VTK_CREATE (vtkPPHClustering, cluster);
  cluster->SetInputData (finalTable);
  cluster->Update ();

  if (proc == 0)
    {
    cerr << "writing the results" << endl;
    }
  VTK_CREATE (vtkTableWriter, init_assignments);
  init_assignments->SetInputConnection (cluster->GetOutputPort (0));
  char filename[256];
  sprintf (filename, "initial_assignments_%06d.vtk", proc);
  init_assignments->SetFileName (filename);
  init_assignments->Write ();

  if (proc == 0)
    {
    VTK_CREATE (vtkTableWriter, hier_assignments);
    hier_assignments->SetInputConnection (cluster->GetOutputPort (1));
    hier_assignments->SetFileName ("hierarchical_assignments.vtk");
    hier_assignments->Write ();
    }

  finalTable->UnRegister (0);

  vtkMultiProcessController::SetGlobalController (0);
  ctrl->Finalize ();
  ctrl->Delete ();
  return 0;
}
