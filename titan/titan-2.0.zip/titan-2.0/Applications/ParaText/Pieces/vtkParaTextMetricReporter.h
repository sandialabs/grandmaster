/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkCleanupNonUTF8TextExtractionStrategy.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2012 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
  -------------------------------------------------------------------------*/

// .NAME vtkParaTextMetricReporter - Cleanly report measurements in a multiprocessor setting
//
// .SECTION Description
//
// ParaText can report lots of information about execution time and
// memory requirements.  However, when we're in a multiprocessor
// environment we run into the usual problems with race conditions and
// competition for output streams.
//
// This class handles that gracefully by synchronizing across
// processors.

#ifndef __vtkParaTextMetricReporter_h
#define __vtkParaTextMetricReporter_h

#include <vtkObject.h>
#include <string>

class vtkMultiProcessController;

class vtkParaTextMetricReporter : public vtkObject
{
public:
  vtkTypeMacro(vtkParaTextMetricReporter, vtkObject);
  static vtkParaTextMetricReporter *New();
  void PrintSelf(ostream& os, vtkIndent indent);

  template<typename T>
  void ReportMetric(const std::string& Component,
                    const std::string& Metric,
                    const T& Value,
                    const std::string& Units);

  void SetDestination(std::ostream* dest);

  void SetController(vtkMultiProcessController* c);

  static std::string DefaultMetricFormat();

protected:
  vtkParaTextMetricReporter();
  ~vtkParaTextMetricReporter();

  std::ostream* Destination;
  vtkMultiProcessController* Controller;


private:
  vtkParaTextMetricReporter(const vtkParaTextMetricReporter&);
  void operator=(const vtkParaTextMetricReporter&);

};

#include "vtkParaTextMetricReporter.txx"

#endif
