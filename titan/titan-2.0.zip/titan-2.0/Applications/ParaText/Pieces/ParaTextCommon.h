/*=========================================================================

  Program:   Visualization Toolkit
  Module:    ParaTextCommon.h

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2012 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
  -------------------------------------------------------------------------*/

#ifndef __ParaTextCommon_h
#define __ParaTextCommon_h

#include <iostream>

class vtkAlgorithm;
class vtkObject;
class vtkParaTextMetricReporter;

namespace ParaTextCommon {
  typedef void (vtkEventCallback)(vtkObject*, unsigned long int, void*, void*);

  vtkEventCallback ExportFrequencyMatrixStatistics_Callback;

  std::string FormatFileName(const std::string& filename_pattern);
  std::ostream* OpenMetricDestination(const std::string& filename_pattern);
  void PrintFormattingOptions(std::ostream* destination);
  void AddCallback(vtkObject* source, unsigned long int event, vtkEventCallback callback);
  void AttachTimer(vtkAlgorithm* filter, vtkParaTextMetricReporter* reporter);

  /// Helper classes for managing timing.
  class CPUTimer
  {
  public:
    CPUTimer();
    const double elapsed() const;
    void reset();
  private:
    double start_time;
  };

  class WallClockTimer
  {
  public:
    WallClockTimer();
    const double elapsed() const;
    void reset();
  private:
    double start_time;
  };

};


#endif
