#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"
#include "vtkParaTextExecutionTimer.h"

#include <vtkAssignMimeType.h>
#include "../vtkCleanupNonUTF8TextExtractionStrategy.h"
#include <vtkCollection.h>
#include <vtkDistributedArray.h>
#include <vtkDocumentPerLinePDocumentReaderStrategy.h>
#include <vtkMPIController.h>
#include <vtkNGramExtraction.h>
#include <vtkPassThrough.h>
#include <vtkPDocumentReader.h>
#include <vtkPGenerateIndexArray.h>
#include <vtkRoundRobinPDocumentReaderStrategy.h>
#include <vtkScaleDimension.h>
#include <vtkSmartPointer.h>
#include <vtkSortedBytePDocumentReaderStrategy.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkTextExtraction.h>
#include <vtkUnsortedBytePDocumentReaderStrategy.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  std::string document_output_file;
  std::string metrics_output_file;
  std::string default_mime_type;
  std::string document_partition_strategy;
  std::vector<std::string> document_directories;
  std::vector<std::string> document_files;
  std::vector<std::string> file_lists;
  std::vector<std::string> document_recursive_directories;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};

// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  try
    {
    // Set up command line parser
    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("directory", boost::program_options::value<std::vector<std::string> >(&state.document_directories), "Adds a directory to the list of inputs to be processed.")
      ("default-mime-type", boost::program_options::value<std::string>(&state.default_mime_type)->default_value("text/plain"), "Default MIME type for documents whose MIME type isn't detected automatically.")
      ("document-output-file", boost::program_options::value<std::string>(&state.document_output_file), "Document table will be written to this file")
      ("export-metrics", boost::program_options::value<std::string>(&state.metrics_output_file), "Writes execution metrics to a file.  Use '-' for stdout.")
      ("file,f", boost::program_options::value<std::vector<std::string> >(&state.document_files), "Adds a file to the list of inputs to be processed.")
      ("file-list,l", boost::program_options::value<std::vector<std::string> >(&state.file_lists), "Adds a file containing a line-delimited list of files to the list of inputs to be processed.")
      ("help,h", "Prints this help message and exits.")
      ("partition-strategy", boost::program_options::value<std::string>(&state.document_partition_strategy)->default_value("round-robin"), "Document reader partitioning strategy. Valid values are 'round-robin', 'sorted-bytes', and 'unsorted-bytes'.")
      ("recursive-directory", boost::program_options::value<std::vector<std::string> >(&state.document_recursive_directories), "Adds a directory and all its subdirectories to the list of inputs to be processed.")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;
    boost::program_options::positional_options_description positional_options;
    positional_options.add("document-output-file", 1);
    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(& std::cout);
        }
      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText Suite version 0.2\n";
      throw early_exit();
      }

    if (arguments.count("document-output-file") == 0)
      {
      std::cout << "ERROR: You must supply a filename for the output (document table).\n";
      throw early_exit();
      }

    // We're going to set up the pipeline in three stages.  First,
    // create all the objects; second, instrument them for execution
    // time; third, make the pipeline connections; fourth, put in all
    // the settings.  The point is to try to keep the code easy to
    // read.

    VTK_CREATE(vtkPDocumentReader, document_reader);
    vtkSmartPointer<vtkPDocumentReaderStrategy> reader_strategy;
    VTK_CREATE(vtkAssignMimeType, assign_mime_types);
    VTK_CREATE(vtkTextExtraction, text_extraction);
    VTK_CREATE(vtkTableWriter, document_table_writer);

    VTK_CREATE(vtkParaTextMetricReporter, reporter);
    VTK_CREATE(vtkParaTextExecutionTimer, time_document_reader);
    VTK_CREATE(vtkParaTextExecutionTimer, time_assign_mime_types);
    VTK_CREATE(vtkParaTextExecutionTimer, time_text_extraction);
    VTK_CREATE(vtkParaTextExecutionTimer, time_document_table_writer);

    time_document_reader->SetMetricReporter(reporter);
    time_assign_mime_types->SetMetricReporter(reporter);
    time_text_extraction->SetMetricReporter(reporter);
    time_document_table_writer->SetMetricReporter(reporter);

    time_document_reader->SetFilter(document_reader);
    time_assign_mime_types->SetFilter(assign_mime_types);
    time_text_extraction->SetFilter(text_extraction);
    time_document_table_writer->SetFilter(document_table_writer);

    reporter->SetController(controller);

    // ------------------------------------------------------------
    //
    // User-Selectable Strategies
    //
    // ------------------------------------------------------------

    // First we have to fill in the document reader and feature
    // dictionary creation strategies

    if(state.document_partition_strategy == "round-robin")
      {
      reader_strategy.TakeReference(vtkRoundRobinPDocumentReaderStrategy::New());
      }
    else if(state.document_partition_strategy == "sorted-bytes")
      {
      reader_strategy.TakeReference(vtkSortedBytePDocumentReaderStrategy::New());
      }
    else if(state.document_partition_strategy == "unsorted-bytes")
      {
      reader_strategy.TakeReference(vtkUnsortedBytePDocumentReaderStrategy::New());
      }
    else if(state.document_partition_strategy == "document-per-line")
      {
      reader_strategy.TakeReference(vtkDocumentPerLinePDocumentReaderStrategy::New());
      }
    else
      {
      throw std::runtime_error("Unknown document reader partitioning strategy: " + state.document_partition_strategy);
      }

    // ------------------------------------------------------------
    //
    // Pipeline Connection
    //
    // ------------------------------------------------------------

    // Now we can go about hooking up the rest of the pipeline.  We're
    // going to do the individual pipeline segments and then at the
    // end hook up the placeholders that depend on which data source
    // has been chosen.
    document_reader->SetStrategy(reader_strategy);
    assign_mime_types->SetInputConnection(0, document_reader->GetOutputPort());
    text_extraction->SetInputConnection(0, assign_mime_types->GetOutputPort());
    document_table_writer->SetInputConnection(0, text_extraction->GetOutputPort());

    // ------------------------------------------------------------
    //
    // Pipeline Configuration
    //
    // ------------------------------------------------------------

    if (state.metrics_output_file.size() > 0)
      {
      if (state.metrics_output_file == "-")
        {
        reporter->SetDestination(&std::cout);
        }
      else
        {
        std::ofstream* destination = new std::ofstream(ParaTextCommon::FormatFileName(state.metrics_output_file).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(destination);
        }
      }

    vtkCleanupNonUTF8TextExtractionStrategy *text_strategy =
      vtkCleanupNonUTF8TextExtractionStrategy::New();
    text_extraction->PrependStrategy(text_strategy);
    text_strategy->Delete();

    // Set up all the places for reading documents
    for(int i = 0; i != state.document_files.size(); ++i)
      {
      document_reader->AddFile(state.document_files[i].c_str());
      }
    for(int i = 0; i != state.document_directories.size(); ++i)
      {
      document_reader->AddDirectory(state.document_directories[i].c_str());
      }
    for(int i = 0; i != state.document_recursive_directories.size(); ++i)
      {
      document_reader->AddRecursiveDirectory(state.document_recursive_directories[i].c_str());
      }
    for(int i = 0; i != state.file_lists.size(); ++i)
      {
      std::ifstream list(state.file_lists[i].c_str());
      std::string file;
      for(std::getline(list, file); list; std::getline(list, file))
        document_reader->AddFile(file.c_str());
      }
    assign_mime_types->SetDefaultMimeType(state.default_mime_type.c_str());
    document_table_writer->SetFileName(ParaTextCommon::FormatFileName(state.document_output_file).c_str());

    // ------------------------------------------------------------
    //
    // Pipeline Execution
    //
    // ------------------------------------------------------------

    // This will automatically update its inputs.  The execution times
    // will come from vtkParaTextExecutionTimer and will be reported
    // via vtkParaTextMetricReporter.
    document_table_writer->Write();
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
