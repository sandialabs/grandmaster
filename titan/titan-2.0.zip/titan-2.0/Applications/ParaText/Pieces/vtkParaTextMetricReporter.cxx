/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkParaTextMetricReporter.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2012 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
  -------------------------------------------------------------------------*/

#include "vtkParaTextMetricReporter.h"
#include <vtkMultiProcessController.h>
#include <vtkObjectFactory.h>
#include <iostream>

#include <boost/format.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

namespace {
  std::string metric_format = "%2%,%|5t|%3%,%|10t|%4%,%|45t|%5%,%|70t|%6%,%|85t|%7%";
};

// ----------------------------------------------------------------------

vtkStandardNewMacro(vtkParaTextMetricReporter);
vtkCxxSetObjectMacro(vtkParaTextMetricReporter, Controller, vtkMultiProcessController);

// ----------------------------------------------------------------------

vtkParaTextMetricReporter::vtkParaTextMetricReporter()
{
  this->Destination = 0;
  this->Controller = 0;
}

vtkParaTextMetricReporter::~vtkParaTextMetricReporter()
{
  this->SetController(0);
}

std::string vtkParaTextMetricReporter::DefaultMetricFormat()
{
  return ::metric_format;
}

// ----------------------------------------------------------------------

void vtkParaTextMetricReporter::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Metric format: " << vtkParaTextMetricReporter::DefaultMetricFormat() << "\n";
}

// ----------------------------------------------------------------------

void vtkParaTextMetricReporter::SetDestination(std::ostream* wherever)
{
  this->Destination = wherever;
}
