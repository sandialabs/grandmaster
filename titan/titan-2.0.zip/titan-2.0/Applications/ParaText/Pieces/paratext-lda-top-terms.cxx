#include <vtkArrayReader.h>
#include <vtkDistributedArray.h>
#include <vtkMPIController.h>
#include <vtkSmartPointer.h>
#include <vtkTable.h>
#include <vtkTableReader.h>
#include <vtkTableWriter.h>
#include <vtkTextAnalysisUtilities.h>
#include <vtkUnicodeStringArray.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/format.hpp>
#include <boost/program_options.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include "ParaTextCommon.h"
#include "vtkParaTextMetricReporter.h"

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

/// Store the program state in one place so we can pass-it-around easily.
struct program_state
{
  boost::posix_time::ptime timestamp;
  vtkIdType process_id;
  vtkIdType process_count;

  std::string phi_filename;
  std::string term_dictionary_filename;
  std::string output_filename;

  int top_terms_per_topic;

  std::string export_metrics;
};

/// Used for quiet early termination of the program.
struct early_exit
{
};

// ----------------------------------------------------------------------

int main(int argc, char* argv[])
{
  int error_count = 0;

  VTK_CREATE(vtkMPIController, controller);
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  program_state state;
  state.timestamp = boost::posix_time::second_clock::local_time();
  state.process_id = controller->GetLocalProcessId();
  state.process_count = controller->GetNumberOfProcesses();

  try
    {
    /// Setup command-line arguments
    boost::program_options::options_description options("ParaText Options", 120);
    options.add_options()
      ("phi", boost::program_options::value<std::string>(&state.phi_filename), "Filename containing the phi (topic/term) matrix from LDA")
      ("term-dictionary", boost::program_options::value<std::string>(&state.term_dictionary_filename), "Filename containing the term dictionary used with LDA")
      ("top-terms-per-topic", boost::program_options::value<int>(&state.top_terms_per_topic)->default_value(10), "How many terms to print for each topic")
      ("output", boost::program_options::value<std::string>(&state.output_filename), "Where to write the output (use '-'for stdout)")
      ("export-metrics", boost::program_options::value<std::string>(&state.export_metrics), "Write execution metrics to a file.  Use '-' for stdout.")
      ("help,h", "Prints this help message and exits.")
      ("version", "Prints program version information and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("phi", 1);
    positional_options.add("term-dictionary", 1);
    positional_options.add("output", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      if(0 == state.process_id)
        {
        std::cout << options << "\n";
        ParaTextCommon::PrintFormattingOptions(&std::cout);
        }

      throw early_exit();
      }

    if(arguments.count("version"))
      {
      if(0 == state.process_id)
        std::cout << "ParaText version 0.1\n";
      throw early_exit();
      }

    // Check for required arguments
    bool can_continue = true;
    if (arguments.count("phi") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must provide a filename for the phi matrix.\n";
      }
    if (arguments.count("term-dictionary") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must provide a filename for the term dictionary.\n";
      }
    if (arguments.count("output") == 0)
      {
      can_continue = false;
      std::cerr << "ERROR: You must provide a filename for the output.\n";
      }
    if (!can_continue)
      {
      throw early_exit();
      }

    // --------------------------------------------------
    //
    // Pipeline Connection
    //
    // --------------------------------------------------

    VTK_CREATE(vtkTableReader, dictionary_reader);
    VTK_CREATE(vtkArrayReader, phi_reader);

    VTK_CREATE(vtkParaTextMetricReporter, reporter);
    ParaTextCommon::AttachTimer(dictionary_reader, reporter);
    ParaTextCommon::AttachTimer(phi_reader, reporter);

    // There are no connections to make here because the code is
    // actually in vtkTextAnalysisUtilities.

    // --------------------------------------------------
    //
    // Configuration
    //
    // --------------------------------------------------
    dictionary_reader->SetFileName(ParaTextCommon::FormatFileName(state.term_dictionary_filename).c_str());
    phi_reader->SetFileName(ParaTextCommon::FormatFileName(state.phi_filename).c_str());
    // Set up metric reporting
    std::ostream* MetricDestination = 0;
    if (arguments.count("export-metrics"))
      {
      if (state.export_metrics == "-")
        {
        MetricDestination = &std::cout;
        reporter->SetDestination(&std::cout);
        }
      else
        {
        MetricDestination = new std::ofstream(ParaTextCommon::FormatFileName(state.export_metrics).c_str(), std::ios::out | std::ios::app);
        reporter->SetDestination(MetricDestination);
        }
      }

    ParaTextCommon::CPUTimer cpu_timer;
    ParaTextCommon::WallClockTimer wall_clock_timer;

    // --------------------------------------------------
    //
    // Run!
    //
    // --------------------------------------------------

    // This first call will trigger the LDA engine when the pipeline
    // updates itself
    phi_reader->Update();
    dictionary_reader->Update();

    vtkArray* phi = phi_reader->GetOutput()->GetArray(0);
    vtkUnicodeStringArray* terms = vtkUnicodeStringArray::SafeDownCast(dictionary_reader->GetOutput()->GetColumnByName("text"));
    std::string out_filename = ParaTextCommon::FormatFileName(state.output_filename);

    if (phi == 0)
      {
      throw std::runtime_error("ERROR: Phi matrix is null!");
      }
    if (terms == 0)
      {
      throw std::runtime_error("ERROR: Term list is null!");
      }

    vtkTextAnalysisUtilities::SaveTopTermsTable( phi, terms, state.top_terms_per_topic,
                                                 out_filename );

    if (MetricDestination != 0)
      {
      reporter->ReportMetric("Total Execution Time", "CPU time", cpu_timer.elapsed(), "seconds");
      reporter->ReportMetric("Total Execution Time", "Wall clock time", wall_clock_timer.elapsed(), "seconds");
      }
    }
  catch(early_exit&)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
    }
  catch(...)
    {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
    }

  controller->GetCommunicator()->Barrier();
  controller->Finalize();
  return error_count;
}
