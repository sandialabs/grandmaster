#include <ParaTextTest.h>

#include <vtkSmartPointer.h>
#include <vtkTableReader.h>
#include <vtkTable.h>
#include <vtkUnicodeStringArray.h>

#include <boost/filesystem.hpp>
#include <iostream>
#include <sstream>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  try
    {
    remove(boost::filesystem::path("feature-dictionary.vtk"));

    std::vector<std::string> arguments;
    arguments.push_back("paratext-lsa");
    arguments.push_back("--directory=" DPT_LOCATION);
    arguments.push_back("--stop-words=bbb");
    arguments.push_back("--export-feature-dictionary=feature-dictionary.vtk");

    launch(PARATEXT_LOCATION, arguments);

    VTK_CREATE(vtkTableReader, feature_dictionary);
    feature_dictionary->SetFileName("feature-dictionary.vtk");
    feature_dictionary->Update();

    test_expression(feature_dictionary->GetOutput());
    test_expression(feature_dictionary->GetOutput()->GetNumberOfRows() == 124);
    test_expression(feature_dictionary->GetOutput()->GetNumberOfColumns() == 1);
    test_expression(feature_dictionary->GetOutput()->GetColumnName(0) == std::string("text"));

    vtkUnicodeStringArray* const text = vtkUnicodeStringArray::SafeDownCast(feature_dictionary->GetOutput()->GetColumn(0));
    test_expression(text);
    test_expression(text->GetValue(0) == vtkUnicodeString::from_utf8("aa0"));
    test_expression(text->GetValue(1) == vtkUnicodeString::from_utf8("aa1"));
    test_expression(text->GetValue(123) == vtkUnicodeString::from_utf8("be3"));

    return 0;
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    return 1;
    }
}
