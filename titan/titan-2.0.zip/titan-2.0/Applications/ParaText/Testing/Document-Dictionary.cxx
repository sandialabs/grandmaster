#include <ParaTextTest.h>

#include <vtkIdTypeArray.h>
#include <vtkSmartPointer.h>
#include <vtkStringArray.h>
#include <vtkTableReader.h>
#include <vtkTable.h>
#include <vtkUnicodeStringArray.h>

#include <boost/filesystem.hpp>
#include <iostream>
#include <sstream>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  try
    {
    remove(boost::filesystem::path("document-dictionary.vtk"));

    std::vector<std::string> arguments;
    arguments.push_back("paratext-lsa");
    arguments.push_back("--directory=" DPT_LOCATION);
    arguments.push_back("--export-document-dictionary=document-dictionary.vtk");

    launch(PARATEXT_LOCATION, arguments);

    VTK_CREATE(vtkTableReader, document_dictionary);
    document_dictionary->SetFileName("document-dictionary.vtk");
    document_dictionary->Update();

    test_expression(document_dictionary->GetOutput());
    test_expression(document_dictionary->GetOutput()->GetNumberOfRows() == 16);
    test_expression(document_dictionary->GetOutput()->GetNumberOfColumns() == 5);
    test_expression(document_dictionary->GetOutput()->GetColumnName(0) == std::string("document"));
    test_expression(document_dictionary->GetOutput()->GetColumnName(1) == std::string("uri"));
    test_expression(document_dictionary->GetOutput()->GetColumnName(2) == std::string("content"));
    test_expression(document_dictionary->GetOutput()->GetColumnName(3) == std::string("mime_type"));
    test_expression(document_dictionary->GetOutput()->GetColumnName(4) == std::string("text"));

    vtkIdTypeArray* const document = vtkIdTypeArray::SafeDownCast(document_dictionary->GetOutput()->GetColumn(0));
    test_expression(document);

    vtkStringArray* const uri = vtkStringArray::SafeDownCast(document_dictionary->GetOutput()->GetColumn(1));
    test_expression(uri);

    vtkStringArray* const content = vtkStringArray::SafeDownCast(document_dictionary->GetOutput()->GetColumn(2));
    test_expression(content);

    vtkStringArray* const mime_type = vtkStringArray::SafeDownCast(document_dictionary->GetOutput()->GetColumn(3));
    test_expression(mime_type);

    vtkUnicodeStringArray* const text = vtkUnicodeStringArray::SafeDownCast(document_dictionary->GetOutput()->GetColumn(4));
    test_expression(text);

    return 0;
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    return 1;
    }
}
