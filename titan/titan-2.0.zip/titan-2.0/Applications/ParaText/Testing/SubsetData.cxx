/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$
  Language:  C++
  Date:      $Date: 2005-06-06 19:49:35 -0600 (Mon, 06 Jun 2005) $
  Version:   $Revision: 4814 $

  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000, there is a non-exclusive
  license for use of this work by or on behalf of the
  U.S. Government. Redistribution and use in source and binary forms, with
  or without modification, are permitted provided that this Notice and any
  statement of authorship are reproduced on all copies.

=========================================================================*/

//#include "ParallelTextPipeline.h"

#include <boost/filesystem.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/program_options.hpp>
#include <boost/version.hpp>

#include <cmath>
#include <fstream>
#include <ios>
#include <iostream>
#include <iterator>
#include <sstream>

#include <stdio.h>

///////////////////////////////////////////////////////////////////////////////////////
// early_exit

struct early_exit
{
};

///////////////////////////////////////////////////////////////////////////////////////
// main

int main(int argc, char* argv[])
{
  int error_count = 0;

  try
    {
    // Process command-line arguments ...
    boost::filesystem::path source_directory;
    boost::filesystem::path target_directory;
    uint64_t data_size = 0;

    boost::program_options::options_description options("ParaText data subsetting options", 120);
    options.add_options()
      ("source", boost::program_options::value<boost::filesystem::path>(&source_directory), "Specify the source directory.")
      ("target", boost::program_options::value<boost::filesystem::path>(&target_directory), "Specify the target directory.")
      ("size", boost::program_options::value<uint64_t>(&data_size), "Specify the output data size (in Mb).")
      ("dry-run", "Doesn't actually copy files.")
      ("help,h", "Prints this help message and exits.")
      ;

    boost::program_options::variables_map arguments;

    boost::program_options::positional_options_description positional_options;
    positional_options.add("source", 1);
    positional_options.add("target", 1);
    positional_options.add("size", 1);

    boost::program_options::store(boost::program_options::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    boost::program_options::notify(arguments);

    // Handle arguments that cause an immediate exit ...
    if(arguments.count("help"))
      {
      std::cout << options << "\n";
      throw early_exit();
      }

    // Sanity-check the remaining arguments ...
    if(!arguments.count("source"))
      throw std::runtime_error("Source directory must be specified.");
    if(!exists(source_directory))
      throw std::runtime_error("Source directory doesn't exist.");
    if(!arguments.count("target"))
      throw std::runtime_error("Target directory must be specified.");
    if(!arguments.count("size"))
      throw std::runtime_error("Data size must be specified.");

    const uint64_t data_bytes = static_cast<uint64_t>(data_size * std::pow(2.0, 20.0));

    // Ensure that the source directory contains enough data to meet our requirements ...
    uint64_t total_file_bytes = 0;
    boost::filesystem::recursive_directory_iterator end;
    for(boost::filesystem::recursive_directory_iterator file(source_directory); file != end; ++file)
      {
      if(is_directory(file->path()))
        continue;

      total_file_bytes += file_size(file->path());

      if(total_file_bytes > data_bytes)
        break;

      std::cerr << "Checking file sizes: " << total_file_bytes << " " << static_cast<double>(total_file_bytes) / static_cast<double>(data_bytes) * 100.0 << "%         \r";
      }
    if(total_file_bytes < data_bytes)
      throw std::runtime_error("Source directory doesn't contain enough data: " + boost::lexical_cast<std::string>(total_file_bytes) + " bytes, " + boost::lexical_cast<std::string>(data_bytes) + " bytes required.");

    if(arguments.count("dry-run"))
      throw early_exit();

    // Now start copying files ...
    total_file_bytes = 0;
    for(boost::filesystem::recursive_directory_iterator file(source_directory); file != end; ++file)
      {
      if(is_directory(file->path()))
        continue;

      total_file_bytes += file_size(file->path());

      boost::filesystem::path source_path = source_directory;
      boost::filesystem::path target_path = file->path();

      boost::filesystem::path::iterator source_begin = source_path.begin();
      boost::filesystem::path::iterator target_begin = target_path.begin();
      for(; source_begin != source_path.end() && target_begin != target_path.end() && *source_begin == *target_begin; ++source_begin, ++target_begin)
        {
        }

      boost::filesystem::path source_relative;
      for(; source_begin != source_path.end(); ++source_begin)
        source_relative /= *source_begin;

      boost::filesystem::path target_relative;
      for(; target_begin != target_path.end(); ++target_begin)
        target_relative /= *target_begin;

      std::cerr << "copying " << file->path() << " to " << target_directory / target_relative << " ... ";
      create_directories(target_directory / target_relative.parent_path());

      copy_file(file->path(), target_directory / target_relative, boost::filesystem::copy_option::overwrite_if_exists);

      std::cerr << static_cast<double>(total_file_bytes) / static_cast<double>(data_bytes) * 100.0 << "%\n";

      if(total_file_bytes > data_bytes)
        break;
      }
    }
  catch(early_exit& e)
    {
    }
  catch(std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    error_count += 1;
    }

  return error_count;
}
