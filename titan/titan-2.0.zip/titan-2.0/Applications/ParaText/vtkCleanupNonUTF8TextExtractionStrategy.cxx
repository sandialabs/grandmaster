/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkCleanupNonUTF8TextExtractionStrategy.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/

#include <vtkIdTypeArray.h>
#include <vtkObjectFactory.h>
#include <vtkMimeTypes.h>
#include <vtkStringArray.h>
#include <vtkUnicodeStringArray.h>
#include "vtkCleanupNonUTF8TextExtractionStrategy.h"

vtkStandardNewMacro(vtkCleanupNonUTF8TextExtractionStrategy);

vtkCleanupNonUTF8TextExtractionStrategy::vtkCleanupNonUTF8TextExtractionStrategy()
{
}

vtkCleanupNonUTF8TextExtractionStrategy::~vtkCleanupNonUTF8TextExtractionStrategy()
{
}

void vtkCleanupNonUTF8TextExtractionStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

bool vtkCleanupNonUTF8TextExtractionStrategy::Extract(
  const vtkIdType document,
  const vtkStdString& vtkNotUsed(uri),
  const vtkStdString& mime_type,
  const vtkTypeUInt8* content_begin,
  const vtkTypeUInt8* content_end,
  vtkUnicodeString& text,
  vtkIdTypeArray* tag_document,
  vtkIdTypeArray* tag_begin,
  vtkIdTypeArray* tag_end,
  vtkStringArray* tag_type)
{
  // Determine whether we can handle this content or not ...
  bool supported = false;
  if(vtkMimeTypes::Match("text/*", mime_type))
    supported = true;
  else if(vtkMimeTypes::Match("application/x-latex", mime_type))
    supported = true;
  else if(vtkMimeTypes::Match("application/x-tex", mime_type))
    supported = true;
  if(!supported)
    return false;

  // Extract text from the content ...
  const char *text_begin = reinterpret_cast<const char *>(content_begin);
  const char *text_end = reinterpret_cast<const char *>(content_end);
  // this is painful but what else can we do?
  std::string temp_string(text_begin, (text_end - text_begin + 1));
  if (vtkUnicodeString::is_utf8(temp_string) == false)
    {
    for (std::string::size_type i = 0; i < temp_string.size(); ++i)
      {
      if (temp_string[i] < 0)
        {
        temp_string[i] = 'x';
        }
      }
    }
  text = vtkUnicodeString::from_utf8(temp_string);

  // Generate a tag for the content ...
  tag_document->InsertNextValue(document);
  tag_begin->InsertNextValue(0);
  tag_end->InsertNextValue(text.character_count());
  tag_type->InsertNextValue("TEXT");

  return true;
}
