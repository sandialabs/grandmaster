#!/usr/bin/python

from copy import deepcopy
from datetime import datetime
from optparse import OptionParser
from paratext import iso8601
from pprint import pprint
from subprocess import Popen
from titan.Web import vtkJSONArrayWriter, vtkJSONTableWriter
from urlparse import urlparse
from vtk import vtkArrayReader, vtkTableReader
import couchdb
import json
import os
import shutil
import sys
import tempfile
import threading

class worker(threading.Thread):
  def __init__(self, options):
    threading.Thread.__init__(self)
    self.options = options
    self.server = couchdb.Server(options.host)
    self.database = self.server[options.database]

  def run(self):
    self.task = {"_id":self.server.uuids(1)[0],"type":"task","description":"LSA Query","started":iso8601.now(),"status":"Starting."}
    self.database.save(self.task)

    self.task["status"] = "Retrieving model."
    self.database.save(self.task)

    temp_dir_path = tempfile.mkdtemp()
    feature_dictionary_path = os.path.join(temp_dir_path, "feature-dictionary.vtk")
    global_weighting_path = os.path.join(temp_dir_path, "global-weighting")
    lsv_path = os.path.join(temp_dir_path, "left-singular-vectors.vtk")
    sv_path = os.path.join(temp_dir_path, "singular-values.vtk")
    rsv_path = os.path.join(temp_dir_path, "right-singular-vectors.vtk")

    features_path = os.path.join(temp_dir_path, "features.vtk")
    frequency_matrix_path = os.path.join(temp_dir_path, "frequency-matrix.vtk")
    projection_matrix_path = os.path.join(temp_dir_path, "projection-matrix.vtk")
    similarity_table_path = os.path.join(temp_dir_path, "similarity-table.vtk")
    metrics_path = os.path.join(temp_dir_path, "metrics.csv")

    model = self.database[self.options.model]
    open(feature_dictionary_path, "w").write(self.database.get_attachment(model, "feature-dictionary.vtk").read())
    open(global_weighting_path, "w").write(self.database.get_attachment(model, "global-weighting.vtk").read())
    open(lsv_path, "w").write(self.database.get_attachment(model, "left-singular-vectors.vtk").read())
    open(sv_path, "w").write(self.database.get_attachment(model, "singular-values.vtk").read())
    open(rsv_path, "w").write(self.database.get_attachment(model, "right-singular-vectors.vtk").read())

    self.task["status"] = "Executing query."
    self.database.save(self.task)

    paratext_command = ["paratext-lsa-query",
      "--query-text", self.options.query_text,
      "--maximum-token-length", self.options.maximum_token_length,
      "--minimum-token-length", self.options.minimum_token_length,
      "--minimum-similarity", self.options.minimum_similarity,
      "--ngram-length", self.options.ngram_length,
      "--import-feature-dictionary", feature_dictionary_path,
      "--import-global-weighting", global_weighting_path,
      "--import-left-singular-vectors", lsv_path,
      "--import-singular-values", sv_path,
      "--import-right-singular-vectors", rsv_path,
      "--export-features", features_path,
      "--export-frequency-matrix", frequency_matrix_path,
      "--export-projection-matrix", projection_matrix_path,
      "--export-similarity-table", similarity_table_path,
      "--export-metrics", metrics_path
      ]

    sys.stderr.write(str(paratext_command))
    sys.stderr.flush()

    paratext_query = Popen(paratext_command)
    paratext_query.wait()

    self.task["status"] = "Storing query results."
    self.database.save(self.task)

    results = {"_id":self.server.uuids(1)[0],"type":"lsa-query-results","created":iso8601.now()}
    results["name"] = self.options.name
    results["model"] = self.options.model
    results["query-text"] = self.options.query_text
    results["maximum-token-length"] = self.options.maximum_token_length
    results["minimum-token-length"] = self.options.minimum_token_length
    results["minimum-similarity"] = self.options.minimum_similarity
    results["ngram-length"] = self.options.ngram_length

    self.database.save(results)
    self.database.put_attachment(results, open(features_path, "r").read(), filename="features.vtk", content_type="application/x-vtk-table")
    self.database.put_attachment(results, open(frequency_matrix_path, "r").read(), filename="frequency-matrix.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(results, open(projection_matrix_path, "r").read(), filename="projection-matrix.vtk", content_type="application/x-vtk-array")
    self.database.put_attachment(results, open(similarity_table_path, "r").read(), filename="similarity-table.vtk", content_type="application/x-vtk-table")
    self.database.put_attachment(results, open(metrics_path, "r").read(), filename="metrics.csv", content_type="text/csv")

    reader = vtkTableReader()
    writer = vtkJSONTableWriter()
    writer.SetInputConnection(reader.GetOutputPort())
    writer.SetWriteToOutputString(True)
    writer.SetFormat(1)

    reader.SetFileName(features_path)
    writer.Write()
    self.database.put_attachment(results, writer.GetOutputString(), filename="features.json", content_type="application/json")

    reader.SetFileName(similarity_table_path)
    writer.Write()
    self.database.put_attachment(results, writer.GetOutputString(), filename="similarity-table.json", content_type="application/json")

    reader = vtkArrayReader()
    writer = vtkJSONArrayWriter()
    writer.SetInputConnection(reader.GetOutputPort())
    writer.SetWriteToOutputString(True)

    reader.SetFileName(frequency_matrix_path)
    writer.Write()
    self.database.put_attachment(results, writer.GetOutputString(), filename="frequency-matrix.json", content_type="application/json")

    reader.SetFileName(projection_matrix_path)
    writer.Write()
    self.database.put_attachment(results, writer.GetOutputString(), filename="projection-matrix.json", content_type="application/json")

    self.task["status"] = "Removing work area."
    self.database.save(self.task)

    shutil.rmtree(temp_dir_path)

    self.task["finished"] = iso8601.now()
    self.task["status"] = "Finished."
    self.database.save(self.task)

def map_option(request, name, option):
  if request["query"].has_key(name):
    return request["query"][name]
  else:
    return option

def main():
  parser = OptionParser()
  parser.add_option("--database", type="string", dest="database", default="paratext", help="Specify the database name.  Default: %default")
  parser.add_option("--host", type="string", dest="host", default="http://localhost:5984", help="Specify the database server host.  Default: %default")
  parser.add_option("--maximum-token-length", dest="maximum_token_length", default="32", help="Specify the maximum allowable token length in characters.  Default: %default")
  parser.add_option("--minimum-similarity", dest="minimum_similarity", default="0", help="Specify the minimum similarity threshold.  Default: %default")
  parser.add_option("--minimum-token-length", dest="minimum_token_length", default="2", help="Specify the minimum allowable token length in characters.  Default: %default")
  parser.add_option("--model", type="string", dest="model", help="Specify an existing model ID.")
  parser.add_option("--name", type="string", dest="name", default="LSA Query", help="Specify a human-readable query name.  Default: %default")
  parser.add_option("--ngram-length", dest="ngram_length", default="1", help="Specify the length of extracted n-grams.  Default: %default")
  parser.add_option("--server", action="store_true", dest="server", default=False, help="Serve CouchDB requests instead of executing immediately.  Default: %default")
  parser.add_option("--query-text", type="string", dest="query_text", help="Specify the text to be queried.")
  (options, arguments) = parser.parse_args()

  if options.server:
    while True:
      line = sys.stdin.readline()
      if len(line) == 0:
        break
      request = json.loads(line)

      request_options = deepcopy(options)
      request_options.host = "http://" + request["headers"]["Host"]
      request_options.database = request["info"]["db_name"]
      request_options.maximum_token_length = map_option(request, "maximum-token-length", request_options.maximum_token_length)
      request_options.minimum_similarity = map_option(request, "minimum-similarity", request_options.minimum_similarity)
      request_options.minimum_token_length = map_option(request, "minimum-token-length", request_options.minimum_token_length)
      request_options.model = map_option(request, "model", request_options.model)
      request_options.name = map_option(request, "name", request_options.name)
      request_options.ngram_length = map_option(request, "ngram-length", request_options.ngram_length)
      request_options.query_text = map_option(request, "query-text", request_options.query_text)

      worker(request_options).start() # Change "start" to "run" to serialize requests

      response = {"code":202, "json":{"ok":True, "message":"Computing LSA model."}}
      sys.stdout.write("%s\n" % json.dumps(response))
      sys.stdout.flush()
  else:
    if not options.model:
      raise Exception("--model must be specified.")
    if not options.query_text:
      raise Exception("--query-text must be specified.")

    worker(options).start()

if __name__ == "__main__":
  main()
