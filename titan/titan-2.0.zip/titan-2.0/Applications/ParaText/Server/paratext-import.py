#!/usr/bin/python

from datetime import datetime
from optparse import OptionParser
from paratext import iso8601
import couchdb
import mimetypes
import os

class importer:
  def __init__(self, options):
    self.options = options
    self.server = couchdb.Server(self.options.host)
    self.database = self.server[self.options.database]
    self.file_count = 0

  def start(self):
    self.task = {"_id":self.server.uuids(1)[0],"type":"task","description":"Import task","started":iso8601.now(),"status":"Starting."}
    self.database.save(self.task)

  def import_file(self, path):
    content = open(path, "r")
    mime_type = mimetypes.guess_type(path)

    doc = {}
    doc["_id"] = self.server.uuids(1)[0]
    doc["type"] = "document"
    doc["corpus"] = self.options.corpus
    doc["system"] = { "import_time" : iso8601.now() }
    doc["file"] = { "uri" : "file://" + path }
    doc["file"]["modified_time"] = datetime.utcfromtimestamp(os.path.getmtime(path)).isoformat() + "Z"

    self.database.save(doc)
    self.database.put_attachment(doc, content, filename = "content", content_type = mime_type[0])

    print "Imported", path

    self.file_count += 1
    self.task["status"] = "Imported " + str(self.file_count) + " files."
    self.database.save(self.task)

  def import_directory(self, path):
    children = os.listdir(path)
    for child in children:
      child_path = os.path.join(path, child)
      if os.path.isdir(child_path) and self.options.recursive:
        self.import_directory(child_path)
      elif os.path.isdir(child_path):
        continue
      else:
        self.import_file(child_path)

  def import_path(self, path):
    if os.path.isdir(path):
      self.import_directory(path)
    else:
      self.import_file(path)

  def finish(self):
    self.task["finished"] = iso8601.now()
    self.database.save(self.task)

def main():
  parser = OptionParser()
  parser.add_option("--host", type="string", dest="host", default="http://localhost:5984", help="Specify the database server host.  Default: %default")
  parser.add_option("--database", type="string", dest="database", default="paratext", help="Specify the database name.  Default: %default")
  parser.add_option("--recursive", action="store_true", dest="recursive", default=False, help="Recursively import subdirectories.  Default: %default")
  parser.add_option("--corpus", type="string", dest="corpus", default="", help="Specify a corpus name for imported documents.  Default: %default")
  (options, arguments) = parser.parse_args()

  worker = importer(options)
  worker.start()
  for path in arguments:
    worker.import_path(path)
  worker.finish()

if __name__ == "__main__":
  main()
