function(doc)
{
  if(doc.type != "lsa-model")
    return;

  emit(doc.created + "-" + doc._id, null);
}
