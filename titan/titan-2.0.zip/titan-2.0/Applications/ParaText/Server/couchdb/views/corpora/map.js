function(doc)
{
  if(doc.type != "document")
    return;

  emit(doc.corpus, 1);
}
