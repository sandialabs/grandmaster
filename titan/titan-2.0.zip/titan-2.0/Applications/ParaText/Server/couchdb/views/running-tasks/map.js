function(doc)
{
  if(doc.type != "task")
    return;

  if(doc.finished != undefined)
    return;

  emit(doc.started + "-" + doc._id, doc._rev)
}
