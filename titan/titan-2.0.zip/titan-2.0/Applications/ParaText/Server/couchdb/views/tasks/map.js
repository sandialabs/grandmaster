function(doc)
{
  if(doc.type != "task")
    return;

  emit(doc.started + "-" + doc._id, doc._rev);
}
