Date.iso8601 = function(dString)
{
  var result = new Date(0);

  var regexp = /(\d\d\d\d)(-)?(\d\d)(-)?(\d\d)(T)?(\d\d)(:)?(\d\d)(:)?(\d\d)(\.\d+)?(Z|([+-])(\d\d)(:)?(\d\d))/;

  if(dString.toString().match(new RegExp(regexp)))
  {
    var d = dString.match(new RegExp(regexp));
    var offset = 0;
    result.setUTCDate(1);
    result.setUTCFullYear(parseInt(d[1],10));
    result.setUTCMonth(parseInt(d[3],10) - 1);
    result.setUTCDate(parseInt(d[5],10));
    result.setUTCHours(parseInt(d[7],10));
    result.setUTCMinutes(parseInt(d[9],10));
    result.setUTCSeconds(parseInt(d[11],10));
    if(d[12])
    {
      result.setUTCMilliseconds(parseFloat(d[12]) * 1000);
    }
    else
    {
      result.setUTCMilliseconds(0);
    }

    if(d[13] && d[13] != 'Z')
    {
      offset = (d[15] * 60) + parseInt(d[17], 10);
      offset *= ((d[14] == '-') ? -1 : 1);
      result.setTime(result.getTime() - offset * 60 * 1000);
    }
  }
  else
  {
    result.setTime(Date.parse(dString));
  }

  return result;
};
