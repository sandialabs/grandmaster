#include <boost/format.hpp>
#include <boost/program_options.hpp>
#include <boost/multi_array.hpp>

#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <iterator>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

#include <boost/tokenizer.hpp>

/* Proximity Functions */
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Clustering/ProximityGenerators/titanMinkowskiDistance.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Clustering/ProximityGenerators/titanChebyshevDistance.h>
#include <Clustering/ProximityGenerators/titanManhattanDistance.h>
#include <Clustering/ProximityGenerators/titanCosineSimilarity.h>
#include <Clustering/ProximityGenerators/titanKLDivergence.h>
#include <Clustering/ProximityGenerators/titanKLDivergenceJensenShannon.h>
#include <Clustering/ProximityGenerators/titanPearsonCorrelationCoefficient.h>
#include <Clustering/ProximityGenerators/titanEmptyDistance.h>
#include <Clustering/ProximityGenerators/titanMutableProximityExplicit.h>

/* Cluster Assignment */
#include <Clustering/titanHardClusterAssignment.h>
#include <Clustering/titanDiffClusterAssignments.h>
#include <Clustering/titanRelationProximities.h>

/* Centroid Generators */
#include <Clustering/CentroidGenerators/titanExplicitSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanExplicitCentroids.h>
#include <Clustering/CentroidGenerators/titanRandomSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/CentroidGenerators/titanMedoids.h>
#include <Clustering/CentroidGenerators/titanRepositionEmptyCentroids.h>
#include <Clustering/CentroidGenerators/titanRepositionEmptyCentroidsFarthestOutlier.h>
#include <Clustering/titanLinkClusterAdjustment.h>
#include <Clustering/CentroidGenerators/titanMeanCentroidsClusterList.h>
#include <Clustering/CentroidGenerators/titanMeanCentroidsObservationList.h>


/* Iterators/Vector Operators */
#include <Clustering/titanNormalizingIterator.h>
#include <Clustering/titanBoostMultiArrayIterator.h>
#include <Clustering/titanVectorOperations.h>
#include <Clustering/titanNormalizingIterator.h>

#include <titanNormalizeVectors.h>

/* Cluster Linkages */
#include <Clustering/Linkages/titanClusterLinkageSingle.h>
#include <Clustering/Linkages/titanClusterLinkageGroupAverage.h>
#include <Clustering/Linkages/titanClusterLinkageComplete.h>

/* Dispersion metrics */
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Clustering/titanIntraClusterTotalSquaredProximity.h>
#include <Clustering/titanInterClusterTotalSquaredProximity.h>
#include <Clustering/titanIntraClusterAverageProximity.h>

/* Clustering strategies */
#include <Clustering/titanBasicHierarchicalClustering.h>
#include <Clustering/titanFlattenHierarchy.h>

#include <Clustering/titanBoostMultiArrayAdaptor.h>

//For random centroid selection
#include <boost/date_time/posix_time/posix_time.hpp>

#include <boost/progress.hpp>

#define VTK_CREATE(classname, varname) vtkSmartPointer<classname > varname = vtkSmartPointer<classname>::New()

using namespace std;
using namespace boost;


typedef boost::multi_array<double, 2> double_matrix_type;
typedef boost::multi_array<size_t, 2> uint_matrix_type;

typedef titanBoostMultiArrayIterator<double_matrix_type,double> double_matrix_iterator;
typedef titanBoostMultiArrayIterator<uint_matrix_type,size_t> uint_matrix_iterator;

/// Used for quiet early termination of the program.
struct early_exit
{
};

enum CentroidInitializationType
{
  CentroidInitializationFirstK,
  CentroidInitializationSelection,
  CentroidInitializationRandomlySelectedK,
  CentroidInitializationRandomlyGeneratedK,
  CentroidInitializationSeedAssignments
};

struct program_state
{
  std::string data_file_name;

  size_t max_iterations;
  size_t min_k;
  size_t max_k;
  size_t num_trials;

  size_t current_k;
  size_t current_trial;
  size_t current_iteration;

  size_t row_count;
  size_t col_count;

  size_t maximum_hierarchy_levels;

  bool reposition_empty_centroids;

  bool  normalize_data;
  bool  normalize_centroids;

  bool  store_iteration_history;

  CentroidInitializationType centroid_initialization_method;

};


void setProximityGenerator(std::vector<std::string>& proximity_string_vector, titanMutableProximity& proximity_generator)
{
  if (!proximity_string_vector[0].compare("cheb"))
  {
    proximity_generator.SetProximityChebyshev();
  }
  else if (!proximity_string_vector[0].compare("cos"))
  {
    proximity_generator.SetProximityCosineSimilarity();
  }
  else if (!proximity_string_vector[0].compare("euc"))
  {
    proximity_generator.SetProximityEuclidean();
  }
  else if (!proximity_string_vector[0].compare("jac"))
  {
    proximity_generator.SetProximityJaccard();
  }
  else if (!proximity_string_vector[0].compare("kl"))
  {
    double base;
    try {
      base = boost::lexical_cast<double>(proximity_string_vector[1]);
      proximity_generator.SetProximityKLDivergence(base);
    }
    catch (boost::bad_lexical_cast &)
    {
      cerr << "Proximity parameter '" << proximity_string_vector[1] << "' is not valid."  << endl;
      throw early_exit();
    }
  }
  else if (!proximity_string_vector[0].compare("kljs"))
  {
    double base;
    try {
      base = boost::lexical_cast<double>(proximity_string_vector[1]);
      proximity_generator.SetProximityKLDivergenceJensenShannon(base);
    }
    catch (boost::bad_lexical_cast &)
    {
      cerr << "Proximity parameter '" << proximity_string_vector[1] << "' is not valid."  << endl;
      throw early_exit();
    }
  }
  else if (!proximity_string_vector[0].compare("man"))
  {
    proximity_generator.SetProximityManhattan();
  }
  else if (!proximity_string_vector[0].compare("min"))
  {
    double order;
    try {
      order = boost::lexical_cast<double>(proximity_string_vector[1]);
      proximity_generator.SetProximityMinkowski(order);
    }
    catch (boost::bad_lexical_cast &)
    {
      cerr << "Proximity parameter '" << proximity_string_vector[1] << "' is not valid."  << endl;
      throw early_exit();
    }
  }
  else if (!proximity_string_vector[0].compare("pcc"))
  {
    proximity_generator.SetProximityPearson();
  }
  else
  {
    cerr << "Invalid Proximity" << endl;
    throw early_exit();
  }

}

bool initializeCentroids(
    program_state& state,
    double_matrix_iterator observations_begin,
    double_matrix_iterator observations_end,
    std::vector<std::vector<double> >& centroids,
    titanBoostMultiArrayAdaptor<uint_matrix_type,size_t>& cluster_assignments,
    uint_matrix_type* seed_array)
{

  switch (state.centroid_initialization_method)
  {
  case CentroidInitializationFirstK:
  {
    size_t* initial_centroids = new size_t[state.current_k];
    for (size_t i = 0; i != state.current_k; i++)
    {
      initial_centroids[i] = i;
    }

    // Constructor, specifying the number and exemplar indices of initial
    // centroids
    titanExplicitSampleCentroids centroid_generator;

    centroid_generator.Initialize(
        initial_centroids,
        initial_centroids + state.current_k);


    // Create centroids from observation indices, storing them in
    // InitialCentroids
    centroid_generator(
        observations_begin,
        observations_end,
        cluster_assignments,
        centroids,
        titanEmptyDistance());

    // Assign observations to clusters using InitialCentroids
    titanHardClusterAssignment()(
        observations_begin,
        observations_end,
        centroids,
        cluster_assignments,
        titanEmptyDistance());

  }
    break;
  case CentroidInitializationRandomlySelectedK:
  {


    // Generate a random seed using the current time
    unsigned int random_seed;
    boost::posix_time::ptime now =
        boost::posix_time::second_clock::local_time();
    random_seed = static_cast<unsigned int>(state.current_k * now.time_of_day().total_milliseconds()
        + state.current_trial);

    // Constructor, specifying the number of initial centroids and a random
    // seed for generation
    titanRandomSampleCentroids centroid_generator(state.current_k, random_seed);

    // Create centroids from random observation indices, storing them in
    // InitialCentroids
    centroid_generator(
        observations_begin,
        observations_end,
        cluster_assignments,
        centroids,
        titanEmptyDistance ());

    // Assign observations to clusters using InitialCentroids
    titanHardClusterAssignment()(
        observations_begin,
        observations_end,
        centroids,
        cluster_assignments,
        titanEmptyDistance());

 }
    break;
  case CentroidInitializationSelection:
  {
    return false;
  }
    break;
  case CentroidInitializationSeedAssignments:
  {
    /*
    if (!seed_array)
    {
      vtkErrorMacro ("Missing seed array. Centroid initialization could not be completed.");
      return false;
    }

    cluster_assignments.resize(boost::extents[seed_array->GetExtent(0).GetSize()][0]);

    for (vtkIdType i = 0; i != seed_array->GetExtent(0).GetSize(); i++)
    {
      vtkGenericWarningMacro( << seed_array->GetValue(i));

      cluster_assignments[i][0] = seed_array->GetValue(i);
    }

    // Generate centroids from the mean of the observations, using the cluster assignments
    // This resize will probably need to be more complex. Current K and the index
    // for the incoming cluster assignments may not always be the same.
    this->InitialCentroids.resize();

    titanMeanCentroids preClusterAdjustment = titanMeanCentroids();

    preClusterAdjustment(
        observations_begin,
        observations_end,
        cluster_assignments,
        this->InitialCentroids,
        titanEuclideanDistance<std::vector<double> > ());
        */
  }
    break;
  default:
  {
  }
    break;
  }

  return true;

}


void read_data(program_state& state, std::string current_data_file, double_matrix_type& data)
{
  // Setup file variables
  typedef tokenizer< escaped_list_separator<char> > Tokenizer;
  string line;
  ifstream in;

  // Read data file to determine data size and structure integrity
  in.open(current_data_file.c_str());
  if (!in.is_open())
  {
    cerr << "Cannot open data file." << endl;
    throw early_exit();
  }


  state.row_count=0;
  while(getline(in,line))
  {
    Tokenizer tok(line);

    if (state.row_count==0)
      state.col_count = std::distance(tok.begin(), tok.end());
    else
    {
      if ((std::distance(tok.begin(), tok.end())) != state.col_count)
      {
        cout << "Uneven number of fields" << endl;
        throw early_exit();
      }
    }

    state.row_count++;
  }
  in.close();

  cout << "Original data" << endl;
  cout << "=============" << endl;
  cout << "Number of rows : " << state.row_count << endl;
  cout << "Number of cols : " << state.col_count << endl << endl;

  data.resize(boost::extents[state.row_count][state.col_count]);

  cout << "Reading data from file: " << current_data_file << ".." << flush;

  // Read the data into memory
  in.clear();
  in.open(current_data_file.c_str());

  std::vector<double> data_row;
  string token;
  double  value;
  size_t array_row, array_col;

  array_row=0;

  while (getline(in,line))
  {
    data_row.clear();
    Tokenizer tok(line);

    array_col=0;
    for (Tokenizer::iterator token_iterator = tok.begin(); token_iterator
        != tok.end(); ++token_iterator, ++array_col)
    {
      token = *token_iterator;
      value = atof(token.c_str());
      data[array_row][array_col] = value;
    }

    array_row++;
  }

  cout << ".done." << endl << flush;
}

int main(int argc, char* argv[])
{
  double_matrix_type data(boost::extents[1][1]);

  namespace po = boost::program_options;

  int error_count = 0;

  std::string cluster_initialization_string;
  std::vector<std::string> proximity_string_vector;
  std::vector<std::string> input_file_name;
  std::vector<size_t> columns;

  bool verbose=false;
  bool super_verbose=false;

  program_state state;


  try
  {
    // Setup command-line arguments
    po::options_description options("Cluster Options", 120);
    options.add_options()
        ("help,h", "Prints this help message and exits.")
        ("store_history,s", "Store the centroids and assignments for each iteration.")
        ("display_data,d", "Displays the data that is being used.")
        ("display_clustering,D", "Displays the cluster assignments")
        ("min_k,k", po::value<size_t>(&state.min_k)->default_value(1), "Sets the minimum number of clusters.")
        ("max_k,K", po::value<size_t>(&state.max_k)->default_value(1), "Sets the maximum number of clusters.")
        ("normalize,n", "Normalize data and centroids.")
        ("verbose,v", "Verbose mode.")
        ("super_verbose,V", "Super verbose mode.")
        ("normalize_centroids,N", "Normalize centroids only.")
        ("rep_empty,r", po::value<bool>(&state.reposition_empty_centroids)->default_value(true), "Reposition empty centroids.")
        ("proximity,p", po::value<std::vector<std::string> >(&proximity_string_vector)->multitoken()->default_value(vector<string>(1,"euc"),""), "Sets the proximity function to use.")
        ("iterations,i", po::value<size_t>(&state.max_iterations)->default_value(1000), "Sets the maximum iterations to convergence.")
        ("trials,t", po::value<size_t>(&state.num_trials)->default_value(100), "Sets the number of restarts.")
        ("cluster_initialization,z", po::value<std::string>(&cluster_initialization_string)->default_value("randselk"), "Sets the maximum number of clusters.")
        ("infile,f", po::value<std::vector<std::string> >(&input_file_name), "Adds a file to the list of inputs to be processed.")
        ("columns,c", po::value<std::vector<size_t> >(&columns)->multitoken(), "Columns to be used.")
        ("omit_columns,C", po::value<std::vector<size_t> >(&columns)->multitoken(), "Columns to be omitted.")
        ("hierarchical,H", "Perform hierarchical clustering.")
        ("flatten,F", po::value<size_t>(&state.maximum_hierarchy_levels), "Flatten hierarchy.")
        ;


    po::variables_map arguments;
    po::positional_options_description positional_options;
    positional_options.add("infile", 1);
    po::store(po::command_line_parser(argc, argv).options(options).positional(positional_options).run(), arguments);
    po::notify(arguments);



    // Handle arguments that cause an immediate exit ...
    if (arguments.count("help"))
    {
      std::cout << options << "\n";
      std::cout << "No help available at this time";
      throw early_exit();
    }

    if (arguments.count("columns") && arguments.count("omit_columns"))
    {
      cerr << "Use of --columns and --omit_columns is ambiguous. Use only one or the other." << endl;;
      throw early_exit();
    }

    if (arguments.count("verbose"))
    {
      verbose=true;
    }

    if (arguments.count("super_verbose"))
    {
      verbose=true;
      super_verbose=true;
    }

    state.store_iteration_history = false;
    if (arguments.count("store_history"))
    {
      state.store_iteration_history = true;
    }

    // Setup normalization options
    state.normalize_data=false;
    state.normalize_centroids=false;

    if (arguments.count("normalize"))
    {
      if (arguments.count("normalize_centroids"))
      {
        cerr << "Use of --normalize and --normalize_centroids is redundant. Use only one or the other." << endl;;
        throw early_exit();
      }

      state.normalize_data=true;
      state.normalize_centroids = true;

    }
    else if (arguments.count("normalize_centroids"))
    {
      state.normalize_centroids = true;
      state.normalize_data=false;
    }

    /* Setup essential clustering components */
    titanMutableProximity  proximity_generator;
    titanDiffClusterAssignments diffClusterAssignments; // stats for assignments between interations
    titanRelationProximities    observationCentroidProximities(false); // proximities between observations and centroids
    titanRepositionEmptyCentroids repositionEmptyCentroids;

    // Set the initialization method
    if (arguments.count("cluster_initialization") )
    {
      if (!cluster_initialization_string.compare("firstk"))
      {
        state.centroid_initialization_method = CentroidInitializationFirstK;
      }
      else if (!cluster_initialization_string.compare("randselk"))
      {
        state.centroid_initialization_method = CentroidInitializationRandomlySelectedK;
      }
      else if (!cluster_initialization_string.compare("seed"))
      {
        state.centroid_initialization_method = CentroidInitializationSeedAssignments;
      }
      else
      {
        cerr << "Invalid Initialization Method" << endl;;
        throw early_exit();
      }
    }


    /* Read data file and setup data */
    if (!arguments.count("infile") )
    {
      cerr << "Data file must be specified (-infile)." << endl;
      throw early_exit();
    }
    else
      read_data(state, input_file_name[0], data);

    if (arguments.count("columns") || arguments.count("omit_columns"))
    {
      // sort column ids, and remove duplicates
      std::sort( columns.begin(), columns.end() );
      columns.erase( std::unique( columns.begin(), columns.end() ), columns.end() );

      for (size_t col_index=0; col_index != columns.size(); ++col_index)
      {
        if (columns[col_index] >= data.shape()[1])
        {
          cerr << "Invalid column index." << endl;
          throw early_exit();
        }
      }

      if (arguments.count("omit_columns"))
      {
        // Transform from omissions to inclusions
        std::vector<size_t> include_columns;
        for (size_t col_index = 0; col_index != data.shape()[1]; ++col_index)
        {
          if (std::find(columns.begin(),columns.end(),col_index) == columns.end())
          {
            include_columns.push_back(col_index);
          }
        }

        columns.assign(include_columns.begin(), include_columns.end());
      }

      if (columns.size()==0)
      {
        cout << "Using ALL columns." << endl;
      }
      else
      {
        cout << "Using " << columns.size() << " columns {";
        for (size_t i=0; i < (columns.size()-1); i++)
        {
          cout << columns[i] << ",";
        }
        cout << columns[columns.size()-1] << "}" << endl;
      }

    }


    double_matrix_iterator observation_begin = double_matrix_iterator(&data, 0, 0, false, columns);
    double_matrix_iterator observation_end = double_matrix_iterator(&data, data.shape()[0], 0, false, columns);

    size_t num_observations = observation_end - observation_begin;

    if (state.normalize_data==true)
    {
      if (verbose)
        cout << "Normalizing data..";

        titanNormalizeVectors()(observation_begin, observation_end);

      if (verbose)
        cout << ".done." << endl;
    }

    if (arguments.count("display_data"))
    {
      size_t p;
      for (double_matrix_iterator data_iter = observation_begin; data_iter !=observation_end; ++data_iter)
      {
        for (p = 0; p != (*observation_begin).size()-1; ++p)
          cout << (*data_iter)[p] << ",";
        cout << (*data_iter)[p] << endl;
      }
    }

    /* Setup optional clustering components */

    titanHardClusterAssignment  clusterAssignment; // Standard hard clustering assignments
//    clusterAssignment.set_store_cluster_members(true);

    // Set the appropriate proximity generator
    if (arguments.count("proximity") )
    {
      setProximityGenerator(proximity_string_vector, proximity_generator);
    }

    if (arguments.count("hierarchical") && arguments.count("flatten"))
    {
      state.maximum_hierarchy_levels = std::max(state.min_k,state.maximum_hierarchy_levels);
      state.maximum_hierarchy_levels = std::min(observation_end-observation_begin,static_cast<size_t>(state.maximum_hierarchy_levels));
    }


    /***************/


    if (arguments.count("hierarchical") )
    {
      uint_matrix_type cluster_assignments(boost::extents[1][1]);

      uint_matrix_iterator assignments_begin = uint_matrix_iterator(&cluster_assignments, 0, 0, false);
      uint_matrix_iterator assignments_end = uint_matrix_iterator(&cluster_assignments, num_observations, 0, false);

      {
        boost::progress_timer timer;

        // TODO remove and use component form instead of this example form
        titanBasicHierarchicalClustering hierarchical =
          titanBasicHierarchicalClustering();

        if (verbose) hierarchical.set_verbose(true);

        hierarchical(titanHardClusterAssignment(), proximity_generator,
          observation_begin, observation_end, state.min_k,
          state.normalize_centroids, cluster_assignments);

        if (state.min_k != 1) state.maximum_hierarchy_levels = state.min_k;

        // Flatten the hierarchy if requested
        if ((state.min_k != 1) || (arguments.count("flatten")))
        {
          uint_matrix_type new_cluster_assignments(boost::extents[cluster_assignments.shape()[0]][1]);

          new_cluster_assignments = cluster_assignments;

          uint_matrix_iterator new_assignments_begin = uint_matrix_iterator(
            &new_cluster_assignments, 0, 0, false);
          uint_matrix_iterator new_assignments_end = uint_matrix_iterator(
            &new_cluster_assignments, new_cluster_assignments.shape()[0], 0, false);

          titanFlattenHierarchy flattenHierarchy = titanFlattenHierarchy(
            state.maximum_hierarchy_levels);

          flattenHierarchy(new_assignments_begin, new_assignments_end, observation_end - observation_begin);

          cluster_assignments.resize(boost::extents[observation_end - observation_begin][cluster_assignments.shape()[1]]);

          uint_matrix_iterator assignments_begin = uint_matrix_iterator(
            &cluster_assignments, 0, 0, false);

          for (size_t i=0; i != (observation_end - observation_begin); ++i)
            (*(assignments_begin+i))[0]=(*(new_assignments_begin+i))[0];
        }

      }

      if (arguments.count("display_clustering"))
      {
        cout << "obs\tclus" << endl;
        for (size_t i = 0; i != cluster_assignments.shape()[0]; ++i)
        {
          cout << i << "\t" << cluster_assignments[i][0] << endl;
        }
      }

    }
    else
    {

      // Cluster centroid storage
      std::vector<std::vector<double> > cluster_centroids(0);
      std::vector<std::vector<double> > best_cluster_centroids(0);

      // Setup storage for cluster assignments
      uint_matrix_type cluster_assignments_multiarray(boost::extents[observation_end
        - observation_begin][1]);
      uint_matrix_type old_cluster_assignments_multiarray(boost::extents[observation_end
        - observation_begin][1]);
      uint_matrix_type best_cluster_assignments_multiarray(
        boost::extents[observation_end - observation_begin][1]);

      titanBoostMultiArrayAdaptor<uint_matrix_type,size_t>  cluster_assignments(&cluster_assignments_multiarray,0);
      titanBoostMultiArrayAdaptor<uint_matrix_type,size_t>  old_cluster_assignments(&old_cluster_assignments_multiarray,0);
      titanBoostMultiArrayAdaptor<uint_matrix_type,size_t>  best_cluster_assignments(&best_cluster_assignments_multiarray,0);

      size_t best_k, best_k_index, best_trial, best_iteration;
      double best_proximity;

      /***************/
      {
        boost::progress_timer timer;

        // set default cluster assignments to cluster 0
        for (size_t i = 0; i != cluster_assignments.size(); ++i)
        {
          for (size_t j = 0; j != cluster_assignments[i].size(); ++j)
          {
            cluster_assignments[i][j]=0;
          }
        }

        uint_matrix_type * seed_array=0;

        size_t consecutive_static_iterations;

        /* Set bounds for K */
        state.min_k = std::max(state.min_k, static_cast<size_t>(1));
        state.max_k = std::max(state.min_k, state.max_k);

        size_t number_of_k_configurations;

        number_of_k_configurations = state.max_k - state.min_k + 1;

        std::vector<std::vector<std::vector<std::vector<double> > > >
          output_centroids;
        std::vector<std::vector<titanBoostMultiArrayAdaptor<uint_matrix_type,size_t> > > output_cluster_assignments;

        std::vector<std::vector<double> > trialAverageProximity;

        /* Make space for the data kept between each k configuration */
        if (state.store_iteration_history)
        {
          output_centroids.resize(number_of_k_configurations);
          output_cluster_assignments.resize(number_of_k_configurations);
          trialAverageProximity.resize(number_of_k_configurations);

          for (size_t k = 0; k != number_of_k_configurations; ++k)
          {
            output_centroids[k].resize(state.num_trials);
//            output_cluster_assignments[k].resize(state.num_trials);

            trialAverageProximity[k].resize(state.num_trials, 0);
          }
        }

        /* Begin clustering iterations */
        cout << "Beginning clustering." << endl;

        best_proximity= proximity_generator.farthest_value();

        size_t current_k_index = 0;
        for (state.current_k = state.min_k; state.current_k != state.max_k + 1; ++state.current_k, ++current_k_index)
        {
          if (verbose) cout << "Current K\t" << state.current_k << endl;

          for (state.current_trial = 0; state.current_trial != state.num_trials; ++state.current_trial)
          {
            if (verbose) cout << "Current Trial\t" << state.current_trial
              << endl;


            // Initialize the centroids for the current k and current trial,
            // using the method indicated by the user
            bool centroid_intialization_successful = initializeCentroids(state,
              observation_begin, observation_end, cluster_centroids,
              cluster_assignments, seed_array);


            if (!centroid_intialization_successful) return 0;


            clusterAssignment(observation_begin, observation_end,
              cluster_centroids,
              cluster_assignments,
              proximity_generator);

            // Iterate through the maximum iterations for the current K and current trial
            // Short-circuit if there is no change in assignments after an iteration
            consecutive_static_iterations = 0;
            for (state.current_iteration = 0; state.current_iteration
              != state.max_iterations; ++state.current_iteration)
            {
              if (super_verbose) cout << "Current Iteration\t"
                << state.current_iteration << endl;


              // store the old cluster assignments
              old_cluster_assignments = cluster_assignments;

              // calculate the centroid using the mean of the observations
              titanMeanCentroids()(observation_begin, observation_end,
                cluster_assignments, cluster_centroids, proximity_generator); // compute mean

              // Normalize if requested
              if (state.normalize_centroids) titanNormalizeVectors()(
                cluster_centroids.begin(), cluster_centroids.end());

              clusterAssignment(observation_begin, observation_end,
                cluster_centroids,
                cluster_assignments,
                proximity_generator);

              // Reassign centroids with no observations to different coordinates
              if (state.reposition_empty_centroids)
              {
                repositionEmptyCentroids(observation_begin, observation_end,
                  cluster_assignments, cluster_centroids, proximity_generator);

                // If a centroid has been repositioned, then re-assign observations
                if ((repositionEmptyCentroids.get_repositioned_centroids())->size())
                {
                  clusterAssignment(observation_begin, observation_end,
                    cluster_centroids,
                    cluster_assignments,
                    proximity_generator);
                }
              }

              // Check to see if there is a change in assignments, terminating
              // if there hasn't been a change after 2 iterations
              diffClusterAssignments(old_cluster_assignments,
                cluster_assignments, cluster_centroids);

              if ((diffClusterAssignments.getChangedAssignments())->size() > 0)
                consecutive_static_iterations = 0;
              else
                consecutive_static_iterations++;

              if (consecutive_static_iterations > 2) break;
            }

            if (state.store_iteration_history)
            {
              // Store the centroids and assignments for this trial
              output_centroids[current_k_index][state.current_trial]
                = cluster_centroids;
              output_cluster_assignments[current_k_index].push_back(cluster_assignments);
            }

            std::vector<double> * intraClusterTotalProximities;

            std::vector<std::vector<double> > obs_centroid_proximity_matrix;


            // Calculate the proximities between observations and their centroids
            observationCentroidProximities(observation_begin, observation_end,
              cluster_centroids.begin(), cluster_centroids.end(),
              proximity_generator, obs_centroid_proximity_matrix);

            // Calculate the total intra cluster squared proximities
            titanIntraClusterTotalSquaredProximity
              intraClusterTotalSquaredProximityGen =
                titanIntraClusterTotalSquaredProximity();

            intraClusterTotalSquaredProximityGen(observation_begin,
              observation_end, cluster_assignments, cluster_centroids,
              proximity_generator);

            intraClusterTotalProximities
              = intraClusterTotalSquaredProximityGen.get_proximities();


            double averageObservationCentroidProximity = 0;

            for (size_t i = 0; i
              != (*intraClusterTotalProximities).size(); i++)
            {
              if ((*intraClusterTotalSquaredProximityGen.get_counts())[i]) averageObservationCentroidProximity
                += (*intraClusterTotalProximities)[i];
            }

            averageObservationCentroidProximity /= (observation_end
              - observation_begin);

            if (state.store_iteration_history)
            {
              trialAverageProximity[current_k_index][state.current_trial];
            }

            // Find the best trial, as judged by the given metric
            // If iterating over K, there should be adjustment, such as a weighting or the gap statistic
            if (proximity_generator.closer(averageObservationCentroidProximity,
              best_proximity))
            {
              best_k = state.current_k;
              best_k_index = current_k_index;
              best_trial = state.current_trial;
              best_proximity = averageObservationCentroidProximity;
              best_cluster_assignments = cluster_assignments;
              best_cluster_centroids = cluster_centroids;
              best_iteration = state.current_iteration;
            }

          }
        }

    }

    cout << "888" << endl;

    cout << "Best" << endl;
    cout << "     K     : " << best_k << endl;
    cout << "     Trial : " << best_trial << endl;
    cout << "     Iter  : " << best_iteration << endl;
    cout << "     Prox  : " << best_proximity << endl;
    cout << endl;

    // Display the clustering output
    if (arguments.count("display_clustering"))
    {
      cout << "Final Cluster Assignments\n";
      cout << "=========================\n";
      for (size_t i = 0; i
          < best_cluster_assignments.size(); i++)
      {
        cout << "Obs=" << i << "\tCluster="
            << best_cluster_assignments[i][0]
            << "\n";
      }
    }

  }  // Partitional

  }
  catch(early_exit&)
  {
  }
  catch(std::exception& e)
  {
    std::cerr << "Caught exception: " << e.what() << std::endl;
    ++error_count;
  }
  catch(...)
  {
    std::cerr << "Caught unknown exception." << std::endl;
    ++error_count;
  }
  return 0;
}
