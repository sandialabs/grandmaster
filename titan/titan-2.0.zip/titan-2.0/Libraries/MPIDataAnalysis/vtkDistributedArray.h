/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkDistributedArray_h
#define __vtkDistributedArray_h

/// \class vtkDistributedArray vtkDistributedArray.h <MPIDataAnalysis/vtkDistributedArray.h>
/// \brief Helper functions for working with distributed
///  vtkArray data structures.
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National
///  Laboratories.

#include <titanMPIDataAnalysis.h>

#include <vtkArrayExtents.h>
#include <vtkArrayExtentsList.h>

class vtkArray;
class vtkMultiProcessController;

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkDistributedArray
{
public:
  /// Given a controller and a distributed (partitioned) array, communicates
  /// the number of array dimensions to every process.  The results are a list
  /// of dimensions, one-per-process, in rank order.  Note: in-general,
  /// every piece of a distributed array should always have the same number
  /// of dimensions, so this function is of value mainly for sanity-checking.
  static const std::vector<vtkIdType> AllGatherDimensions(vtkMultiProcessController* controller, vtkArray* local_array);

  /// Given a controller and a distributed (partitioned) array, communicates
  /// array extents to every process.  The results are a list of extents,
  /// one-per-process, in rank order.  Note: in-general, every piece of a
  /// distributed array should always have the same number of dimensions, but
  /// that is not enforced by this function - the returned extents might not
  /// have a consistent number of dimensions!  If you want to enforce
  /// dimensional consistency across processors, use AllGatherDimensions() and
  /// test its results, implementing your desired error-handling behavior.
  static const vtkArrayExtentsList AllGatherExtents(vtkMultiProcessController* controller, vtkArray* local_array);

  /// Given a list of extents describing a distributed (partitioned) array,
  /// compute the global extents.  Typically, this would be used with the
  /// output from AllGatherExtents().  Note that GlobalExtents() assumes
  /// that the input represents a properly-partitioned array without "gaps"
  /// between partitions.  Returns an empty list if the input extents don't
  /// all have the same number of dimensions.
  static const vtkArrayExtents GlobalExtents(const vtkArrayExtentsList& process_extents);

  /// Given a controller and a distributed (partitioned) array, "gather"
  /// the array to a single processor.  Returns the global array on the
  /// destination processor, and NULL everywhere else.  Returns NULL if
  /// the partitioned array doesn't have a consistent number of dimensions
  /// on all processors.  The caller is responsible for the lifetime of the
  /// returned array.
  static vtkArray* GatherArray(vtkMultiProcessController* controller, vtkArray* local_array, int destination_process = 0);

private:
  class GatherArrayHelper;
};

#endif
