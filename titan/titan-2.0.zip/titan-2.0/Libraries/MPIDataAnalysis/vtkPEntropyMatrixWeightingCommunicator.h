/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPEntropyMatrixWeightingCommunicator_h
#define __vtkPEntropyMatrixWeightingCommunicator_h

#include <titanMPIDataAnalysis.h>

#include <vtkMPICommunicator.h>
#include <vtkSmartPointer.h>

#include <map>

/// \class vtkPEntropyMatrixWeightingCommunicator vtkPEntropyMatrixWeightingCommunicator.h <MPIDataAnalysis/vtkPEntropyMatrixWeightingCommunicator.h>
/// \brief Helper class for implementing term dictionary filters.
///
/// \sa
///  vtkPEntropyMatrixWeightingNTo1, vtkPEntropyMatrixWeightingNToN
///
/// \par Thanks :
///  Developed by Eric T. Stanton (etstant@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPEntropyMatrixWeightingCommunicator
{
public:
  vtkPEntropyMatrixWeightingCommunicator(vtkCommunicator* communicator);

  /// Defines storage for a collection of feature counts/weights
  typedef std::map<int, double> FeatureValues;

  void Send(const FeatureValues& vals, int recipient);
  void Receive(int sender, FeatureValues& vals);
  void Broadcast(FeatureValues& vals, int sender);

private:
  vtkSmartPointer<vtkCommunicator> Communicator;
};

#endif
