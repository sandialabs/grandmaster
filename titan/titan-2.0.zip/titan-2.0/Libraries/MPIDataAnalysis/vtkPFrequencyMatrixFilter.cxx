/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkInformation.h"
#include "vtkObjectFactory.h"
#include "vtkPFrequencyMatrixFilter.h"
#include "vtkSparseArray.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"

#include <iterator>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// vtkPFrequencyMatrixFilter


vtkStandardNewMacro(vtkPFrequencyMatrixFilter);

vtkPFrequencyMatrixFilter::vtkPFrequencyMatrixFilter() :
  Controller(0),
  MinimumDocumentCount(0),
  MinimumDocumentPercent(0.0),
  MinimumFeatureCount(0)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");

  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(2);
}

vtkPFrequencyMatrixFilter::~vtkPFrequencyMatrixFilter()
{
  this->SetController(0);
}

void vtkPFrequencyMatrixFilter::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "MinimumDocumentCount: " << this->MinimumDocumentCount << "\n";
  os << indent << "MinimumDocumentPercent: " << this->MinimumDocumentPercent << "\n";
  os << indent << "MinimumFeatureCount: " << this->MinimumFeatureCount << "\n";
}

int vtkPFrequencyMatrixFilter::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;

    case 1:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;
    }

    return 0;
}

int vtkPFrequencyMatrixFilter::FillOutputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
      return 1;

    case 1:
      information->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkArrayData");
      return 1;
    }

    return 0;
}

int vtkPFrequencyMatrixFilter::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("SetController() must be called before executing this filter.");

    vtkUnicodeStringArray* const input_features = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!input_features)
      throw std::runtime_error("Missing feature dictionary text array.");

    vtkArrayData* const input_array_data = vtkArrayData::GetData(inputVector[1]);
    if(!input_array_data)
      throw std::runtime_error("Missing input frequency matrix.");

    if(input_array_data->GetNumberOfArrays() != 1)
      throw std::runtime_error("Array data on input port 1 must contain exactly one array.");

    vtkSparseArray<double>* const input_matrix = vtkSparseArray<double>::SafeDownCast(input_array_data->GetArray(0));
    if(!input_matrix)
      throw std::runtime_error("Array on input port 1 must be a sparse array of doubles.");

    if(input_matrix->GetDimensions() != 2)
      throw std::runtime_error("Array on input port 1 must be a matrix.");

    if(input_matrix->GetExtent(0).GetBegin() != 0)
      throw std::runtime_error("Input feature dictionary feature coordinates must be zero-based.");

    if(input_matrix->GetExtent(0).GetSize() != input_features->GetNumberOfTuples())
      throw std::runtime_error("Input feature dictionary and frequency matrix row counts must match.");

    const vtkIdType feature_count = input_features->GetNumberOfTuples();
    const vtkArray::SizeT element_count = input_matrix->GetNonNullSize();

    // Compute local counts ...
    vtkIdType local_document_count = input_matrix->GetExtent(1).GetSize();
    std::vector<vtkIdType> local_document_counts(feature_count, 0);
    std::vector<double> local_feature_counts(feature_count, 0);

    vtkArrayCoordinates coordinates(0, 0);
    for(vtkArray::SizeT n = 0; n != element_count; ++n)
      {
      input_matrix->GetCoordinatesN(n, coordinates);
      local_document_counts[coordinates[0]] += 1;
      local_feature_counts[coordinates[0]] += input_matrix->GetValueN(n);
      }

    // Sum counts across processors ...
    vtkIdType global_document_count = 0;
    std::vector<vtkIdType> global_document_counts(feature_count, 0);
    std::vector<double> global_feature_counts(feature_count, 0);

    this->Controller->GetCommunicator()->AllReduce(&local_document_count, &global_document_count, 1, vtkCommunicator::SUM_OP);
    this->Controller->GetCommunicator()->AllReduce(&local_document_counts[0], &global_document_counts[0], local_document_counts.size(), vtkCommunicator::SUM_OP);
    this->Controller->GetCommunicator()->AllReduce(&local_feature_counts[0], &global_feature_counts[0], local_feature_counts.size(), vtkCommunicator::SUM_OP);

    // Remove rows / terms that don't meet our criteria ...
    const double minimum_document_count = this->MinimumDocumentPercent * global_document_count;
    std::vector<bool> remove(feature_count, false);
    for(int i = 0; i != feature_count; ++i)
      {
      if(global_document_counts[i] < this->MinimumDocumentCount)
        {
        remove[i] = true;
        continue;
        }

      if(global_document_counts[i] < minimum_document_count)
        {
        remove[i] = true;
        continue;
        }

      if(global_feature_counts[i] < this->MinimumFeatureCount)
        {
        remove[i] = true;
        continue;
        }
     }

    // Generate the filtered feature dictionary output ...
    vtkUnicodeStringArray* const output_features = vtkUnicodeStringArray::New();
    output_features->SetName("text");
    vtkTable* const output_table = vtkTable::GetData(outputVector, 0);
    output_table->AddColumn(output_features);
    output_features->Delete();
    for(vtkIdType i = 0; i != feature_count; ++i)
      {
      if(remove[i])
        continue;

      output_features->InsertNextValue(input_features->GetValue(i));
      }

    // Create a map from old matrix row indices to new matrix row indices ...
    std::vector<vtkIdType> row_map(feature_count);
    for(vtkIdType old_row = 0, new_row = 0; old_row != feature_count; ++old_row)
      {
      row_map[old_row] = new_row;
      if(!remove[old_row])
        ++new_row;
      }

    // Generate the filtered frequency matrix output ...
    const vtkIdType new_feature_count = std::count(remove.begin(), remove.end(), false);

    vtkSparseArray<double>* const output_matrix = vtkSparseArray<double>::New();
    output_matrix->SetName(input_matrix->GetName());
    output_matrix->Resize(vtkArrayRange(0, new_feature_count), input_matrix->GetExtent(1));
    for(vtkArray::DimensionT i = 0; i != output_matrix->GetDimensions(); ++i)
      output_matrix->SetDimensionLabel(i, input_matrix->GetDimensionLabel(i));
    output_matrix->SetNullValue(input_matrix->GetNullValue());

    for(vtkArray::SizeT n = 0; n != element_count; ++n)
      {
      input_matrix->GetCoordinatesN(n, coordinates);
      if(remove[coordinates[0]])
        continue;
      output_matrix->AddValue(row_map[coordinates[0]], coordinates[1], input_matrix->GetValueN(n));
      }

    vtkArrayData* const output_array_data = vtkArrayData::GetData(outputVector, 1);
    output_array_data->ClearArrays();
    output_array_data->AddArray(output_matrix);
    output_matrix->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "caught unknown exception." << endl);
    }

  return 0;
}
