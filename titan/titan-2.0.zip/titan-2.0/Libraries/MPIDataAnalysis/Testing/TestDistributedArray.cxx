/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkArrayPrint.h>
#include <vtkMPIController.h>
#include <vtkDenseArray.h>
#include <vtkDistributedArray.h>
#include <vtkSmartPointer.h>

#include <vtksys/ios/iostream>
#include <vtksys/ios/sstream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

std::ostream& operator<<(std::ostream& stream, const vtkArrayExtentsList& value)
{
  for(vtkIdType i = 0; i != value.GetCount(); ++i)
    {
    if(i)
      stream << " ";
    stream << value[i];
    }
  return stream;
}

int main(int argc, char* argv[])
{
  int result = 0;

  vtkSmartPointer<vtkMPIController> controller = vtkSmartPointer<vtkMPIController>::New();
  controller->Initialize(&argc, &argv);
  controller->SetGlobalController(controller);

  try
    {
    if(controller->GetNumberOfProcesses() != 4)
      throw std::runtime_error("test requires exactly four processes");

    vtkSmartPointer<vtkDenseArray<double> > local_array = vtkSmartPointer<vtkDenseArray<double> >::Take(vtkDenseArray<double>::New());

    switch(controller->GetLocalProcessId())
      {
      case 0:
        local_array->Resize(vtkArrayRange(0, 20), vtkArrayRange(5, 15));
        local_array->Fill(0);
        break;

      case 1:
        local_array->Resize(vtkArrayRange(0, 15), vtkArrayRange(15, 25));
        local_array->Fill(1);
        break;

      case 2:
        local_array->Resize(vtkArrayRange(20, 25), vtkArrayRange(5, 15));
        local_array->Fill(2);
        break;

      case 3:
        local_array->Resize(vtkArrayRange(15, 25), vtkArrayRange(15, 25));
        local_array->Fill(3);
        break;
      }

    const std::vector<vtkIdType> all_process_dimensions = vtkDistributedArray::AllGatherDimensions(controller, local_array);
    test_expression(all_process_dimensions.size() == 4);
    test_expression(std::count(all_process_dimensions.begin(), all_process_dimensions.end(), 2) == all_process_dimensions.size());

    vtkArrayExtentsList process_extents = vtkDistributedArray::AllGatherExtents(controller, local_array);
    vtkArrayExtents global_extents = vtkDistributedArray::GlobalExtents(process_extents);

    for(int process = 0; process != controller->GetNumberOfProcesses(); ++process)
      {
      controller->Barrier();
      if(process == controller->GetLocalProcessId())
        {
        std::cerr << "Process " << process << " local extents: " << local_array->GetExtents() << std::endl;
        std::cerr << "Process " << process << " all extents: " << process_extents << std::endl;
        std::cerr << "Process " << process << " global extents: " << global_extents << std::endl;
        }
      }

    test_expression(process_extents.GetCount() == 4);
    test_expression(process_extents[0] == vtkArrayExtents(vtkArrayRange(0, 20), vtkArrayRange(5, 15)));
    test_expression(process_extents[1] == vtkArrayExtents(vtkArrayRange(0, 15), vtkArrayRange(15, 25)));

    test_expression(global_extents.GetDimensions() == 2);
    test_expression(global_extents[0] == vtkArrayRange(0, 25));
    test_expression(global_extents[1] == vtkArrayRange(5, 25));

    vtkSmartPointer<vtkArray> global_array = vtkSmartPointer<vtkArray>::Take(vtkDistributedArray::GatherArray(controller, local_array));
    switch(controller->GetLocalProcessId())
      {
      case 0:
        vtkPrintMatrixFormat(std::cerr, vtkDenseArray<double>::SafeDownCast(global_array));
        test_expression(global_array);
        test_expression(global_array->GetDimensions() == 2);
        test_expression(global_array->GetExtent(0) == vtkArrayRange(0, 25));
        test_expression(global_array->GetExtent(1) == vtkArrayRange(5, 25));
        break;

      case 1:
      case 2:
      case 3:
        test_expression(!global_array);
        break;
      }
    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    result = 1;
    }

  controller->Finalize();
  return result;
}
