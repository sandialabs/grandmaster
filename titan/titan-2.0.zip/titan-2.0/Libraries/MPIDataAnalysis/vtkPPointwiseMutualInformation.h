/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPPointwiseMutualInformation_h
#define __vtkPPointwiseMutualInformation_h

#include <titanMPIDataAnalysis.h>
#include "vtkArrayDataAlgorithm.h"
#include "vtkMultiProcessController.h"

/// \class vtkPPointwiseMutualInformation vtkPPointwiseMutualInformation.h <MPIDataAnalysis/vtkPPointwiseMutualInformation.h>
/// \brief Computes pointwise mutual information.
///
///  Given an arbitrary-dimension array of doubles, computes the pointwise mutual
///  information log(p(i,j,...) / p(i)p(j)p(...)) for each value in the array.
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPPointwiseMutualInformation : public vtkArrayDataAlgorithm
{
public:
  static vtkPPointwiseMutualInformation* New();
  vtkTypeMacro(vtkPPointwiseMutualInformation, vtkArrayDataAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Controls the dimension along which data is distributed across processors.  Default: 0
  vtkGetMacro(DistributedDimension, int);
  vtkSetMacro(DistributedDimension, int);
  ///@}

  ///@{
  /// Get/Set the parallel controller.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

//BTX
  enum
  {
    N_TO_1 = 0,
    N_TO_N = 1
  };
//ETX

  ///@{
  /// Specify the strategy to use for inter-process communication
  vtkSetMacro(Strategy, int);
  vtkGetMacro(Strategy, int);
  ///@}

//BTX
protected:
  vtkPPointwiseMutualInformation();
  ~vtkPPointwiseMutualInformation();

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPPointwiseMutualInformation(const vtkPPointwiseMutualInformation&); // Not implemented
  void operator=(const vtkPPointwiseMutualInformation&);   // Not implemented

  int DistributedDimension;
  int Strategy;
  vtkMultiProcessController* Controller;
//ETX
};

#endif
