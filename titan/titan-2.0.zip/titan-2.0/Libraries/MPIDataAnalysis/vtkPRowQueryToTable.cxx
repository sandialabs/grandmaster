/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include "vtkPRowQueryToTable.h"

#include "vtkCharArray.h"
#include "vtkCommunicator.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkIntArray.h"
#include "vtkObjectFactory.h"
#include "vtkRowQuery.h"
#include "vtkSerializeArrays.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkTypeUInt64Array.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"

#include <vtksys/ios/sstream>

#define VTK_ROW_AVAILABLE 123456
#define VTK_ROW_DATA      234567


vtkStandardNewMacro(vtkPRowQueryToTable);

vtkCxxSetObjectMacro(vtkPRowQueryToTable,Communicator,vtkCommunicator);

// ----------------------------------------------------------------------

vtkPRowQueryToTable::vtkPRowQueryToTable()
{
  this->Communicator = NULL;
  this->ReadEntireRow = true;
}

// ----------------------------------------------------------------------

vtkPRowQueryToTable::~vtkPRowQueryToTable()
{
  this->SetCommunicator(NULL);
}

// ----------------------------------------------------------------------

void vtkPRowQueryToTable::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Communicator: " << (this->Communicator ? "" : "NULL");
  if (this->Communicator)
    {
    this->Communicator->PrintSelf(os, indent.GetNextIndent());
    }
}

// ----------------------------------------------------------------------

int vtkPRowQueryToTable::RequestData(
  vtkInformation*,
  vtkInformationVector** vtkNotUsed(inputVector),
  vtkInformationVector* outputVector)
{
  if (!this->Communicator)
    {
    vtkErrorMacro(<<"No communicator has been set.  Execution cannot proceed.");
    return 0;
    }

  this->LocateMasterProcess();
  int MyId = this->Communicator->GetLocalProcessId();

  if (this->MasterProcessId == -1)
    {
    vtkErrorMacro(<<"Could not locate master node.  Execution cannot proceed.");
    return 0;
    }

  vtkTable* output = vtkTable::GetData(outputVector);

  if (this->MasterProcessId == MyId)
    {
    // Well, if noone else is going to run this thing then I guess I should.

    // Set up the columns
    this->Query->Execute();

    // Check for query error
    if (this->Query->HasError())
      {
      vtksys_ios::ostringstream errbuf;
      errbuf << "Query Error: " << this->Query->GetLastErrorText();
      this->AnnounceQueryError(errbuf.str());
      return 0;
      }
    else
      {
      vtkDebugMacro(<<"Master process executed query OK");
      this->AnnounceQuerySuccess();
      }

    // Pull the column names and types out of the result
    vtkSmartPointer<vtkStringArray> columnNames = vtkSmartPointer<vtkStringArray>::New();
    vtkSmartPointer<vtkIntArray> columnTypes = vtkSmartPointer<vtkIntArray>::New();

    int cols = this->Query->GetNumberOfFields();
    vtkDebugMacro(<<"Master process sees "
                  << this->Query->GetNumberOfFields()
                  << " columns in result");
    for (int c = 0; c < cols; c++)
      {
      columnTypes->InsertNextValue(this->Query->GetFieldType(c));
      columnNames->InsertNextValue(vtkStdString(this->Query->GetFieldName(c)));
      }

    // Broadcast the column information to the process group so that
    // all members can set up their tables
    this->AnnounceTableDefinition(columnNames, columnTypes);

    this->SetupTable(columnNames, columnTypes, output);

    // Fill the table
    int numRows = 0;
    float progressGuess = 0;
    vtkVariantArray* rowArray = vtkVariantArray::New();

    while (this->FetchNextRow(rowArray))
      {
      // XXX FIXME: Ultimately we should replace this with a Strategy
      // pattern in case we want to use distribution schemes slightly
      // more intelligent than round robin.
      int DestinationProcess = numRows % this->Communicator->GetNumberOfProcesses();
      if (DestinationProcess == MyId)
        {
        output->InsertNextRow(rowArray);
        }
      else
        {
        this->SendRowToProcess(rowArray, DestinationProcess);
        }

      // Update progress every 100 rows
      numRows++;
      if ((numRows%100)==0)
        {
        // 1% for every 100 rows, and then 'spin around'
        progressGuess = ((numRows/100)%100)*.01;
        this->UpdateProgress(progressGuess);
        }
      }
    rowArray->Delete();
    }
  else
    {
    int queryError = this->ListenForQueryStatus();
    if (queryError)
      {
      return 0;
      }
    else
      {
      this->ReceiveTableDefinition(output);
      while (this->AnotherRowAvailable())
        {
        this->ReceiveNextRow(output);
        }
      }
    }

  this->AnnounceNoMoreRows();
  return 1;
}

// ----------------------------------------------------------------------

int
vtkPRowQueryToTable::LocateMasterProcess()
{
  if (this->Communicator == NULL)
    {
    vtkErrorMacro(<<"LocateMasterProcessId: No communicator!  This should never happen.");
    return -1;
    }
  else
    {
    int SendId;
    int RecvId = VTK_INT_MAX;

    vtkCommunicator::StandardOperations op = vtkCommunicator::MIN_OP;
    int MyId = this->Communicator->GetLocalProcessId();

    if (this->Query)
      {
      // I can be the master node
      SendId = MyId;
      }
    else
      {
      SendId = VTK_INT_MAX;
      }

    this->Communicator->AllReduce(&SendId, &RecvId, 1, op);
    vtkDebugMacro( << "Process " << MyId << " believes that master node is "
                   << RecvId );

    this->SetMasterProcessId(RecvId);
    return RecvId;
    }
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::AnnounceTableDefinition(vtkStringArray *names, vtkIntArray *types)
{
  vtkSmartPointer<vtkCharArray> nameArchive = vtkSmartPointer<vtkCharArray>::New();
  vtkSerializeArrays::SaveStringArray(names, nameArchive);

  this->Communicator->Broadcast(nameArchive, this->GetMasterProcessId());
  this->Communicator->Broadcast(types, this->GetMasterProcessId());
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::ReceiveTableDefinition(vtkTable *output)
{
  vtkSmartPointer<vtkCharArray> nameArchive = vtkSmartPointer<vtkCharArray>::New();
  vtkSmartPointer<vtkStringArray> names = vtkSmartPointer<vtkStringArray>::New();
  vtkSmartPointer<vtkIntArray> types = vtkSmartPointer<vtkIntArray>::New();

  this->Communicator->Broadcast(nameArchive, this->GetMasterProcessId());
  this->Communicator->Broadcast(types, this->GetMasterProcessId());

  vtkSerializeArrays::RestoreStringArray(nameArchive, names);

  this->SetupTable(names, types, output);
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::AnnounceQueryError(const vtkStdString &message)
{
  int ErrorOccurred = 1;

  this->Communicator->Broadcast(&ErrorOccurred, 1, this->GetMasterProcessId());
  vtkSmartPointer<vtkCharArray> errorBuffer = vtkSmartPointer<vtkCharArray>::New();
  errorBuffer->SetName("error message");
  char *write_here = errorBuffer->WritePointer(0, message.size());
  memcpy(write_here, message.data(), message.size());

  this->Communicator->Broadcast(errorBuffer, this->GetMasterProcessId());
}

// ----------------------------------------------------------------------

bool
vtkPRowQueryToTable::ListenForQueryStatus()
{
  int ErrorOccurred = 0;

  this->Communicator->Broadcast(&ErrorOccurred, 1, this->GetMasterProcessId());
  if (!ErrorOccurred)
    {
    vtkDebugMacro(<<"vtkPRowQueryToTable: Node "
                  << this->Communicator->GetLocalProcessId()
                  <<" believes that query executed OK");
    return false;
    }
  else
    {
    vtkSmartPointer<vtkCharArray> errorBuffer = vtkSmartPointer<vtkCharArray>::New();
    this->Communicator->Broadcast(errorBuffer, this->GetMasterProcessId());
    vtkStdString errorMessage(errorBuffer->GetPointer(0), errorBuffer->GetNumberOfTuples());

    vtkErrorMacro(<<"vtkPRowQueryToTable: Node "
                  << this->Communicator->GetLocalProcessId()
                  <<" received query error: "
                  << errorMessage.c_str());
    return true;
    }
}


// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::AnnounceQuerySuccess()
{
  int ErrorOccurred = 0;

  this->Communicator->Broadcast(&ErrorOccurred, 1, this->GetMasterProcessId());
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::SendRowToProcess(vtkVariantArray *data, int DestinationProcess)
{
  int Available = 1;
  this->Communicator->Send(&Available, 1, DestinationProcess,
                           VTK_ROW_AVAILABLE);

  vtkSmartPointer<vtkCharArray> archive = vtkSmartPointer<vtkCharArray>::New();
  vtkSerializeArrays::SaveVariantArray(data, archive);

  this->Communicator->Send(archive, DestinationProcess,
                           VTK_ROW_DATA);
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::SetupTable(vtkStringArray *names,
                                vtkIntArray *types,
                                vtkTable *table)
{
  for (int c = 0; c < names->GetNumberOfTuples(); ++c)
    {
    vtkAbstractArray *arr;

    int type = types->GetValue(c);
    // Take care of the special case of uint64
    // to ensure timepoints have specific array type
    if (type == VTK_TYPE_UINT64)
      {
      arr = vtkTypeUInt64Array::New();
      }
    else
      {
      arr = vtkAbstractArray::CreateArray(type);
      }

    // Make sure name doesn't clash with existing name.
    vtkStdString name = names->GetValue(c);
    if (table->GetColumnByName(name.c_str()))
      {
      int i = 1;
      vtksys_ios::ostringstream oss;
      vtkStdString newName;
      do
        {
        oss.str("");
        oss << name << "_" << i;
        newName = oss.str();
        ++i;
        } while (table->GetColumnByName(newName));
      arr->SetName(newName);
      }
    else
      {
      arr->SetName(name);
      }

    // Add the column to the table.
    table->AddColumn(arr);
    arr->Delete();
    }
}

// ----------------------------------------------------------------------

bool
vtkPRowQueryToTable::AnotherRowAvailable()
{
  int result = -1;

  this->Communicator->Receive(&result, 1, this->GetMasterProcessId(),
                              VTK_ROW_AVAILABLE);

  if (result == -1)
    {
    vtkErrorMacro(<<"AnotherRowAvailable: Result code was -1 on node "
                  <<this->Communicator->GetLocalProcessId()
                  <<".  This shouldn't happen.");
    return false;
    }
  else if (result)
    {
    vtkDebugMacro(<<"AnotherRowAvailable: Node "
                  << this->Communicator->GetLocalProcessId()
                  << " ready to receive next row.");
    return true;
    }
  else
    {
    vtkDebugMacro(<<"AnotherRowAvailable: Node "
                  << this->Communicator->GetLocalProcessId()
                  << " done reading rows.");
    return false;
    }
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::ReceiveNextRow(vtkTable *table)
{
  vtkSmartPointer<vtkCharArray> archive = vtkSmartPointer<vtkCharArray>::New();

  vtkDebugMacro(<< "Process "
                << this->Communicator->GetLocalProcessId()
                << " listening for next row");

  this->Communicator->Receive(archive, this->GetMasterProcessId(),
                              VTK_ROW_DATA);

  vtkSmartPointer<vtkVariantArray> row = vtkSmartPointer<vtkVariantArray>::New();
  vtkSerializeArrays::RestoreVariantArray(archive, row);
  table->InsertNextRow(row);
}

// ----------------------------------------------------------------------

void
vtkPRowQueryToTable::AnnounceNoMoreRows()
{
  vtkDebugMacro(<<"Announcing the end of the rows.");

  for (int i = 0; i < this->Communicator->GetNumberOfProcesses(); ++i)
    {
    if (i == this->Communicator->GetLocalProcessId())
      {
      continue; // I know already
      }
    else
      {
      int message = 0;
      vtkDebugMacro(<<"Sending NoMoreRows to process " << i);
      this->Communicator->Send(&message, 1, i, VTK_ROW_AVAILABLE);
      }
    }

  vtkDebugMacro(<<"Sent NoMoreRows to all processes.");
}

// ----------------------------------------------------------------------

bool
vtkPRowQueryToTable::FetchNextRow(vtkVariantArray *output)
{
  output->Reset();
  if (this->ReadEntireRow)
    {
    return this->Query->NextRow(output);
    }
  else
    {
    bool status = this->Query->NextRow();
    if (status)
      {
      for (int i = 0; i < this->Query->GetNumberOfFields(); ++i)
        {
        output->InsertNextValue(this->Query->DataValue(i));
        }
      }
    return status;
    }
}
