/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkCellData.h"
#include "vtkDataSet.h"
#include "vtkDataSetAttributes.h"
#include "vtkDemandDrivenPipeline.h"
#include "vtkPGenerateIndexArray.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMultiProcessController.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkTable.h"

#include <algorithm>
#include <map>
#include <numeric>
#include <vector>

#include <vtksys/SystemTools.hxx>

vtkStandardNewMacro(vtkPGenerateIndexArray);
vtkCxxSetObjectMacro(vtkPGenerateIndexArray, Controller, vtkMultiProcessController);

vtkPGenerateIndexArray::vtkPGenerateIndexArray() :
  ArrayName(0),
  FieldType(ROW_DATA),
  PedigreeID(false)
{
  this->SetArrayName("index");
  this->Controller = 0;
  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPGenerateIndexArray::~vtkPGenerateIndexArray()
{
  this->SetArrayName(0);
  this->SetController(0);
}

void vtkPGenerateIndexArray::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os,indent);
  os << "ArrayName: " << (this->ArrayName ? this->ArrayName : "(none)") << endl;
  os << "FieldType: " << this->FieldType << endl;
  os << "PedigreeID: " << this->PedigreeID << endl;
  os << indent << "Controller: " << this->Controller << endl;
}

int vtkPGenerateIndexArray::ProcessRequest(
  vtkInformation* request,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  if(request->Has(vtkDemandDrivenPipeline::REQUEST_DATA_OBJECT()))
    {
    return this->RequestDataObject(request, inputVector, outputVector);
    }
  return this->Superclass::ProcessRequest(request, inputVector, outputVector);
}

int vtkPGenerateIndexArray::RequestDataObject(
  vtkInformation*,
  vtkInformationVector** inputVector ,
  vtkInformationVector* outputVector)
{
  vtkInformation* inInfo = inputVector[0]->GetInformationObject(0);
  if (!inInfo)
    {
    return 0;
    }
  vtkDataObject *input = inInfo->Get(vtkDataObject::DATA_OBJECT());

  if (input)
    {
    // for each output
    for(int i=0; i < this->GetNumberOfOutputPorts(); ++i)
      {
      vtkInformation* info = outputVector->GetInformationObject(i);
      vtkDataObject *output = info->Get(vtkDataObject::DATA_OBJECT());

      if (!output || !output->IsA(input->GetClassName()))
        {
        vtkDataObject* newOutput = input->NewInstance();
        info->Set(vtkDataObject::DATA_OBJECT(), newOutput);
        newOutput->Delete();
        }
      }
    return 1;
    }
  return 0;
}

int vtkPGenerateIndexArray::RequestData(
  vtkInformation *vtkNotUsed(request),
  vtkInformationVector **inputVector,
  vtkInformationVector *outputVector)
{
  // An output array name is required ...
  if(!(this->ArrayName && strlen(this->ArrayName)))
    {
    vtkErrorMacro(<< "No array name defined.");
    return 0;
    }

  // Make a shallow-copy of our input ...
  vtkDataObject* const input = vtkDataObject::GetData(inputVector[0]);
  vtkDataObject* const output = vtkDataObject::GetData(outputVector);
  output->ShallowCopy(input);

  // Figure-out where we'll be reading/writing data ...
  vtkDataSetAttributes* output_attributes = 0;
  vtkIdType output_count = 0;

  switch(this->FieldType)
    {
    case ROW_DATA:
      {
      vtkTable* const table = vtkTable::SafeDownCast(output);
      output_attributes = table ? table->GetRowData() : 0;
      output_count = table ? table->GetNumberOfRows() : 0;
      break;
      }
    case POINT_DATA:
      {
      vtkDataSet* const data_set = vtkDataSet::SafeDownCast(output);
      output_attributes = data_set ? data_set->GetPointData() : 0;
      output_count = data_set ? data_set->GetNumberOfPoints() : 0;
      break;
      }
    case CELL_DATA:
      {
      vtkDataSet* const data_set = vtkDataSet::SafeDownCast(output);
      output_attributes = data_set ? data_set->GetCellData() : 0;
      output_count = data_set ? data_set->GetNumberOfCells() : 0;
      break;
      }
    case VERTEX_DATA:
      {
      vtkGraph* const graph = vtkGraph::SafeDownCast(output);
      output_attributes = graph ? graph->GetVertexData() : 0;
      output_count = graph ? graph->GetNumberOfVertices() : 0;
      break;
      }
    case EDGE_DATA:
      {
      vtkGraph* const graph = vtkGraph::SafeDownCast(output);
      output_attributes = graph ? graph->GetEdgeData() : 0;
      output_count = graph ? graph->GetNumberOfEdges() : 0;
      break;
      }
    }

  if(!output_attributes)
    {
    vtkErrorMacro(<< "Invalid field type for this data object.");
    return 0;
    }

  // Create our output array ...
  vtkIdTypeArray* const output_array = vtkIdTypeArray::New();
  output_array->SetName(this->ArrayName);
  output_array->SetNumberOfTuples(output_count);
  output_attributes->AddArray(output_array);
  output_array->Delete();

  if(this->PedigreeID)
    output_attributes->SetPedigreeIds(output_array);

  vtkCommunicator* comm = this->Controller->GetCommunicator();
  if (!comm)
    {
    vtkErrorMacro("Need a communicator.");
    return 0;
    }

  int numProcesses = this->Controller->GetNumberOfProcesses();

  // Generate globally-unique document identifiers that are contiguous for each process ...
  vtksys_stl::vector<vtkIdType> global_counts(numProcesses);

  this->Controller->AllGather( &output_count, &global_counts[0], 1);

  const vtkIdType processor_offset =
    std::accumulate(global_counts.begin(), global_counts.begin() + this->Controller->GetLocalProcessId(), 0);

  for(vtkIdType i = 0; i != output_count; ++i)
    output_array->SetValue(i, processor_offset + i);

  return 1;
}
