/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkPEntropyMatrixWeightingNToN vtkPEntropyMatrixWeightingNToN.h <MPIDataAnalysis/vtkPEntropyMatrixWeightingNToN.h>
/// \brief Computes a global weighting vector for an
///  input matrix.
///
///
///  This is a parallel filter that uses a scatter-gather scheme for computing
///  global weights for an input matrix. Each processor is responsible for
///  computing the "global" weights for its local set of documents and then sharing
///  the results with the others who then sum them all up to obtain the actual
///  global weights.
///
///    Input port 0: (required) A vtkArrayData containing a frequency matrix.
///
///    Output port 0: A vtkArrayData containing a vector with the global feature weights.
///
/// \par Thanks :
///  Developed by Eric Stanton (etstant@sandia.gov) at Sandia National Laboratories.

#ifndef __vtkPEntropyMatrixWeightingNToN_h
#define __vtkPEntropyMatrixWeightingNToN_h

#include <titanMPIDataAnalysis.h>
#include <vtkArrayDataAlgorithm.h>
#include <vtkMultiProcessController.h>

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPEntropyMatrixWeightingNToN :
  public vtkArrayDataAlgorithm
{
public:
  static vtkPEntropyMatrixWeightingNToN* New();
  vtkTypeMacro(vtkPEntropyMatrixWeightingNToN, vtkArrayDataAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Controls the feature dimension.  Default: 0
  vtkGetMacro(FeatureDimension, int);
  vtkSetMacro(FeatureDimension, int);
  ///@}

  ///@{
  /// Get/Set the parallel controller.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

//BTX
protected:
  vtkPEntropyMatrixWeightingNToN();
  ~vtkPEntropyMatrixWeightingNToN();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPEntropyMatrixWeightingNToN(const vtkPEntropyMatrixWeightingNToN&); // Not implemented
  void operator=(const vtkPEntropyMatrixWeightingNToN&);   // Not implemented

  int FeatureDimension;

  vtkMultiProcessController* Controller;
//ETX
};

#endif
