/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkArrayExtentsList.h"
#include "vtkCommand.h"
#include "vtkDenseArray.h"
#include "vtkDistributedArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMPI.h"
#include "vtkMPICommunicator.h"
#include "vtkObjectFactory.h"
#include "vtkPEntropyMatrixWeightingNTo1.h"
#include "vtkPEntropyMatrixWeightingCommunicator.h"
#include "vtkSmartPointer.h"

#include <stdexcept>
#include <iterator>
#include <numeric>

#if defined(WIN32) && !defined(__MINGW32__)

static inline double log2(double n)
{
  return log(n) / log(2.);
}

#endif // WIN32

///////////////////////////////////////////////////////////////////////////////
// vtkPEntropyMatrixWeightingNTo1


vtkStandardNewMacro(vtkPEntropyMatrixWeightingNTo1);

vtkPEntropyMatrixWeightingNTo1::vtkPEntropyMatrixWeightingNTo1() :
  FeatureDimension(0),
  DataStructure(VECTOR),
  Controller(0)
{
  this->SetNumberOfInputPorts(1);

  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPEntropyMatrixWeightingNTo1::~vtkPEntropyMatrixWeightingNTo1()
{
  this->SetController(0);
}

void vtkPEntropyMatrixWeightingNTo1::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "FeatureDimension: " << this->FeatureDimension << endl;
}

int vtkPEntropyMatrixWeightingNTo1::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    vtkMPICommunicator* const mpi_communicator = vtkMPICommunicator::SafeDownCast(this->Controller->GetCommunicator());
    if(!mpi_communicator)
      throw std::runtime_error("Process controller must provide an MPI communicator.");

    // Test our preconditions ...
    vtkArrayData* const input_data = vtkArrayData::GetData(inputVector[0]);
    if(!input_data)
      throw std::runtime_error("Missing input vtkArrayData on port 0.");
    if(input_data->GetNumberOfArrays() != 1)
      throw std::runtime_error("Input vtkArrayData must contain exactly one array.");
    vtkTypedArray<double>* const input_array = vtkTypedArray<double>::SafeDownCast(input_data->GetArray(0));
    if(!input_array)
      throw std::runtime_error("Input array must be a vtkTypedArray<double>.");
    if(input_array->GetDimensions() != 2)
      throw std::runtime_error("Input array must be a matrix.");

    vtkIdType feature_dimension;
    vtkIdType object_dimension;
    switch(this->FeatureDimension)
      {
      case 0:
        feature_dimension = 0;
        object_dimension = 1;
        break;
      case 1:
        feature_dimension = 1;
        object_dimension = 0;
        break;
      default:
        throw std::runtime_error("FeatureDimension out-of-bounds.");
      }

    const vtkIdType feature_count = input_array->GetExtents()[feature_dimension].GetSize();
    //const vtkIdType global_doc_count = input_array->GetExtent(object_dimension).GetSize();

    // Setup our output ...
    vtkDenseArray<double>* const output_array = vtkDenseArray<double>::New();
    output_array->Resize(feature_count);
    output_array->Fill(0.0);
    output_array->SetName("entropy_weight");

    vtkArrayData* const output = vtkArrayData::GetData(outputVector);
    output->ClearArrays();
    output->AddArray(output_array);
    output_array->Delete();

    int numProcs = this->Controller->GetNumberOfProcesses();

    // Make it happen ...

    this->Controller->GetCommunicator()->Barrier();
    vtkArrayExtentsList extent_list = vtkDistributedArray::AllGatherExtents(this->Controller, input_array);
    vtkArrayExtents global_extents = vtkDistributedArray::GlobalExtents(extent_list);
    const vtkIdType global_doc_count = global_extents[object_dimension].GetSize();

    const double logN = log2(static_cast<double>(global_doc_count));

    if(this->DataStructure == VECTOR)
      {
      // Cache the frequency of each feature across the local documents ...
      this->Controller->GetCommunicator()->Barrier();
      std::vector<double> Fi(feature_count, 0);
      vtkArrayCoordinates coordinates;
      const vtkIdType non_null_count = input_array->GetNonNullSize();
      for(vtkIdType n = 0; n != non_null_count; ++n)
        {
        input_array->GetCoordinatesN(n, coordinates);
        const vtkIdType i = coordinates[feature_dimension];
        const double fij = input_array->GetValueN(n);
        Fi[i] += fij;
        }

      // Send local feature counts to the root node, summing, then broadcast ...
      this->Controller->GetCommunicator()->Barrier();
      std::vector<double> global_feature_counts(feature_count, 0);
      this->Controller->GetCommunicator()->Reduce(&Fi[0], &global_feature_counts[0], feature_count, vtkCommunicator::SUM_OP, 0);

      this->Controller->GetCommunicator()->Barrier();
      this->Controller->GetCommunicator()->Broadcast(&global_feature_counts[0], feature_count, 0);

      // Compute global feature weights using the local documents ...
      this->Controller->GetCommunicator()->Barrier();
      std::vector<double> local_feature_weights(feature_count, 0);
      for(vtkIdType n = 0; n != non_null_count; ++n)
        {
        input_array->GetCoordinatesN(n, coordinates);
        const vtkIdType i = coordinates[feature_dimension];
        const double fij = input_array->GetValueN(n);
        const double pij = fij / global_feature_counts[i];
        local_feature_weights[i] += (pij * log2(pij));
        }

      // Compute actual global feature weights by summing across processes
      this->Controller->GetCommunicator()->Barrier();
      std::vector<double> global_feature_weights(feature_count, 0);
      this->Controller->GetCommunicator()->Reduce(&local_feature_weights[0], &global_feature_weights[0], feature_count, vtkCommunicator::SUM_OP, 0);

      this->Controller->GetCommunicator()->Barrier();
      this->Controller->GetCommunicator()->Broadcast(&global_feature_weights[0], feature_count, 0);

      // Add 1 to each weight ...
      for(vtkIdType i = 0; i != feature_count; ++i)
        {
        output_array->SetValue(i, global_feature_weights[i]/logN + 1);
        }
      }
    else if(this->DataStructure == MAP)
      {
      vtkPEntropyMatrixWeightingCommunicator communicator(this->Controller->GetCommunicator());

      // Cache the frequency of each feature across the local documents ...
      vtkArrayCoordinates coordinates;
      const vtkIdType non_null_count = input_array->GetNonNullSize();
      std::map<int, double> feature_counts;
      for(vtkIdType n = 0; n != non_null_count; ++n)
        {
        input_array->GetCoordinatesN(n, coordinates);
        const vtkIdType i = coordinates[feature_dimension];
        const double fij = input_array->GetValueN(n);
        std::map<int, double>::iterator iter = feature_counts.find(i);
        if(iter == feature_counts.end())
          {
          feature_counts.insert(std::make_pair<int, double>(i, fij));
          }
        else
          {
          iter->second += fij;
          }
        }

      // Send local feature counts to the root node
      if(0 != this->Controller->GetLocalProcessId())
        {
        communicator.Send(feature_counts, 0);
        }
      else
        {
        for(int i = 1; i < this->Controller->GetNumberOfProcesses(); ++i)
          {
          communicator.Receive(i, feature_counts);
          }
        }

      // Broadcast global feature counts back to every node ...
      this->Controller->GetCommunicator()->Barrier();
      communicator.Broadcast(feature_counts, 0);

      // Compute global feature weights using the local documents ...
      this->Controller->GetCommunicator()->Barrier();
      std::map<int, double> feature_weights;
      for(vtkIdType n = 0; n != non_null_count; ++n)
        {
        input_array->GetCoordinatesN(n, coordinates);
        const vtkIdType i = coordinates[feature_dimension];
        const double fij = input_array->GetValueN(n);
        const double pij = fij / feature_counts[i];
        std::map<int, double>::iterator iter = feature_weights.find(i);
        if(iter == feature_weights.end())
          {
          feature_weights.insert(std::make_pair<int, double>(i, (pij * log2(pij))));
          }
        else
          {
          iter->second += (pij * log2(pij));
          }
        }

      // Send the local feature weights to the root node
      if(0 != this->Controller->GetLocalProcessId())
        {
        communicator.Send(feature_weights, 0);
        }
      else
        {
        for(int i = 1; i < this->Controller->GetNumberOfProcesses(); ++i)
          {
          communicator.Receive(i, feature_weights);
          }
        }

      // Broadcast global feature weights back to every node ...
      this->Controller->GetCommunicator()->Barrier();
      communicator.Broadcast(feature_weights, 0);

      // Add 1 to each weight ...
      std::map<int, double>::iterator iter;
      for(iter = feature_weights.begin(); iter != feature_weights.end(); ++iter)
        {
        output_array->SetValue(iter->first, iter->second/logN + 1);
        }
      }
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
    }
  catch(...)
    {
    vtkErrorMacro(<< "unknown exception");
    return 0;
    }

  return 1;
}
