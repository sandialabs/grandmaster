/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkPFrequencyMatrixFilter_h
#define __vtkPFrequencyMatrixFilter_h

#include "titanMPIDataAnalysis.h"

#include <vtkArrayDataAlgorithm.h>
#include <vtkMultiProcessController.h>

/// \class vtkPFrequencyMatrixFilter vtkPFrequencyMatrixFilter.h <DataAnalysis/vtkPFrequencyMatrixFilter.h>
/// \brief Given a frequency matrix and a feature dictionary, removes
///  features that do not appear "often enough" in a corpus.
///
///  Inputs:
///    Input port 0: (required) A vtkTable feature dictionary containing a "text" column.
///    Input port 1: (required) A vtkArrayData object containing a frequency matrix.
///
///  Outputs:
///    Output port 0: A modified feature dictionary that may contain fewer features.
///    Output port 0: A modified frequency matrix that may contain fewer rows.
///
///  Use SetInputArrayToProcess(0, 0, ...) to specify the input feature dictionary "text" array.
///
/// \sa
///  vtkFrequencyMatrix
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_DATA_ANALYSIS_EXPORT vtkPFrequencyMatrixFilter :
  public vtkArrayDataAlgorithm
{
public:
  static vtkPFrequencyMatrixFilter* New();
  vtkTypeMacro(vtkPFrequencyMatrixFilter, vtkArrayDataAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

  ///@{
  /// A feature must appear in this many documents or it
  /// will be removed from the output.  The default (0)
  /// allows all features.
  vtkSetMacro(MinimumDocumentCount, vtkIdType);
  vtkGetMacro(MinimumDocumentCount, vtkIdType);
  ///@}

  ///@{
  /// A feature must appear in this percentage of all
  /// documents or it will be removed from the output.
  /// The default (0.0) allows all features.
  vtkSetMacro(MinimumDocumentPercent, double);
  vtkGetMacro(MinimumDocumentPercent, double);
  ///@}

  ///@{
  /// A feature must appear this many times across the
  /// entire corpus or it will be removed from the output.
  /// The default (0) allows all features.
  vtkSetMacro(MinimumFeatureCount, vtkIdType);
  vtkGetMacro(MinimumFeatureCount, vtkIdType);
  ///@}

//BTX
protected:
  vtkPFrequencyMatrixFilter();
  ~vtkPFrequencyMatrixFilter();

  int FillInputPortInformation(int, vtkInformation*);
  int FillOutputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPFrequencyMatrixFilter(const vtkPFrequencyMatrixFilter&); // Not implemented
  void operator=(const vtkPFrequencyMatrixFilter&);   // Not implemented

  vtkMultiProcessController* Controller;

  vtkIdType MinimumDocumentCount;
  double MinimumDocumentPercent;
  vtkIdType MinimumFeatureCount;
//ETX
};

#endif
