/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanMutableClusterLinkage titanMutableClusterLinkage.h <Clustering/Linkages/titanMutableClusterLinkage.h>
/// \brief A Linkage that can be dynamically decided.
///
///  titanMutableClusterLinkage is a model of the Linkage concept that
///  can manifest as any included ClusterLinkage. This may be at the
///  expense of speed, but can provide runtime flexibility if necessary.
///  If the desired Linkage function is known ahead of time, it may be better
///  to code a specific instance which utilizes the desired Linkage.
///
#include <Clustering/Linkages/titanClusterLinkage.h>
#include <Clustering/Linkages/titanClusterLinkageComplete.h>
#include <Clustering/Linkages/titanClusterLinkageGroupAverage.h>
#include <Clustering/Linkages/titanClusterLinkageSingle.h>

#ifndef __titanMutableClusterLinkage_h
#define __titanMutableClusterLinkage_h


#include <cmath>
#include <vector>

#include <iostream>

using namespace std;

class titanMutableClusterLinkage
{

private:
  titanClusterLinkageComplete titanClusterLinkageCompleteInstance;
  titanClusterLinkageGroupAverage titanClusterLinkageGroupAverageInstance;
  titanClusterLinkageSingle titanClusterLinkageSingleInstance;

public:

  enum
  {
    Complete,
    GroupAverage,
    Single,
  } LinkageSelection;


  titanMutableClusterLinkage()
  {
   LinkageSelection=Complete;

   titanClusterLinkageCompleteInstance  = titanClusterLinkageComplete();
   titanClusterLinkageGroupAverageInstance  = titanClusterLinkageGroupAverage();
   titanClusterLinkageSingleInstance  = titanClusterLinkageSingle();
  }

  string GetLinkageName()
  {
    switch (LinkageSelection)
    {
    case Complete :
      return "Complete";
    case GroupAverage :
      return "GroupAverage";
    case Single :
      return "Single";
    default :
      return "Unknown";
    }
  }


  void SetLinkageComplete()
  {
    LinkageSelection=Complete;
  }

  void SetLinkageGroupAverage()
  {
    LinkageSelection=GroupAverage;
  }

  void SetLinkageSingle()
  {
    LinkageSelection=Single;
  }

  template<typename ProximityGeneratorT, typename ProximityMatrixT>
  void operator() (
      const ProximityGeneratorT proximity_generator,
      ProximityMatrixT& proximity_matrix,
      std::vector<size_t>& orphanClusterIds,
      size_t target_cluster_id,
      size_t first_cluster_id,
      size_t second_cluster_id,
      size_t& closest_orphan_id,
      double& closest_prox_value,
      std::vector<size_t>& leafMemberCount)
  {
    switch (LinkageSelection)
    {
    case Complete:
      return titanClusterLinkageCompleteInstance(proximity_generator,
          proximity_matrix, orphanClusterIds, target_cluster_id,
          first_cluster_id, second_cluster_id, closest_orphan_id,
          closest_prox_value, leafMemberCount);
    case GroupAverage:
      return titanClusterLinkageGroupAverageInstance(proximity_generator,
          proximity_matrix, orphanClusterIds, target_cluster_id,
          first_cluster_id, second_cluster_id, closest_orphan_id,
          closest_prox_value, leafMemberCount);
    case Single :
      return titanClusterLinkageSingleInstance(proximity_generator,
          proximity_matrix, orphanClusterIds, target_cluster_id,
          first_cluster_id, second_cluster_id, closest_orphan_id,
          closest_prox_value, leafMemberCount);
    default :
      return;
    }
  }

};

typedef titanMutableClusterLinkage  titanMutableClusterLinkageType;

#endif
