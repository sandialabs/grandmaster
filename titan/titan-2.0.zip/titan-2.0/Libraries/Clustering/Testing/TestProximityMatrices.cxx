/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

// Centroid Generators tested
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/titanHardClusterAssignment.h>

#include <Clustering/titanRelationProximityRanking.h>

// Supporting includes
#include <Clustering/titanHardClusterAssignment.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Clustering/ProximityGenerators/titanCosineSimilarity.h>
#include <Common/titanVectorOperations.h>

#include <Clustering/titanRelationProximities.h>

#include <iostream>
#include <iterator>
#include <stdexcept>

#include <boost/multi_array.hpp>

#include <Clustering/titanBoostMultiArrayAdaptor.h>

typedef boost::multi_array<size_t, 2> uint_matrix_type;
typedef titanBoostMultiArrayIterator<uint_matrix_type,size_t> uint_matrix_iterator;

using namespace std;


#define test_expression(expression) \
{ \
  if(!(expression)) \
    throw std::runtime_error("Expression failed: " #expression); \
}

int TestProximityMatrices(int argc, char *argv[])
{

  try
  {
    /* Data initialization */
    std::vector<std::vector<double> > observations, centroids;

    // Create observation vectors.
    observations.push_back(std::vector<double>(4, 1));  // observations[0]={1,1,1,1}
    observations.push_back(std::vector<double>(4, 2));  // observations[1]={2,2,2,2}
    observations.push_back(std::vector<double>(4, 5));  // observations[2]={5,5,5,5}
    observations.push_back(std::vector<double>(4, 6));  // observations[3]={6,6,6,6}
    observations.push_back(std::vector<double>(4, 11)); // observations[4]={11,11,11,11}
    observations.push_back(std::vector<double>(4, 12)); // observations[5]={12,12,12,12}

    // Create two centroids
    centroids.push_back(std::vector<double>(4, 2));     // centroids[0] = observations[1]
    centroids.push_back(std::vector<double>(4, 5));     // centroids[1] = observations[2]
    centroids.push_back(std::vector<double>(4, 11));    // centroids[2] = observations[4]

    // The proximity measure we will use is the Euclidean distance for simplicity.
    titanEuclideanDistance proximity_generator = titanEuclideanDistance();

    // Initializing cluster assignments to cluster 0
    boost::multi_array<size_t, 2> cluster_assignments_multiarray(boost::extents[observations.size()][1]);

    titanBoostMultiArrayAdaptor<boost::multi_array<size_t, 2>, size_t> cluster_assignments(&cluster_assignments_multiarray,0);

    // Setting two clusters to cluster 1
    cluster_assignments[0][0] = 0;
    cluster_assignments[1][0] = 0;
    cluster_assignments[2][0] = 1;
    cluster_assignments[3][0] = 1;
    cluster_assignments[4][0] = 2;
    cluster_assignments[5][0] = 2;

    // Finding the mean cluster centroids, given the current assignments
    cout << "==Testing mean centroids==" << endl;

    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    for (size_t centroid_index = 0; centroid_index < centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index] << endl;
    }
    cout << endl;

    // Reassign observations and get the new mean
    titanHardClusterAssignment()(observations.begin(), observations.end(), centroids, cluster_assignments, proximity_generator);
    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    test_expression(centroids[0][0] == 1.5);
    test_expression(centroids[1][0] == 5.5);
    test_expression(centroids[2][0] == 11.5);

    std::vector<std::vector<double> > proximity_matrix;

    titanRelationProximities  observationCentroidProximities(false);
    observationCentroidProximities(observations.begin(), observations.end(), centroids.begin(), centroids.end(), proximity_generator, proximity_matrix);



    titanRelationProximityRanking ranking;

    std::vector<std::vector<size_t> > rank_matrix;

    cout << "Creating ranking with max ranks == the number of clusters:" << endl;
    ranking.set_max_ranks(3);
    ranking(observations.begin(), observations.end(), centroids.begin(), centroids.end(), proximity_generator, proximity_matrix, rank_matrix);

    for (size_t i = 0; i < observations.size(); ++i)
    {
      for (size_t j = 0; j < ranking.get_max_ranks(); ++j)
      {
        cout << rank_matrix[i][j] << "\t";

      }
      cout << endl;
    }
    cout<< endl;

    cout << "Creating ranking with max ranks > the number of clusters:" << endl;
    ranking.set_max_ranks(100);
    ranking(observations.begin(), observations.end(), centroids.begin(), centroids.end(), proximity_generator, proximity_matrix, rank_matrix);

    for (size_t i = 0; i < observations.size(); ++i)
    {
      for (size_t j = 0; j < ranking.get_max_ranks(); ++j)
      {
        cout << rank_matrix[i][j] << "\t";

      }
      cout << endl;
    }
    cout<< endl;

    cout << "Creating ranking with max ranks < the number of clusters:" << endl;
    ranking.set_max_ranks(2);
    ranking(observations.begin(), observations.end(), centroids.begin(), centroids.end(), proximity_generator, proximity_matrix, rank_matrix);

    for (size_t i = 0; i < observations.size(); ++i)
    {
      for (size_t j = 0; j < ranking.get_max_ranks(); ++j)
      {
        cout << rank_matrix[i][j] << "\t";

      }
      cout << endl;
    }
    cout<< endl;

    return 0;
  }
  catch(std::exception& e)
  {
    cerr << e.what() << endl;
    return 1;
  }
}
