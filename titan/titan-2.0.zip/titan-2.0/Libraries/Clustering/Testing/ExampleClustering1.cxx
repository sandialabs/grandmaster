#include <Clustering/titanBasicClustering.h>
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Clustering/CentroidGenerators/titanRandomSampleCentroids.h>

#include <iostream>
#include <iterator>

int ExampleClustering1(int argc, char *argv[])
{
  // Compute clusters using caller-specified starting samples ...
  std::vector<double> observations;
  std::vector<double> centroids;
  std::vector<size_t> cluster_assignments;
  int max_iterations;

  max_iterations=100;

  observations.push_back(0);
  observations.push_back(7);
  observations.push_back(8);
  observations.push_back(2);
  observations.push_back(1);
  observations.push_back(10);


  // Generate random initial starting centroids ...
  titanRandomSampleCentroids(2)(observations.begin(), observations.end(), cluster_assignments, centroids, titanEuclideanDistance());

  // Assign observations to these centroids
  titanHardClusterAssignment(1)(observations.begin(), observations.end(), centroids, cluster_assignments, titanEuclideanDistance());

  // Iteratively compute new centroids, followed by assignment
  for(size_t iteration = 0; iteration != max_iterations; ++iteration)
  {
    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, titanEuclideanDistance());
    titanHardClusterAssignment(1)(observations.begin(), observations.end(), centroids, cluster_assignments, titanEuclideanDistance());
  }

  // Print the results ...
  std::cout << "observations: ";
  std::copy(observations.begin(), observations.end(), std::ostream_iterator<double>(std::cout, " "));
  std::cout << "\n";

  std::cout << "centroids: ";
  std::copy(centroids.begin(), centroids.end(), std::ostream_iterator<double>(std::cout, " "));
  std::cout << "\n";

  std::cout << "cluster assignments: ";
  std::copy(cluster_assignments.begin(),
      cluster_assignments.end(), std::ostream_iterator<size_t>(
          std::cout, " "));
  std::cout << "\n";


  return 0;
}
