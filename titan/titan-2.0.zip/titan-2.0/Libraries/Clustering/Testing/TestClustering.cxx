/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

// Centroid Generators tested
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/CentroidGenerators/titanExplicitSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanRandomSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanCentroidsAdd.h>
#include <Clustering/CentroidGenerators/titanMeanCentroidsObservationList.h>
#include <Clustering/CentroidGenerators/titanMeanCentroidsClusterList.h>

// Supporting includes
#include <Clustering/titanHardClusterAssignment.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Common/titanVectorOperations.h>

#include <Clustering/titanHardClusterAssignment.h>

#include <Clustering/titanDiffClusterAssignments.h>

#include <iostream>
#include <iterator>
#include <stdexcept>

#include <boost/multi_array.hpp>
#include <Clustering/titanBoostMultiArrayIterator.h>
#include <Clustering/titanBoostMultiArrayAdaptor.h>

#include <Clustering/titanRelationProximityRanking.h>
#include <Clustering/titanRelationProximities.h>

// Metrics
//TODO separate metric testing
#include <Clustering/titanInterClusterTotalSquaredProximity.h>
#include <Clustering/titanIntraClusterTotalSquaredProximity.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Clustering/titanIntraClusterAverageProximity.h>
#include <Clustering/titanIntraClusterFarthestOutlier.h>
#include <Clustering/titanIntraClusterObservationCentroidProximity.h>

typedef boost::multi_array<size_t, 2> uint_matrix_type;
typedef titanBoostMultiArrayIterator<uint_matrix_type,size_t> uint_matrix_iterator;

using namespace std;

int TestClustering(int argc, char *argv[])
{

  try
  {
    /* Data initialization */
    std::vector<std::vector<double> > observations, centroids;

    // Create observation vectors.
    observations.push_back(std::vector<double>(4, 1));  // observations[0]={1,1,1,1}
    observations.push_back(std::vector<double>(4, 2));  // observations[1]={2,2,2,2}
    observations.push_back(std::vector<double>(4, 5));  // observations[2]={5,5,5,5}
    observations.push_back(std::vector<double>(4, 6));  // observations[3]={6,6,6,6}
    observations.push_back(std::vector<double>(4, 11)); // observations[4]={11,11,11,11}
    observations.push_back(std::vector<double>(4, 12)); // observations[5]={12,12,12,12}

    // Create two centroids
    centroids.push_back(std::vector<double>(4, 2));     // centroids[0] = observations[1]
    centroids.push_back(std::vector<double>(4, 4));     // centroids[1] = observations[1]
    centroids.push_back(std::vector<double>(4, 11));    // centroids[2] = observations[4]


    // The proximity measure we will use is the euclidean distance for simplicity.
    titanEuclideanDistance proximity_generator = titanEuclideanDistance();


    // Initializing cluster assignments to cluster 0
    boost::multi_array<size_t, 2> old_cluster_assignments_multiarray(boost::extents[observations.size()][1]);
    boost::multi_array<size_t, 2> cluster_assignments_multiarray(boost::extents[observations.size()][1]);

    typedef titanBoostMultiArrayAdaptor<boost::multi_array<size_t,2>,size_t> assignments_type;

    titanBoostMultiArrayAdaptor<boost::multi_array<size_t,2>,size_t> old_cluster_assignments(&old_cluster_assignments_multiarray,0);
    titanBoostMultiArrayAdaptor<boost::multi_array<size_t,2>,size_t> cluster_assignments(&cluster_assignments_multiarray,0);

    // Setting two clusters to cluster 1
    cluster_assignments[0][0] = 0;
    cluster_assignments[1][0] = 1;
    cluster_assignments[2][0] = 2;
    cluster_assignments[3][0] = 1;
    cluster_assignments[4][0] = 2;
    cluster_assignments[5][0] = 0;

    titanHardClusterAssignment hardClusterAssignments(1);
    titanDiffClusterAssignments diffClusterAssignments;

    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);


    for (size_t i=0; i<10; ++i)
    {
      vector_assign<assignments_type,assignments_type>::copy_vector(cluster_assignments,old_cluster_assignments);

      hardClusterAssignments(observations.begin(), observations.end(), centroids, cluster_assignments, proximity_generator);

      diffClusterAssignments(old_cluster_assignments, cluster_assignments, centroids);

      titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

/*
      titanMeanCentroidsClusterList(
          diffClusterAssignments.getChangedClusters()
          )(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
*/

/*
      titanMeanCentroidsObservationList<assignments_type> (
          diffClusterAssignments.getChangedAssignments(),
          diffClusterAssignments.getChangedClusters(),
          diffClusterAssignments.getClusterSizeDifferences(),
          old_cluster_assignments
          )(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
*/
    }


    titanIntraClusterTotalSquaredProximity  intraClusterTotalSquaredProximity;
    titanInterClusterTotalSquaredProximity  interClusterTotalSquaredProximity;
    titanIntraClusterAverageProximity       intraClusterAverageProximity;
    titanIntraClusterAverageSquaredProximity  intraClusterAverageSquaredProximity;
    titanIntraClusterFarthestOutlier        intraClusterFarthestOutlier;
    titanIntraClusterObservationCentroidProximity intraClusterObservationCentroidProximity;

    std::vector<std::vector<double> > * proximity_matrix=NULL;

    intraClusterTotalSquaredProximity(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
    interClusterTotalSquaredProximity(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
    intraClusterAverageSquaredProximity(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
    intraClusterAverageProximity(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator, proximity_matrix);
    intraClusterFarthestOutlier(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
    intraClusterObservationCentroidProximity(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    cout << *(intraClusterTotalSquaredProximity.get_proximities()) << endl << endl;
    cout << *(interClusterTotalSquaredProximity.get_proximities()) << endl << endl;
    cout << *(intraClusterAverageProximity.get_proximities()) << endl << endl;
    cout << *(intraClusterAverageSquaredProximity.get_proximities()) << endl << endl;
    cout << *(intraClusterFarthestOutlier.get_proximities()) << endl << endl;
    cout << *(intraClusterObservationCentroidProximity.get_proximities()) << endl << endl;

    for (size_t i = 0; i < centroids.size(); ++i)
    {
      for (size_t j = 0; j < centroids[0].size(); ++j)
      {
        cout << centroids[i][j] << "\t";
      }
      cout << endl;
    }

    return 0;
  }
  catch(std::exception& e)
  {
    cerr << e.what() << endl;
    return 1;
  }

}
