/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <Clustering/ProximityGenerators/titanChebyshevDistance.h>
#include <Clustering/ProximityGenerators/titanCosineSimilarity.h>
#include <Clustering/ProximityGenerators/titanEmptyDistance.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Clustering/ProximityGenerators/titanKLDivergence.h>
#include <Clustering/ProximityGenerators/titanKLDivergenceJensenShannon.h>
#include <Clustering/ProximityGenerators/titanManhattanDistance.h>
#include <Clustering/ProximityGenerators/titanMinkowskiDistance.h>
#include <Clustering/ProximityGenerators/titanPearsonCorrelationCoefficient.h>
#include <Clustering/ProximityGenerators/titanJaccardSimilarity.h>
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <boost/concept/requires.hpp>

#include <iostream>

using namespace std;

int TestConceptProximityGenerators(int argc, char *argv[])
{
  try
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanChebyshevDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanChebyshevDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanCosineSimilarity>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanCosineSimilarity>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanEmptyDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanEmptyDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanEuclideanDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanEuclideanDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanJaccardSimilarity>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanJaccardSimilarity>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanKLDivergence>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanKLDivergence>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanKLDivergenceJensenShannon>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanKLDivergenceJensenShannon>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanManhattanDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanManhattanDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanMinkowskiDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanMinkowskiDistance>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanPearsonCorrelationCoefficient>));
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<titanPearsonCorrelationCoefficient>));

    return 0;
  }
  catch(std::exception& e)
  {
    std::cerr << e.what() << std::endl;
    return 1;
  }
}
