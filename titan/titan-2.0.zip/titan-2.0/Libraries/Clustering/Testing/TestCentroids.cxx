/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

// Centroid Generators tested
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/CentroidGenerators/titanMedoids.h>
#include <Clustering/CentroidGenerators/titanExplicitSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanRandomSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanCentroidsAdd.h>
#include <Clustering/CentroidGenerators/titanKKZCentroids.h>

// Supporting includes
#include <Clustering/titanHardClusterAssignment.h>
#include <Clustering/ProximityGenerators/titanEuclideanDistance.h>
#include <Common/titanVectorOperations.h>

#include <iostream>
#include <iterator>
#include <stdexcept>

#include <boost/multi_array.hpp>
#include <Clustering/titanBoostMultiArrayIterator.h>
#include <Clustering/titanBoostMultiArrayAdaptor.h>

#include <boost/date_time/posix_time/posix_time.hpp>


typedef boost::multi_array<size_t, 2> uint_matrix_type;
typedef titanBoostMultiArrayIterator<uint_matrix_type,size_t> uint_matrix_iterator;

using namespace std;

#define test_expression(expression) \
{ \
  if(!(expression)) \
    throw std::runtime_error("Expression failed: " #expression); \
}

int TestCentroids(int argc, char *argv[])
{

  try
  {
    /* Data initialization */
    std::vector<std::vector<double> > observations;

    // Create observation vectors.
    observations.push_back(std::vector<double>(4, 1));  // observations[0]={1,1,1,1}
    observations.push_back(std::vector<double>(4, 2));  // observations[1]={2,2,2,2}
    observations.push_back(std::vector<double>(4, 5));  // observations[2]={5,5,5,5}
    observations.push_back(std::vector<double>(4, 6));  // observations[3]={6,6,6,6}
    observations.push_back(std::vector<double>(4, 11)); // observations[4]={11,11,11,11}
    observations.push_back(std::vector<double>(4, 12)); // observations[5]={12,12,12,12}


    boost::multi_array<double, 2> centroid_array(boost::extents[2][4]);

    titanBoostMultiArrayAdaptor<boost::multi_array<double, 2>, double> centroids = titanBoostMultiArrayAdaptor<boost::multi_array<double, 2>, double>(&centroid_array, 0);

    for (int i = 0; i !=4; ++i)
    {
      centroids[0][i] = 2;
      centroids[1][i] = 11;
    }

    // The proximity measure we will use is the Euclidean distance for simplicity.
    titanEuclideanDistance proximity_generator = titanEuclideanDistance();

    // Initializing cluster assignments to cluster 0
    boost::multi_array<size_t, 2> cluster_assignments_multiarray(boost::extents[observations.size()][1]);

    titanBoostMultiArrayAdaptor< boost::multi_array<size_t, 2> , size_t> cluster_assignments(&cluster_assignments_multiarray,0);

    for (size_t row=0; row != cluster_assignments.size(); ++row)
    {
      for (size_t col=0; col != cluster_assignments[0].size(); ++col)  // explicitly two-dimensional, so no need for vector_traits
      {
        cluster_assignments[row][col]=0;
      }
    }

    // Setting two assignments to cluster 1
    cluster_assignments[4][0] = 1;
    cluster_assignments[5][0] = 1;

    // Finding the mean cluster centroids, given the current assignments
    cout << "==Testing mean centroids==" << endl;

    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    for (size_t centroid_index = 0; centroid_index != centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index][0] << endl;
    }
    cout << endl;

    test_expression(centroids[0][0] == 3.5);
    test_expression(centroids[1][0] == 11.5);

    // Use titanCentroidsAdd to add a centroid
    cout << "==Testing adding centroids==" << endl;

    titanCentroidsAdd()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    // Reassign observations and get the new mean
    titanHardClusterAssignment(1)(observations.begin(), observations.end(), centroids, cluster_assignments, proximity_generator);
    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    for (size_t centroid_index = 0; centroid_index != centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index][0] << endl;
    }
    cout << endl;

    test_expression(centroids[0][0] == 5.5);
    test_expression(centroids[1][0] == 11.5);
    test_expression(centroids[2][0] == 1.5);

    cout << "==Testing Random Sample Centroids==" << endl;

    unsigned int random_seed;
    boost::posix_time::ptime now =
        boost::posix_time::microsec_clock::local_time();
    random_seed = static_cast<unsigned int>(now.time_of_day().total_microseconds());

    titanRandomSampleCentroids initial_generator(3, random_seed);
    initial_generator(observations.begin(), observations.end(), cluster_assignments, centroids,
        proximity_generator);

    cout << "   First Random Sample Centroids" << endl;
    for (size_t centroid_index = 0; centroid_index != centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index][0] << endl;
    }
    cout << endl;

    initial_generator(observations.begin(), observations.end(), cluster_assignments, centroids,
        proximity_generator);

    cout << "  Second Random Sample Centroids" << endl;
    for (size_t centroid_index = 0; centroid_index < centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index][0] << endl;
    }
    cout << endl;


    // Reassign observations and get the new mean
    cout << "==Testing medoids==" << endl;

    titanMedoids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
    titanHardClusterAssignment()(observations.begin(), observations.end(), centroids, cluster_assignments, proximity_generator);

//    titanMeanCentroids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    for (size_t centroid_index = 0; centroid_index != centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index][0] << endl;
    }
    cout << endl;

    test_expression(centroids[0][0] == 5);
    test_expression(centroids[1][0] == 11);
    test_expression(centroids[2][0] == 1);



    // Reassign observations and get the new mean
    cout << "==Testing KKZ==" << endl;

    titanKKZCentroids(3)(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);
    titanHardClusterAssignment()(observations.begin(), observations.end(), centroids, cluster_assignments, proximity_generator);
    titanMedoids()(observations.begin(), observations.end(), cluster_assignments, centroids, proximity_generator);

    for (size_t centroid_index = 0; centroid_index != centroids.size(); centroid_index++)
    {
      cout << centroids[centroid_index][0] << endl;
    }
    cout << endl;


    return 0;
  }
  catch(std::exception& e)
  {
    cerr << e.what() << endl;
    return 1;
  }
}
