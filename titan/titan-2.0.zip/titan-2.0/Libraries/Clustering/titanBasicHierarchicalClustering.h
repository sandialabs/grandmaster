/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanBasicHierarchicalClustering titanBasicHierarchicalClustering.h <Clustering/titanBasicHierarchicalClustering.h>
/// \brief Basic implementation of Hierarchical Agglomerative clustering
///
///

#ifndef __titanBasicHierarchicalClustering_h
#define __titanBasicHierarchicalClustering_h

#include <algorithm>
#include <cmath>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <vector>

#include <Common/titanVectorOperations.h>

#include <Clustering/Linkages/titanClusterLinkage.h>
#include <Clustering/Linkages/titanClusterLinkageGroupAverage.h>
#include <Clustering/Linkages/titanClusterLinkageComplete.h>
#include <Clustering/Linkages/titanClusterLinkageSingle.h>
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <Clustering/titanHierarchicalAgglomerativeClustering.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>
#include <boost/tuple/tuple.hpp>

#include <boost/progress.hpp>

using namespace std;
/// Given a set of observations, compute a new set of clusters using K-means and caller-provided strategies for initial cluster generation and iteration.
class titanBasicHierarchicalClustering
{
protected:
  std::vector<std::vector<size_t> > ChildrenList;
  std::vector<size_t> LeafMemberCount;
  size_t NewClusterId;
  bool Verbose;

private:
  typedef std::vector<std::vector<double> >array_type;

  titanHierarchicalAgglomerativeClustering Agglomeration;

public:
  mutable array_type ProximityMatrix;

  template<class ClusterAssignmentT, class ProximityGeneratorT,
    typename ObservationIteratorT, typename ClusterAssignmentOutputT>
  void operator()(const ClusterAssignmentT& cluster_assignment,
    const ProximityGeneratorT& proximity_generator,
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    const size_t& minClusters,
    const bool& normalize,
    ClusterAssignmentOutputT& output_cluster_assignments)
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    size_t numObservations = observation_end - observation_begin;

    if (!numObservations) throw std::runtime_error(
      "Cannot cluster without observations.");


    if (this->Verbose) cout << "Initializing proximity matrix.." << flush;

    // If the Proximity Matrix is the wrong size (or empty) then build
    // a new one
    size_t current_size = ProximityMatrix.size();

    if (ProximityMatrix.size() != numObservations)
    {
      ProximityMatrix.resize(numObservations);
      for (size_t row_id = 0; row_id != numObservations; ++row_id)
      {
        ProximityMatrix[row_id].resize(numObservations,
            proximity_generator.farthest_value());
        if (row_id >= current_size)
        {
          std::fill(ProximityMatrix[row_id].begin(),ProximityMatrix[row_id].begin()+current_size,proximity_generator.farthest_value());
        }
      }

      // Set diagonal to closest value
      for (size_t row = 0; row != numObservations; ++row)
      {
        ProximityMatrix[row][row] = proximity_generator.closest_value();
      }
    }

    double prox;
    for (size_t row = 0; row != numObservations; ++row)
    {
      for (size_t col = row + 1; col != numObservations; ++col)
      {
        ObservationIteratorT sourceObservationIterator(observation_begin + row);
        ObservationIteratorT targetObservationIterator(observation_begin + col);
        prox = proximity_generator.proximity(*sourceObservationIterator,
          *targetObservationIterator);
        ProximityMatrix[row][col] = prox;
        ProximityMatrix[col][row] = prox;
      }
    }

    if (this->Verbose) cout << "..done." << endl << flush;

    /* Cluster */

    this->Agglomeration.set_verbose(this->get_verbose());
    //titanClusterLinkageSingle linkage;
    titanClusterLinkageGroupAverage linkage;
    //titanClusterLinkageComplete linkage;


    this->Agglomeration(linkage, proximity_generator, ProximityMatrix,
      minClusters, normalize, output_cluster_assignments);


    if (this->Verbose) cout << "..done." << endl << flush;
  }




  template<class ClusterAssignmentT, class ProximityGeneratorT,
    typename ObservationIteratorT, typename ClusterAssignmentOutputT>
  void operator()(const ClusterAssignmentT& cluster_assignment,
      array_type& proximity_matrix,
    const ProximityGeneratorT& proximity_generator,
    const size_t& minClusters,
    const bool& normalize,
    ClusterAssignmentOutputT& output_cluster_assignments)
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));
    size_t numObservations = proximity_matrix.size();

    this->Agglomeration.set_verbose(this->get_verbose());
    //titanClusterLinkageSingle linkage;
    titanClusterLinkageGroupAverage linkage;
    //titanClusterLinkageComplete linkage;


    this->Agglomeration(linkage, proximity_generator, proximity_matrix, numObservations,
      minClusters, normalize, output_cluster_assignments);

  }

  std::vector<double> * get_merge_proximities()
  {
    return this->Agglomeration.get_merge_proximities();

  }

  void set_verbose(bool verbose)
  {
    this->Verbose = verbose;
  }

  bool get_verbose()
  {
    return this->Verbose;
  }

  std::vector<size_t> * get_first_cluster_id_list()
  {
    return this->Agglomeration.get_first_cluster_id_list();
  }

  std::vector<size_t> * get_second_cluster_id_list()
  {
    return this->Agglomeration.get_second_cluster_id_list();
  }

};
#endif
