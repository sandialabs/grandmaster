/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanBoostMultiArrayIterator titanBoostMultiArrayIterator.h <Clustering/titanBoostMultiArrayIterator.h>
/// \brief titanBoostMultiArrayIterator


#ifndef __titanBoostMultiArrayIterator_h
#define __titanBoostMultiArrayIterator_h

#include <iterator>
#include <vector>

#include <iostream>

#include <Common/titanVectorOperations.h>

using namespace std;

/// Model of RandomAccessIterator that makes a matrix (2D vtkArray) look like a 1D collection of vectors, suitable for clustering.
template<typename ArrayT, typename ElementTypeT>
class titanBoostMultiArrayIterator
{

  class boostMultiArrayVector
  {
  public:
    typedef ElementTypeT value_type;
    value_type * Start;
    size_t Stride;
    size_t NumberOfElements;

    std::vector<size_t> ElementIndices;

    size_t size() const
    {
      return NumberOfElements;
    }

    void resize(const size_t& new_size)
    {
      return;
    }

    value_type operator[](const size_t& i) const
    {
      return Start[i*Stride];
    }

    value_type& operator[](const size_t& i)
    {
      return Start[i*Stride];
    }

    template<typename VectorT>
    boostMultiArrayVector& operator=(const VectorT& b)
    {
      for(size_t i = 0; i != this->size(); ++i)
      {
        (*this)[i] = b[i];
      }
      return *this;
    }

    boostMultiArrayVector& operator=(const boostMultiArrayVector& b)
    {
      for(size_t i = 0; i != this->size(); ++i)
      {
        (*this)[i] = b[i];
      }
      return *this;
    }
  };

public:
  typedef boostMultiArrayVector  value_type;

  typedef value_type* pointer;
  typedef value_type& reference;

  typedef std::random_access_iterator_tag iterator_category;

  typedef size_t difference_type;


  titanBoostMultiArrayIterator()
  {

  }

  /// Specifies the array for iteration, plus the current observation number.
  titanBoostMultiArrayIterator(ArrayT* array, const size_t& observation, const size_t observation_dimension, const bool normalize) :
    CurrentRow(observation),
    Array(array),
    ObservationDimension(observation_dimension),
    ElementDimension(1-observation_dimension),
    Normalize(normalize)
  {
    if (ObservationDimension==0)
    {
      this->ObservationStride = array->shape()[1];
      this->CurrentValue.Stride = 1;
    }
    else
    {
      this->ObservationStride = 1;
      this->CurrentValue.Stride = array->shape()[1];
    }

    this->CurrentValue.NumberOfElements = array->shape()[this->ElementDimension];
  }

  titanBoostMultiArrayIterator(ArrayT* array, const size_t observation_index, const size_t observation_dimension, const bool normalize, const std::vector<size_t>& column_list) :
    CurrentRow(observation_index),
    Array(array),
    ObservationDimension(observation_dimension),
    ElementDimension(1-observation_dimension),
    Normalize(normalize),
    ColumnList(column_list)
  {
    if (ObservationDimension==0)
    {
      this->ObservationStride = array->shape()[1];
      this->CurrentValue.Stride = 1;
    }
    else
    {
      this->ObservationStride = 1;
      this->CurrentValue.Stride = array->shape()[1];
    }

    this->CurrentValue.NumberOfElements = array->shape()[this->ElementDimension];
  }

  size_t operator-(const titanBoostMultiArrayIterator& other) const
  {
    return this->CurrentRow - other.CurrentRow;
  }

  bool operator!=(const titanBoostMultiArrayIterator& other) const
  {
    return this->CurrentRow != other.CurrentRow;
  }

  bool operator<(const titanBoostMultiArrayIterator& other) const
  {
    return this->CurrentRow < other.CurrentRow;
  }

  titanBoostMultiArrayIterator& operator++()
  {
    ++this->CurrentRow;
    return *this;
  }

  titanBoostMultiArrayIterator operator+(const size_t offset) const
  {
    return titanBoostMultiArrayIterator(this->Array, this->CurrentRow + offset, this->ObservationDimension, this->Normalize, this->ColumnList);
  }


  titanBoostMultiArrayIterator& operator=(const titanBoostMultiArrayIterator& rhs)
  {
    this->Array = rhs.Array;
    this->ColumnList = rhs.ColumnList;
    this->Normalize = rhs.Normalize;

    this->ObservationDimension = rhs.ObservationDimension;
    this->ElementDimension = rhs.ElementDimension;
    this->ObservationStride = rhs.ObservationStride;

    return *this;

  }

  value_type operator*() const
  {
    this->CurrentValue.Start = &((*this->Array)[0][0]) + (this->CurrentRow*this->ObservationStride);
    return this->CurrentValue;
  }

  value_type& operator*()
  {
    this->CurrentValue.Start = &((*this->Array)[0][0]) + (this->CurrentRow*this->ObservationStride);
    return this->CurrentValue;
  }

  mutable size_t CurrentRow;

private:
  ArrayT* Array;

  size_t ObservationDimension;
  size_t ElementDimension;
  size_t ObservationStride;

  bool  Normalize;
  mutable std::vector<size_t> ColumnList;

  mutable value_type CurrentValue;

};

#endif
