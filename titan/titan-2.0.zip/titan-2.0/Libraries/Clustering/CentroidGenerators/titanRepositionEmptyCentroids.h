/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanReassignEmptyCentroids titanReassignEmptyCentroids.h <Clustering/titanReassignEmptyCentroids.h>
/// \brief ...
///
///  titanRepositionEmptyCentroids is a model of the ClusterAdjustment concept that
///  detects "empty" centroids (centroids with no observations assigned),
///  reassigning the first to whichever cluster is currently weakest (has the
///  highest dispersion).  Note that the number of centroids never changes using
///  this method.
///

#ifndef __titanRepositionEmptyCentroids_h
#define __titanRepositionEmptyCentroids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Common/titanVectorTraits.h>

#include <algorithm>

#include <iostream>

#include <boost/multi_array.hpp>

using namespace std;

class titanRepositionEmptyCentroids
{
private:
  mutable std::vector<size_t> RepositionedCentroids;

public:
  titanRepositionEmptyCentroids()
  {
  }

  std::vector<size_t> * get_repositioned_centroids()
  {
    return &RepositionedCentroids;
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;
    typedef typename ClusterAssignmentContainerT::value_type assignment_type;

    this->RepositionedCentroids.clear();

    // Compute the number of observations assigned to each cluster ...
    std::vector<size_t> count(centroids.size(), 0);

    for(size_t i = 0; i != cluster_assignments.size(); ++i)
      ++count[vector_traits<assignment_type>::get(cluster_assignments[i],0)];

    // If there aren't any empty clusters, we're done ...
    if(0 == std::count(count.begin(), count.end(), 0))
      return false;

    // Compute intra-cluster distances ...
    std::vector<double> * proximities;

    titanIntraClusterAverageSquaredProximity proximityMetric;

    proximityMetric(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

    proximities=proximityMetric.get_proximities();


    // Find the first cluster that's empty ...
    size_t empty_cluster_index = std::distance(count.begin(), std::find(count.begin(), count.end(), 0));

    // Find the weakest (most dispersed) cluster ...
    double farthest_proximity = proximity_generator.closest_value();
    size_t weakest_cluster_index=0;


    for (size_t i=0; i < (*proximities).size();i++)
    {
      if (proximity_generator.closer(farthest_proximity,(*proximities)[i]))
      {
        farthest_proximity = (*proximities)[i];
        weakest_cluster_index=i;
      }
    }

    // Find the first observation in the weakest cluster ...
    //size_t first_observation_index = std::distance(cluster_assignments.begin(), std::find(cluster_assignments.begin(), cluster_assignments.end(), weakest_cluster_index));

    size_t first_observation_index=0;

    for (size_t current_obs=0; current_obs != cluster_assignments.size(); ++current_obs)
    {
      if (cluster_assignments[current_obs][0]==weakest_cluster_index)
      {
        first_observation_index = current_obs;
        break;
      }
    }

    RepositionedCentroids.push_back(empty_cluster_index);

    // Assign the first observation in the weakest cluster as the new centroid for the empty cluster ...
    vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + first_observation_index), centroids[empty_cluster_index] );

   return true;
  }
};

#endif
