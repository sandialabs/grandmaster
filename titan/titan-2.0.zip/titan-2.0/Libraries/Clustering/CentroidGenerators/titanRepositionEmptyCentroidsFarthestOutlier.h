/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanRepositionEmptyCentroidsFarthestOutlier titanRepositionEmptyCentroidsFarthestOutlier.h <Clustering/titanRepositionEmptyCentroidsFarthestOutlier.h>
/// \brief ...
///
///  titanRepositionEmptyCentroidsFarthestOutlier is a model of the
///  ClusterAdjustment concept that detects "empty" centroids (centroids with no
///  observations assigned), reassigning the first to whichever cluster is
///  currently weakest (has the highest dispersion).  Note that the number of
///  centroids never changes using this method.
///
///  This centroid generator assumes hard clustering.

#ifndef __titanRepositionEmptyCentroidsFarthestOutlier_h
#define __titanRepositionEmptyCentroidsFarthestOutlier_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterFarthestOutlier.h>
#include <algorithm>

#include <boost/multi_array.hpp>

class titanRepositionEmptyCentroidsFarthestOutlier
{
public:
  titanRepositionEmptyCentroidsFarthestOutlier()
  {
  }

public:
  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;

    // Compute the number of observations assigned to each cluster ...
    std::vector<size_t> count(centroids.size(), 0);
    for(size_t i = 0; i != cluster_assignments.size(); ++i)
      ++count[cluster_assignments[i][0]];

    // If there aren't any empty clusters, we're done ...
    if(0 == std::count(count.begin(), count.end(), 0))
      return false;


    titanIntraClusterFarthestOutlier farthest_outlier_calc;

    farthest_outlier_calc(
      observation_begin,
      observation_end,
      cluster_assignments,
      centroids,
      proximity_generator);

    // Compute intra-cluster distances ...
    std::vector<double> * proximities = farthest_outlier_calc.get_proximities();
    std::vector<size_t> * outlier = farthest_outlier_calc.get_outliers();

    // Find the first cluster that's empty ...
    size_t empty_cluster_index = std::distance(count.begin(), std::find(count.begin(), count.end(), 0));

    // Find the weakest (most dispersed) cluster ...
    double farthest_proximity = proximity_generator.closest_value();
    size_t outlier_index = 0;

    size_t weakest_cluster;
    for (size_t i=0; i < proximities->size();i++)
    {
      if (proximity_generator.closer(farthest_proximity,(*proximities)[i]))
      {
        farthest_proximity = (*proximities)[i];
        outlier_index=(*outlier)[i];
        weakest_cluster=i;
      }
    }

    // Assign the first observation in the weakest cluster as the new centroid for the empty cluster ...
    vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + outlier_index), *(centroids.begin() + empty_cluster_index));

    return true;
  }
};

#endif
