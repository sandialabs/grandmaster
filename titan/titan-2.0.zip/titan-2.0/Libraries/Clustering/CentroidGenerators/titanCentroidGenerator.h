/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __titanCentroidGenerator_h
#define __titanCentroidGenerator_h

#include <Clustering/ProximityGenerators/titanEmptyDistance.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>

#include <vector>

/// \class titanCentroidGenerator titanCentroidGenerator.h <Clustering/titanCentroidGenerator.h>
/// \brief ...
///
///  titanCentroidGenerator creates or removes centroids, updates existing
///  centroids, and modifies cluster assignments based on an existing set
///  of observations, centroids, and cluster assignments.
///
///  Notation:
///
///    G - A type that is a model of CentroidGenerator.
///    P - A type that is a model of ProximityGenerator.
///
///    g - Object of type G.
///    i, j - RandomAccessIterator instances that designate a range of observations.
///    a - RandomAccessContainer instance containing unsigned integers that represent a set of
///        cluster assignments.
///    c - RandomAccessContainer instance containing centroids.
///    p - Object of type P.
///
///  Valid Expressions:
///
///    g(i, j, a, c, p) - Given a range of observations, a set of existing cluster assignments,
///                       a set of existing centroids, and a proximity generator, computes a new
///                       set of centroids.  The number of input observations and the size of the
///                       cluster assignments container will always be equal, and the size of the
///                       centroids container will always be at least one larger than the largest
///                       cluster assignment value.  Implementations may alter the contents of
///                       the cluster assignment container, and the size and/or contents of the
///                       centroid container as desired, so long as the preceding preconditions
///                       are still met.  The reference type of the observation iterators must be
///                       implicitly convertable to the value type of the centroid container.

template<typename G>
struct titanCentroidGenerator
{
public:
  BOOST_CONCEPT_USAGE(titanCentroidGenerator)
  {
    g(observations.begin(), observations.end(), assignments, centroids, p);
  }

private:
  G g;
  std::vector<std::vector<double> > observations;
  std::vector<std::vector<double> > centroids;
  boost::multi_array<size_t, 2> assignments;

  titanEmptyDistance p;
};

#endif
