/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanMeanCentroidsObservationList titanMeanCentroidsObservationList <Clustering/titanMeanCentroidsObservationList>
/// \brief ...
///
///  titanMeanCentroidsObservationList is a model of the CentroidGenerator concept that
///  recomputes each centroid using the mean of the observations currently
///  assigned to the cluster.
///
///  This centroid generator assumes hard clustering.
///
///  titanMeanCentroidsObservationList does not calculate the centroid of a
///  cluster from scratch, but instead modifies the position of the centroid
///  by adjusting for observations that are being added or removed from the
///  cluster. This is the 'delta updates' strategy as defined in "Making
///  k-means even faster" by Greg Hamerly, in the Proceedings of SIAM SDM 2010.
///

#ifndef __titanMeanCentroidsObservationList_h
#define __titanMeanCentroidsObservationList_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <boost/unordered/unordered_set.hpp>
#include <boost/array.hpp>

using namespace std;

class titanMeanCentroidsObservationList
{
private:
  mutable std::vector<size_t> * ObservationIDList;  // List of observations for which to perform delta updates
  mutable boost::unordered_set<size_t> * ClusterIDList; // The cluster IDs to recalculate
  mutable std::vector<size_t> * OldClusterAssignments;  // Old clusters assignments
  mutable std::vector<std::vector<size_t> > ClusterMembers; // All members of all clusters
  mutable std::vector<size_t>* ClusterSizeDifferences; // The differences in size from the old clusters to the new
  mutable bool Initialized;

public:

  titanMeanCentroidsObservationList() : Initialized(false)
  {
  }

  template <typename ClusterAssignmentContainerT>
  void Initialize(std::vector<size_t> * observation_id_list,
      boost::unordered_set<size_t> * cluster_id_list,
      std::vector<size_t>* cluster_size_diff,
      ClusterAssignmentContainerT& old_cluster_assignments)
  {
    OldClusterAssignments = &old_cluster_assignments;
    ClusterIDList = cluster_id_list;
    ClusterSizeDifferences = cluster_size_diff;
    ObservationIDList = observation_id_list;

    this->Initialized=true;
  }


  template<
    typename ObservationIteratorT,
    typename ClusterAssignmentContainerT,
    typename CentroidContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    if (!this->Initialized)
      return false;

    if ((observation_end-observation_begin) < 0)
      return false;

    size_t num_observations = static_cast<size_t>(observation_end-observation_begin);

    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;
    typedef typename ClusterAssignmentContainerT::value_type assignment_type;

    size_t num_elements = vector_traits<observation_type>::size(*observation_begin);

    if (!centroids.size())
      return false;

    if (cluster_assignments.size() != num_observations)
      return false;

    if (vector_traits<centroid_type>::size(centroids[0]) != vector_traits<observation_type>::size(*observation_begin))
    {
      cerr << "Mismatched centroid/observation sizes." << endl;
      return false;
    }

    boost::unordered_set<size_t>::iterator cluster_id_iterator;

    std::vector<size_t>::iterator observation_list_iterator;

    size_t previous_cluster_id;
    size_t current_cluster_id;

    ClusterMembers.resize(centroids.size());

    for (size_t obs_index=0; obs_index != num_observations; ++obs_index)
    {
      ClusterMembers[vector_traits<typename ClusterAssignmentContainerT::value_type>::get(cluster_assignments[obs_index],0)].push_back(obs_index);
    }

    // Multiply the values of the centroid by the original number of
    // observations used to calculate the centroid
    for (cluster_id_iterator=ClusterIDList->begin(); cluster_id_iterator != ClusterIDList->end(); cluster_id_iterator++)
    {
      for (size_t element_index =0; element_index != vector_traits<centroid_type>::size(centroids[*cluster_id_iterator]); ++element_index)
      {
        vector_traits<centroid_type>::put(centroids[*cluster_id_iterator], element_index,
            vector_traits<centroid_type>::get(centroids[*cluster_id_iterator], element_index) *
            static_cast<double>(ClusterMembers[*cluster_id_iterator].size() - (*ClusterSizeDifferences)[*cluster_id_iterator]));
      }
    }

    // Add the new members, and subtract the old members
    for (observation_list_iterator=ObservationIDList->begin(); observation_list_iterator != ObservationIDList->end(); observation_list_iterator++)
    {
      previous_cluster_id = vector_traits<size_t>::get((*this->OldClusterAssignments)[*observation_list_iterator],0);
      current_cluster_id = vector_traits<assignment_type>::get(cluster_assignments[*observation_list_iterator],0);

      for (size_t i=0; i!= num_elements; ++i)
      {
        vector_traits<centroid_type>::put(
            centroids[previous_cluster_id], i,
            vector_traits<observation_type>::get(*(observation_begin+*observation_list_iterator),i) - vector_traits<centroid_type>::get(centroids[previous_cluster_id],i) );
        vector_traits<centroid_type>::put(
            centroids[current_cluster_id], i,
            vector_traits<observation_type>::get(*(observation_begin+*observation_list_iterator),i) + vector_traits<centroid_type>::get(centroids[current_cluster_id],i) );
      }
    }

    // Divide the values of the centroid by the new number of observations
    // in the centroid
    for (cluster_id_iterator=ClusterIDList->begin(); cluster_id_iterator != ClusterIDList->end(); cluster_id_iterator++)
    {
      for (size_t element_index =0; element_index != vector_traits<centroid_type>::size(centroids[*cluster_id_iterator]); ++element_index)
      {
        vector_traits<centroid_type>::put(centroids[*cluster_id_iterator], element_index,
            vector_traits<centroid_type>::get(centroids[*cluster_id_iterator], element_index) / static_cast<double>(ClusterMembers[*cluster_id_iterator].size()) );
      }
    }

    this->Initialized=false;

    return true;
  }
};

#endif
