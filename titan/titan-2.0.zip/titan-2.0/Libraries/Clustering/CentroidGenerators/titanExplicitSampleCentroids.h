/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanExplicitSampleCentroids titanExplicitSampleCentroids.h <Clustering/titanExplicitSampleCentroids.h>
/// \brief ...
///
///  titanExplicitSampleCentroids is a model of the ClusterAdjustment concept
///  that creates centroids based on a list of observation samples specified by
///  the caller.  One centroid will be created for each sample in the list,
///  drawn from the set of observations by index.
///  Note: out-of-range indices will "wrap around".  Throws std::runtime_error
///  if called without any observations.  The number of centroids created never
///  changes using this method.
///

#ifndef __titanExplicitSampleCentroids_h
#define __titanExplicitSampleCentroids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Common/titanVectorTraits.h>

#include <stdexcept>

#include <iostream>

#include <Common/titanVectorOperations.h>

using namespace std;

class titanExplicitSampleCentroids
{
private:

public:

  titanExplicitSampleCentroids()
  {

  }


  /// Initializes the object with a set of sample indices.
  template<typename IndexIteratorT>
  void Initialize(const IndexIteratorT begin, const IndexIteratorT end)
  {
    for (IndexIteratorT iterator=begin; iterator!= end; ++iterator)
    {
      Indices.push_back(*iterator);
    }


  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename ObservationIteratorT::value_type observation_type;
    typedef typename CentroidContainerT::value_type centroid_type;

    const size_t observation_count = observation_end - observation_begin;
    if(Indices.size() && !observation_count)
      throw std::runtime_error("Cannot generate centroid samples without observations.");

    centroids.resize(Indices.size());

    for(size_t centroid_index = 0; centroid_index != centroids.size(); ++centroid_index)
    {
      vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + (Indices[centroid_index] % observation_count)), centroids[centroid_index]);
    }


    return true;
  }

private:
  std::vector<size_t> Indices;
};


#endif
