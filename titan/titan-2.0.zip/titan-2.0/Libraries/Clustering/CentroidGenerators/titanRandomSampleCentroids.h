/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanRandomSampleCentroids titanRandomSampleCentroids.h <Clustering/titanRandomSampleCentroids.h>
/// \brief Generate centroids from randomly selected observations
///
///  titanRandomSampleCentroids is a model of the ClusterAdjustment concept that
///  selects a random set of centroids out of a set of observations.  Note that
///  the number of centroids created never changes using this method, and is
///  specified in the constructor.
///

#ifndef __titanRandomSampleCentroids_h
#define __titanRandomSampleCentroids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <boost/random.hpp>
#include <boost/unordered/unordered_set.hpp>
#include <iostream>

#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <iostream>

using namespace std;

class titanRandomSampleCentroids
{
public:
  titanRandomSampleCentroids() :
    CentroidCount(2)
  {
    RandomGenerator.seed();
  }
  /// Initialize the number of random centroids to generate.
  titanRandomSampleCentroids(const size_t centroid_count) :
    CentroidCount(centroid_count)
  {
    RandomGenerator.seed();
  }

  titanRandomSampleCentroids(const size_t centroid_count, unsigned int seed) :
    CentroidCount(centroid_count)
  {
    RandomGenerator.seed(seed);
  }

  void SetNumberOfCentroids(const size_t centroid_count)
  {
    this->CentroidCount = centroid_count;
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentMatrixT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentMatrixT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;

    const size_t observation_count = observation_end - observation_begin;
    if(this->CentroidCount && !observation_count)
      throw std::runtime_error("Cannot generate random centroid samples without observations.");

    boost::uniform_int<> random_map(0, static_cast<unsigned int>(observation_count-1) );

    boost::variate_generator<boost::mt19937&, boost::uniform_int<> > random_observation_index(RandomGenerator, random_map);

    centroids.resize(CentroidCount);

    size_t random_index;
    boost::unordered_set<size_t> observation_id_list;

    for(size_t centroid_index = 0; centroid_index != centroids.size(); ++centroid_index)
    {
      random_index= random_observation_index();

      if (observation_id_list.find(random_index) != observation_id_list.end())
      {
        centroid_index--;
        continue;
      }

      observation_id_list.insert(random_index);

      vector_assign<observation_type, centroid_type>::copy_vector(*(observation_begin + random_index), centroids[centroid_index]);
    }


    return true;
  }

  void ResetRandomGeneratorSeed(const unsigned int seed)
  {
    RandomGenerator.seed(seed);
  }

private:
  size_t CentroidCount;
  mutable boost::mt19937 RandomGenerator;
};

#endif
