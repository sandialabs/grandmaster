/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanMeanCentroids titanMeanCentroids <Clustering/titanMeanCentroids.h>
/// \brief Calculate the cluster centroids by taking the mean of observations
///
///  titanMeanCentroids is a model of the CentroidGenerator concept that
///  recomputes each centroid using the mean of the observations currently
///  assigned to the cluster.
///
///  This centroid generator assumes hard clustering.

#ifndef __titanMeanCentroids_h
#define __titanMeanCentroids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <iostream>

using namespace std;

class titanMeanCentroids
{
public:
  titanMeanCentroids()
  {
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    typedef typename ObservationIteratorT::value_type observation_type;
    typedef typename ClusterAssignmentContainerT::value_type assignment_type;

    size_t num_elements = vector_traits<observation_type>::size(*observation_begin);

    if (!centroids.size())
      return false;

    if ((observation_end - observation_begin) < 0) return false;

    if (cluster_assignments.size() != static_cast<size_t>(observation_end - observation_begin))
      return false;

    if (vector_traits<centroid_type>::size(centroids[0]) != vector_traits<observation_type>::size(*observation_begin))
    {
      cerr << "Mismatched centroid/observation sizes." << endl;
      return false;
    }

    // Clear centroids and counts
    std::vector<size_t> counts(centroids.size(), 0);

    for(size_t i = 0; i != centroids.size(); ++i)
      for (size_t element_index =0; element_index != num_elements; ++element_index)
      {
        vector_traits<centroid_type>::put(centroids[i], element_index, 0);
      }

    // Sum all the observations of a cluster in the cluster centroid vector
    size_t observation_index = 0;
    for(ObservationIteratorT observation = observation_begin; observation != observation_end; ++observation, ++observation_index)
    {
      size_t cluster_id = vector_traits<assignment_type>::get(cluster_assignments[observation_index],0);

      for (size_t i=0; i!= num_elements; ++i)
      {
        vector_traits<centroid_type>::put(
            centroids[cluster_id], i,
            vector_traits<observation_type>::get(*observation,i) + vector_traits<centroid_type>::get(centroids[cluster_id],i) );
      }
      counts[cluster_id] += 1;
    }

    // Take the average of all the centroid sums
    for(size_t centroid_index = 0; centroid_index != centroids.size(); ++centroid_index)
    {
      if(counts[centroid_index])
      {
        for (size_t element_index =0; element_index != num_elements; ++element_index)
        {
          vector_traits<centroid_type>::put(centroids[centroid_index], element_index,
              vector_traits<centroid_type>::get(centroids[centroid_index], element_index) / static_cast<double>(counts[centroid_index]));
        }
      }
    }

    return true;
  }
};

#endif
