/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanMutableCentroidGenerator titanMutableCentroidGenerator.h <Clustering/CentroidGenerators/titanMutableCentroidGenerator.h>
/// \brief A proximity that can be dynamically decided.
///
///  titanMutableCentroidGenerator is a model of the CentroidGenerator concept that
///  can manifest as any included centroid generator.
///
#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/CentroidGenerators/titanCentroidsAdd.h>
#include <Clustering/CentroidGenerators/titanExplicitCentroids.h>
#include <Clustering/CentroidGenerators/titanExplicitSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanKKZCentroids.h>
#include <Clustering/CentroidGenerators/titanMeanCentroids.h>
#include <Clustering/CentroidGenerators/titanMeanCentroidsClusterList.h>
#include <Clustering/CentroidGenerators/titanMeanCentroidsObservationList.h>
#include <Clustering/CentroidGenerators/titanMedoids.h>
#include <Clustering/CentroidGenerators/titanRandomSampleCentroids.h>
#include <Clustering/CentroidGenerators/titanRepositionEmptyCentroids.h>
#include <Clustering/CentroidGenerators/titanRepositionEmptyCentroidsFarthestOutlier.h>

#ifndef __titanMutableCentroidGenerator_h
#define __titanMutableCentroidGenerator_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <cmath>
#include <vector>

#include <iostream>

using namespace std;

class titanMutableCentroidGenerator
{

private:

  string  CentroidGeneratorName;

  titanCentroidsAdd titanCentroidsAddInstance;
  titanExplicitCentroids titanExplicitCentroidsInstance;
  titanExplicitSampleCentroids titanExplicitSampleCentroidsInstance;
  titanKKZCentroids titanKKZCentroidsInstance;
  titanMeanCentroids titanMeanCentroidsInstance;
  titanMeanCentroidsClusterList titanMeanCentroidsClusterListInstance;
  titanMeanCentroidsObservationList titanMeanCentroidsObservationListInstance;
  titanMedoids titanMedoidsInstance;
  titanRandomSampleCentroids titanRandomSampleCentroidsInstance;
  titanRepositionEmptyCentroids titanRepositionEmptyCentroidsInstance;
  titanRepositionEmptyCentroidsFarthestOutlier titanRepositionEmptyCentroidsFarthestOutlierInstance;

public:

  enum
  {
    Add,
    Explicit,
    ExplicitSample,
    KKZ,
    Mean,
    MeanClusterList,
    MeanObservationList,
    Medoid,
    RandomSample,
    RepositionEmpty,
    RepositionEmptyFarthestOutlier
  } GeneratorSelection;


  titanMutableCentroidGenerator()
  {
   this->GeneratorSelection=this->Mean;
  }


  string GetCentroidGeneratorName() const
  {
    switch (this->GeneratorSelection)
    {
    case Add :
      return "Add";
    case Explicit :
      return "Explicit";
    case ExplicitSample :
      return "ExplicitSample";
    case KKZ :
      return "KKZ";
    case Mean :
      return "Mean";
    case MeanClusterList :
      return "MeanClusterList";
    case MeanObservationList :
      return "MeanObservationList";
    case Medoid :
      return "Medoid";
    case RandomSample :
      return "RandomSample";
    case RepositionEmpty :
      return "RepositionEmpty";
    case RepositionEmptyFarthestOutlier :
      return "RepositionEmptyFarthestOutlier";
    default :
      return "Unknown";
    }
  }


  void SetGenerator_Add()
  {
    GeneratorSelection=Add;
    CentroidGeneratorName = "Add";
  }

  template<typename InitialCentroidContainerT>
  void SetGenerator_Explicit(InitialCentroidContainerT& centroids)
  {
    GeneratorSelection=Explicit;
    titanExplicitCentroidsInstance.Initialize(centroids);
    CentroidGeneratorName = "Explicit";
  }

  template<typename IndexIteratorT>
  void SetGenerator_ExplicitSample(const IndexIteratorT begin, const IndexIteratorT end)
  {
    GeneratorSelection=ExplicitSample;
    CentroidGeneratorName = "ExplicitSample";
  }

  void SetGenerator_KKZ(const size_t num_centroids)
  {
    GeneratorSelection=KKZ;
    titanKKZCentroidsInstance.SetNumberOfCentroids(num_centroids);

    CentroidGeneratorName = "KKZ";
  }

  void SetGenerator_Mean()
  {
    GeneratorSelection=Mean;
    CentroidGeneratorName = "Mean";
  }

  void SetGenerator_MeanClusterList(boost::unordered_set<size_t>* cluster_id_list)
  {
    GeneratorSelection=MeanClusterList;
    titanMeanCentroidsClusterListInstance.SetClusterIdList(cluster_id_list);
    CentroidGeneratorName = "MeanClusterList";
  }

  template<typename ClusterAssignmentContainerT>
  void SetGenerator_MeanObservationList(std::vector<size_t> * observation_id_list,
      boost::unordered_set<size_t> * cluster_id_list,
      std::vector<size_t>* cluster_size_diff,
      ClusterAssignmentContainerT& old_cluster_assignments)
  {
    GeneratorSelection=MeanObservationList;
    titanMeanCentroidsObservationListInstance.Initialize(observation_id_list, cluster_id_list, cluster_size_diff, old_cluster_assignments);
    CentroidGeneratorName = "MeanObservationList";
  }

  void SetGenerator_Medoid()
  {
    GeneratorSelection=Medoid;
    CentroidGeneratorName = "Medoid";
  }

  void SetGenerator_RandomSample(const size_t num_centroids)
  {
    GeneratorSelection=RandomSample;
    titanRandomSampleCentroidsInstance.SetNumberOfCentroids(num_centroids);

    CentroidGeneratorName = "RandomSample";
  }

  void SetGenerator_RepositionEmpty()
  {
    GeneratorSelection=RepositionEmpty;
    CentroidGeneratorName = "RepositionEmpty";
  }

  void SetGenerator_RepositionEmptyFarthestOutlier()
  {
    GeneratorSelection=RepositionEmptyFarthestOutlier;
    CentroidGeneratorName = "RepositionEmptyFarthestOutlier";
  }


  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    switch (GeneratorSelection)
    {
    case Add :
      return titanCentroidsAddInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case Explicit :
      return titanExplicitCentroidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case ExplicitSample :
      return titanExplicitSampleCentroidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case KKZ :
      return titanKKZCentroidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case Mean :
      return titanMeanCentroidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case MeanClusterList :
      return titanMeanCentroidsClusterListInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case MeanObservationList :
      return titanMeanCentroidsObservationListInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case Medoid :
      return titanMedoidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case RandomSample :
      return titanRandomSampleCentroidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case RepositionEmpty :
      return titanRepositionEmptyCentroidsInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    case RepositionEmptyFarthestOutlier :
      return titanRepositionEmptyCentroidsFarthestOutlierInstance(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);
    default :
      return false;
    }
  }

};
typedef titanMutableCentroidGenerator  titanMutableCentroidGeneratorType;

#endif
