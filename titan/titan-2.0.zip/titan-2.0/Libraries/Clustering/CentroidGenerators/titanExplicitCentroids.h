/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanIntraClusterFarthestOutlier titanIntraClusterFarthestOutlier.h <Clustering/titanIntraClusterFarthestOutlier.h>
/// \brief ...
///
///  titanExplicitCentroids is a model of the ClusterAdjustment concept that
///  creates centroids based on a list of centroid centers provided by the
///  caller.  One centroid will be created for each item in the list, using
///  the list item as its value.  Note that the number of centroids created
///  never changes using this method.
///

#ifndef __titanExplicitCentroids_h
#define __titanExplicitCentroids_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

class titanExplicitCentroids
{
public:
  titanExplicitCentroids() : Initialized(false)
  {
  }


  /// Initializes the generator with a list of caller-supplied centroids.
  template<typename InitialCentroidContainerT>
  void Initialize(const InitialCentroidContainerT& centroids)
  {
    typedef typename InitialCentroidContainerT::value_type initial_centroid_type;

    this->Centroids.resize(centroids.size());

    for (size_t centroid_index=0; centroid_index != centroids.size(); ++centroid_index)
      vector_assign<initial_centroid_type,std::vector<double> >::copy_vector(centroids[centroid_index],this->Centroids[centroid_index]);
    this->Initialized=true;
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    typedef typename CentroidContainerT::value_type centroid_type;
    size_t num_centroids = vector_traits<std::vector<std::vector<double> > >::size(this->Centroids);

    centroids.resize(num_centroids);

    for (size_t centroid_index=0; centroid_index != num_centroids; ++centroid_index)
      vector_assign<std::vector<double>, centroid_type >::copy_vector(this->Centroids[centroid_index], centroids[centroid_index]);

    return true;
  }

private:
  mutable std::vector<std::vector<double> > Centroids;
  mutable bool Initialized;
};

#endif
