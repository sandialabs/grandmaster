/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanLinkClusterAdjustmentIfFalseImplementation titanLinkClusterAdjustmentIfFalseImplementation.h <Clustering/titanLinkClusterAdjustmentIfFalseImplementation.h>
/// \brief ...
///
///  titanLinkClusterAdjustmentIfFalseImplementation is a model of the ClusterAdjustment
///  concept that simply combines two other generators, calling them in-order.
///  This model performs the second ClusterAdjustment if and only if the first
///  ClusterAdjustment returns false. Otherwise, it returns false.
///
///  See \class titanLinkClusterAdjustment for more information.

#ifndef __titanLinkClusterAdjustmentIfFalse_h
#define __titanLinkClusterAdjustmentIfFalse_h

template<
  typename FirstT,
  typename SecondT>
class titanLinkClusterAdjustmentIfFalseImplementation
{
public:
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<FirstT>));
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<SecondT>));

  titanLinkClusterAdjustmentIfFalseImplementation(const FirstT& first, const SecondT& second) :
    First(first),
    Second(second)
  {
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    ClusterAssignmentContainerT& cluster_assignments,
    CentroidContainerT& centroids,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    bool continueClusteringFirst, continueClusteringSecond;

    continueClusteringFirst=
      First(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

    if (continueClusteringFirst)
      return false;

    continueClusteringSecond=
      Second(observation_begin, observation_end, cluster_assignments, centroids, proximity_generator);

    return (continueClusteringSecond);
  }

private:
  const FirstT& First;
  const SecondT& Second;
};

/// Convenience function for creating titanLinkClusterAdjustmentImplementation instances.
template<typename FirstT, typename SecondT>
titanLinkClusterAdjustmentIfFalseImplementation<FirstT, SecondT> titanLinkClusterAdjustmentIfFalse(const FirstT& first, const SecondT& second)
{
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<FirstT>));
//  BOOST_CONCEPT_ASSERT((titanClusterAdjustment<SecondT>));

  return titanLinkClusterAdjustmentIfFalseImplementation<FirstT, SecondT>(first, second);
}

#endif
