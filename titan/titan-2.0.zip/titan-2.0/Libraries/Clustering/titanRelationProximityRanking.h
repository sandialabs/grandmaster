/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanRelationProximityRanking titanRelationProximityRanking.h <Clustering/titanRelationProximityRanking.h>
/// \brief Assign observations to clusters.
///
///  titanRelationProximityRanking assigns, for each observation, a rank to
///  each cluster. It then orders the centroid ids for each observation based
///  on rank, with position 0 being the closest.
///
///  The results is a matrix, with the rows index as observation ids, and the entries
///  of the columns being the cluster ids, ordered from closest to furthest.
///
///  It must be used with a pre-computed proximity matrix. A possible source
///  this is titanRelationProximities, which computes such a proximity matrix.


#ifndef __titanRelationProximityRanking_h
#define __titanRelationProximityRanking_h

#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <algorithm>

#include <boost/multi_array.hpp>

#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>

#include <Common/titanVectorTraits.h>

using namespace boost::lambda;

class titanRelationProximityRanking
{

public:
  titanRelationProximityRanking() : MaxRanks(1)
  {
  }

  titanRelationProximityRanking(size_t max_ranks) : MaxRanks(max_ranks)
  {
  }

  template<
    typename Items1IteratorT,
    typename Items2IteratorT,
    typename ProximityGeneratorT,
    typename ProximityMatrixT,
    typename RankMatrixT>
    bool operator()(
    const Items1IteratorT items1_begin,
    const Items1IteratorT items1_end,
    const Items2IteratorT items2_begin,
    const Items2IteratorT items2_end,
    const ProximityGeneratorT& proximity_generator,
    const ProximityMatrixT& proximity_matrix,
    RankMatrixT& rank_matrix) const
  {
    typedef typename RankMatrixT::value_type rank_row_type;

    size_t numItems1 = items1_end - items1_begin;
    size_t numItems2 = items2_end - items2_begin;

    if (numItems2 < MaxRanks)
    {
      MaxRanks=numItems2;
    }

    // Adjust the size of the rank matrix
    if (rank_matrix.size() != numItems1)
      rank_matrix.resize(numItems1);

    for (size_t row=0; row != numItems1; ++row )
    {
      if (vector_traits<rank_row_type>::size(rank_matrix[row]) != MaxRanks)
        vector_traits<rank_row_type>::resize(rank_matrix[row], MaxRanks);

      for (size_t col=0; col != vector_traits<rank_row_type>::size(rank_matrix[row]); ++col )
      {
        vector_traits<rank_row_type>::put(rank_matrix[row], col, 0);
      }

    }


    size_t items1_index = 0;

    for (Items1IteratorT item1 = items1_begin; item1 != items1_end; ++item1, ++items1_index)
    {
      std::vector<size_t> rank;
      std::vector<double> observationVector;

      observationVector.clear();
      for (size_t i = 0; i != numItems2; ++i)
      {
        rank.push_back(i);
        observationVector.push_back(proximity_matrix[items1_index][i]);
      }

      // TODO fix lambda expression so that the sort can utilize the closer() method
      if (proximity_generator.closer(0, 1))
        std::sort(rank.begin(), rank.end(), var(observationVector)[_1]
            < var(observationVector)[_2]);
      else
        std::sort(rank.begin(), rank.end(), var(observationVector)[_1]
            > var(observationVector)[_2]);

      //      std::sort(rank.begin(), rank.end(), var(proximity_generator.closer(observationVector[_1], observationVector[_2] ) ) );

      // TODO either assign/copy into the multi-array, or figure out how to sort within the multi-array
      for (size_t i=0; i != MaxRanks; ++i)
      {
        vector_traits<rank_row_type>::put(rank_matrix[items1_index], i, rank[i]);
      }
      //     std::copy(rank.begin(), rank.end(), RelationMatrix[items1_index]);


    }

    return true;
  }

  ///@{
  /// Returns a reference to the centroid matrix
  void set_max_ranks(size_t maxRanks)
  {
    MaxRanks=maxRanks;
  }
  ///@}

  ///@{
  /// Returns a reference to the centroid matrix
  size_t get_max_ranks()
  {
    return MaxRanks;
  }
  ///@}



private:
  mutable size_t MaxRanks;

};

#endif
