/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanHardClusterAssignment titanHardClusterAssignment.h <Clustering/titanHardClusterAssignment.h>
/// \brief Assign observations to clusters.
///
///  titanHardClusterAssignment is a model of the ClusterAdjustment concept
///  that assigns each observation to its nearest cluster, using the caller-
///  supplied ProximityGenerator. It can be used with a pre-computed proximity
///  matrix, or it can calculate the proximities itself. This class will
///  not attempt to create nor modify a proximity matrix.
///
///  The cluster assignments are stored in the cluster_assignments parameter.
///  The cluster counts are computed during the assignment and stored in the
///  ObservationCounts attribute.
///
///  If StoreClusterMembers==true, then upon assigning an observation to a
///  cluster, a separate list of assignments indexed by cluster is updated,
///  with the observation id being added to the list of observations for the
///  specified cluster.
///

#ifndef __titanHardClusterAssignment_h
#define __titanHardClusterAssignment_h

#include <Clustering/CentroidGenerators/titanCentroidGenerator.h>
#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <Clustering/titanRelationProximities.h>
#include <Clustering/titanRelationProximityRanking.h>

#include <boost/concept_check.hpp>
#include <boost/multi_array.hpp>

#include <algorithm>
#include <iostream>

#include <Common/titanVectorTraits.h>


using namespace std;

class titanHardClusterAssignment
{

public:
  titanHardClusterAssignment() : MaxRanks(1)
  {
  }

  titanHardClusterAssignment(size_t max_ranks) : MaxRanks(max_ranks)
  {
  }

  template<
    typename ObservationIteratorT,
    typename CentroidContainerT,
    typename ClusterAssignmentContainerT,
    typename ProximityGeneratorT>
    bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    CentroidContainerT& centroids,
    ClusterAssignmentContainerT& cluster_assignments,
    const ProximityGeneratorT& proximity_generator
    ) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    size_t num_centroids = centroids.end() - centroids.begin();

    // Calculate the observation-centroid proximity matrix
    titanRelationProximities observation_centroid_prox_generator = titanRelationProximities(false);

    std::vector<std::vector<double> > proximity_matrix;

    proximity_matrix.clear();

    observation_centroid_prox_generator(observation_begin, observation_end, centroids.begin(), centroids.end(), proximity_generator, proximity_matrix);

    // Calculate the observation-centroid ranks
    titanRelationProximityRanking rank_generator;
    rank_generator.set_max_ranks(std::min(num_centroids,this->MaxRanks));

    rank_generator(observation_begin, observation_end, centroids.begin(), centroids.end(), proximity_generator, proximity_matrix, cluster_assignments);


    return true;
  }


private:
  mutable size_t  MaxRanks;

  boost::multi_array<double, 2> * ProximityMultiArray;

};

#endif
