/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class titanMinkowskiDistance titanMinkowskiDistance.h <Clustering/titanMinkowskiDistance.h>
/// \brief Minkowski distances.
///
///  titanMinkowskiDistance is a model of the titanProximityGenerator concept
///  that calculates Minkowski Distances.
///
#ifndef __titanMinkowskiDistance_h
#define __titanMinkowskiDistance_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Common/titanVectorTraits.h>

#include <cmath>
#include <limits>
#include <vector>

class titanMinkowskiDistance
{
public:

  titanMinkowskiDistance() :
      Order(2.0)
  {
  }

  titanMinkowskiDistance(double order) :
      Order(std::max<double>(order, 0.0))
  {
  }

  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 0;
  }

  double farthest_value() const
  {
    return std::numeric_limits<double>::max();
  }

  bool closer(const double a, const double b) const
  {
    return a < b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double distance = 0;
    for (size_t i = 0;
        i != vector_traits<Observation1T>::size(a)
            && i != vector_traits<Observation2T>::size(b); ++i)
      distance += std::pow(
          std::abs(
              vector_traits<Observation1T>::get(a, i)
                  - vector_traits<Observation2T>::get(b, i)), Order);
    return std::pow(distance, 1.0 / Order);
  }

  double proximity(const double a, const double b) const
  {
    return std::abs(a - b);
  }

private:
  double Order;
};

typedef titanMinkowskiDistance titanMinkowskiDistanceType;

#endif
