/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanKLDivergenceJensenShannon titanKLDivergenceJensenShannon.h <Clustering/titanKLDivergenceJensenShannon.h>
/// \brief Jensen-Shannon KL-Divergence
///
///  titanKLDivergenceJensenShannon is a model of the ProximityGenerator concept
///   that computes K-L Divergences. This is a symmetric version from Jensen
///   Shannon and uses a base 2 log (as was used elsewhere in Titan).
///

#ifndef __titanKLDivergenceJensenShannon_h
#define __titanKLDivergenceJensenShannon_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>
#include <Common/titanVectorTraits.h>

#include <algorithm>
#include <cmath>
#include <limits>
#include <vector>

class titanKLDivergenceJensenShannon
{

public:
  titanKLDivergenceJensenShannon() :
    Divisor(std::log(2.0))
  {
  }

  titanKLDivergenceJensenShannon(double base) :
    Divisor(std::log(std::max(base, 1e-20)))
  {
  }

  double vector_norm() const
  {
    return 1;
  }

  double closest_value() const
  {
    return 0;
  }

  double farthest_value() const
  {
    return std::numeric_limits<double>::max();
  }

  bool closer(const double a, const double b) const
  {
    return a < b;
  }

  bool symmetric() const
  {
    return true;
  }

  /*
  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double distance = 0;
    for(size_t i = 0; i != vector_traits<Observation1T>::size(a) && i != vector_traits<Observation2T>::size(b); ++i)
      distance += (
          vector_traits<Observation1T>::get(a,i) * LogN(std::max(vector_traits<Observation1T>::get(a,i), 1e-20) / std::max(vector_traits<Observation2T>::get(b,i), 1e-20)) +
          vector_traits<Observation2T>::get(b,i) * LogN(std::max(vector_traits<Observation2T>::get(b,i), 1e-20) / std::max(vector_traits<Observation1T>::get(a,i), 1e-20)))
      *.5;
    return distance;
  }
  */

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double distance = 0;
    double divisor = 0;
    for(size_t i = 0; i != vector_traits<Observation1T>::size(a) && i != vector_traits<Observation2T>::size(b); ++i)
    {    
        divisor = std::max(0.5*(vector_traits<Observation1T>::get(a,i) + vector_traits<Observation2T>::get(b,i)), 1e-20);
        distance += (vector_traits<Observation1T>::get(a,i) * LogN(vector_traits<Observation1T>::get(a,i) / divisor) +
  	             vector_traits<Observation2T>::get(b,i) * LogN(vector_traits<Observation2T>::get(b,i) / divisor));
    }
    return distance;
  }

private:
  inline double LogN(double x) const
  {
    return std::log(x) / this->Divisor;
  }

  double Divisor;
};


typedef titanKLDivergenceJensenShannon  titanKLDivergenceJensenShannonType;

#endif
