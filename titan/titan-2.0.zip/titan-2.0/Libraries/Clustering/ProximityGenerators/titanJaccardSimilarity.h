/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanJaccardSimilarity titanJaccardSimilarity.h <Clustering/titanJaccardSimilarity.h>
/// \brief Calculates the Jaccard similarity between two observations.
///
///  titanJaccardSimilarity is a model of the ProximityGenerator concept that
///  computes Jaccard similarities.
///

#ifndef __titanJaccardSimilarity_h
#define __titanJaccardSimilarity_h

#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <cmath>
#include <limits>
#include <vector>
#include <iostream>

class titanJaccardSimilarity
{
public:
  double vector_norm() const
  {
    return 0;
  }

  double closest_value() const
  {
    return 1;
  }

  double farthest_value() const
  {
    return 0;
  }

  bool closer(const double a, const double b) const
  {
    return a > b;
  }

  bool symmetric() const
  {
    return true;
  }

  template<typename Observation1T, typename Observation2T>
  double proximity(const Observation1T& a, const Observation2T& b) const
  {
    double a_and_b=0, a_or_b=0;

    for(size_t i = 0; i < vector_traits<Observation1T>::size(a) && i < vector_traits<Observation2T>::size(b); ++i)
    {
      if (vector_traits<Observation1T>::get(a,i) && vector_traits<Observation2T>::get(b,i))
        a_and_b++;
      if (vector_traits<Observation1T>::get(a,i) || vector_traits<Observation2T>::get(b,i))
        a_or_b++;
    }

    if (a_or_b==0)
      return 1;
    else
      return a_and_b/a_or_b;
  }

  double proximity(const double a, const double b) const
  {
    return (a && b);
  }

};

typedef titanJaccardSimilarity  titanJaccardSimilarityDistanceType;

#endif
