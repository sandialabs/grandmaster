/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __titanProximityGenerator_h
#define __titanProximityGenerator_h

#include <boost/concept_check.hpp>
#include <vector>

/// \class titanProximityGenerator titanProximityGenerator.h <Clustering/titanProximityGenerator.h>
/// \brief Similarity/dissimilarity measures
///
///  Models of the titanProximityGenerator concept generate a scalar proximity "score" between two
///  data values.  Proximity scores are used throughout the system to evaluate the fitness
///  of a clustering solution, assign observations to clusters, and more.
///
///  Notation:
///
///    G - A type that is a model of ProximityGenerator.
///    O - a type that represents an observation or centroid.
///
///    g - Object of type G.
///    o1,o2 - Object of type O.
///    a, b - Scores of type double.
///
///  Associated Types:
///    observation_type - A type that is implicitly convertible to an observation or a centroid.
///
///  Valid Expressions:
///
///    g.vector_norm() - Returns a double value representing the Lp space necessary for this proximity.
///                      0 implies no vector normalization is necessary.
///
///    g.closest_value() - Returns a double value representing the highest possible proximity
///                        between two data values.
///
///    g.farthest_value() - Returns a double value representing the lowest possible proximity
///                         between two data values.
///
///    g.closer(a, b) - Returns true iff value a represents a proximity that is closer than b.
///
///    g.symmetric() - Returns true iff g.proximity(o1, o2) == g.proximity(o2, o1) for all valid o1 and o2
///
///    g.proximity(o1, o2) - Returns the double proximity score between two observations,
///                          measured from o1 to o2. The order is important for non-symmetric
///                          proximities.
///
/// Defines concept-checking for the titanProximityGenerator concept.
/// Use with BOOST_CONCEPT_ASSERT() and/or BOOST_CONCEPT_REQUIRES()
/// to verify that a type is a model of titanProximityGenerator.  For example:
///
/// template<typename G>
/// void use_proximity_generator(const G& generator)
/// {
///   BOOST_CONCEPT_ASSERT((titanProximityGenerator<G>));
///   ...
/// }

template<typename G>
struct titanProximityGenerator
{
public:
  BOOST_CONCEPT_USAGE(titanProximityGenerator)
  {
    double v_norm = g.vector_norm();
    double closest = g.closest_value();
    double farthest = g.farthest_value();
    bool closer = g.closer(1.0, 2.0);
    bool symmetric = g.symmetric();
    double proximity = g.proximity(o1, o2);

    boost::ignore_unused_variable_warning(v_norm);
    boost::ignore_unused_variable_warning(closest);
    boost::ignore_unused_variable_warning(farthest);
    boost::ignore_unused_variable_warning(closer);
    boost::ignore_unused_variable_warning(symmetric);
    boost::ignore_unused_variable_warning(proximity);
  }

private:
  G g;
  std::vector<double> o1;
  std::vector<double> o2;
};

#endif
