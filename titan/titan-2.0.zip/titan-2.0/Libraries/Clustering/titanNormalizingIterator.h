/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanNormalizingIterator titanNormalizingIterator.h <Clustering/titanNormalizingIterator.h>
/// \brief ...
///
///  "Adapts" an existing iterator class so that it returns normalized values
///  when dereferenced.  Note that this is intended as a convenience for running
///  experiments; for production work, callers will want to normalize their input
///  data in advance for performance, to avoid redundant computation.
///
///  The following example computes K-means clusters, with normalized observations:
///
///    titanPartitionalClustering<std::vector<double> >(
///      titanRandomSampleClusters(4),
///      titanMeanCentroids(),
///      titanEuclideanDistance<std::vector<double> >(),
///      10,
///  --> titanNormalizingIterator(titanMatrixVectorIterator<double, vtkDenseArray<double> >(dense_input_array, 0, dense_input_array->GetExtent(0).GetBegin())),
///  --> titanNormalizingIterator(titanMatrixVectorIterator<double, vtkDenseArray<double> >(dense_input_array, 0, dense_input_array->GetExtent(0).GetEnd())),
///      std::back_inserter(clusters),
///      std::back_inserter(cluster_assignments)
///      );
///

#ifndef __titanNormalizingIterator_h
#define __titanNormalizingIterator_h

#include <cmath>
#include <Common/titanVectorTraits.h>

template<typename IteratorT>
class titanNormalizingIteratorImplementation
{
public:
  typedef std::random_access_iterator_tag iterator_category;
  typedef std::vector<double> value_type;
  typedef value_type& reference;
  typedef value_type* pointer;
  typedef size_t difference_type;

  titanNormalizingIteratorImplementation(const IteratorT& iterator) :
    Iterator(iterator)
  {
  }

  int operator-(const titanNormalizingIteratorImplementation& other) const
  {
    return this->Iterator - other.Iterator;
  }

  bool operator!=(const titanNormalizingIteratorImplementation& other) const
  {
    return this->Iterator != other.Iterator;
  }

  bool operator<(const titanNormalizingIteratorImplementation& other) const
  {
    return this->Iterator < other.Iterator;
  }

  titanNormalizingIteratorImplementation& operator++()
  {
    ++this->Iterator;
    return *this;
  }

  titanNormalizingIteratorImplementation operator+(const int offset) const
  {
    return titanNormalizingIterator(this->Iterator + offset);
  }

  reference operator*() const
  {
    this->CurrentValue.resize(vector_traits<IteratorT>::size(*this->Iterator));

    vector_assign<value_type, typename IteratorT::value_type>::copy_vector(*this->Iterator,this->CurrentValue);

 //   this->CurrentValue = *this->Iterator;

    double magnitude = 0;
    const int element_count = this->CurrentValue.size();
    for(int i = 0; i != element_count; ++i)
      magnitude += this->CurrentValue[i] * this->CurrentValue[i];
    magnitude = std::sqrt(magnitude);

    if(magnitude)
      {
      magnitude = 1.0 / magnitude;
      for(int i = 0; i != element_count; ++i)
        this->CurrentValue[i] *= magnitude;
      }

    return this->CurrentValue;
  }

private:
  IteratorT Iterator;
  mutable value_type CurrentValue;
};

template<typename IteratorT>
titanNormalizingIteratorImplementation<IteratorT> titanNormalizingIterator(const IteratorT& iterator)
{
  return titanNormalizingIteratorImplementation<IteratorT>(iterator);
}

#endif
