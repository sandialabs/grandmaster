/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanIntraClusterTotalSquaredProximity titanIntraClusterTotalSquaredProximity.h <Clustering/titanIntraClusterTotalSquaredProximity.h>
/// \brief Calculate the total squared intra cluster proximity for each cluster
///
///  Given a set of centroids, a set of observations, a set of cluster
///  assignments, and proximity generator, compute total squared intra-cluster
///  proximities.
///


#ifndef __titanInterClusterTotalSquaredProximity_h
#define __titanInterClusterTotalSquaredProximity_h

#include <cmath>
#include <iostream>

/// Given a set of centroids, a set of observations, a set of cluster assignments, and proximity generator, compute intra-cluster distances.
class titanInterClusterTotalSquaredProximity
{
private:
  mutable std::vector<double> ProximityValues; /// Stores the intra-cluster average squared proximities
  mutable std::vector<size_t> Counts; /// Stores the number of observations per cluster

  mutable boost::multi_array<double, 2> * ProximityMatrix; /// Reference to a proximity matrix
  mutable bool UseMatrix; /// True if the metric will attempt to use a proximity matrix


public :
  // If passed in with no arguments, the constructor will set
  titanInterClusterTotalSquaredProximity() : UseMatrix(false)
  {
  }

  titanInterClusterTotalSquaredProximity(boost::multi_array<double, 2>* proximityMatrix) : ProximityMatrix(proximityMatrix), UseMatrix(true)
  {
  }

template<
  typename CentroidContainerT,
  typename ObservationIteratorT,
  typename ClusterAssignmentT,
  typename ProximityGeneratorT
  >
  bool operator()(
    const ObservationIteratorT observation_begin,
    const ObservationIteratorT observation_end,
    const ClusterAssignmentT& cluster_assignments,
    CentroidContainerT& centroids,
    ProximityGeneratorT& proximity_generator) const
  {
    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));
  // Setup per-cluster distance storage ...
    ProximityValues.resize(centroids.size(),0);

    double proximityValue;

    size_t source_centroid_index = 0;
    size_t target_centroid_index = 0;

    typedef typename CentroidContainerT::iterator CentroidIteratorT;

    CentroidIteratorT sourceCentroid, targetCentroid;
    if (!UseMatrix)
    {
      if (proximity_generator.symmetric())
      {
        for (sourceCentroid = centroids.begin(); sourceCentroid != centroids.end(); ++sourceCentroid, ++source_centroid_index)
        {
          for (targetCentroid = sourceCentroid + 1; targetCentroid != centroids.end(); ++targetCentroid, ++target_centroid_index)
          {
            proximityValue = proximity_generator.proximity(*sourceCentroid, *targetCentroid);
            proximityValue = std::pow(proximityValue, 2.0) * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
            ProximityValues[source_centroid_index] += proximityValue;
            ProximityValues[target_centroid_index] += proximityValue;
          }
        }
      }
      else
      {
        for (sourceCentroid = centroids.begin(); sourceCentroid != centroids.end(); ++sourceCentroid, ++source_centroid_index)
        {
          for (targetCentroid = sourceCentroid + 1; targetCentroid != centroids.end(); ++targetCentroid, ++target_centroid_index)
          {
            proximityValue = proximity_generator.proximity(*sourceCentroid, *targetCentroid);
            ProximityValues[source_centroid_index] += std::pow(proximityValue, 2.0)
                * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));

            proximityValue = proximity_generator.proximity(*targetCentroid, *sourceCentroid);
            ProximityValues[target_centroid_index] += std::pow(proximityValue, 2.0)
                * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
          }
        }
      }
    }
    // If the ProximityMatrix is not the correct size, throw some type of error
    else if (
        (ProximityMatrix->shape()[0]!=observation_end-observation_begin) ||
        (ProximityMatrix->shape()[1]!=centroids.size()) )
    {
      cerr << "Incorrect Proximity Matrix size" << endl;
      // throw

    }
    // If everything is correct, we can use the ProximityMatrix passed into the constructor
    else
    {
      if (proximity_generator.symmetric())
      {

        for (sourceCentroid = centroids.begin(); sourceCentroid
            != centroids.end(); ++sourceCentroid, ++source_centroid_index)
        {
          for (targetCentroid = sourceCentroid + 1; targetCentroid
              != centroids.end(); ++targetCentroid, ++target_centroid_index)
          {
            proximityValue
                = (*ProximityMatrix)[source_centroid_index][target_centroid_index];

            proximityValue = std::pow(proximityValue, 2.0) * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
            ProximityValues[source_centroid_index] += proximityValue;
            ProximityValues[target_centroid_index] += proximityValue;
          }
        }
      }
      else
      {
        for (sourceCentroid = centroids.begin(); sourceCentroid
            != centroids.end(); ++sourceCentroid, ++source_centroid_index)
        {
          for (targetCentroid = sourceCentroid + 1; targetCentroid
              != centroids.end(); ++targetCentroid, ++target_centroid_index)
          {
            proximityValue = (*ProximityMatrix)[source_centroid_index][target_centroid_index];
            proximityValue = std::pow(proximityValue, 2.0) * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
            ProximityValues[source_centroid_index] += proximityValue;

            proximityValue = (*ProximityMatrix)[source_centroid_index][target_centroid_index];
            proximityValue = std::pow(proximityValue, 2.0) * (proximityValue > 0 ? 1 : (proximityValue < 0 ? -1 : 0));
            ProximityValues[target_centroid_index] += proximityValue;
          }
        }

      }
    }

    return true;
  }

/// Returns a reference to the ProximityValues attribute
std::vector<double> * get_proximities()
{
  return &ProximityValues;
}

};

#endif
