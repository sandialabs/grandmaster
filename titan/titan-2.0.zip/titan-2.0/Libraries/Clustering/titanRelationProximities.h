/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


///  \class titanRelationProximities titanRelationProximities.h <Clustering/titanRelationProximities.h>
///  \brief Calculates and stores pairwise proximities between two sets of
///  items (possibly the same set). The proximities are determined by the
///  proximity_generator parameter.

///  If IsSymmetric == true, the algorithm assumes that the cardinalities of
///  the two item sets are the same (though not necessarily the values). On
///  itemsets with identical cardinalities, the proximity stored is the
///  proximity from the first itemset to the second. The calculations from
///  the second to the first are ignored.
///
///  This will be the preferred way of calculations if the proximity is a
///  symmetric one and the itemsets are the same. In this case, half of the
///  proximity calculations are skipped. Otherwise, one should consider
///  setting IsSymmetric to false.
///
///  A full matrix is returned in either case (a calculated proximity value
///  will be in all cells).

#ifndef __titanRelationProximities_h
#define __titanRelationProximities_h

#include <Clustering/titanIntraClusterAverageSquaredProximity.h>
#include <Clustering/ProximityGenerators/titanProximityGenerator.h>

#include <Common/titanVectorTraits.h>

#include <boost/concept_check.hpp>

#include <algorithm>

#include <iostream>
#include <stdexcept>


class titanRelationProximities
{
  class nonSymmetric: public std::exception
  {
    virtual const char* what() const throw ()
    {
      return "items1 and items2 are not the same size";
    }
  } nonsym;


public:
  ///@{
  /// Default constructor.
  /// isSymmetric should be true only if |items1| == |items2|
  /// The archetypical scenario for (isSymmetric==true) is where
  /// items1 == items2. This class will not enforce that constraint,
  /// but will throw an exception if the cardinalities of items1 and items2
  /// are not the same.
  ///@}
  titanRelationProximities(bool isSymmetric) : IsSymmetric(isSymmetric)
  {
  }

  template<
    typename Items1IteratorT,
    typename Items2IteratorT,
    typename ProximityGeneratorT,
    typename ProximityValueContainerT>
    bool operator()(
    const Items1IteratorT items1_begin,
    const Items1IteratorT items1_end,
    const Items2IteratorT items2_begin,
    const Items2IteratorT items2_end,
    const ProximityGeneratorT& proximity_generator,
    ProximityValueContainerT& proximity_matrix
    ) const
  {
    typedef typename ProximityValueContainerT::value_type prox_row_type;

    typedef typename Items1IteratorT::value_type items1_row_type;
    typedef typename Items2IteratorT::value_type items2_row_type;

    BOOST_CONCEPT_ASSERT((titanProximityGenerator<ProximityGeneratorT>));

    // Initialize Proximity Matrix
    size_t numItems1 = items1_end - items1_begin;
    size_t numItems2 = items2_end - items2_begin;

    if (IsSymmetric)
    {
      if (numItems1 != numItems2)
        throw nonsym;
    }

    if (numItems1==0 || numItems2==0)
    {
      // how should this be handled..
      return false;
    }

    if (vector_traits<ProximityValueContainerT>::size(proximity_matrix) != numItems1)
      vector_traits<ProximityValueContainerT>::resize(proximity_matrix,numItems1);

    for (size_t row=0; row != numItems1; ++row )
    {
      prox_row_type & prox_row = vector_traits<ProximityValueContainerT>::get(proximity_matrix,row);

      if (vector_traits<prox_row_type>::size(prox_row) != numItems2)
        vector_traits<prox_row_type>::resize(prox_row, numItems2);

      for (size_t col=0; col != numItems2; ++col )
      {
        vector_traits<prox_row_type>::put(prox_row, col, proximity_generator.farthest_value());
      }
    }

    size_t num_items1, num_items2;

    if ((items1_end - items1_begin) < 0)
      return false;
    else
      num_items1 = static_cast<size_t>(items1_end - items1_begin);

    if ((items2_end - items2_begin) < 0)
      return false;
    else
      num_items2 = static_cast<size_t>(items2_end - items2_begin);


    if (IsSymmetric)
    {
      for (size_t item1_index = 0; item1_index != num_items1; ++item1_index)
      {
        for (size_t item2_index = 0; item2_index != num_items2; ++item2_index)
        {
//TODO iterators are messed up for some reason
//      for (Items1IteratorT item1 = items1_begin; item1 != items1_end; ++item1, ++item1_index)
//      {
//        size_t item2_index = 0;
//        for (Items2IteratorT item2 = items2_begin+item1_index; item2 != items2_end; ++item2, ++item2_index)
//        {
//          const double p = proximity_generator.proximity(*item1, *item2);
          const double p = proximity_generator.proximity(*(items1_begin+item1_index), *(items2_begin+item2_index));

          prox_row_type & prox_row_1 = vector_traits<ProximityValueContainerT>::get(proximity_matrix,item1_index);
          prox_row_type & prox_row_2 = vector_traits<ProximityValueContainerT>::get(proximity_matrix,item2_index);

          vector_traits<prox_row_type>::put(prox_row_1,item2_index, p);
          vector_traits<prox_row_type>::put(prox_row_2,item1_index, p);
        }
      }
    }
    else
    {
      for (size_t item1_index = 0; item1_index != num_items1; ++item1_index)
      {
        for (size_t item2_index = 0; item2_index != num_items2; ++item2_index)
        {
          prox_row_type & prox_row_1 = vector_traits<ProximityValueContainerT>::get(proximity_matrix,item1_index);

          const double p = proximity_generator.proximity(*(items1_begin+item1_index), *(items2_begin+item2_index));

          vector_traits<prox_row_type>::put(prox_row_1,item2_index, p);
        }
      }
    }

    return true;
  }


private:
  mutable bool IsSymmetric; // true if |items1| == |items2|
};

#endif
