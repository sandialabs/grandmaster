/*=========================================================================

  Program:   Visualization Toolkit
  Module:    vtkJVMManagerManager.cxx

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#include "vtkJVMManagerManager.h"
#include "vtkJVMManager.h"

// Must NOT be initialized.  Default initialization to zero is required.
unsigned int vtkJVMManagerManager::Count;

vtkJVMManagerManager::vtkJVMManagerManager()
{
if(++vtkJVMManagerManager::Count == 1)
    {
    vtkJVMManager::ClassInitialize();
    }
}

vtkJVMManagerManager::~vtkJVMManagerManager()
{
if(--vtkJVMManagerManager::Count == 0)
    {
    vtkJVMManager::ClassFinalize();
    }
}
