/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkPTermDictionaryCommunicator.h"

#include <vtkMPICommunicator.h>
#include <vtkMultiProcessController.h>

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryCommunicator::NoBlockRequest

void vtkPTermDictionaryCommunicator::NoBlockRequest::Wait()
{
  this->SendByteCountRequest.Wait();
  this->SendDataRequest.Wait();
}

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryCommunicator

vtkPTermDictionaryCommunicator::vtkPTermDictionaryCommunicator(vtkCommunicator* communicator) :
  Communicator(communicator),
  BytesSent(0),
  TermsSent(0)
{
}

void vtkPTermDictionaryCommunicator::ConvertTerms(vtkUnicodeStringArray& source, UniqueSortedTerms& terms)
{
  const vtkIdType count = source.GetNumberOfTuples();
  for(vtkIdType i = 0; i != count; ++i)
    terms.insert(source.GetValue(i));
}

void vtkPTermDictionaryCommunicator::SendTerms(const UniqueSortedTerms& terms, int recipient)
{
  std::string send_buffer;
  PackTerms(terms, send_buffer);

  unsigned long send_byte_count = send_buffer.size();
  this->Communicator->Send(&send_byte_count, 1, recipient, 0);
  this->Communicator->Send(&send_buffer[0], send_byte_count, recipient, 0);

  this->BytesSent += sizeof(send_byte_count);
  this->BytesSent += send_byte_count;
  this->TermsSent += terms.size();
}

void vtkPTermDictionaryCommunicator::ReceiveTerms(int sender, UniqueSortedTerms& terms)
{
  unsigned long receive_byte_count = 0;
  this->Communicator->Receive(&receive_byte_count, 1, sender, 0);

  std::string receive_buffer(receive_byte_count, '\0');
  this->Communicator->Receive(&receive_buffer[0], receive_byte_count, sender, 0);

  UnpackTerms(receive_buffer, terms);
}

void vtkPTermDictionaryCommunicator::NoBlockSendTerms(const UniqueSortedTerms& terms, int recipient, NoBlockRequest& request)
{
  PackTerms(terms, request.SendBuffer);
  request.SendByteCount = request.SendBuffer.size();

  vtkMPICommunicator::SafeDownCast(this->Communicator)->NoBlockSend(&request.SendByteCount, 1, recipient, 0, request.SendByteCountRequest);
  vtkMPICommunicator::SafeDownCast(this->Communicator)->NoBlockSend(&request.SendBuffer[0], request.SendByteCount, recipient, 0, request.SendDataRequest);

  this->BytesSent += sizeof(request.SendByteCount);
  this->BytesSent += request.SendByteCount;
  this->TermsSent += terms.size();
}

vtkIdType vtkPTermDictionaryCommunicator::GetBytesSent() const
{
  return this->BytesSent;
}

vtkIdType vtkPTermDictionaryCommunicator::GetTermsSent() const
{
  return this->TermsSent;
}

void vtkPTermDictionaryCommunicator::UnpackTerms(const std::string& buffer, UniqueSortedTerms& terms)
{
  const char* const end = &buffer[0] + buffer.size();
  for(const char* start = &buffer[0]; start != end; ++start)
    {
    for(const char* finish = start; finish != end; ++finish)
      {
      if(*finish == 0)
        {
        terms.insert(terms.end(), vtkUnicodeString::from_utf8(start));
        start = finish;
        break;
        }
      }
    }
}

void vtkPTermDictionaryCommunicator::UnpackTerms(const std::string& buffer, Terms& terms)
{
  const char* const end = &buffer[0] + buffer.size();
  for(const char* start = &buffer[0]; start != end; ++start)
    {
    for(const char* finish = start; finish != end; ++finish)
      {
      if(*finish == 0)
        {
        terms.push_back(vtkUnicodeString::from_utf8(start));
        start = finish;
        break;
        }
      }
    }
}
