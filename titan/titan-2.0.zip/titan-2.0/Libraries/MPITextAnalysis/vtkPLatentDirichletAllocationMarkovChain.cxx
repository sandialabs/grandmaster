/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkPLatentDirichletAllocationMarkovChain.h"


#include "vtkArray.h"
#include "vtkDataObject.h"
#include "vtkDenseArray.h"
#include "vtkDoubleArray.h"
#include "vtkFieldData.h"
#include "vtkIdTypeArray.h"
#include "vtkIntArray.h"
#include "vtkMath.h"
#include "vtkMinimalStandardRandomSequence.h"
#include "vtkObjectFactory.h"
#include "vtkRandomSequence.h"
#include "vtkSmartPointer.h"
#include "vtkTextAnalysisUtilities.h"
#include "vtkType.h"
#include "vtkUnicodeStringArray.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"
#include "vtkMultiProcessController.h"

#include <vtksys/ios/sstream>

#include <vtksys/stl/algorithm>
#include <vtksys/hash_map.hxx>
#include <vtksys/stl/map>
#include <vtksys/stl/set>
#include <vtksys/stl/stdexcept>
#include <vtksys/stl/vector>
#include <vtksys/stl/functional>

#include <boost/math/special_functions/gamma.hpp>

#if defined(VTK_USE_64BIT_IDS)
struct HashIdType: public vtksys_stl::unary_function<vtkIdType, size_t>
{
public:
  size_t operator()(vtkIdType id) const
    {
      vtkTypeUInt64 key = static_cast<vtkTypeUInt64>(id);
      key = (~key) + (key << 21); // key = (key << 21) - key - 1;
      key = key ^ (key >> 24);
      key = (key + (key << 3)) + (key << 8); // key * 265
      key = key ^ (key >> 14);
      key = (key + (key << 2)) + (key << 4); // key * 21
      key = key ^ (key >> 28);
      key = key + (key << 31);
      return key;
    }
};
#else // idtype is 32-bit
struct HashIdType : public vtksys_stl::unary_function<vtkIdType, size_t>
{
public:
  size_t operator()(vtkIdType id) const
    {
      vtkTypeUInt32 a = static_cast<vtkTypeUInt32>(id);
      a = (a+0x7ed55d16) + (a<<12);
      a = (a^0xc761c23c) ^ (a>>19);
      a = (a+0x165667b1) + (a<<5);
      a = (a+0xd3a2646c) ^ (a<<9);
      a = (a+0xfd7046c5) + (a<<3);
      a = (a^0xb55a4f09) ^ (a>>16);
      return a;
    }
};
#endif // define a hash functor for vtkIdType

#define VTK_CREATE(type,name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New();


vtkStandardNewMacro(vtkPLatentDirichletAllocationMarkovChain);
vtkCxxSetObjectMacro(vtkPLatentDirichletAllocationMarkovChain, Controller, vtkMultiProcessController);
// ----------------------------------------------------------------------

namespace
{
  const char *SAVED_STATE_IDENTIFIER = "Parallel_LDA_metadata";
};

// ----------------------------------------------------------------------

typedef vtksys_stl::vector<int> IntVector;
typedef vtksys_stl::vector<IntVector> IntVectorVector;
typedef vtksys_stl::vector<double> DoubleVector;
typedef vtksys_stl::vector<DoubleVector> DoubleVectorVector;
typedef vtksys_stl::vector<vtkIdType> IdTypeVector;
typedef vtksys_stl::vector<IdTypeVector> IdTypeVectorVector;
typedef vtksys_stl::map<vtkIdType, int> DocIdToSizeMap;
typedef vtksys::hash_map<vtkIdType, vtkIdType, HashIdType> IdToIdHashMap;

// ----------------------------------------------------------------------

class vtkPLatentDirichletAllocationMarkovChainInternals
{
public:
  // These two arrays hold building blocks for the term/topic (phi)
  // and topic/document (theta) weightings.  Phi is computed from
  // TermInstancesPerTopic and will need to be updated *after* the
  // sync step but is held in totality on every processor.  Theta is
  // computed from TopicInstancesPerDocument and represents only the
  // documents held locally on each processor.
  DoubleVectorVector  AccumulatedPhi;
  DoubleVectorVector  AccumulatedTheta;
  int                 MatrixSampleCount;

  // For efficiency's sake we want to maintain the processor-local
  // documents in contiguous arrays.  Sparse data structures are
  // relatively expensive to loop through.  However, we still need to
  // refer to the global document IDs when communicating with the
  // outside world, so we maintain these two maps for translation.
  IdToIdHashMap       GlobalToLocalDocIdMap;
  IdToIdHashMap       LocalToGlobalDocIdMap;
  vtkArrayRange       GlobalIdRangeForLocalDocuments;

  // These refer to processor-local documents only and are indexed
  // using local document IDs.
  IdTypeVectorVector  Documents;
  IntVector           DocumentSizes;
  IntVectorVector     WordTopicAssignments;
  IntVectorVector     TopicInstancesPerDocument;

  // This is the array that needs to be kept globally in sync.  It
  // gets modified by every call to RemoveTermTopicAssignment or
  // AssignTermToTopic.  Tom will probably split it into two
  // components: TermInstancesPerTopic_GLOBAL and
  // TermInstancesPerTopic_LocalChanges.  At the end of each iteration
  // we'll perform an all-reduce on the LocalChanges component, then
  // broadcast out a new copy of TermInstancesPerTopic_GLOBAL.
  //
  // In the long run we might want to convert this to a sparse data
  // structure.  I think something like 3% of the entries are nonzero
  // at any time.  However, we can sort that out *after* the parallel
  // version is up and running.
  // IntVectorVector     TermInstancesPerTopic;
  IntVectorVector     TermInstancesPerTopic_GLOBAL;
  IntVectorVector     TermInstancesPerTopic_LocalChanges;

  // Oops.  This one also needs to be kept in sync globally but I
  // forgot to mention it.  The same paradigm applies but it's far
  // less data.
  //IntVector           WordsPerTopic;
  IntVector           WordsPerTopic_GLOBAL;
  IntVector           WordsPerTopic_LocalChanges;

  // This array is used in the inner loop.  We keep it here instead of
  // there to avoid the expense of allocating and de-allocating memory
  // every time we look at a different term.
  DoubleVector        TopicProbabilities;

  // We use these arrays when topics are flagged read-only
  // (i.e. during inference).  They will need to be kept in sync just
  // like TermInstancesPerTopic and WordsPerTopic -- in fact, we'll
  // use exactly the same code.
  //IntVectorVector     TermInstancesPerTopic_Inference;
  //IntVector           WordsPerTopic_Inference;
  IntVectorVector     TermInstancesPerTopic_Inference_GLOBAL;
  IntVectorVector     TermInstancesPerTopic_Inference_LocalChanges;
  IntVector           WordsPerTopic_Inference_GLOBAL;
  IntVector           WordsPerTopic_Inference_LocalChanges;

  // Once we've finished all of the sampling iterations we can discard
  // all of the cache arrays.  We only keep data that (1) contributes
  // directly to the output (i.e. theta and phi) or (2) gets saved
  // along with the sampler state.
  void CompactForArchiving()
    {
      //this->TermInstancesPerTopic.clear();
      //this->TermInstancesPerTopic_Inference.clear();
      this->TermInstancesPerTopic_GLOBAL.clear();
      this->TermInstancesPerTopic_LocalChanges.clear();
      this->TermInstancesPerTopic_Inference_GLOBAL.clear();
      this->TermInstancesPerTopic_Inference_LocalChanges.clear();
      this->TopicInstancesPerDocument.clear();
//      this->WordsPerTopic.clear();
//      this->WordsPerTopic_Inference.clear();
      this->WordsPerTopic_GLOBAL.clear();
      this->WordsPerTopic_LocalChanges.clear();
      this->WordsPerTopic_Inference_GLOBAL.clear();
      this->WordsPerTopic_Inference_LocalChanges.clear();
      this->DocumentSizes.clear();
      this->TopicProbabilities.clear();
    }

  // This method gets called with a map from global document ID to
  // size.  It builds the arrays that we need for the actual Markov
  // chain state -- the documents themselves and the token->topic
  // assignments -- and leaves the cache arrays for later.
  void AllocateCorpusArrays(const DocIdToSizeMap &docSizeMap)
    {
      int nextDocId = 0;

      this->GlobalToLocalDocIdMap.clear();
      this->LocalToGlobalDocIdMap.clear();

      int minGlobalDocId = 1<<30;
      int maxGlobalDocId = -1;
      for (DocIdToSizeMap::const_iterator iter = docSizeMap.begin();
           iter != docSizeMap.end(); ++iter)
        {
        int globalDocId = (*iter).first;
        if (globalDocId < minGlobalDocId) minGlobalDocId = globalDocId;
        if (globalDocId > maxGlobalDocId) maxGlobalDocId = globalDocId;
        GlobalToLocalDocIdMap[globalDocId] = nextDocId;
        LocalToGlobalDocIdMap[nextDocId] = globalDocId;
        ++ nextDocId;
        }
      this->GlobalIdRangeForLocalDocuments = vtkArrayRange(minGlobalDocId, maxGlobalDocId+1);

      // Sanity check: it *should* be the case that we have a
      // contiguous set of global document IDs.
      vtksys_stl::vector<int> docIdCheck(1 + maxGlobalDocId - minGlobalDocId, -1);
      for (DocIdToSizeMap::const_iterator iter = docSizeMap.begin();
           iter != docSizeMap.end(); ++iter)
        {
        int globalDocId = (*iter).first;
        docIdCheck[globalDocId - minGlobalDocId] = 1;
        }
      for (vtksys_stl::vector<int>::size_type i = 0;
           i < docIdCheck.size();
           ++i)
        {
        if (docIdCheck[i] == -1)
          {
          cerr << "INVESTIGATE ME: Global document ID range is "
               << minGlobalDocId << " to " << maxGlobalDocId
               << " and ID "
               << i + minGlobalDocId << " is missing!  This is not "
               << "necessarily wrong, just something that Andy did not "
               << "anticipate.\n";
          }
        }

      this->Documents.clear();
      this->Documents.resize(docSizeMap.size());
      this->DocumentSizes.assign(docSizeMap.size(), 0);

      this->WordTopicAssignments.clear();
      this->WordTopicAssignments.resize(docSizeMap.size());


      for (DocIdToSizeMap::const_iterator iter = docSizeMap.begin();
           iter != docSizeMap.end(); ++iter)
        {
        vtkIdType globalId = (*iter).first;
        vtkIdType localId = GlobalToLocalDocIdMap[globalId];
        int size = (*iter).second;

        this->Documents[localId].reserve(size);
        this->WordTopicAssignments[localId].reserve(size);
        this->DocumentSizes[localId] = size;
        }
    } // done with AllocateCorpusArrays


  // This is where we allocate all of the cache arrays that let us run
  // Gibbs sampling quickly.  The 'preserve_topic_word_counts'
  // argument is used in cases where we've already loaded in a saved
  // chain state and want to use its topics during inference.
  void Initialize(int local_document_count,
                  int vocabulary_size,
                  int topic_count,
                  bool preserve_topic_word_counts)
    {
      this->MatrixSampleCount = 0;

      DoubleVector double_topic_vector(topic_count, 0);
      DoubleVector double_term_vector(vocabulary_size, 0);
      IntVector int_topic_vector(topic_count, 0);
      IntVector int_term_vector(vocabulary_size, 0);

      this->AccumulatedTheta.assign(local_document_count, double_topic_vector);
      this->AccumulatedPhi.assign(topic_count, double_term_vector);

      if (!preserve_topic_word_counts)
        {
        // TermInstancesPerTopic: num_topics x vocabulary_size
        this->TermInstancesPerTopic_GLOBAL.assign(topic_count, int_term_vector);
        this->TermInstancesPerTopic_LocalChanges.assign(topic_count, int_term_vector);
        }
      this->TermInstancesPerTopic_Inference_GLOBAL.assign(topic_count, int_term_vector);
      this->TermInstancesPerTopic_Inference_LocalChanges.assign(topic_count, int_term_vector);

      // TopicInstancesPerDocument: num_documents x num_topics
      this->TopicInstancesPerDocument.assign(local_document_count,
                                             int_topic_vector);

      if (!preserve_topic_word_counts)
        {
        // WordsPerTopic, TopicProbabilities: num_topics
        this->WordsPerTopic_GLOBAL.assign(topic_count, 0);
        this->WordsPerTopic_LocalChanges.assign(topic_count, 0);
        }
      this->WordsPerTopic_Inference_GLOBAL.assign(topic_count, 0);
      this->WordsPerTopic_Inference_LocalChanges.assign(topic_count, 0);

      this->TopicProbabilities.assign(topic_count, 0);
    }

};

// ----------------------------------------------------------------------

vtkPLatentDirichletAllocationMarkovChain::vtkPLatentDirichletAllocationMarkovChain()
  : NumberOfGlobalDocuments(-1),
    Internals(new vtkPLatentDirichletAllocationMarkovChainInternals)
{
  this->Controller = 0;
  this->SetController(vtkMultiProcessController::GetGlobalController());
  // nothing else to do
}

// ----------------------------------------------------------------------

vtkPLatentDirichletAllocationMarkovChain::~vtkPLatentDirichletAllocationMarkovChain()
{
  this->SetController(0);
  delete this->Internals;
}

// ----------------------------------------------------------------------

// Note: The array coming in has global document IDs in it.  Those
// will get remapped to local document IDs inside
// AllocateCorpusArrays().

void
vtkPLatentDirichletAllocationMarkovChain::BuildCorpus(vtkArray *frequencyMatrix)
{
  // Walk the matrix twice: once to find out how much room we need for
  // the documents and again to populate the documents.

  vtkArrayExtents dimensions = frequencyMatrix->GetExtents();
  vtkIdType maxTermId = dimensions[0].GetSize();
  DocIdToSizeMap documentSizes;

  for (vtkIdType n = 0; n < frequencyMatrix->GetNonNullSize(); ++n)
    {
      vtkArrayCoordinates coords;
      frequencyMatrix->GetCoordinatesN(n, coords);
      vtkIdType docId = coords[1];
      vtkIdType tokenCountThisTerm =
        frequencyMatrix->GetVariantValueN(n).ToInt();
      documentSizes[docId] += tokenCountThisTerm;
    }

  this->Internals->AllocateCorpusArrays(documentSizes);

  this->VocabularySize = maxTermId;

  for (vtkIdType n = 0; n < frequencyMatrix->GetNonNullSize(); ++n)
    {
      vtkArrayCoordinates coords;
      frequencyMatrix->GetCoordinatesN(n, coords);
      vtkIdType globalDocId = coords[1];
      vtkIdType localDocId =
        this->Internals->GlobalToLocalDocIdMap[globalDocId];
      vtkIdType termId = coords[0];
      int count = frequencyMatrix->GetVariantValueN(n).ToInt();

      for (int i = 0; i < count; ++i)
  {
        this->Internals->Documents[localDocId].push_back(termId);
        this->Internals->WordTopicAssignments[localDocId].push_back(-1);
  }
    }
  // Done!
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::AllocateCacheArrays()
{
  if (this->Controller->GetLocalProcessId() == 0)
    {
    cerr << "AllocateCacheArrays: Local document count "
         << this->GetNumberOfLocalDocuments()
         << ", vocabulary size "
         << this->GetVocabularySize()
         << ", topic count "
         << this->GetNumberOfTopics()
         << ", inference "
         << this->GetInferenceEnabled() << "\n";
    }

  this->Internals->Initialize(this->GetNumberOfLocalDocuments(),
                              this->GetVocabularySize(),
                              this->GetNumberOfTopics(),
                              this->GetInferenceEnabled());
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::InitializeTermTopicAssignments()
{
  if (this->Internals->Documents.size() == 0)
    {
    vtkErrorMacro(<<"You must supply a document corpus before you can initialize the Markov chain.");
    return;
    }

  // Now we initialize random values for the word-to-topic
  // assignments.  At the moment I'm drawing them from a uniform
  // distribution.  Reimplement ChooseInitialTopic() to substitute a
  // more interesting prior.

  for (int doc = 0; doc < this->GetNumberOfLocalDocuments(); ++doc)
    {
    for (int term = 0; term < this->GetNumberOfWords(doc); ++term)
      {
      int topic = this->ChooseInitialTopic(doc, term);
      assert(topic >= 0 && topic < this->GetNumberOfTopics());
      this->AssignTermToTopic(doc, term, topic);
      }
    }

  this->SyncTopicCountArrays();
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::AssignTermToTopic(vtkIdType docId,
                                                           vtkIdType termIndex,
                                                           vtkIdType topic)
{
  vtkIdType termId = this->Internals->Documents[docId][termIndex];

  // Record the new topic assignment
  this->Internals->WordTopicAssignments[docId][termIndex] = topic;

  if (!this->TopicsReadOnly)
    {
    // Number of instances of word termId assigned to topic
    this->Internals->TermInstancesPerTopic_LocalChanges[topic][termId] ++;
    // Number of words total assigned to topic
    this->Internals->WordsPerTopic_LocalChanges[topic] ++;
    }
  else
    {
    this->Internals->WordsPerTopic_Inference_LocalChanges[topic] ++;
    this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic][termId] ++;
    }

  // Number of words in document docId assigned to topic
  this->Internals->TopicInstancesPerDocument[docId][topic] ++;
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::RemoveTermTopicAssignment(vtkIdType docId,
                                                                   vtkIdType termIndex)
{
  vtkIdType topic = this->Internals->WordTopicAssignments[docId][termIndex];
  vtkIdType termId = this->Internals->Documents[docId][termIndex];

  assert(topic >= 0);
  this->Internals->TopicInstancesPerDocument[docId][topic] --;
  if (!this->TopicsReadOnly)
    {
    this->Internals->TermInstancesPerTopic_LocalChanges[topic][termId] --;
    this->Internals->WordsPerTopic_LocalChanges[topic] --;
    }
  else
    {
    this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic][termId] --;
    this->Internals->WordsPerTopic_Inference_LocalChanges[topic] --;
    }
}

// ----------------------------------------------------------------------

/*
 * This method is the heart of Gibbs sampling for LDA.  It chooses a
 * topic allocation for a given word in a given document by sampling
 * from a distribution composed of the Dirichlet prior and information
 * about the current topic distribution in the rest of the corpus.
 *
 * In English, here's what's going on.  We need to choose a new topic
 * for a word W in a document D.  We estimate that, roughly, as the
 * following:
 *
 * prob(topic T | word W, document D) =
 *
 * prob(word W in topic T) * prob(topic T in document D)
 *
 * Look for numer1, denom1, numer2 and denom2 to see where this
 * actually happens.  The extra bits with Alpha and Beta are where we
 * incorporate the Dirichlet prior on the distributions.
 *
 */

int
vtkPLatentDirichletAllocationMarkovChain::ChooseNewTopic(vtkIdType docId,
                                                        vtkIdType termIndex)
{
  vtkIdType termId = this->Internals->Documents[docId][termIndex];

  // Compute the probability of each possible topic
  double VocabularySizeTimesBeta = this->VocabularySize * this->Beta;

  for (int topic = 0; topic < this->NumberOfTopics; ++topic)
    {
    int termInstancesAssignedToTopic =
      this->Internals->TermInstancesPerTopic_GLOBAL[topic][termId] +
      this->Internals->TermInstancesPerTopic_LocalChanges[topic][termId];
    int wordsAssignedToTopic =
      this->Internals->WordsPerTopic_GLOBAL[topic] +
      this->Internals->WordsPerTopic_LocalChanges[topic];
    int documentWordsAssignedToTopic =
      this->Internals->TopicInstancesPerDocument[docId][topic];

    // probability of this term within this topic
    double numer1 = termInstancesAssignedToTopic + this->Beta;
    double denom1 = wordsAssignedToTopic + VocabularySizeTimesBeta;

    // probability of this topic within this document
    double numer2 = documentWordsAssignedToTopic + this->Alpha;
    double prob = (numer1 * numer2) / denom1;
    this->Internals->TopicProbabilities[topic] = prob;
    }

  // Cumulate parameters to get a CDF so we can sample
  for (int topic = 1; topic < this->NumberOfTopics; ++topic)
    {
    this->Internals->TopicProbabilities[topic] +=
      this->Internals->TopicProbabilities[topic-1];
    }

  // Create a random number between 0 and maxProbability -- we'll use
  // this to determine which topic we've just chosen
  this->RandomSequence->Next();
  double randVal = this->RandomSequence->GetValue();
  double randIndex = randVal * this->Internals->TopicProbabilities[this->NumberOfTopics - 1];

  DoubleVector::iterator selected_position =
    vtksys_stl::lower_bound(this->Internals->TopicProbabilities.begin(),
                            this->Internals->TopicProbabilities.end(),
                            randIndex);

  int selected_topic =
    vtksys_stl::distance(this->Internals->TopicProbabilities.begin(),
                         selected_position);

  return selected_topic;
}

// ----------------------------------------------------------------------

int
vtkPLatentDirichletAllocationMarkovChain::ChooseInitialTopic(vtkIdType docId,
                                                            vtkIdType termIndex)
{
  // This speeds up the convergence of the sampler quite a bit.
  // Instead of choosing purely random topics at the beginning, we
  // choose random topics for the very first document and then take
  // those assignments into account for all the other initial topics.
  // Think of it as running a regular iteration as soon as we've got
  // one document's assignments as a basis for sampling.
  if (docId == 0 && (this->GetInferenceEnabled() == false))
    {
    this->RandomSequence->Next();
    double value = this->RandomSequence->GetValue();
    return static_cast<int>(floor(value * this->NumberOfTopics));
    }
  else
    {
    return this->ChooseNewTopic(docId, termIndex);
    }
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::SampleFullConditional(vtkIdType docId,
                                                               vtkIdType termIndex)
{
  this->RemoveTermTopicAssignment(docId, termIndex);
  int newTopic = this->ChooseNewTopic(docId, termIndex);
  this->AssignTermToTopic(docId, termIndex, newTopic);
}

// ----------------------------------------------------------------------

int
vtkPLatentDirichletAllocationMarkovChain::GetNumberOfLocalDocuments()
{
  // This conversion from size_t to int could technically lose data
  // but you'll have to have more than two billion documents on a
  // single node for that to happen
  return static_cast<int>(this->Internals->Documents.size());
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::UpdateOutputMatrices()
{
  int docId, termId, topic;

  for (docId = 0; docId < this->GetNumberOfLocalDocuments(); ++docId)
    {
    for(topic = 0; topic < this->NumberOfTopics; ++topic)
      {
      double numer = this->Internals->TopicInstancesPerDocument[docId][topic] + this->Alpha;
      double denom = this->GetNumberOfWords(docId) + this->NumberOfTopics * this->Alpha;
      this->Internals->AccumulatedTheta[docId][topic] += (numer / denom);
      }
    }

  for (topic = 0; topic < this->NumberOfTopics; ++topic)
    {
    for (termId = 0; termId < this->VocabularySize; ++termId)
      {
      double numer =
        this->Internals->TermInstancesPerTopic_GLOBAL[topic][termId] +
        this->Internals->TermInstancesPerTopic_LocalChanges[topic][termId] +
        this->Beta;
      double denom =
        this->Internals->WordsPerTopic_GLOBAL[topic] +
        this->Internals->WordsPerTopic_LocalChanges[topic] +
        this->VocabularySize * this->Beta;

      this->Internals->AccumulatedPhi[topic][termId] += (numer / denom);
      }
    }

  this->RunningHarmonicMeanDenominator += 1.0 / this->GetRawCorpusLikelihood();

  ++ this->Internals->MatrixSampleCount;
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::GuessParameterValues()
{
  this->Alpha = 50.0 / this->NumberOfTopics;
  this->Beta = 0.1;
}

// ----------------------------------------------------------------------

int
vtkPLatentDirichletAllocationMarkovChain::GetNumberOfWords(vtkIdType doc)
{
  // Yes, this truncates to 31 bits, but that's only a problem if you
  // have documents with more than two billion tokens
  return static_cast<int>(this->Internals->Documents[doc].size());
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Alpha: " << this->Alpha << "\n";
  os << indent << "Beta: " << this->Beta << "\n";
  os << indent << "Number of topics: " << this->NumberOfTopics << "\n";
  if (this->Controller)
    {
    os << indent << "Controller:\n";
    this->Controller->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << indent << "Controller: (null)\n";
    }
}

// ----------------------------------------------------------------------

//
// theta(doc d, topic j):
//
// (count(words in doc d assigned to topic j) + alpha) /
// (words in doc d + #topics * alpha)
//
// in english:
//
// given document d, the chance that you will (randomly) choose topic j
//
// the higher alpha is, the closer the distribution is to uniform.
// "words in doc" should be substantially larger than "#topics *
// alpha".

vtkArray *
vtkPLatentDirichletAllocationMarkovChain::GetDocumentTopicMatrix()
{
  vtkArrayExtents localExtentInGlobalSpace;
  localExtentInGlobalSpace.SetDimensions(2);
  localExtentInGlobalSpace[0] = this->Internals->GlobalIdRangeForLocalDocuments;
  localExtentInGlobalSpace[1] = vtkArrayRange(0, this->NumberOfTopics);

  assert(this->Internals->AccumulatedTheta.size());

  vtkDenseArray<double> *Matrix = vtkDenseArray<double>::New();
  Matrix->Resize(localExtentInGlobalSpace);

  for (int doc = 0; doc < this->GetNumberOfLocalDocuments(); ++doc)
    {
    for (int topic = 0; topic < this->NumberOfTopics; ++topic)
      {
      double weight = this->Internals->AccumulatedTheta[doc][topic] /
        static_cast<double>(this->Internals->MatrixSampleCount);
      int globalDocId = this->Internals->LocalToGlobalDocIdMap[doc];
      assert(globalDocId >= localExtentInGlobalSpace[0].GetBegin());
      assert(globalDocId < localExtentInGlobalSpace[0].GetEnd());
      Matrix->SetValue(globalDocId, topic, weight);
      }
    }

  return Matrix;
}


// ----------------------------------------------------------------------

// phi
//
//
// phi(word i, topic j): (count(i assigned to j) + beta) / (count(words assigned to j) + (vocab# * beta))
//
//
// in english: the probability of choosing word i at random from topic j
//
// the higher beta is, the closer the distribution is to uniform
// for good results, vocab# * beta should be substantially smaller than "words assigned to topic #"

vtkArray *
vtkPLatentDirichletAllocationMarkovChain::GetTopicTermMatrix()
{
  vtkDenseArray<double> *Matrix = vtkDenseArray<double>::New();

  assert(this->Internals->AccumulatedPhi.size());
  bool on_proc0 = (this->Controller->GetLocalProcessId() == 0);
  if (on_proc0)
    {
    cerr << "Resizing phi matrix to " << this->NumberOfTopics << " x "
         << this->VocabularySize << "\n";
    }
  Matrix->Resize(this->NumberOfTopics,
                 this->VocabularySize);

  for (int topic = 0; topic < this->NumberOfTopics; ++topic)
    {
    for (int term = 0; term < this->VocabularySize; ++term)
      {
      Matrix->SetValue(topic, term,
                       (this->Internals->AccumulatedPhi[topic][term] /
                        static_cast<double>(this->Internals->MatrixSampleCount)));
      }
    }

  return Matrix;
}

// ----------------------------------------------------------------------

// XXX PARALLEL This is where you drop in the synchronization methods
void
vtkPLatentDirichletAllocationMarkovChain::RunSingleIteration()
{
  for (int doc = 0; doc < this->GetNumberOfLocalDocuments(); ++doc)
    {
    for (int termIndex = 0; termIndex < this->GetNumberOfWords(doc); ++termIndex)
      {
      this->SampleFullConditional(doc, termIndex);
      }
    }

  // Sync Local perTopic arrays
  this->SyncTopicCountArrays();
}

// ----------------------------------------------------------------------

/*
 * I do not expect anyone to understand the inner workings of this function.
 *
 * Here goes.  One of the ways of evaluating whether we've got the
 * right number of topics for a given corpus is to evaluate the
 * likelihood of the supplied set of words given the assignment of
 * words to topics \em{z}.  We abbreviate this P(w|z).  There's an
 * ugly but straightforward equation for this on page 2 of "Finding
 * scientific topics" by Griffiths and Steyvers.  It's listed as
 * equation 5 and involves the Gamma function and a bunch of products
 * over all words/topics.
 *
 * I am not using this equation as is.  The problem is that a 64-bit
 * (double-precision) floating point number will only hold values of
 * Gamma(x) for x < 171.  We need to be able to compute gamma for
 * parameters up into the thousands.  We could solve this using
 * arbitrary-precision arithmetic but that's some awfully heavy
 * machinery (including external libraries) to drag into play.
 *
 * A cleaner solution is to look at the natural logarithm of that
 * expression.  Boost.math contains code to compute ln(gamma(x)).
 * That solves all of our range problems.  All I have to do is the
 * algebra to express the logarithm of the original equation (with all
 * of its calls to gamma(x)) as an equation involving only calls to
 * ln(gamma(x)).
 */

using boost::math::lgamma;

double
vtkPLatentDirichletAllocationMarkovChain::GetRawCorpusLikelihood()
{
  double W = static_cast<double>(this->VocabularySize);
  double T = static_cast<double>(this->NumberOfTopics);

  double term1 = T * ( lgamma(W*this->Beta) - W * lgamma(this->Beta) );

  double term2_part1 = 0;
  double term2_part2 = 0;

  for (int topic = 0; topic < this->NumberOfTopics; ++topic)
    {
    double second_part;
    if (this->TopicsReadOnly)
      {
      second_part =
        lgamma(this->Internals->WordsPerTopic_Inference_GLOBAL[topic] +
               this->Internals->WordsPerTopic_Inference_LocalChanges[topic] +
               this->VocabularySize * this->Beta);
      }
    else
      {
      second_part = lgamma(this->Internals->WordsPerTopic_GLOBAL[topic] +
                           this->Internals->WordsPerTopic_LocalChanges[topic] +
                           this->VocabularySize * this->Beta);
      }

    double first_part = 0;
    for (int term_id = 0; term_id < this->VocabularySize; ++term_id)
      {
      if (this->TopicsReadOnly)
        {
        first_part +=
          lgamma(this->Internals->TermInstancesPerTopic_Inference_GLOBAL[topic][term_id] +
                 this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic][term_id] +
                 this->Beta);
        }
      else
        {
        first_part +=
          lgamma(this->Internals->TermInstancesPerTopic_GLOBAL[topic][term_id] +
                 this->Internals->TermInstancesPerTopic_LocalChanges[topic][term_id] +
                 this->Beta);
        }
      }

    term2_part1 += first_part;
    term2_part2 -= second_part;
    }


  return term1 + term2_part1 + term2_part2;
}

// ----------------------------------------------------------------------

double
vtkPLatentDirichletAllocationMarkovChain::GetCorpusLikelihood()
{
  return static_cast<double>(this->Internals->MatrixSampleCount) /
    this->RunningHarmonicMeanDenominator;
}

// ----------------------------------------------------------------------

// XXX PARALLEL This will probably need to be rewritten and should
// definitely save one object per process

void
vtkPLatentDirichletAllocationMarkovChain::SaveSamplerState(vtkDataObject *archive)
{
  // The archive information is stored in the field data and is
  // structured as follows:
  // Array 0 ("metadata"): vtkVariantArray:
  //   Item 0: int NumberOfDocuments
  //   Item 1: int NumberOfTopics
  //   Item 2: double Alpha
  //   Item 3: double Beta
  //   Item 4: number of processors
  //
  // Arrays 2 - numDocuments+1: vtkIntArray:
  //   items 0 - #words in document i: term IDs
  //
  // Arrays (numDocuments+2) - (2*numDocuments+1): chain state
  //   items 0 - #words in document i: assignment of words to topics
  //
  // Array (2*numDocuments+1) + 1: local document ID -> global document ID count

  VTK_CREATE(vtkVariantArray, metadata);
  metadata->SetName("Parallel_LDA_metadata");
  metadata->InsertNextValue(vtkVariant(this->GetNumberOfLocalDocuments()));
  metadata->InsertNextValue(vtkVariant(this->NumberOfTopics));
  metadata->InsertNextValue(vtkVariant(this->Alpha));
  metadata->InsertNextValue(vtkVariant(this->Beta));
  metadata->InsertNextValue(vtkVariant(this->VocabularySize));
  // XXX PARALLEL
  metadata->InsertNextValue(this->Controller->GetNumberOfProcesses());
  metadata->InsertNextValue(this->GetNumberOfGlobalDocuments());

  archive->GetFieldData()->AddArray(metadata);

  // raw documents
  for (int doc_id = 0; doc_id < this->GetNumberOfLocalDocuments(); ++doc_id)
    {
    vtksys_ios::ostringstream namebuf;
    namebuf << "local_document_" << doc_id << "_of_" << this->GetNumberOfLocalDocuments();
    VTK_CREATE(vtkIntArray, doc_array);
    doc_array->SetName(namebuf.str().c_str());
    for (int word = 0; word < this->GetNumberOfWords(doc_id); ++word)
      {
      doc_array->InsertNextValue(this->Internals->Documents[doc_id][word]);
      }
    archive->GetFieldData()->AddArray(doc_array);
    }

  // term-to-topic assignments
  for (int doc_id = 0; doc_id < this->GetNumberOfLocalDocuments(); ++doc_id)
    {
    vtksys_ios::ostringstream namebuf;
    namebuf << "local_topic_assignments_" << doc_id << "_of_" << this->GetNumberOfLocalDocuments();
    VTK_CREATE(vtkIntArray, assignment_array);
    assignment_array->SetName(namebuf.str().c_str());
    for (int word = 0; word < this->GetNumberOfWords(doc_id); ++word)
      {
      int topic = this->Internals->WordTopicAssignments[doc_id][word];
      assignment_array->InsertNextValue(topic);
      }
    archive->GetFieldData()->AddArray(assignment_array);
    }

  VTK_CREATE(vtkIntArray, docIdMapArray);
  for (int i = 0; i < this->GetNumberOfLocalDocuments(); ++i)
    {
    docIdMapArray->InsertNextValue(this->Internals->LocalToGlobalDocIdMap[i]);
    }
  docIdMapArray->SetName("local_to_global_doc_id_map");
  archive->GetFieldData()->AddArray(docIdMapArray);
}

// ----------------------------------------------------------------------

// XXX PARALLEL This will also need to be rewritten and should load
// one object per process (initially) and then redistribute across all
// processors if necessary

void
vtkPLatentDirichletAllocationMarkovChain::LoadSamplerState(vtkDataObject *archive)
{
  vtkVariantArray *metadata =
    vtkVariantArray::SafeDownCast(archive->GetFieldData()->GetAbstractArray(0));
  int local_document_count = metadata->GetValue(0).ToInt();
  int topic_count = metadata->GetValue(1).ToInt();
  double alpha = metadata->GetValue(2).ToDouble();
  double beta = metadata->GetValue(3).ToDouble();
  int vocab_size = metadata->GetValue(4).ToInt();
  int global_doc_count = metadata->GetValue(6).ToInt();

  try
    {
    if (!metadata)
      {
      throw std::runtime_error("Couldn't find metadata array in saved LDA chain state");
      }

    vtkStdString expected_name(SAVED_STATE_IDENTIFIER);
    if (expected_name != metadata->GetName())
      {
      vtksys_ios::ostringstream errbuf;
      errbuf << "ERROR: Wrong identifier string in saved sampler state.  Expected '"
             << SAVED_STATE_IDENTIFIER << "', got "
             << metadata->GetName() << ".";
      throw std::runtime_error(errbuf.str());
      }

    this->Alpha = alpha;
    this->Beta = beta;

    this->NumberOfTopics = topic_count;
    this->VocabularySize = vocab_size;

    this->NumberOfGlobalDocuments = global_doc_count;

    vtkDebugMacro( << "Metadata: local document count "
                   << local_document_count
                   << ", global document count "
                   << this->NumberOfGlobalDocuments
                   << ", alpha " << alpha
                   << ", beta " << beta
                   << ", topic_count " << topic_count
                   << ", vocabulary size " << vocab_size);

    IdToIdHashMap local_to_global_id_map;
    vtkIntArray *stored_hash =
      vtkIntArray::SafeDownCast(archive->GetFieldData()->GetArray("local_to_global_doc_id_map"));
    if (!stored_hash)
      {
      throw std::runtime_error("Couldn't find saved local->global doc IDs");
      }
    for (int i = 0; i < stored_hash->GetNumberOfTuples(); ++i)
      {
      local_to_global_id_map[i] = stored_hash->GetValue(i);
      }

    // Since AllocateCorpusArrays is expecting global document IDs we
    // have to use the hash we just loaded to fake the array contents.
    DocIdToSizeMap doc_sizes;
    for (vtkIdType doc_id = 0; doc_id < local_document_count; ++doc_id)
      {
      doc_sizes[local_to_global_id_map[doc_id]] =
        archive->GetFieldData()->GetArray(1 + doc_id)->GetNumberOfTuples();
      }

    this->Internals->AllocateCorpusArrays(doc_sizes);
    this->Internals->Initialize(local_document_count, vocab_size, topic_count, false);

    // Restore the documents in the corpus
    for (int doc_id = 0; doc_id < local_document_count; ++doc_id)
      {
      int array_index = doc_id + 1; // skip past metadata
      vtkIntArray *document = vtkIntArray::SafeDownCast(archive->GetFieldData()->GetArray(array_index));
      if (!document)
        {
        vtksys_ios::ostringstream errbuf;
        errbuf << "Couldn't find document " << doc_id
               << " in saved LDA chain state";
        throw std::runtime_error(errbuf.str().c_str());
        }

      for (int word = 0; word < document->GetNumberOfTuples(); ++word)
        {
        int term_id = document->GetValue(word);
        this->Internals->Documents[doc_id].push_back(term_id);
        this->Internals->WordTopicAssignments[doc_id].push_back(-1);
        }
      }

    // Restore the term assignments
    for (int doc_id = 0; doc_id < local_document_count; ++doc_id)
      {
      int array_index = doc_id + local_document_count + 1; // skip past metadata and documents
      vtkIntArray *assignment = vtkIntArray::SafeDownCast(archive->GetFieldData()->GetArray(array_index));
      if (!assignment)
        {
        vtksys_ios::ostringstream errbuf;
        errbuf << "Couldn't find topic assignment array " << doc_id
               << " in saved LDA chain state";
        throw std::runtime_error(errbuf.str().c_str());
        }

      for (int word = 0; word < assignment->GetNumberOfTuples(); ++word)
        {
        int topic_id = assignment->GetValue(word);
        // Going through this function instead of populating the
        // assignments by hand will automatically fill in the count
        // arrays
        this->AssignTermToTopic(doc_id, word, topic_id);
        }
      }
    }
  catch (vtksys_stl::runtime_error e)
    {
    vtkErrorMacro(<<"Error restoring LDA chain state: "
                  << e.what());
    return;
    }
  catch (...)
    {
    vtkErrorMacro(<<"Unknown exception while restoring LDA chain state");
    return;
    }
}

// ----------------------------------------------------------------------

// Compute the fraction of the corpus-total topic mass assigned to
// each topic

// XXX PARALLEL This will need to operate on local documents only and
// then do an all-reduce (maybe in the parent class) to combine all
// the pieces

void
vtkPLatentDirichletAllocationMarkovChain::GetTopicMasses(vtkDoubleArray *masses)
{
  masses->SetNumberOfTuples(this->GetNumberOfTopics());
  double total_mass = 0;
  DoubleVector mass_per_topic(this->GetNumberOfTopics(), 0);

  for (int doc_id = 0; doc_id < this->GetNumberOfLocalDocuments(); ++doc_id)
    {
    for (int topic_id = 0; topic_id < this->GetNumberOfTopics(); ++topic_id)
      {
      assert(static_cast<size_t>(topic_id) <
             this->Internals->AccumulatedTheta[doc_id].size());
      assert(static_cast<size_t>(doc_id) <
             this->Internals->AccumulatedTheta.size());

      double topic_mass_in_document = this->Internals->AccumulatedTheta[doc_id][topic_id];
      mass_per_topic[topic_id] += topic_mass_in_document;
      total_mass += topic_mass_in_document;
      }
    }

  vtkDebugMacro( << "GetTopicMasses: Total topic mass is " << total_mass << " for "
                 << this->GetNumberOfLocalDocuments() << " documents and "
                 << this->Internals->MatrixSampleCount << " theta samples");

  for (int t = 0; t < this->GetNumberOfTopics(); ++t)
    {
    masses->SetValue(t, mass_per_topic[t] / total_mass);
    }
}

// ----------------------------------------------------------------------

// Get the fraction of the mass in phi allocated to each individual term

void
vtkPLatentDirichletAllocationMarkovChain::GetTermMasses(vtkDoubleArray *masses)
{
  masses->SetNumberOfTuples(this->GetVocabularySize());
  double total_mass = 0;
  DoubleVector mass_per_term(this->GetVocabularySize(), 0);

  for (int term_id = 0; term_id < this->GetVocabularySize(); ++term_id)
    {
    for (int topic_id = 0; topic_id < this->GetNumberOfTopics(); ++topic_id)
      {
      assert(static_cast<size_t>(topic_id) <
             this->Internals->AccumulatedPhi.size());
      assert(static_cast<size_t>(term_id) <
             this->Internals->AccumulatedPhi[topic_id].size());

      double term_mass_in_topic = this->Internals->AccumulatedPhi[topic_id][term_id];
      mass_per_term[term_id] += term_mass_in_topic;
      total_mass += term_mass_in_topic;
      }
    }

  vtkDebugMacro( << "GetTermMasses: Total term mass is " << total_mass << " for "
                 << this->GetVocabularySize() << " terms and "
                 << this->Internals->MatrixSampleCount << " phi samples" );

  for (int t = 0; t < this->GetVocabularySize(); ++t)
    {
    masses->SetValue(t, mass_per_term[t] / total_mass);
    }
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::SetParameterValues(vtkDoubleArray *values)
{
  this->SetAlpha(values->GetValue(0));
  this->SetBeta(values->GetValue(1));
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::ResetOutputMatrices()
{
  this->Internals->MatrixSampleCount = 0;
  this->RunningHarmonicMeanDenominator = 0;

  DoubleVectorVector::size_type i;
  for (i = 0; i < this->Internals->AccumulatedTheta.size(); ++i)
    {
    DoubleVector::size_type count = this->Internals->AccumulatedTheta[i].size();
    this->Internals->AccumulatedTheta[i].assign(count, 0);
    }

  for (i = 0; i < this->Internals->AccumulatedPhi.size(); ++i)
    {
    DoubleVector::size_type count = this->Internals->AccumulatedPhi[i].size();
    this->Internals->AccumulatedPhi[i].assign(count, 0);
    }
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::FinalizeState()
{
  this->Internals->CompactForArchiving();
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::SyncTopicCountArrays()
{

//  IntVectorVector     TermInstancesPerTopic_GLOBAL;
//  IntVectorVector     TermInstancesPerTopic_LocalChanges;
//  IntVector           WordsPerTopic_GLOBAL;
//  IntVector           WordsPerTopic_LocalChanges;
//  IntVectorVector     TermInstancesPerTopic_Inference_GLOBAL;
//  IntVectorVector     TermInstancesPerTopic_Inference_LocalChanges;
//  IntVector           WordsPerTopic_Inference_GLOBAL;
//  IntVector           WordsPerTopic_Inference_LocalChanges;

  // Sanity check: preconditions: all elements of doc/topic and
  // term/topic arrays must be non-negative
  for (int doc_id = 0; doc_id < this->GetNumberOfLocalDocuments(); ++doc_id)
    {
    for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
      {
      assert(this->Internals->TopicInstancesPerDocument[doc_id][topic] >= 0);
      }
    }

  for (int term_id = 0; term_id < this->GetVocabularySize(); ++term_id)
    {
    for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
      {
      assert(this->Internals->TermInstancesPerTopic_GLOBAL[topic][term_id] >= 0);
      }
    }

  for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
    {
    assert(this->Internals->WordsPerTopic_GLOBAL[topic] >= 0);
    }

  vtkCommunicator *comm = this->Controller->GetCommunicator();
  int myId = this->Controller->GetLocalProcessId();

  if (comm == 0)
    {
    vtkErrorMacro("No communicator on controller.");
    return;
    }

  // Note: AllReduce is the equivalent of a Reduce to one processor,
  //       followed by a broadcast of the result to all processors.
  //       The final result is stored in the second argument of the
  //       function, which is in this case *_GLOBAL.


  // Implementation note: AllReduce overwrites the contents of the
  // destination array instead of adding to them.  We're going to fold
  // in the current contents of GLOBAL before the AllReduce to make
  // sure everything gets included.

  // Our data is stored as STL vectors. C++ says we can get a contiguous
  // chunk of memory by using &v[0]

  // Sanity check -- can be removed after debugging is done.
  if(this->Internals->WordsPerTopic_LocalChanges.size() !=
     this->Internals->WordsPerTopic_GLOBAL.size())
    {
    vtkErrorMacro("MyRank = " << myId << " Cannot perform AllReduce.  Wrong size.");
    return;
    }

  // Fold in GLOBAL state arrays for WordsPerTopic and
  // TermInstancesPerTopic to LocalChanges so that AllReduce will pick
  // them up
  for (int topic = myId; topic < this->GetNumberOfTopics();
       topic += this->Controller->GetNumberOfProcesses())
    {
    this->Internals->WordsPerTopic_LocalChanges[topic] +=
      this->Internals->WordsPerTopic_GLOBAL[topic];
    }

  for (int termId = myId; termId < this->VocabularySize;
       termId += this->Controller->GetNumberOfProcesses())
    {
    for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
      {
      this->Internals->TermInstancesPerTopic_LocalChanges[topic][termId] +=
        this->Internals->TermInstancesPerTopic_GLOBAL[topic][termId];
      }
    }

  // Sync WordsPerTopic and TermInstancesPerTopic LocalChanges to GLOBAL
  comm->AllReduce( & (this->Internals->WordsPerTopic_LocalChanges[0]),
                   & (this->Internals->WordsPerTopic_GLOBAL[0]),
                   static_cast<int>(this->Internals->WordsPerTopic_LocalChanges.size()),
                   vtkCommunicator::SUM_OP);

  for (int topic = 0; topic < this->NumberOfTopics; ++topic)
    {
    // Sanity check -- can be removed after debugging is done.
    if(this->Internals->TermInstancesPerTopic_LocalChanges[topic].size() !=
       this->Internals->TermInstancesPerTopic_GLOBAL[topic].size())
      {
      vtkErrorMacro("MyRank = " << myId << " Cannot perform AllReduce.  Wrong size.");
      return;
      }

    comm->AllReduce( &(this->Internals->TermInstancesPerTopic_LocalChanges[topic])[0],
                     &(this->Internals->TermInstancesPerTopic_GLOBAL[topic])[0],
                     static_cast<int>(this->Internals->TermInstancesPerTopic_LocalChanges[topic].size()),
                     vtkCommunicator::SUM_OP);
    }


  // That's the main state arrays taken care of.  If we're doing
  // inference we alos need to handle the _Inference equivalents so
  // that we can compute the corpus likelihood for the documents we're
  // projecting.
  if (this->GetTopicsReadOnly() && this->GetInferenceEnabled())
    {
    for (int topic = myId; topic < this->GetNumberOfTopics();
         topic += this->Controller->GetNumberOfProcesses())
      {
      this->Internals->WordsPerTopic_Inference_LocalChanges[topic] +=
        this->Internals->WordsPerTopic_Inference_GLOBAL[topic];
      }

    for (int termId = myId; termId < this->VocabularySize;
         termId += this->Controller->GetNumberOfProcesses())
      {
      for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
        {
        this->Internals->TermInstancesPerTopic_Inference_LocalChanges[termId][topic] +=
          this->Internals->TermInstancesPerTopic_Inference_GLOBAL[termId][topic];
        }
      }

    // Sanity check -- can be removed after debugging is done.
    if(this->Internals->WordsPerTopic_Inference_LocalChanges.size() !=
       this->Internals->WordsPerTopic_Inference_GLOBAL.size())
      {
      vtkErrorMacro("MyRank = " << myId << " Cannot perform AllReduce.  Wrong size.");
      return;
      }

    comm->AllReduce( &(this->Internals->WordsPerTopic_Inference_LocalChanges[0]),
                     &(this->Internals->WordsPerTopic_Inference_GLOBAL[0]),
                     static_cast<int>(this->Internals->WordsPerTopic_Inference_LocalChanges.size()),
                     vtkCommunicator::SUM_OP);

    for (int topic = 0; topic < this->NumberOfTopics; ++topic)
      {

      if(this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic].size() !=
         this->Internals->TermInstancesPerTopic_Inference_GLOBAL[topic].size())
        {
        vtkErrorMacro("MyRank = " << myId << " Cannot perform AllReduce.  Wrong size.");
        return;
        }

      comm->AllReduce( &(this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic])[0],
                       &(this->Internals->TermInstancesPerTopic_Inference_GLOBAL[topic])[0],
                       static_cast<int>(this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic].size()),
                       vtkCommunicator::SUM_OP);

      }
    } // done handling _Inference arrays
  // done with SyncTopicCountArrays

  // Zero out all of the LocalChanges arrays for the next iteration
  this->Internals->WordsPerTopic_LocalChanges.assign(this->GetNumberOfTopics(), 0);
  this->Internals->WordsPerTopic_Inference_LocalChanges.assign(this->GetNumberOfTopics(), 0);

  for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
    {
    this->Internals->TermInstancesPerTopic_LocalChanges[topic].assign(this->GetVocabularySize(), 0);
    this->Internals->TermInstancesPerTopic_Inference_LocalChanges[topic].assign(this->GetVocabularySize(), 0);
    }

  // Sanity check: preconditions: all elements of term/topic arrays
  // must be non-negative
  for (int term_id = 0; term_id < this->GetVocabularySize(); ++term_id)
    {
    for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
      {
      assert(this->Internals->TermInstancesPerTopic_GLOBAL[topic][term_id] >= 0);
      }
    }

  for (int topic = 0; topic < this->GetNumberOfTopics(); ++topic)
    {
    assert(this->Internals->WordsPerTopic_GLOBAL[topic] >= 0);
    }

}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::DumpChainState(ostream &out)
{
  vtkErrorMacro(<<"DumpChainState unimplemented");
}

// ----------------------------------------------------------------------

void
vtkPLatentDirichletAllocationMarkovChain::SortTopicsByWeight()
{
  vtkSmartPointer<vtkDoubleArray> local_masses = vtkSmartPointer<vtkDoubleArray>::New();
  this->GetTopicMasses(local_masses);

  // That only gave us the topic masses on this processor.  To do this
  // right we need the masses across all processors.

  vtkCommunicator *comm = this->Controller->GetCommunicator();
  if (comm == 0)
    {
    vtkErrorMacro("No communicator on controller.");
    return;
    }

  vtkSmartPointer<vtkDoubleArray> masses = vtkSmartPointer<vtkDoubleArray>::New();
  masses->SetNumberOfTuples(local_masses->GetNumberOfTuples());
  comm->AllReduce( local_masses, masses, vtkCommunicator::SUM_OP);

  // Now we can proceed as normal.  Since topics are just labels and
  // don't live on any particular processor, all we need to do is
  // re-label and permute our local data.

  vtkSmartPointer<vtkIdTypeArray> old_topic_from_new
    = vtkSmartPointer<vtkIdTypeArray>::New();

  this->GetTopicMasses(masses);
  vtkTextAnalysisUtilities::SortIndicesByDescendingValue(masses, old_topic_from_new);
  int document_count = static_cast<int>(this->Internals->AccumulatedTheta.size());
  int topic_count = static_cast<int>(this->Internals->AccumulatedTheta[0].size());
  int term_count = static_cast<int>(this->Internals->AccumulatedPhi[0].size());

  // Rewrite the document/topic matrix
  for (int doc = 0; doc < document_count; ++doc)
    {
    DoubleVector theta_scratch = this->Internals->AccumulatedTheta[doc];
    for (int new_topic = 0; new_topic < topic_count; ++new_topic)
      {
      int old_topic = old_topic_from_new->GetValue(new_topic);
      theta_scratch[new_topic] = this->Internals->AccumulatedTheta[doc][old_topic];
      }
    this->Internals->AccumulatedTheta[doc] = theta_scratch;
    }

  // Rewrite the topic/term matrix
  DoubleVectorVector original_phi = this->Internals->AccumulatedPhi;
  for (int new_topic = 0; new_topic < topic_count; ++new_topic)
    {
    int old_topic = old_topic_from_new->GetValue(new_topic);
    for (int term = 0; term < term_count; ++term)
      {
      this->Internals->AccumulatedPhi[new_topic][term] =
        original_phi[old_topic][term];
      }
    }

  // Rewrite the internal state arrays
  vtksys_stl::vector<int> new_topic_from_old(topic_count);
  for (int new_topic = 0;
       new_topic < old_topic_from_new->GetNumberOfTuples(); ++new_topic)
    {
    int old_topic = old_topic_from_new->GetValue(new_topic);
    new_topic_from_old[old_topic] = new_topic;
    }

  for (int doc = 0; doc < document_count; ++doc)
    {
    for (int word = 0; word < static_cast<int>(this->Internals->WordTopicAssignments[doc].size()); ++word)
      {
      int old_topic = this->Internals->WordTopicAssignments[doc][word];
      this->RemoveTermTopicAssignment(doc, word);
      this->AssignTermToTopic(doc, word, new_topic_from_old[old_topic]);
      }
    }

  // All of those term reassignments just affected the local counts.
  // We need to tell everyone else about it and find out what they
  // changed.
  this->SyncTopicCountArrays();
}
