/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkMultiProcessController.h>
#include <vtkObjectFactory.h>
#include <vtkRoundRobinPDocumentReaderStrategy.h>
#include <vtkStringArray.h>

#include <boost/filesystem/v3/operations.hpp>
#include <boost/filesystem.hpp>


vtkStandardNewMacro(vtkRoundRobinPDocumentReaderStrategy);

vtkRoundRobinPDocumentReaderStrategy::vtkRoundRobinPDocumentReaderStrategy()
{
}

vtkRoundRobinPDocumentReaderStrategy::~vtkRoundRobinPDocumentReaderStrategy()
{
}

void vtkRoundRobinPDocumentReaderStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkRoundRobinPDocumentReaderStrategy::LoadFiles(
  vtkMultiProcessController* const controller,
  const PathList& files,
  const PathList& directories,
  const PathList& recursive_directories,
  vtkStringArray* uri_array,
  vtkStringArray* contents_array
  )
{
  vtkIdType file_index = 0;
  int documents_loaded = 0;

  // Load files ...
  for(PathList::const_iterator file = files.begin(); file != files.end(); ++file)
    {
    const vtkIdType file_processor = file_index++ % controller->GetNumberOfProcesses();
    if(file_processor == controller->GetLocalProcessId())
      {
      ++ documents_loaded;
      this->LoadLocalFile(*file, uri_array, contents_array);
      }
    }

  // Load directories ...
  for(PathList::const_iterator directory = directories.begin(); directory != directories.end(); ++directory)
    {
    boost::filesystem::directory_iterator end;
    for(boost::filesystem::directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(!is_regular_file(file->status()))
        continue;

      const vtkIdType file_processor = file_index++ % controller->GetNumberOfProcesses();
      if(file_processor == controller->GetLocalProcessId())
        {
        ++ documents_loaded;
        this->LoadLocalFile(file->path().string(), uri_array, contents_array);
        }
      }
    }

  // Load recursive directories ...
  for(PathList::const_iterator directory = recursive_directories.begin(); directory != recursive_directories.end(); ++directory)
    {
    boost::filesystem::recursive_directory_iterator end;
    for(boost::filesystem::recursive_directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(!is_regular_file(file->status()))
        continue;

      const vtkIdType file_processor = file_index++ % controller->GetNumberOfProcesses();
      if(file_processor == controller->GetLocalProcessId())
        {
        ++ documents_loaded;
        this->LoadLocalFile(file->path().string(), uri_array, contents_array);
        }
      }
    }
  return documents_loaded;
}
