/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMPI.h"
#include "vtkMPICommunicator.h"
#include "vtkObjectFactory.h"
#include "vtkPTermDictionaryCommunicator.h"
#include "vtkPTermDictionaryMapReduce.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"
#include <vtkTimerLog.h>

#include <boost/scoped_ptr.hpp>

#include <map>
#include <stdexcept>

#include <keyvalue.h>
#include <mapreduce.h>
using namespace MAPREDUCE_NS;

///////////////////////////////////////////////////////////////////////////////
// map_terms

// Maps each term in a collection of terms to a single mapreduce key with empty value.
static void map_terms(int task, KeyValue* key_values, void* data)
{
  vtkPTermDictionaryCommunicator::UniqueSortedTerms& terms = *reinterpret_cast<vtkPTermDictionaryCommunicator::UniqueSortedTerms*>(data);

  for(vtkPTermDictionaryCommunicator::UniqueSortedTerms::const_iterator term = terms.begin(); term != terms.end(); ++term)
    key_values->add(const_cast<char*>(term->utf8_str()), term->byte_count() + 1, 0, 0);
}

///////////////////////////////////////////////////////////////////////////////
// collect_terms

// Inserts the key from a mapreduce multikey into a container of terms.
static void collect_terms(char* key, int keybytes, char* multivalue, int nvalues, int* valuebytes, KeyValue* key_values, void* data)
{
  vtkPTermDictionaryCommunicator::Terms& terms = *reinterpret_cast<vtkPTermDictionaryCommunicator::Terms*>(data);
  terms.push_back(vtkUnicodeString::from_utf8(key));
}

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryMapReduce


vtkStandardNewMacro(vtkPTermDictionaryMapReduce);

vtkPTermDictionaryMapReduce::vtkPTermDictionaryMapReduce() :
  Controller(0),
  Gather(false)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");

  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);

  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPTermDictionaryMapReduce::~vtkPTermDictionaryMapReduce()
{
  this->SetController(0);
}

void vtkPTermDictionaryMapReduce::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkPTermDictionaryMapReduce::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}

int vtkPTermDictionaryMapReduce::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    vtkMPICommunicator* const mpi_communicator = vtkMPICommunicator::SafeDownCast(this->Controller->GetCommunicator());
    if(!mpi_communicator)
      throw std::runtime_error("Process controller must provide an MPI communicator.");

    vtkUnicodeStringArray* const input_term_array = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!input_term_array)
      throw std::runtime_error("missing input term array");

    vtkPTermDictionaryCommunicator communicator(mpi_communicator);

    // Compute the set of unique local terms ...
    vtkPTermDictionaryCommunicator::UniqueSortedTerms terms;
    vtkPTermDictionaryCommunicator::ConvertTerms(*input_term_array, terms);

    // Compute a distributed globally-unique list of terms ...
    vtkPTermDictionaryCommunicator::Terms distributed_terms;
    boost::scoped_ptr<MapReduce> map_reduce(new MapReduce(*mpi_communicator->GetMPIComm()->GetHandle()));

    map_reduce->map(this->Controller->GetNumberOfProcesses(), &map_terms, &terms);

    map_reduce->collate(0);

    map_reduce->reduce(&collect_terms, &distributed_terms);

    // Everybody broadcasts their subset of the distributed terms to everybody else ...
    vtkPTermDictionaryCommunicator::Terms global_terms;

    if(this->Gather)
      {
      communicator.AllGatherTerms(distributed_terms, terms);
      }
    else
      {
      for(int i = 0; i < this->Controller->GetNumberOfProcesses(); ++i)
        {
        communicator.BroadcastTerms(distributed_terms, i, terms);
        }
      }

    // Insert terms into the term dictionary ...
    vtkUnicodeStringArray* const output_dictionary = vtkUnicodeStringArray::New();
    output_dictionary->SetName("text");
    vtkPTermDictionaryCommunicator::ConvertTerms(terms, *output_dictionary);

    // Configure our outputs ...
    vtkTable* const output = vtkTable::GetData(outputVector, 0);
    output->AddColumn(output_dictionary);
    output_dictionary->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "caught unknown exception." << endl);
    }

  return 0;
}
