/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkMultiProcessController.h>
#include <vtkObjectFactory.h>
#include <vtkUnsortedBytePDocumentReaderStrategy.h>
#include <vtkStringArray.h>

#include <boost/filesystem/v3/operations.hpp>
#include <boost/filesystem.hpp>
// #include <boost/filesystem/operations.hpp>

#include <map>

//////////////////////////////////////////////////////////////////////////////////////
// vtkUnsortedBytePDocumentReaderStrategy::Implementation


vtkStandardNewMacro(vtkUnsortedBytePDocumentReaderStrategy);

vtkUnsortedBytePDocumentReaderStrategy::vtkUnsortedBytePDocumentReaderStrategy()
{
}

vtkUnsortedBytePDocumentReaderStrategy::~vtkUnsortedBytePDocumentReaderStrategy()
{
}

void vtkUnsortedBytePDocumentReaderStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

typedef std::multimap<vtkIdType, vtkIdType> ProcessorSizesT;

// Helper function that assigns each file to a processor, keeping-track of how many
// files / bytes have been assigned to each processor, and returning true if the
// given file was assigned to the local processor.
static bool LocalFile(
  vtkMultiProcessController* const controller,
  const vtkIdType file_index,
  const vtkPDocumentReaderStrategy::FileSizes& file_sizes,
  ProcessorSizesT& processor_sizes)
{
  // Get information about the file ...
  const vtkIdType file_bytes = file_sizes[file_index];

  // Get information about the processor with the lowest number of bytes ...
  const vtkIdType processor_bytes = processor_sizes.begin()->first;
  const vtkIdType processor_id = processor_sizes.begin()->second;

  // Add each file to the processor with the lowest number of bytes ...
  processor_sizes.erase(processor_sizes.begin());
  processor_sizes.insert(std::make_pair(processor_bytes + file_bytes, processor_id));

  // If this is a local file, load it ...
  return processor_id == controller->GetLocalProcessId();
}

int vtkUnsortedBytePDocumentReaderStrategy::LoadFiles(
  vtkMultiProcessController* const controller,
  const PathList& files,
  const PathList& directories,
  const PathList& recursive_directories,
  vtkStringArray* uri_array,
  vtkStringArray* contents_array
  )
{
  int documents_loaded = 0;

  // Use processor 0 to collect file sizes for every file, then broadcast the results to everyone ...
  FileSizes file_sizes;
  this->LookupFileSizes(controller, files, directories, recursive_directories, file_sizes);

  // Setup a map to keep track of processors, sorted in order of increasing numbers of bytes ...
  ProcessorSizesT processor_sizes;
  for(vtkIdType i = 0; i != controller->GetNumberOfProcesses(); ++i)
    processor_sizes.insert(std::make_pair(0, i));

  // Iterate through our list of files, assigning each to the processor with the fewest number of bytes ...
  vtkIdType file_index = 0;
  for(PathList::const_iterator file = files.begin(); file != files.end(); ++file)
    {
    if(LocalFile(controller, file_index++, file_sizes, processor_sizes))
      {
      ++ documents_loaded;
      this->LoadLocalFile(*file, uri_array, contents_array);
      }
    }
  for(PathList::const_iterator directory = directories.begin(); directory != directories.end(); ++directory)
    {
    boost::filesystem::directory_iterator end;
    for(boost::filesystem::directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(!boost::filesystem::is_regular_file(file->status()))
        continue;

      if(LocalFile(controller, file_index++, file_sizes, processor_sizes))
        {
        ++ documents_loaded;
        this->LoadLocalFile(file->path().string(), uri_array, contents_array);
        }
      }
    }
  for(PathList::const_iterator directory = recursive_directories.begin(); directory != recursive_directories.end(); ++directory)
    {
    boost::filesystem::recursive_directory_iterator end;
    for(boost::filesystem::recursive_directory_iterator file(directory->c_str()); file != end; ++file)
      {
      if(!boost::filesystem::is_regular_file(file->status()))
        continue;

      if(LocalFile(controller, file_index++, file_sizes, processor_sizes))
        {
        ++ documents_loaded;
        this->LoadLocalFile(file->path().string(), uri_array, contents_array);
        }
      }
    }

  return documents_loaded;
}
