/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

#include <vtkMultiProcessController.h>
#include <vtkObjectFactory.h>
#include <vtkSortedBytePDocumentReaderStrategy.h>
#include <vtkStringArray.h>

#include <boost/filesystem.hpp>

#include <map>

//////////////////////////////////////////////////////////////////////////////////////
// vtkSortedBytePDocumentReaderStrategy::Implementation


vtkStandardNewMacro(vtkSortedBytePDocumentReaderStrategy);

vtkSortedBytePDocumentReaderStrategy::vtkSortedBytePDocumentReaderStrategy()
{
}

vtkSortedBytePDocumentReaderStrategy::~vtkSortedBytePDocumentReaderStrategy()
{
}

void vtkSortedBytePDocumentReaderStrategy::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkSortedBytePDocumentReaderStrategy::LoadFiles(
  vtkMultiProcessController* const controller,
  const PathList& files,
  const PathList& directories,
  const PathList& recursive_directories,
  vtkStringArray* uri_array,
  vtkStringArray* contents_array
  )
{
  int documents_loaded = 0;

  // We don't support loading directories at this time ...
  if(directories.size() || recursive_directories.size())
    throw std::runtime_error("vtkSortedBytePDocumentReaderStrategy doesn't support loading directories.");

  // Use processor 0 to collect file sizes for every file, then broadcast the results to everyone ...
  FileSizes file_sizes;
  this->LookupFileSizes(controller, files, directories, recursive_directories, file_sizes);

  // Setup a map to keep track of processors, sorted in order of increasing numbers of bytes ...
  std::multimap<vtkIdType, vtkIdType> processor_byte_counts;
  for(vtkIdType i = 0; i != controller->GetNumberOfProcesses(); ++i)
    processor_byte_counts.insert(std::make_pair(0, i));

  // Organize the list of files into a map, sorted in order of decreasing length ...
  typedef std::multimap<vtkIdType, vtkIdType, std::greater<vtkIdType> > file_size_map_t;
  file_size_map_t file_size_map;
  for(vtkIdType i = 0; i != static_cast<vtkIdType>(files.size()); ++i)
    {
    file_size_map.insert(std::make_pair(file_sizes[i], i));
    }

  // Scan through our list of files in order of decreasing length ...
  for(file_size_map_t::const_iterator file = file_size_map.begin(); file != file_size_map.end(); ++file)
    {
    // Get information about the file ...
    const vtkIdType file_bytes = file->first;
    const vtkIdType file_index = file->second;

    // Get information about the processor with the lowest number of bytes ...
    const vtkIdType processor_bytes = processor_byte_counts.begin()->first;
    const vtkIdType processor_id = processor_byte_counts.begin()->second;

    // Add each file to the processor with the lowest number of bytes ...
    processor_byte_counts.erase(processor_byte_counts.begin());
    processor_byte_counts.insert(std::make_pair(processor_bytes + file_bytes, processor_id));

    // If this is a local file, load it ...
    if(processor_id == controller->GetLocalProcessId())
      {
      documents_loaded += 1;
      this->LoadLocalFile(files[file_index], uri_array, contents_array);
      }
    }

  return documents_loaded;
}
