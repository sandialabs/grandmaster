/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPTermDictionaryNTo1_h
#define __vtkPTermDictionaryNTo1_h

#include <titanMPITextAnalysis.h>

#include <vtkTableAlgorithm.h>
#include <vtkMultiProcessController.h>

/// \class vtkPTermDictionaryNTo1 vtkPTermDictionaryNTo1.h <MPITextAnalysis/vtkPTermDictionaryNTo1.h>
/// \brief Generates a dictionary of unique terms.
///
///  vtkPTermDictionaryNTo1 reorganizes a distributed table containing (potentially duplicated)
///  terms into a dictionary where every term appears exactly once.
///
///  Inputs:
///    Input port 0: (required) A vtkTable containing a "text" column.
///
///  Outputs:
///    Output port 0: A dense dictionary of unique terms - a vtkDenseArray<vtkUnicodeString> with two dimensions and one column.
///
///  Use SetInputArrayToProcess(0, ...) to specify the input "text" array.
///
/// \warning
///  vtkPTermDictionaryNTo1 uses a brain-dead algorithm that sends each
///  processor's list of terms to the root to eliminate duplicates, and the results are
///  broadcast back.  We know that smarter algorithms are possible, along the lines of a
///  distributed merge sort or a distributed hash table.
///
/// \sa
///  vtkPTermDictionaryNToN, vtkFeatureDictionary
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPTermDictionaryNTo1 :
  public vtkTableAlgorithm
{
public:
  static vtkPTermDictionaryNTo1* New();
  vtkTypeMacro(vtkPTermDictionaryNTo1, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Get/Set the parallel controller.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

  vtkSetMacro(Gather, int);
  vtkGetMacro(Gather, int);

//BTX
protected:
  vtkPTermDictionaryNTo1();
  ~vtkPTermDictionaryNTo1();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPTermDictionaryNTo1(const vtkPTermDictionaryNTo1&); // Not implemented
  void operator=(const vtkPTermDictionaryNTo1&);   // Not implemented

  vtkMultiProcessController* Controller;
  int Gather;
//ETX
};

#endif
