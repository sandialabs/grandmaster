/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkFeatureTableToDictionaryAndMatrix vtkFeatureTableToDictionaryAndMatrix.h <MPITextAnalysis/vtkFeatureTableToDictionaryAndMatrix.h>
/// \brief Convenience class encapsulating the document prep pipeline from feature table to term dictionary and (unweighted) term/doc matrix
///
///
///  This filter contains part of the document preparation pipeline for
///  LDA.  It can use an existing term dictionary and will build one
///  itself if necessary.
///
///  The feature table should be input 0.  The term dictionary, if
///  available, should be input 1.  Output 0 will be the term/doc
///  matrix.  Output 1 will be the term dictionary.

#ifndef __vtkFeatureTableToDictionaryAndMatrix_h
#define __vtkFeatureTableToDictionaryAndMatrix_h

#include <titanMPITextAnalysis.h>
#include "vtkArrayDataAlgorithm.h"
#include "vtkToolkits.h" // needed for VTK_USE_MPI
#include "vtkSmartPointer.h" // for smart pointer ivars

class vtkCallbackCommand;
class vtkFeatureDictionary;
class vtkFrequencyMatrix;
class vtkInformation;
class vtkInformationVector;
class vtkMultiProcessController;
class vtkPTermDictionaryMapReduce;
class vtkTable;
class vtkTextExtraction;
class vtkTokenizer;
class vtkTokenValueFilter;


class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkFeatureTableToDictionaryAndMatrix : public vtkArrayDataAlgorithm
{
public:
  vtkTypeMacro(vtkFeatureTableToDictionaryAndMatrix, vtkArrayDataAlgorithm);
  static vtkFeatureTableToDictionaryAndMatrix *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  /// This method will give you the output port from the dictionary
  /// source.  If you supplied a term dictionary as one of the inputs
  /// then the data object here will just be a shallow copy of the one
  /// you supplied.
  vtkAlgorithmOutput *GetDictionaryOutputPort();

  /// This (convenience) method will give you the term/doc matrix
  /// output port.
  vtkAlgorithmOutput *GetTermDocumentMatrixOutputPort();

#if defined(VTK_USE_MPI)
  /// If you are using this class in parallel you need to call this
  /// method first.
  void SetController(vtkMultiProcessController *controller);
#endif

//BTX
protected: // methods
  vtkFeatureTableToDictionaryAndMatrix();
  ~vtkFeatureTableToDictionaryAndMatrix();

  int RequestData(vtkInformation *, vtkInformationVector **, vtkInformationVector *);
  int FillInputPortInformation(int port, vtkInformation *info);
  int FillOutputPortInformation(int port, vtkInformation *info);

  void ConnectPipelineForDictionaryBuild(vtkInformationVector **invec);
  void ConnectPipelineForExistingDictionary(vtkInformationVector **invec);

protected: // ivars
#if defined(VTK_USE_MPI)
  vtkMultiProcessController *Controller;
#endif

  // here are the components of the encapsulated pipeline -- the user
  // won't need to access all of them so we'll expose only the ones
  // that have useful parameters
  vtkSmartPointer<vtkFeatureDictionary>         SerialDictionaryBuilder;
  vtkSmartPointer<vtkFrequencyMatrix>           TermDocumentMatrixBuilder;
#if defined(VTK_USE_MPI)
  vtkSmartPointer<vtkPTermDictionaryMapReduce>  ParallelDictionaryBuilder;
#endif

private:
  vtkFeatureTableToDictionaryAndMatrix(const vtkFeatureTableToDictionaryAndMatrix &);
  void operator=(const vtkFeatureTableToDictionaryAndMatrix &);
//ETX
};

#endif
