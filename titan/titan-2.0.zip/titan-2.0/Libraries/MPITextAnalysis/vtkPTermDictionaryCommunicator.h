/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPTermDictionaryCommunicator_h
#define __vtkPTermDictionaryCommunicator_h

#include <titanMPITextAnalysis.h>

#include <vtkDenseArray.h>
#include <vtkMPICommunicator.h>
#include <vtkSmartPointer.h>
#include <vtkUnicodeString.h>
#include <vtkUnicodeStringArray.h>

#include <set>
#include <string>

/// \class vtkPTermDictionaryCommunicator vtkPTermDictionaryCommunicator.h <MPITextAnalysis/vtkPTermDictionaryCommunicator.h>
/// \brief Helper class for implementing term dictionary filters.
///
/// \sa
///  vtkPTermDictionaryNTo1, vtkPTermDictionaryNToN, vtkPTermDictionaryRoundRobin
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPTermDictionaryCommunicator
{
public:
  vtkPTermDictionaryCommunicator(vtkCommunicator* communicator);

  /// Defines storage for a collection of unique, sorted terms
  typedef std::set<vtkUnicodeString> UniqueSortedTerms;
  /// Defines storage for a collection of terms
  typedef std::vector<vtkUnicodeString> Terms;

  class NoBlockRequest
  {
  public:
    void Wait();

  private:
    friend class vtkPTermDictionaryCommunicator;

    std::string SendBuffer;
    unsigned long SendByteCount;
    vtkMPICommunicator::Request SendByteCountRequest;
    vtkMPICommunicator::Request SendDataRequest;
  };

  static void ConvertTerms(vtkUnicodeStringArray& source, UniqueSortedTerms& terms);

  void SendTerms(const UniqueSortedTerms& terms, int recipient);

  void ReceiveTerms(int sender, UniqueSortedTerms& terms);

  template<typename LocalT, typename GlobalT>
  void BroadcastTerms(const LocalT& local_terms, int sender, GlobalT& global_terms);

  void NoBlockSendTerms(const UniqueSortedTerms& terms, int recipient, NoBlockRequest& request);

  template<typename LocalT, typename GlobalT>
  void GatherTerms(const LocalT& local_terms, int recipient, GlobalT& global_terms);

  template<typename LocalT, typename GlobalT>
  void AllGatherTerms(const LocalT& local_terms, GlobalT& global_terms);

  template<typename ContainerT>
  static void ConvertTerms(const ContainerT& terms, vtkUnicodeStringArray& dictionary);

  vtkIdType GetBytesSent() const;
  vtkIdType GetTermsSent() const;

  template<typename ContainerT>
  static void PackTerms(const ContainerT& terms, std::string& buffer);

  static void UnpackTerms(const std::string& buffer, UniqueSortedTerms& terms);
  static void UnpackTerms(const std::string& buffer, Terms& terms);

private:
  vtkSmartPointer<vtkCommunicator> Communicator;
  vtkIdType BytesSent;
  vtkIdType TermsSent;
};

#include "vtkPTermDictionaryCommunicator.txx"

#endif
