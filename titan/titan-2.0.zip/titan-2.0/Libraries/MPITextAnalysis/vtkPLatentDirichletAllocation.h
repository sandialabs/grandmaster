/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkPLatentDirichletAllocation vtkPLatentDirichletAllocation.h <MPITextAnalysis/vtkPLatentDirichletAllocation.h>
/// \brief Perform LDA decomposition on a corpus of documents
///
///
///
///  Latent Dirichlet Allocation (LDA) is an analysis technique that
///  operates on a corpus of documents composed of terms.  These
///  documents don't have to be text -- you're free to define 'document'
///  and 'term' any way you like.
///
///  The LDA algorithm decomposes each document into a weighted mixture
///  of topics such that the weights for each document add up to 1.  A
///  topic, in turn, is a weighted set of terms whose weights all add up
///  to 1.
///
///  This particular implementation implements LDA using Gibbs sampling.
///  For more details on the algorithm please see the following paper:
///
///  Mark Steyvers and Tom Griffiths. "Probabilistic Topic Models."  In
///  T. Landauer, D. McNamara, S. Dennis and W. Kintsch (eds), "Latent
///  Semantic Analysis: A Road to Meaning".
///
///  I referred to the following code during implementation:
///
///  http://arbylon.net/projects/LdaGibbsSampler.java
///
/// \par Usage :
///
///  INPUT:
///
///  0.  REQUIRED: the corpus of documents as a term/document frequency
///      matrix.  Note that LDA does not support matrix weighting the
///      way LSA does: you need to supply the UNWEIGHTED matrix.
///      Topic decomposition will be done on this corpus.
///
///  1.  OPTIONAL: a saved chain state that came previously from the
///      GetSamplerState() method.  The document corpus in this chain
///      state must use the same term IDs as the documents in input 0.
///      term/document frequency matrix.  This corpus must use the same
///      term IDs as the documents in input 0.  The best way to
///      accomplish this is to use the same vtkFeatureDictionary for
///      inputs #0 and #1.  This will be used as a starting state for
///      inference -- that is, the documents in input #0 will be
///      decomposed into the topics already contained in input #1.
///
///  See Testing/Cxx/TestLatentDirichletAllocation.cxx for a complete
///  example of how to generate this format starting from a collection
///  of documents.
///
///
///  PARAMETERS:
///
///  LDA operation is controlled by the following parameters:
///
///  - NumberOfTopics: how many topics to extract from the corpus.
///    There are (as yet) no fixed guidelines for how to choose this.
///    Defaults to 10, which is almost certainly too low.
///
///  - Alpha, Beta: "Magic" parameters that control the structure of the
///    Dirichlet prior.  Typical values for these are Alpha = 50 /
///    #topics and Beta = 0.01.  The filter will set these
///    automatically for you unless you specify your own values.
///
///  - BurnInIterations: Since the initial state of the Markov chain is
///    random we need to run it for a while in order to reach a
///    converged state.  We call this "burning in" the chain.  We only
///    begin to sample the Phi and Theta matrices after the burn-in
///    period is complete.  A typical value for this is 1000 iterations.
///
///  - SamplingIterations: Once the chain is burned in we run for a
///    while longer in order to compute Monte Carlo samples of the
///    converged distribution.  A typical value for this is (also) 1000
///    iterations.
///
///  - SamplingInterval: The state of the Markov chain exhibits high
///    temporal correlation from one iteration to the next.  In order to
///    get a better estimate of the result distribution we wait between
///    samples.  A typical value for this parameter is 100 iterations.
///
///  OUTPUT:
///
///  Output #0: a breakdown of documents in terms of topics.  This is a
///  vtkArrayData containing three arrays:
///
///  Array 0: vtkDenseArray<double>: the Theta matrix (documents x
///  topics) describing each document as a mixture of topics.  The
///  weights within each row sum to 1.
///
///  Array 1: vtkDenseArray<double>: the relative weight of each
///           individual topic through the whole corpus.  These weights
///           sum to 1.
///
///  Array 2: vtkDenseArray<vtkIdType>: topic IDs sorted in descending
///           order according to their weight.
///
///  Output #1: a breakdown of topics as mixtures of terms.  This is
///  also a vtkArrayData containing three arrays:
///
///  Array 0: vtkDenseArray<double>: the Phi matrix (topics x terms)
///           describing each topic as a weighted sum of terms.  The
///           weights within each row sum to 1.
///
///  Array 1: vtkDenseArray<double>: the relative weight of each
///           individual term through the whole corpus.  These weights
///           sum to 1.
///
///  Array 2: vtkDenseArray<vtkIdType>: term IDs sorted in descending
///           order according to their weights.
///
///  Output #2: the final state of the Gibbs sampler stored in a
///  vtkDataObject.  This can be used as input to another LDA instance
///  in order to do inference on new documents.
///
///
/// \sa
///  vtkPLatentDirichletAllocationMarkovChain
///
/// \warning
///
///  You may get better results if you filter the input to discard any
///  terms that occur in fewer than D documents (where D is small
///  compared to the size of the corpus).


#ifndef __vtkPLatentDirichletAllocation_h
#define __vtkPLatentDirichletAllocation_h

#include <titanMPITextAnalysis.h>
#include "vtkLatentDirichletAllocation.h"
#include "vtkSmartPointer.h" // for vtkSmartPointer

class vtkArray;
class vtkArrayData;
class vtkDoubleArray;
class vtkAbstractLatentDirichletAllocationMarkovChain;
class vtkPLatentDirichletAllocationMarkovChain;
class vtkRandomSequence;
class vtkMultiProcessController;

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPLatentDirichletAllocation : public vtkLatentDirichletAllocation
{
public:
  vtkTypeMacro(vtkPLatentDirichletAllocation, vtkLatentDirichletAllocation);
  static vtkPLatentDirichletAllocation *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  ///@{
  /// Set and get the Multi Process Controller.
  virtual void SetController(vtkMultiProcessController*);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

protected: // methods
//BTX
  vtkPLatentDirichletAllocation();
  ~vtkPLatentDirichletAllocation();

  void SetParameters(vtkPLatentDirichletAllocationMarkovChain *chain);

  virtual int RequestData(vtkInformation *request, vtkInformationVector **inVector, vtkInformationVector *outVector);

  ///@{
  /// This method takes the term/doc frequency matrix and sets up all
  /// the topic arrays in the corpus.
  virtual void InitializeCorpus(vtkAbstractLatentDirichletAllocationMarkovChain *sampler,
                                vtkArray *termDocMatrix);
  ///@}


  ///@{
  /// Given the inputs to the algorithm, set up the Markov chain to be
  /// ready to run.  If you need to add more arguments then override
  /// this method in the subclass.
  virtual bool SetupMarkovChain(vtkAbstractLatentDirichletAllocationMarkovChain *chain,
                                vtkArrayData *termdoc_matrix_input,
                                vtkDataObject *saved_state);
  ///@}

  ///@{
  /// Take the topic decomposition from the (converged) sampler,
  /// transform it into the arrays needed for the output, and add it to
  /// the output containers.
  virtual void SaveThetaPhiMatrices(vtkAbstractLatentDirichletAllocationMarkovChain *sampler,
                                    vtkArrayData *theta_output,
                                    vtkArrayData *phi_output);
  ///@}

  /// Communicate among all the processes to collect the global
  /// document count.
  void CollectGlobalDocumentCount(vtkArray *termdoc_matrix);

  vtkSetMacro(GlobalDocumentCount, int);
  vtkGetMacro(GlobalDocumentCount, int);

protected: // ivars
  vtkMultiProcessController *Controller;
  int                        GlobalDocumentCount;
private:
  vtkPLatentDirichletAllocation(const vtkPLatentDirichletAllocation&);
  void operator=(const vtkPLatentDirichletAllocation&);

  // this will go away someday soon
  vtkPLatentDirichletAllocationMarkovChain *RunningChain;


//ETX
};

#endif
