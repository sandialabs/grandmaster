/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkPTermDictionaryCommunicator.h"
#include "vtkPTermDictionaryNToN.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"

#include <map>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryNToN


vtkStandardNewMacro(vtkPTermDictionaryNToN);

vtkPTermDictionaryNToN::vtkPTermDictionaryNToN() :
  Controller(0),
  Gather(false)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");

  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);

  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPTermDictionaryNToN::~vtkPTermDictionaryNToN()
{
  this->SetController(0);
}

void vtkPTermDictionaryNToN::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkPTermDictionaryNToN::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}

int vtkPTermDictionaryNToN::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    vtkUnicodeStringArray* const input_term_array = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!input_term_array)
      throw std::runtime_error("missing input term array");

    vtkPTermDictionaryCommunicator communicator(this->Controller->GetCommunicator());

    // Compute the set of unique local terms ...
    vtkPTermDictionaryCommunicator::UniqueSortedTerms terms;
    communicator.ConvertTerms(*input_term_array, terms);

    // Distribute local terms amongst all processes ...

    if(this->Gather)
      {
      communicator.AllGatherTerms(terms, terms);
      }
    else
      {
      for(int i = 0; i < this->Controller->GetNumberOfProcesses(); ++i)
        {
        communicator.BroadcastTerms(terms, i, terms);
        }
      }

    // Insert global terms into the term dictionary ...
    vtkUnicodeStringArray* const output_dictionary = vtkUnicodeStringArray::New();
    output_dictionary->SetName("text");
    communicator.ConvertTerms(terms, *output_dictionary);

    // Configure our outputs ...
    vtkTable* const output = vtkTable::GetData(outputVector, 0);
    output->AddColumn(output_dictionary);
    output_dictionary->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "caught unknown exception." << endl);
    }

  return 0;
}
