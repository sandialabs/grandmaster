/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPDocumentReader_h
#define __vtkPDocumentReader_h

#include <titanMPITextAnalysis.h>

#include <vtkMultiProcessController.h>
#include <vtkPDocumentReaderStrategy.h>
#include <vtkTableAlgorithm.h>

class vtkStdString;

/// \class vtkPDocumentReader vtkPDocumentReader.h <MPITextAnalysis/vtkPDocumentReader.h>
/// \brief Reads documents into memory for parallel text analysis.
///
///  Reads zero-to-many documents into memory, partitioning them across processes using
///  a configurable partition strategy, producing a vtkTable suitable for use as an
///  input to other VTK text analysis filters.
///
///  Parameters:
///    "Files": a collection of filesystem paths to be loaded.
///    "Directories": a collection of filesystem directories to be loaded.
///
///  Outputs:
///    Output port 0: A vtkTable containing "document", "uri", and "content" columns.
///
///  The output "document" column will contain a zero-based integer document index that
///  is unique across all processors; "uri" will contain the filepath to the document
///  formatted as a file:// URI; "contents" will contain the binary contents of the
///  document.
///
/// \warning
///  As a workaround, vtkDocumentReader stores the contents of each document
///  in the "contents" column, which is a vtkStdString array.  Note that the
///  contents of a document may actually be binary data, so check the MIME-Type
///  before treating the contents as a string.
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPDocumentReader :
  public vtkTableAlgorithm
{
public:
  static vtkPDocumentReader* New();
  vtkTypeMacro(vtkPDocumentReader, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Add a file to be loaded.
  void AddFile(const char* file);
  void AddFile(const vtkStdString& file);
  ///@}
  /// Clear the list of files to be loaded.
  void ClearFiles();

  ///@{
  /// Add a directory to be loaded.
  void AddDirectory(const char* directory);
  void AddDirectory(const vtkStdString& directory);
  ///@}
  /// Clear the list of directories to be loaded.
  void ClearDirectories();

  ///@{
  /// Add a directory to be loaded recursively.
  void AddRecursiveDirectory(const char* directory);
  void AddRecursiveDirectory(const vtkStdString& directory);
  ///@}
  /// Clear the list of directories to be recursively loaded.
  void ClearRecursiveDirectories();

  ///@{
  /// Get/Set a file partitioning strategy.
  vtkSetObjectMacro(Strategy, vtkPDocumentReaderStrategy);
  vtkGetObjectMacro(Strategy, vtkPDocumentReaderStrategy);
  ///@}

  ///@{
  /// Get/Set the parallel controller.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

//BTX
  enum PartitionDomainType
  {
    DOCUMENTS = 0,
    BYTES = 1,
    THRASH = 100,
  };
//ETX

  ///@{
  /// Deprecated.  Use a partition strategy object instead.
  vtkSetMacro(PartitionDomain, int);
  vtkGetMacro(PartitionDomain, int);
  ///@}

//BTX
protected:
  vtkPDocumentReader();
  ~vtkPDocumentReader();

  virtual int RequestData(
    vtkInformation* request,
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector);

  virtual int LegacyRequestData(
    vtkInformation* request,
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector);

private:
  vtkPDocumentReader(const vtkPDocumentReader &); // Not implemented.
  void operator=(const vtkPDocumentReader &); // Not implemented.

  class Implementation;
  Implementation* const Internal;

  vtkPDocumentReaderStrategy* Strategy;
  vtkMultiProcessController* Controller;

  int PartitionDomain;
//ETX
};

#endif // __vtkPDocumentReader_h
