/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkPTermDictionaryCommunicator.h"
#include "vtkPTermDictionaryNTo1.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"
#include "vtkUnicodeStringArray.h"
#include <vtkTimerLog.h>

#include <map>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// vtkPTermDictionaryNTo1


vtkStandardNewMacro(vtkPTermDictionaryNTo1);

vtkPTermDictionaryNTo1::vtkPTermDictionaryNTo1() :
  Controller(0),
  Gather(false)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "text");

  this->SetNumberOfInputPorts(1);
  this->SetNumberOfOutputPorts(1);

  this->SetController(vtkMultiProcessController::GetGlobalController());
}

vtkPTermDictionaryNTo1::~vtkPTermDictionaryNTo1()
{
  this->SetController(0);
}

void vtkPTermDictionaryNTo1::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkPTermDictionaryNTo1::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}

int vtkPTermDictionaryNTo1::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    if(!this->Controller)
      throw std::runtime_error("process controller hasn't been set!");

    vtkUnicodeStringArray* const input_term_array = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!input_term_array)
      throw std::runtime_error("missing input term array");

    vtkPTermDictionaryCommunicator communicator(this->Controller->GetCommunicator());

    // Compute the set of unique local terms ...
    vtkPTermDictionaryCommunicator::UniqueSortedTerms terms;
    communicator.ConvertTerms(*input_term_array, terms);

    // Send local terms to the root node ...

    if(this->Gather)
      {
      communicator.GatherTerms(terms, 0, terms);
      }
    else
      {
      if(0 != this->Controller->GetLocalProcessId())
        {
        communicator.SendTerms(terms, 0);
        }
      else
        {
        for(int i = 1; i < this->Controller->GetNumberOfProcesses(); ++i)
          {
          communicator.ReceiveTerms(i, terms);
          }
        }
      }

    // Broadcast global terms back to every node ...
    communicator.BroadcastTerms(terms, 0, terms);

    // Insert terms into the term dictionary ...
    vtkUnicodeStringArray* const output_dictionary = vtkUnicodeStringArray::New();
    output_dictionary->SetName("text");
    communicator.ConvertTerms(terms, *output_dictionary);

    // Configure our outputs ...
    vtkTable* const output = vtkTable::GetData(outputVector, 0);
    output->AddColumn(output_dictionary);
    output_dictionary->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "caught unknown exception." << endl);
    }

  return 0;
}
