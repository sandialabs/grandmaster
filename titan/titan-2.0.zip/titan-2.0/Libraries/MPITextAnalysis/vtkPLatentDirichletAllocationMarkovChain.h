/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkPLatentDirichletAllocationMarkovChain vtkPLatentDirichletAllocationMarkovChain.h <MPITextAnalysis/vtkPLatentDirichletAllocationMarkovChain.h>
/// \brief LDA representation of a corpus of documents
///
///
///
///  The LDA algorithm decomposes a set of documents into a
///  probabilistic representation over a set of topics.  This object
///  encapsulates a compact representation of the corpus and the
///  (evolving) probabilistic results.  It can be used to generate the
///  document/topic and topic/word matrices or (eventually) as a
///  reference against which to compare other documents.
///
///  Multiple instances of this class can share a single corpus without
///  copying.  This is useful when you want to run multiple Markov
///  chains in parallel to get better results.
///
/// \par Musings :
///
///  I might want to switch this to subclass vtkDataObject.  It could be
///  useful to have the model passed off to other filters that can
///  compare it against a corpus.  I'll have to read up on how the
///  statistics algorithms handle their state.
///
/// \sa
///
///  vtkPLatentDirichletAnalysis

#ifndef __vtkPLatentDirichletAllocationMarkovChain_h
#define __vtkPLatentDirichletAllocationMarkovChain_h

#include <titanMPITextAnalysis.h>
#include <vtkAbstractLatentDirichletAllocationMarkovChain.h>

class vtkArray;
class vtkDataObject;
class vtkDoubleArray;
class vtkFieldData;
class vtkIdTypeArray;
class vtkMultiProcessController;
class vtkPLatentDirichletAllocationMarkovChainInternals;
class vtkPrivate2DIntArray;
class vtkPrivateDoubleVector;
class vtkPrivateIntVector;
class vtkPrivate2DDoubleArray;
class vtkUnicodeStringArray;

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPLatentDirichletAllocationMarkovChain : public vtkAbstractLatentDirichletAllocationMarkovChain
{
public:
  vtkTypeMacro(vtkPLatentDirichletAllocationMarkovChain, vtkAbstractLatentDirichletAllocationMarkovChain);
  static vtkPLatentDirichletAllocationMarkovChain *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  int GetNumberOfDocuments() { return this->GetNumberOfGlobalDocuments(); }
  int GetNumberOfLocalDocuments();
  vtkGetMacro(VocabularySize,int);

  /// Construct the corpus from a term/doc frequency matrix.  The
  /// caller is responsible for building up the matrix.
  ///   /// XXX PARALLEL: The IDs in the matrix are going to range from k to
  /// k+(n/p) instead of from 0 to n-1.  This will need to be worked
  /// around.
  void BuildCorpus(vtkArray *termDocFrequencyMatrix);

  /// Method from superclass -- allocate space for the cache arrays
  /// that keep track of statistics used from one iteration to the next
  void AllocateCacheArrays();

  /// Guess reasonable values for the Alpha and Beta hyperparameters.
  /// As seen in the literature, these values will be Alpha = (50 /
  /// #documents) and Beta = 0.01.  It only makes sense to call this
  /// after there is a corpus in place.
  void GuessParameterValues();

  /// Set the hyperparameter values from a vector instead of
  /// individually.  This falls through to SetAlpha and SetBeta.
  void SetParameterValues(vtkDoubleArray *params);

  ///@{
  /// If you happen to know better values of Alpha and Beta than the
  /// defaults, use these functions to set them instead of
  /// GuessAlphaBetaValues().
  vtkSetMacro(Alpha, double);
  vtkGetMacro(Alpha, double);
  vtkSetMacro(Beta, double);
  vtkGetMacro(Beta, double);
  ///@}

  ///@{
  /// Set/get the number of topics the chain should extract.  The
  /// "best" value for this parameter is a subject of much debate,
  /// head-scratching and research.  Play around with it for any given
  /// corpus to see what happens.
  vtkSetMacro(NumberOfTopics, int);
  vtkGetMacro(NumberOfTopics, int);
  ///@}

  ///@{
  /// These are the driver methods that will run Gibbs sampling.
  /// SampleFullConditional causes the chain to take exactly one step.
  /// UpdatePhiThetaMatrices records the results.  The driver class
  /// will call RunSingleIteration a bunch of times (a few hundred,
  /// probably) to get the chain to a converged state and then
  /// alternate calls to RunSingleIteration and
  /// UpdatePhiThetaMatrices.
  void RunSingleIteration();
  void UpdateOutputMatrices();
  ///@}

  /// Compute an estimate of the likelihood of the corpus given the
  /// current AND PAST states of the word/topic/document distribution.
  double GetCorpusLikelihood();

  /// Compute an estimate of the likelihood of the corpus given the
  /// CURRENT state of the word/topic/document distribution.
  double GetRawCorpusLikelihood();

  /// This clears out the Markov chain state and initializes it with
  /// random values.
  void InitializeTermTopicAssignments();

  /// This retrieves the Theta (doc/topic) matrix.  The vtkArray is
  /// actually a 2-dimensional vtkDenseArray<double>.
  ///   /// XXX PARALLEL: It's actually a slice of a larger array.  Should it
  /// be implemented as a vtkSparseArray?
  vtkArray *GetDocumentTopicMatrix();

  /// This retrieves the Phi (topic/word) matrix.  Like the Theta
  /// matrix, the vtkArray is actually a 2-dimensional
  /// vtkDenseArray<double>.
  ///   /// XXX PARALLEL: It's actually a slice of a larger array.  Should it
  /// be implemented as a vtkSparseArray?
  vtkArray *GetTopicTermMatrix();

// BTX
  ///@{
  /// Save the Markov chain state in a vtkDataObject that can be saved
  /// to disk and re-loaded later.  The caller is responsible for
  /// deleting the generated object.
  void SaveSamplerState(vtkDataObject *archive);
  void LoadSamplerState(vtkDataObject *archive);
// ETX
  ///@}

  /// Get the amount of mass allocated to each document in the corpus.
  /// The masses will all sum to 1.
  ///   /// XXX PARALLEL: Should this return an array the size of the entire
  /// corpus, all zero except for the documents that live here, or
  /// should it return a compact array for just this subset?
  void GetTopicMasses(vtkDoubleArray *masses);

  /// Get the amount of mass allocated to each term in the corpus.  The
  /// masses will sum to 1.
  ///   /// XXX PARALLEL: Since each process has the makings of the entire
  /// Phi matrix we can always return the whole thing.
  void GetTermMasses(vtkDoubleArray *masses);

  /// Clear out the contents of the Theta and Phi matrices so that
  /// sampling effectively starts over
  void ResetOutputMatrices();

  /// Free up as much memory as possible after computation
  void FinalizeState();

  ///@{
  /// Set and get the Multi Process Controller.
  virtual void SetController(vtkMultiProcessController*);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

  ///@{
  vtkSetMacro(NumberOfGlobalDocuments, int);
  vtkGetMacro(NumberOfGlobalDocuments, int);
  ///@}

  /// Sort and renumber the topics in descending order by total mass.
  /// This requires global communication to get the total topic masses
  /// and transmit the old-to-new map.
  void SortTopicsByWeight();

protected: // methods
  vtkPLatentDirichletAllocationMarkovChain();
  ~vtkPLatentDirichletAllocationMarkovChain();


  ///@{
  /// Two magic parameters controlling the convergence rate (sort of)
  double Alpha;
  double Beta;
  ///@}

  /// Get the number of words in document DocId
  int GetNumberOfWords(vtkIdType DocId);

  void AssignTermToTopic(vtkIdType docId, vtkIdType termIndex, vtkIdType topic);
  void RemoveTermTopicAssignment(vtkIdType docId, vtkIdType termIndex);
  int ChooseNewTopic(vtkIdType docId, vtkIdType termIndex);
  void SampleFullConditional(vtkIdType docId, vtkIdType termIndex);
  virtual int ChooseInitialTopic(vtkIdType docId, vtkIdType termIndex);
  void SyncTopicCountArrays();

  void DumpChainState(ostream &os);

protected: // ivars

  /// MPI controller for this process group.  We expect this to be set
  /// by the caller.
  vtkMultiProcessController *Controller;

  /// Number of documents across all processors.  We expect this to be
  /// set by the caller.
  int                        NumberOfGlobalDocuments;

  /// Number of topics the model will generate.  You MUST set this
  /// before calling SetDocuments.
  int                        NumberOfTopics;

private:
  vtkPLatentDirichletAllocationMarkovChain(const vtkPLatentDirichletAllocationMarkovChain &);
  void operator=(const vtkPLatentDirichletAllocationMarkovChain &);

  // Below this line are the structures that contain the state of the
  // Markov chain

  // Keep track of the denominator for the harmonic mean of corpus
  // likelihood samples
  double RunningHarmonicMeanDenominator;

  // Question: is it possible to fold the frozen chain state into the
  // counts in the active chain state?
  vtkPLatentDirichletAllocationMarkovChainInternals *Internals;
};
#endif
