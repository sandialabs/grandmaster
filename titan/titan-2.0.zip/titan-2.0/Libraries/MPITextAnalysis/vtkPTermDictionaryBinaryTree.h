/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkPTermDictionaryBinaryTree_h
#define __vtkPTermDictionaryBinaryTree_h

#include <titanMPITextAnalysis.h>

#include <vtkTableAlgorithm.h>
#include <vtkMultiProcessController.h>

/// \class vtkPTermDictionaryBinaryTree vtkPTermDictionaryBinaryTree.h <MPITextAnalysis/vtkPTermDictionaryBinaryTree.h>
/// \brief Generates a dictionary of unique terms.
///
///  vtkPTermDictionaryBinaryTree reorganizes a distributed table containing (potentially duplicated)
///  terms into a dictionary where every term appears exactly once.
///
///  Inputs:
///    Input port 0: (required) A vtkTable containing a "text" column.
///
///  Outputs:
///    Output port 0: A dense dictionary of unique terms - a vtkDenseArray<vtkUnicodeString> with two dimensions and one column.
///
///  Use SetInputArrayToProcess(0, ...) to specify the input "text" array.
///
/// \warning
///  vtkPTermDictionaryBinaryTree implements a 'daisy-chain' algorithm where every processor N transmits
///  its terms to processor (N + 1) % N.  Each processor then inserts the newly-received terms into its
///  local list.  Then, each processor 'forwards' the newly-received terms to the next processor in-line, with
///  the process repeating until every term has been forwarded to every processor.
///
/// \sa
///  vtkFeatureDictionary, vtkPTermDictionaryNTo1, vtkPTermDictionaryNToN
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkPTermDictionaryBinaryTree :
  public vtkTableAlgorithm
{
public:
  static vtkPTermDictionaryBinaryTree* New();
  vtkTypeMacro(vtkPTermDictionaryBinaryTree, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Get/Set the parallel controller.
  vtkSetObjectMacro(Controller, vtkMultiProcessController);
  vtkGetObjectMacro(Controller, vtkMultiProcessController);
  ///@}

//BTX
protected:
  vtkPTermDictionaryBinaryTree();
  ~vtkPTermDictionaryBinaryTree();

  int FillInputPortInformation(int, vtkInformation*);

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPTermDictionaryBinaryTree(const vtkPTermDictionaryBinaryTree&); // Not implemented
  void operator=(const vtkPTermDictionaryBinaryTree&);   // Not implemented

  vtkMultiProcessController* Controller;
//ETX
};

#endif
