/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkRoundRobinPDocumentReaderStrategy_h
#define __vtkRoundRobinPDocumentReaderStrategy_h

#include <titanMPITextAnalysis.h>

#include <vtkObject.h>
#include <vtkPDocumentReaderStrategy.h>

/// \class vtkRoundRobinPDocumentReaderStrategy vtkRoundRobinPDocumentReaderStrategy.h <MPITextAnalysis/vtkRoundRobinPDocumentReaderStrategy.h>
/// \brief Does a 'round-robin' distribution of
///  documents across processes.
///
///
///  Concrete implementation of vtkPDocumentReaderStrategy that uses a
///  'round-robin' approach to distribute documents across processes.
///  This approach is fast and does not require any communication, but
///  it can lead to suboptimal load-balancing, since some processors may
///  end up with larger documents than others.
///
/// \sa
///  vtkPDocumentReader
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_MPI_TEXT_ANALYSIS_EXPORT vtkRoundRobinPDocumentReaderStrategy :
  public vtkPDocumentReaderStrategy
{
public:
  static vtkRoundRobinPDocumentReaderStrategy* New();
  vtkTypeMacro(vtkRoundRobinPDocumentReaderStrategy, vtkPDocumentReaderStrategy);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
  virtual int LoadFiles(
    vtkMultiProcessController* const controller,
    const PathList& files,
    const PathList& directories,
    const PathList& recursive_directories,
    vtkStringArray* uri_array,
    vtkStringArray* contents_array
    );

protected:
  vtkRoundRobinPDocumentReaderStrategy();
  ~vtkRoundRobinPDocumentReaderStrategy();

private:
  vtkRoundRobinPDocumentReaderStrategy(const vtkRoundRobinPDocumentReaderStrategy &); // Not implemented.
  void operator=(const vtkRoundRobinPDocumentReaderStrategy &); // Not implemented.
//ETX
};

#endif // __vtkRoundRobinPDocumentReaderStrategy_h
