/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkFeatureTableToDictionaryAndMatrix.h"

#include "vtkCallbackCommand.h"
#include "vtkDataObject.h"
#include "vtkDataObjectReader.h"
#include "vtkFeatureDictionary.h"
#include "vtkFrequencyMatrix.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkMultiProcessController.h"
#include "vtkObjectFactory.h"
#include "vtkTable.h"

#if defined(VTK_USE_MPI)
#include "vtkPTermDictionaryMapReduce.h"
#endif

#include <vtksys/stl/stdexcept>
#include <assert.h>

// ----------------------------------------------------------------------


vtkStandardNewMacro(vtkFeatureTableToDictionaryAndMatrix);
#if defined(VTK_USE_MPI)
vtkCxxSetObjectMacro(vtkFeatureTableToDictionaryAndMatrix, Controller, vtkMultiProcessController);
#endif

// ----------------------------------------------------------------------

vtkFeatureTableToDictionaryAndMatrix::vtkFeatureTableToDictionaryAndMatrix()
{
  this->SerialDictionaryBuilder   = vtkFeatureDictionary::New();
  this->TermDocumentMatrixBuilder = vtkSmartPointer<vtkFrequencyMatrix>::New();

  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(2);

#if defined(VTK_USE_MPI)
  this->Controller = 0;
  this->ParallelDictionaryBuilder =
    vtkSmartPointer<vtkPTermDictionaryMapReduce>::New();
#endif // VTK_USE_MPI
}

// ----------------------------------------------------------------------

vtkFeatureTableToDictionaryAndMatrix::~vtkFeatureTableToDictionaryAndMatrix()
{
#if defined(VTK_USE_MPI)
  this->SetController(0);
#endif
}

// ----------------------------------------------------------------------

int
vtkFeatureTableToDictionaryAndMatrix::FillInputPortInformation(int port,
                                                               vtkInformation *info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    return 1;
    }
  else if (port == 1)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
    return 1;
    }
  else
    {
    return 0;
    }
}


// ----------------------------------------------------------------------

int
vtkFeatureTableToDictionaryAndMatrix::FillOutputPortInformation(int port,
                                                                vtkInformation *info)
{
  if (port == 0)
    {
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkArrayData");
    return 1;
    }
  else if (port == 1)
    {
    info->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkTable");
    return 1;
    }
  else
    {
    return this->Superclass::FillOutputPortInformation(port, info);
    }
}

// ----------------------------------------------------------------------

int
vtkFeatureTableToDictionaryAndMatrix::RequestData(vtkInformation *vtkNotUsed(request),
                                                  vtkInformationVector **inVector,
                                                  vtkInformationVector *outVector)
{
  try
    {
    if (inVector[1] == 0)
      {
      this->ConnectPipelineForDictionaryBuild(inVector);
      }
    else
      {
      this->ConnectPipelineForExistingDictionary(inVector);
      }

    vtkTable *feature_table = vtkTable::GetData(inVector[0], 0);
    this->TermDocumentMatrixBuilder->SetInputData(0, feature_table);

    this->TermDocumentMatrixBuilder->SetInputData(2, feature_table);

    // Force the pipeline to run
    this->TermDocumentMatrixBuilder->Update();

    // Shallow copy the outputs from the internal pipeline to the
    // outside world
    vtkArrayData *output_termdoc = this->GetOutput(0);
    vtkTable *output_dictionary = vtkTable::SafeDownCast(this->GetOutputDataObject(1));
    assert(output_dictionary != 0);

    output_termdoc->ShallowCopy(this->TermDocumentMatrixBuilder->GetOutput());
    if (inVector[1] == 0) // building dictionary from scratch
      {
#if defined(VTK_USE_MPI)
      if (this->Controller != 0)
        {
        output_dictionary->ShallowCopy(this->ParallelDictionaryBuilder->GetOutput());
        }
      else
        {
        output_dictionary->ShallowCopy(this->SerialDictionaryBuilder->GetOutput());
        }
#else // not VTK_USE_MPI
      output_dictionary->ShallowCopy(this->SerialDictionaryBuilder->GetOutput());
#endif // VTK_USE_MPI
      }
    else
      {
      vtkTable *incoming_dictionary = vtkTable::GetData(inVector[1], 0);
      output_dictionary->ShallowCopy(incoming_dictionary);
      }
    }
  catch (const vtksys_stl::runtime_error &e)
    {
    vtkErrorMacro(<<"Fatal error: " << e.what());
    return 0;
    }

  return 1;
}

// ----------------------------------------------------------------------

void
vtkFeatureTableToDictionaryAndMatrix::ConnectPipelineForDictionaryBuild(vtkInformationVector **inVector)
{
  vtkTable *feature_table = vtkTable::GetData(inVector[0], 0);

#if defined(VTK_USE_MPI)
  if (this->Controller != 0)
    {
    vtkDebugMacro(<<"Building term dictionary "
                  <<"in parallel (using "
                  << this->ParallelDictionaryBuilder->GetClassName()
                  << ") from input documents.");
    this->ParallelDictionaryBuilder->SetController(this->Controller);

    this->ParallelDictionaryBuilder->SetInputData(feature_table);
    this->TermDocumentMatrixBuilder->SetInputConnection(1, this->ParallelDictionaryBuilder->GetOutputPort());
    }
  else // we must be running in serial
    {
    vtkDebugMacro(<<"Building term dictionary "
                  <<"in serial from input documents.");
    this->SerialDictionaryBuilder->SetInputData(feature_table);
    this->TermDocumentMatrixBuilder->SetInputConnection(1, this->SerialDictionaryBuilder->GetOutputPort());
    }
#else // not VTK_PARALLEL
  vtkDebugMacro(<<"VTK_PARALLEL is off.  Building term dictionary "
                <<"in serial from input documents.");
  this->SerialDictionaryBuilder->SetInputData(feature_table);
  this->TermDocumentMatrixBuilder->SetInputConnection(1, this->SerialDictionaryBuilder->GetOutputPort());
#endif // VTK_USE_MPI
}


// ----------------------------------------------------------------------

void
vtkFeatureTableToDictionaryAndMatrix::ConnectPipelineForExistingDictionary(vtkInformationVector **inVector)
{
  vtkTable *dictionary = vtkTable::GetData(inVector[1], 0);

  this->TermDocumentMatrixBuilder->SetInputData(1, dictionary);
}

// ----------------------------------------------------------------------

void
vtkFeatureTableToDictionaryAndMatrix::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);

#define GUARD_NULL(thing) ((thing) ? (thing) : "(null)")

  os << indent << "Dictionary builder (serial):\n";
  this->SerialDictionaryBuilder->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Term/document matrix builder:\n";
  this->TermDocumentMatrixBuilder->PrintSelf(os, indent.GetNextIndent());

#if defined(VTK_USE_MPI)
  os << indent << "Dictionary builder (parallel):\n";
  this->ParallelDictionaryBuilder->PrintSelf(os, indent.GetNextIndent());

  os << indent << "Multiprocess controller: ";
  if (this->Controller)
    {
    os << "\n";
    this->Controller->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)";
    }
#endif
}

// ----------------------------------------------------------------------

vtkAlgorithmOutput *
vtkFeatureTableToDictionaryAndMatrix::GetDictionaryOutputPort()
{
  return this->GetOutputPort(1);
}

// ----------------------------------------------------------------------

vtkAlgorithmOutput *
vtkFeatureTableToDictionaryAndMatrix::GetTermDocumentMatrixOutputPort()
{
  return this->GetOutputPort(0);
}
