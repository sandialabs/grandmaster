/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __titanJSONOutputArchive
#define __titanJSONOutputArchive

#include <vtkStdString.h>
#include <vtkUnicodeString.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/optional.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/version.hpp>

#include <list>
#include <map>
#include <ostream>
#include <sstream>
#include <stdexcept>
#include <stack>
#include <string>
#include <vector>

/// titanJSONOutputArchive is a model of the Boost.Serialization "Saving Archive" concept
/// that can serialize a C++ object using JSON format.
///
/// See http://json.org and
/// http://www.boost.org/doc/libs/1_43_0/libs/serialization/doc/index.html for details.

class titanJSONOutputArchive
{
public:
  typedef boost::mpl::bool_<true> is_saving;
  typedef boost::mpl::bool_<false> is_loading;

  titanJSONOutputArchive(std::ostream& Stream) :
    stream(Stream)
  {
  }

  template<typename T>
  void register_type()
  {
  }

  titanJSONOutputArchive& operator<<(const bool& t)
  {
    stream << (t ? "true" : "false");
    return *this;
  }

  titanJSONOutputArchive& operator<<(const int& t)
  {
    stream << t;
    return *this;
  }

  titanJSONOutputArchive& operator<<(const double& t)
  {
    stream << t;
    return *this;
  }

  titanJSONOutputArchive& operator<<(const vtkStdString& t)
  {
    return *this << static_cast<std::string>(t);
  }

  titanJSONOutputArchive& operator<<(const vtkUnicodeString& t)
  {
    return *this << std::string(t.utf8_str());
  }

  titanJSONOutputArchive& operator<<(const std::string& t)
  {
    stream << "\"";
    for(int i = 0; i != t.size(); ++i)
    {
      switch(t[i])
      {
        case '"':
          stream << "\\\"";
          break;
        case '\\':
          stream << "\\";
          break;
        case '/':
          stream << "\\/";
          break;
        case '\b':
          stream << "\\b";
          break;
        case '\f':
          stream << "\\f";
          break;
        case '\n':
          stream << "\\n";
          break;
        case '\r':
          stream << "\\r";
          break;
        case '\t':
          stream << "\\t";
          break;
        default:
          stream << t[i];
          break;
      }
    }
    stream << "\"";
    return *this;
  }

  titanJSONOutputArchive& operator<<(const boost::posix_time::ptime& t)
  {
    return *this << to_iso_extended_string(t);
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const boost::optional<T>& t)
  {
    if(t)
      return *this << *t;

    stream << "null";
    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const std::vector<T>& t)
  {
    stream << "[";
    for(typename std::vector<T>::const_iterator i = t.begin(); i != t.end(); ++i)
    {
      if(i != t.begin())
        stream << ",";
      *this << *i;
    }
    stream << "]";

    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const std::list<T>& t)
  {
    stream << "[";
    for(typename std::list<T>::const_iterator i = t.begin(); i != t.end(); ++i)
    {
      if(i != t.begin())
        stream << ",";
      *this << *i;
    }
    stream << "]";

    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const std::map<vtkStdString, T>& t)
  {
    stream << "{";
    first_nvp.push(true);
    for(typename std::map<vtkStdString, T>::const_iterator i = t.begin(); i != t.end(); ++i)
      *this << boost::serialization::make_nvp(i->first.c_str(), i->second);
    first_nvp.pop();
    stream << "}";

    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const std::map<std::string, T>& t)
  {
    stream << "{";
    first_nvp.push(true);
    for(typename std::map<std::string, T>::const_iterator i = t.begin(); i != t.end(); ++i)
      *this << boost::serialization::make_nvp(i->first.c_str(), i->second);
    first_nvp.pop();
    stream << "}";

    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const T& t)
  {
    stream << "{";
    first_nvp.push(true);
    boost::serialization::serialize_adl(*this, const_cast<T&>(t), ::boost::serialization::version<T>::value);
    first_nvp.pop();
    stream << "}";

    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator<<(const boost::serialization::nvp<T>& t)
  {
    if(!first_nvp.top())
      stream << ",";
    stream << "\"" << t.name() << "\":";
    *this << t.const_value();
    first_nvp.top() = false;

    return *this;
  }

  template<typename T>
  titanJSONOutputArchive& operator&(const T& t)
  {
    return *this << t;
  }

  void save_binary(void *address, std::size_t count)
  {
    throw std::runtime_error("JSON archive binary output unsupported.");
  };

  unsigned int get_library_version()
  {
    return 0;
  }

private:
  std::ostream& stream;
  std::stack<bool> first_nvp;
};

#endif
