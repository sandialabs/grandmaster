/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __titanJSONValue
#define __titanJSONValue

#include <titanJSON.h>

#include <boost/optional.hpp>
#include <boost/variant.hpp>

#include <list>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

class TITAN_JSON_EXPORT titanJSONValue
{
public:
  typedef size_t size_type;
  typedef std::string key_type;

  titanJSONValue();
  titanJSONValue(bool);
  titanJSONValue(double);
  titanJSONValue(const std::string&);

  void reset();

  titanJSONValue& operator=(bool);
  titanJSONValue& operator=(double);
  titanJSONValue& operator=(const std::string&);

  bool operator==(const titanJSONValue&) const;
  bool operator!=(const titanJSONValue&) const;

  bool is_null() const;
  bool is_boolean() const;
  bool is_number() const;
  bool is_string() const;
  bool is_array() const;
  bool is_object() const;

  size_type size() const;

  // Array-related functionality ...
  void push_back(const titanJSONValue&);
  titanJSONValue& operator[](size_type);
  const titanJSONValue& operator[](size_type) const;

  // Object-related functionality ...
  bool has_key(const key_type& Key) const;
  void erase_key(const key_type& Key);

  template<typename T>
  const T get(const key_type& Key) const
  {
    if(!object_storage)
      throw std::runtime_error("Not a JSON object.");
    object::const_iterator property = object_storage->find(Key);
    if(property == object_storage->end())
      throw std::runtime_error("Unknown property: " + Key);
    if(property->second.array_storage || property->second.object_storage)
      throw std::runtime_error("Not a value property: " + Key);
    const T* const result = boost::get<T>(&property->second.storage);
    if(!result)
      throw std::runtime_error("Wrong property type: " + Key);

    return *result;
  }

  const titanJSONValue& get(const key_type& Key) const;

  template<typename T>
  const T get(const key_type& Key, const T& Default) const
  {
    if(!object_storage)
      throw std::runtime_error("Not a JSON object.");
    object::const_iterator property = object_storage->find(Key);
    if(property == object_storage->end())
      return Default;
    if(property->second.array_storage || property->second.object_storage)
      throw std::runtime_error("Not a value property: " + Key);
    const T* const result = boost::get<T>(&property->second.storage);
    if(!result)
      throw std::runtime_error("Wrong property type: " + Key);

    return *result;
  }
  const std::string get(const key_type& Key, const char* Default) const;

  void put(const key_type&, bool);
  void put(const key_type&, double);
  void put(const key_type&, const char*);
  void put(const key_type&, const std::string&);
  void put(const key_type&, const titanJSONValue&);

private:
  typedef std::vector<titanJSONValue> array;
  typedef std::map<std::string, titanJSONValue> object;

  boost::variant<void*, bool, double, std::string> storage;
  boost::optional<array> array_storage;
  boost::optional<object> object_storage;

  void coerce_array();
  void coerce_object();

  friend void read(std::istream&, titanJSONValue&);
  friend void write(std::ostream&, const titanJSONValue&);
};

std::ostream& operator<<(std::ostream&, const titanJSONValue&);

void read(std::string&, titanJSONValue&);
void read(std::istream&, titanJSONValue&);
void write(std::ostream&, const titanJSONValue&);

#endif // !OPENCAL_JSON_H
