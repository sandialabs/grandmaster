/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __titanJSONInputArchive
#define __titanJSONInputArchive

#include <vtkStdString.h>
#include <vtkUnicodeString.h>

#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/serialization/nvp.hpp>
#include <boost/serialization/serialization.hpp>
#include <boost/serialization/version.hpp>

#include <istream>
#include <list>
#include <map>
#include <sstream>
#include <stdexcept>
#include <stack>
#include <string>
#include <vector>

/// titanJSONInputArchive is a model of the Boost.Serialization "Loading Archive" concept
/// that can deserialize a C++ object stored in JSON format.
///
/// See http://json.org and
/// http://www.boost.org/doc/libs/1_43_0/libs/serialization/doc/index.html for details.

class titanJSONInputArchive
{
public:
  typedef boost::mpl::bool_<false> is_saving;
  typedef boost::mpl::bool_<true> is_loading;

  titanJSONInputArchive(std::istream& Stream) :
    stream(Stream)
  {
  }

  titanJSONInputArchive& operator>>(bool& t)
  {
    std::string value;
    while(stream && stream.peek() != ',' && stream.peek() != ']' && stream.peek() != '}')
      {
      char c = stream.get();
      if(!stream)
        break;
      value += c;
      }

    if(value == "true")
      t = true;
    else if(value == "false")
      t = false;
    else
      throw std::runtime_error("Expected 'true' or 'false'.");

    return *this;
  }

  titanJSONInputArchive& operator>>(int& t)
  {
    stream >> t;
    return *this;
  }

  titanJSONInputArchive& operator>>(double& t)
  {
    stream >> t;
    return *this;
  }

  titanJSONInputArchive& operator>>(vtkStdString& t)
  {
    t = read_string();
    return *this;
  }

  titanJSONInputArchive& operator>>(vtkUnicodeString& t)
  {
    t = vtkUnicodeString::from_utf8(read_string());
    return *this;
  }

  titanJSONInputArchive& operator>>(std::string& t)
  {
    t = read_string();
    return *this;
  }

  titanJSONInputArchive& operator>>(boost::posix_time::ptime& t)
  {
    char separator;
    int year = 0;
    int month = 0;
    int day = 0;
    int hour = 0;
    int minute = 0;
    int second = 0;
    std::istringstream buffer(read_string());
    buffer >> year >> separator >> month >> separator >> day >> separator >> hour >> separator >> minute >> separator >> second;
    t = boost::posix_time::ptime(boost::gregorian::date(year, month, day), boost::posix_time::time_duration(hour, minute, second));

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator>>(std::vector<T>& t)
  {
    require_structural_char('[');
    while(stream && stream.peek() != ']')
    {
      optional_char(',');
      T element;
      *this >> element;
      t.push_back(element);
    }
    require_structural_char(']');

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator>>(std::list<T>& t)
  {
    require_structural_char('[');
    while(stream && stream.peek() != ']')
    {
      optional_char(',');
      T element;
      *this >> element;
      t.push_back(element);
    }
    require_structural_char(']');

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator>>(std::map<vtkStdString, T>& t)
  {
    require_structural_char('{');
    while(stream && stream.peek() != '}')
    {
      optional_char(',');
      std::string name;
      *this >> name;
      require_structural_char(':');
      T value;
      *this >> value;
      t.insert(std::make_pair(name, value));
    }
    require_structural_char('}');

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator>>(std::map<std::string, T>& t)
  {
    require_structural_char('{');
    while(stream && stream.peek() != '}')
    {
      optional_char(',');
      std::string name;
      *this >> name;
      require_structural_char(':');
      T value;
      *this >> value;
      t.insert(std::make_pair(name, value));
    }
    require_structural_char('}');

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator>>(const T& t)
  {
    require_structural_char('{');
    boost::serialization::serialize_adl(*this, const_cast<T&>(t), ::boost::serialization::version<T>::value);
    require_structural_char('}');

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator>>(const boost::serialization::nvp<T>& t)
  {
    optional_char(',');

    const std::string name = read_string();
    if(name != t.name())
    {
      std::ostringstream message;
      message << "Expected name '" << t.name() << "', got '" << name << "' instead, at character " << stream.tellg();
      throw std::runtime_error(message.str());
    }

    require_structural_char(':');

    *this >> t.value();

    return *this;
  }

  template<typename T>
  titanJSONInputArchive& operator&(T& t)
  {
    return *this >> t;
  }

private:
  std::istream& stream;

  void skip_insignificant_whitespace()
  {
    while(stream)
    {
      switch(stream.peek())
      {
        case ' ':
        case '\n':
        case '\r':
        case '\t':
          stream.get();
          continue;
      }

      break;
    }
  }

  void require_structural_char(const char C)
  {
    skip_insignificant_whitespace();

    if(stream.peek() != C)
    {
      std::ostringstream message;
      message << "Expected '" << C << "' at character " << stream.tellg();
      throw std::runtime_error(message.str());
    }
    stream.get();

    skip_insignificant_whitespace();
  }

  void optional_char(const char C)
  {
    if(stream.peek() == C)
    {
      stream.get();
      return;
    }
  }

  std::string read_string()
  {
    skip_insignificant_whitespace();

    if(stream.peek() != '"')
    {
      std::ostringstream message;
      message << "Expected '\"' at character " << stream.tellg();
      throw std::runtime_error(message.str());
    }
    stream.get();

    std::string result;
    for(; stream && stream.peek() != '"'; )
    {
      if(stream.peek() == '\\')
      {
        stream.get();
        switch(stream.peek())
        {
          case '\"':
            result += "\"";
            break;
          case '\\':
            result += "\\";
            break;
          case '/':
            result += "/";
            break;
          case 'b':
            result += "\b";
            break;
          case 'f':
            result += "\f";
            break;
          case 'n':
            result += "\n";
            break;
          case 'r':
            result += "\r";
            break;
          case 't':
            result += "\t";
            break;
          default:
          {
            std::ostringstream message;
            message << "Unknown escape '\\" << stream.peek() << "' at character " << stream.tellg();
            throw std::runtime_error(message.str());
          }
        }
        stream.get();
      }
      else
      {
        result += stream.get();
      }
    }

    require_structural_char('"');

    return result;
  }
};

#endif
