/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkDocumentM3MetaTagTable_h
#define __vtkDocumentM3MetaTagTable_h

#include "titanBoostM3.h"

#include <vtkTableAlgorithm.h>

/// \class vtkDocumentM3MetaTagTable vtkDocumentM3MetaTagTable.h <TextAnalysis/vtkDocumentM3MetaTagTable.h>
/// \brief Extracts text from documents based on their MIME type.
///
///  Takes the table from the output of vtkDocumentTextExtraction, containing M3 text in
///  the "text" column and creates a new table of elements with the following columns:
///  * document - the Document Id
///  * document type - A string field containing the document type (default="M3").
///  * line - the line number where this tag was found
///  * begin - the offset into the file where this entry starts
///  * end - the offset into the file where this entry ends
///  * type - a string indicating what kind of entry this is (i.e., TEXT)
///
/// \par Thanks :
///  Developed by William C. McLendon (wcmclen@sandia.gov) at Sandia National Laboratories.

class TITAN_BOOST_M3_EXPORT vtkDocumentM3MetaTagTable :
  public vtkTableAlgorithm
{
public:
  static vtkDocumentM3MetaTagTable* New();
  vtkTypeMacro(vtkDocumentM3MetaTagTable, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
protected:
  vtkDocumentM3MetaTagTable();
  ~vtkDocumentM3MetaTagTable();

  virtual int RequestData(
    vtkInformation* request,
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector);

private:
  vtkDocumentM3MetaTagTable(const vtkDocumentM3MetaTagTable &); // Not implemented.
  void operator=(const vtkDocumentM3MetaTagTable &); // Not implemented.

  char * TextColumnName;
//ETX
};

#endif // __vtkDocumentM3MetaTagTable_h
