/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkDocumentM3MetaData_h
#define __vtkDocumentM3MetaData_h

#include "titanBoostM3.h"

#include <vtkTableAlgorithm.h>

/// \class vtkDocumentM3MetaData vtkDocumentM3MetaData.h <TextAnalysis/vtkDocumentM3MetaData.h>
/// \brief Extracts text from documents based on their MIME type.
///
///  Takes the table from the output of vtkDocumentTextExtraction, containing M3 text in
///  the "text" column, and appends 3 new columns to the table:
///  text.header, text.body, text.footer
///
/// \par Thanks :
///  Developed by William C. McLendon (wcmclen@sandia.gov) at Sandia National Laboratories.

class TITAN_BOOST_M3_EXPORT vtkDocumentM3MetaData :
  public vtkTableAlgorithm
{
public:
  static vtkDocumentM3MetaData* New();
  vtkTypeMacro(vtkDocumentM3MetaData, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Set the name of the column containing the M3 text.
  /// Defaults to 'text'
  vtkSetStringMacro(TextColumnName);
  vtkGetStringMacro(TextColumnName);
  ///@}

//BTX
protected:
  vtkDocumentM3MetaData();
  ~vtkDocumentM3MetaData();

  virtual int RequestData(
    vtkInformation* request,
    vtkInformationVector** inputVector,
    vtkInformationVector* outputVector);

private:
  vtkDocumentM3MetaData(const vtkDocumentM3MetaData &); // Not implemented.
  void operator=(const vtkDocumentM3MetaData &); // Not implemented.

  char * TextColumnName;
//ETX
};

#endif // __vtkDocumentM3MetaData_h
