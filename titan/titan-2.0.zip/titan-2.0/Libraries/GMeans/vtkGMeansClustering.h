/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkGMeansClustering vtkGMeansClustering.h <GMeans/vtkGMeansClustering.h>
/// \brief Generates a hard clustering using the gmeans
///  algorithms and code
///

#ifndef __vtkGMeansClustering_h
#define __vtkGMeansClustering_h

#include "titanGMeans.h"
#include "vtkTableAlgorithm.h"

class TITAN_GMEANS_EXPORT vtkGMeansClustering : public vtkTableAlgorithm
{
public:
  static vtkGMeansClustering *New();

  vtkTypeMacro(vtkGMeansClustering,vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  int FillInputPortInformation(int port, vtkInformation* info);
  int FillOutputPortInformation( int port, vtkInformation* info );

  void SetAlgorithmToSphericalKMeans();
  void SetAlgorithmToEuclideanKMeans();
  void SetAlgorithmToKullbackLeibler();
  void SetAlgorithmToDiametricKMeans();
  void SetAlgorithmToInfoBottleneck();
  void SetInitializationMethodToRandomPerturbation();
  void SetInitializationMethodToRandomClusterId();
  void SetInitializationMethodToRandomVectorCentroids();
  void SetInitializationMethodToRandomFirstCentroid();
  void SetInitializationMethodToFarthestFirstCentroid();
  void SetInitializationMethodToSeedArray();
  void UseCenterLaplacian( double alphain );
  void UseNoLaplacian();
  void SetPriorMethodToUniform();
  void SetPriorMethodToFile( char* filename );
  void SetPerturbationWithPositiveIntegerSeed( int val );
  void SetTrueLabelFile( char* filename );
  void SetVerifyObjectiveFunction( bool val );
  void SetGenerateWordClustering( bool val );
  void SetSkipSphericalKMeans( bool val );

  ///@{
  /// Define IncrementalKMeansMoves.
  vtkSetMacro(IncrementalKMeansMoves, int);
  vtkGetMacro(IncrementalKMeansMoves, int);
  ///@}

  ///@{
  /// Define UpperClusterBound.
  vtkSetMacro(UpperClusterBound, int);
  vtkGetMacro(UpperClusterBound, int);
  ///@}

  ///@{
  /// Define NumberOfClusters.
  vtkSetMacro(NumberOfClusters, int);
  vtkGetMacro(NumberOfClusters, int);
  ///@}

  ///@{
  /// Define NumberOfIterations.
  vtkSetMacro(NumberOfIterations, int);
  vtkGetMacro(NumberOfIterations, int);
  ///@}

  ///@{
  /// Define MaxIterations (stop gaps to prevent potential infinite looping).
  vtkSetMacro(MaxIterations, int);
  vtkGetMacro(MaxIterations, int);
  ///@}

  ///@{
  /// Define MaxRuns (stop gaps to prevent potential infinite looping).
  vtkSetMacro(MaxRuns, int);
  vtkGetMacro(MaxRuns, int);
  ///@}

  ///@{
  /// Define NumberOfFirstVariations.
  vtkSetMacro(NumberOfFirstVariations, int);
  vtkGetMacro(NumberOfFirstVariations, int);
  ///@}

  ///@{
  /// Define PerturbationMagnitude.
  vtkSetMacro(PerturbationMagnitude, double);
  vtkGetMacro(PerturbationMagnitude, double);
  ///@}

  ///@{
  /// Define Delta.
  vtkSetMacro(Delta, double);
  vtkGetMacro(Delta, double);
  ///@}

  ///@{
  /// Define Epsilon.
  vtkSetMacro(Epsilon, double);
  vtkGetMacro(Epsilon, double);
  ///@}

  ///@{
  /// Define Omega.
  vtkSetMacro(Omega, double);
  vtkGetMacro(Omega, double);
  ///@}

  ///@{
  /// Set/Get the name of the PriorFileName.
  vtkSetStringMacro(PriorFileName);
  vtkGetStringMacro(PriorFileName);
  ///@}

  ///@{
  /// Set/Get the name of the PatternFileName.
  vtkSetStringMacro(PatternFileName);
  vtkGetStringMacro(PatternFileName);
  ///@}

protected:
  vtkGMeansClustering();
  ~vtkGMeansClustering();

  int RequestData( vtkInformation*, vtkInformationVector**, vtkInformationVector* );
private:
  int Algorithm;
  int NumberOfClusters;
  double Epsilon;
  double Delta;
  double Omega;
  int InitializationMethod;
  double PerturbationMagnitude;
  double Alpha;
  int UpperClusterBound;
  int NumberOfFirstVariations; //first_var_move_num;
  int IncrementalKMeansMoves;
  int Seed;
  int NumberOfIterations; //sim_est_start
  int MaxIterations;
  int MaxRuns;
  int UseLaplacian;
  bool RandomSeeding;
  bool SkipSPKM;
  bool VerifyObjectiveFunction;
  bool EvaluateOnly;
  bool GenerateWordClustering;
  int PriorMethod;
  char* PriorFileName;
  char* PatternFileName;

  vtkGMeansClustering(const vtkGMeansClustering&);  // Not implemented.
  void operator=(const vtkGMeansClustering&);  // Not implemented.
};

#endif
