/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include <vtkAssignMimeType.h>
#include <vtkDocumentReader.h>
#include <vtkExtractTableColumns.h>
#include <vtkMSWordTextExtractionStrategy.h>
#include <vtkSmartPointer.h>
#include <vtkTable.h>
#include <vtkTextExtraction.h>
#include <vtkVariant.h>

#include <vtksys/ios/sstream>
#include <stdexcept>


#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int argc, char* argv[])
{
  try
    {
    VTK_CREATE(vtkDocumentReader, reader);
    reader->AddFile(titanAntiword_SOURCE_DIR "/Testing/Sample.doc");

    VTK_CREATE(vtkAssignMimeType, mime_types);
    mime_types->SetInputConnection(0, reader->GetOutputPort());

    VTK_CREATE(vtkTextExtraction, text_extraction);
    text_extraction->SetInputConnection(0, mime_types->GetOutputPort());

    VTK_CREATE(vtkMSWordTextExtractionStrategy, word_strategy);
    text_extraction->AppendStrategy(word_strategy);

    VTK_CREATE(vtkExtractTableColumns, extract_columns);
    extract_columns->SetInputConnection(0, text_extraction->GetOutputPort());
    extract_columns->AddColumn("document");
    extract_columns->AddColumn("uri");
    extract_columns->AddColumn("mime_type");
    extract_columns->AddColumn("text");

    extract_columns->Update();
    extract_columns->GetOutput(0)->Dump(20);
    text_extraction->GetOutput(1)->Dump(20);

    std::cout << extract_columns->GetOutput(0)->GetValueByName(0, "text").ToUnicodeString() << std::endl;

    test_expression(extract_columns->GetOutput(0)->GetNumberOfRows() == 1);
    test_expression(extract_columns->GetOutput(0)->GetNumberOfColumns() == 4);
    test_expression(extract_columns->GetOutput(0)->GetValueByName(0, "text").ToUnicodeString().character_count() == 4002);
    }
  catch(std::exception& e)
    {
    cerr << e.what() << endl;
    return 1;
    }

  return 0;
}
