/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkHDF5TableReader vtkHDF5TableReader.h <HDF5/vtkHDF5TableReader.h>
/// \brief Loads a table from an HDF5 file.
///
///
/// \sa

#ifndef __vtkHDF5TableReader_h
#define __vtkHDF5TableReader_h

#include "titanHDF5.h"
#include "vtkTableAlgorithm.h"

class vtkHDF5TableReaderInternal;

class TITAN_HDF5_EXPORT vtkHDF5TableReader : public vtkTableAlgorithm
{
public:
  static vtkHDF5TableReader * New();
  vtkTypeMacro(vtkHDF5TableReader, vtkTableAlgorithm);
  void PrintSelf(ostream & os, vtkIndent indent);

  ///@{
  /// Set the data file name.
  vtkGetStringMacro(FileName);
  vtkSetStringMacro(FileName);
  ///@}

  ///@{
  /// Set the dataset path, if this is not set the reader pulls in the
  /// first dataset in the HDF5 file
  vtkGetStringMacro(DatasetPath);
  vtkSetStringMacro(DatasetPath);
  ///@}

  ///@{
  /// Get the attributes that were stored on the dataset as metadata
  /// This is a single table with descriptors matching the keys in hdf5 and a single row
  vtkSetMacro(ReadAttributes, bool);
  vtkGetMacro(ReadAttributes, bool);
  vtkBooleanMacro(ReadAttributes, bool);
  ///@}

//BTX
protected:
  vtkHDF5TableReader();
  ~vtkHDF5TableReader();

  int ReadGeneric(vtkInformation *);
  int ReadAttribs(vtkInformation *) ;
  int RequestData(vtkInformation *,
                  vtkInformationVector **, vtkInformationVector *);

  char* DatasetPath;
  char* FileName;
  static int NumberOfInstances;
  bool ReadAttributes;

private:
  vtkHDF5TableReader(const vtkHDF5TableReader &); // Not implemented.
  void operator=(const vtkHDF5TableReader &);     // Not implemented.
//ETX
};

#endif // __vtkHDF5TableReader_h
