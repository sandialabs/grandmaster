/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#define H5_USE_16_API

#include "vtkHDF5TableReader.h"

#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkInformationDataObjectKey.h"
#include "vtkIntArray.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkUnsignedIntArray.h"

#include "vtksys/SystemTools.hxx"

#include "vtk_hdf5.h"      // for the HDF data loading engine
#include <hdf5_hl.h>    // high-level HDF API

#include <algorithm>
#include <cctype>

vtkStandardNewMacro(vtkHDF5TableReader);

int vtkHDF5TableReader::NumberOfInstances = 0;


//-----------------------------------------------------------------------------
vtkHDF5TableReader::vtkHDF5TableReader()
{
  this->FileName = 0;
  this->DatasetPath = 0;
  this->SetNumberOfInputPorts(0);
  this->SetNumberOfOutputPorts(2);
  this->ReadAttributes = true;

  // do HDF5 library initialization on consturction of first instance
  if (vtkHDF5TableReader::NumberOfInstances == 0)
    {
    vtkDebugMacro("Initializing HDF5 Library ..." << endl);
    H5open();
    H5Eset_auto(NULL, NULL);
    }
  vtkHDF5TableReader::NumberOfInstances++;
}

//-----------------------------------------------------------------------------
vtkHDF5TableReader::~vtkHDF5TableReader()
{
  this->SetFileName(0);
  this->SetDatasetPath(0);

  // handle HDF5 library termination on descrution of last instance
  vtkHDF5TableReader::NumberOfInstances--;
  if (vtkHDF5TableReader::NumberOfInstances == 0)
    {
    vtkDebugMacro("Finalizing HDF5 Library ..." << endl);
    H5close();
    }
}

//-----------------------------------------------------------------------------
int vtkHDF5TableReader::RequestData( vtkInformation * vtkNotUsed( request ),
  vtkInformationVector ** vtkNotUsed( inputVector ),
  vtkInformationVector  * outputVector )
{
  vtkInformation* outInf = outputVector->GetInformationObject(0);
  int genericResult = this->ReadGeneric(outInf);
  if (0 != genericResult && this->ReadAttributes)
    {
    vtkInformation* outInf1 = outputVector->GetInformationObject(1);
    int attribResult = this->ReadAttribs(outInf1);
    return attribResult;
    }
  else
    return genericResult;
}

namespace { // start anonymous namespace

bool not_isspace(char c)
{
  return !isspace(c);
}

//-----------------------------------------------------------------------------
// trim from start
static inline std::string &ltrim(std::string &s) {
  s.erase(s.begin(), std::find_if(s.begin(), s.end(), not_isspace));
  return s;
}

//-----------------------------------------------------------------------------
// trim from end
static inline std::string &rtrim(std::string &s) {
  s.erase(std::find_if(s.rbegin(), s.rend(), not_isspace).base(), s.end());
  return s;
}

//-----------------------------------------------------------------------------
// trim from both ends
static inline std::string &trim(std::string &s) {
  return ltrim(rtrim(s));
}

//-----------------------------------------------------------------------------
int HDF5TypeToVTKType(hid_t type)
{
  H5T_class_t type_class = H5Tget_class(type);
  if (type_class == H5T_INTEGER || type_class == H5T_FLOAT)
    {
    hid_t native_type = H5Tget_native_type(type, H5T_DIR_ASCEND);
    if (H5Tequal(native_type, H5T_NATIVE_CHAR))
      {
      return VTK_CHAR;
      }
    if (H5Tequal(native_type, H5T_NATIVE_SHORT))
      {
      return VTK_SHORT;
      }
    if (H5Tequal(native_type, H5T_NATIVE_INT))
      {
      return VTK_INT;
      }
    if (H5Tequal(native_type, H5T_NATIVE_LONG))
      {
      return VTK_LONG;
      }
    if (H5Tequal(native_type, H5T_NATIVE_LLONG))
      {
      return VTK_LONG_LONG;
      }
    if (H5Tequal(native_type, H5T_NATIVE_UCHAR))
      {
      return VTK_UNSIGNED_INT;
      }
    if (H5Tequal(native_type, H5T_NATIVE_USHORT))
      {
      return VTK_UNSIGNED_SHORT;
      }
    if (H5Tequal(native_type, H5T_NATIVE_UINT))
      {
      return VTK_UNSIGNED_INT;
      }
    if (H5Tequal(native_type, H5T_NATIVE_ULONG))
      {
      return VTK_UNSIGNED_LONG;
      }
    if (H5Tequal(native_type, H5T_NATIVE_ULLONG))
      {
      return VTK_UNSIGNED_LONG_LONG;
      }
    if (H5Tequal(native_type, H5T_NATIVE_FLOAT))
      {
      return VTK_FLOAT;
      }
    if (H5Tequal(native_type, H5T_NATIVE_DOUBLE))
      {
      return VTK_DOUBLE;
      }
    if (H5Tequal(native_type, H5T_NATIVE_LDOUBLE))
      {
      return VTK_DOUBLE;
      }
    if (H5Tequal(native_type, H5T_NATIVE_B8))
      {
      return VTK_TYPE_UINT8;
      }
    if (H5Tequal(native_type, H5T_NATIVE_B16))
      {
      return VTK_TYPE_UINT16;
      }
    if (H5Tequal(native_type, H5T_NATIVE_B32))
      {
      return VTK_TYPE_UINT32;
      }
    if (H5Tequal(native_type, H5T_NATIVE_B64))
      {
      return VTK_TYPE_UINT64;
      }
    }
  else if (type_class == H5T_STRING)
    {
    return VTK_STRING;
    }
  return -1;
}

//-----------------------------------------------------------------------------
template<typename T>
void HDF5ReadTableValue(hid_t file, std::string name, int num_records, int j, T* data)
{
  size_t field_offset = 0;
  size_t field_size = sizeof(T);
  H5TBread_fields_index(file, name.c_str(), 1, &j, 0, num_records, field_size, &field_offset, &field_size, data);
}

} // end anonymous namespace

//-----------------------------------------------------------------------------
namespace {
herr_t object_iterator(hid_t id, const char *name, const H5O_info_t *object_info, void *op_data)
{
  if (object_info->type == H5O_TYPE_DATASET)
    {
    (*static_cast<std::string*>(op_data)) = name;
    return 1;
    }
  return 0;
}
}

//-----------------------------------------------------------------------------
int vtkHDF5TableReader::ReadGeneric(vtkInformation* outInf)
{
  vtkTable* output = vtkTable::SafeDownCast(outInf->Get(vtkDataObject::DATA_OBJECT()));

  if (!this->FileName)
    {
    vtkErrorMacro("File name must be defined.");
    return 0;
    }

  // Change directory to where the file is located, since some HDF5
  // files reference other files in the same directory
  std::string cwd = vtksys::SystemTools::GetCurrentWorkingDirectory();
  std::string filename = this->FileName;
  std::string path = vtksys::SystemTools::GetFilenamePath(filename);
  vtksys::SystemTools::ChangeDirectory(path.c_str());

  hid_t file = H5Fopen(this->FileName, H5F_ACC_RDONLY, H5P_DEFAULT);
  if (file < 0)
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Could not open file " << this->FileName << ".");
    return 0;
    }

  std::string name;
  if (!this->DatasetPath)
    {
    hid_t g = H5Gopen(file, "/");
    H5Ovisit(g, H5_INDEX_NAME, H5_ITER_NATIVE, &object_iterator, &name);
    H5Gclose(g);
    }
  else
    {
    name = this->DatasetPath;
    }

  if (name == "")
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Could not find dataset, empty dataset name");
    return 0;
    }

  hid_t dataset = H5Dopen(file, name.c_str());
  hid_t datatype = H5Dget_type(dataset);
  H5T_class_t type_class = H5Tget_class(datatype);
  if (type_class != H5T_COMPOUND)
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Expected a compound type.");
    return 0;
    }

  hsize_t num_fields;
  hsize_t num_records;
  H5TBget_table_info(file, name.c_str(), &num_fields, &num_records);

  int num_members = H5Tget_nmembers(datatype);

  if (num_members != num_fields)
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Table and compound data giving inconsistent number of fields. Aborting.");
    return 0;
    }

  size_t* sizes = new size_t[num_fields];
  for (int i = 0; i < num_fields; ++i)
    {
    hid_t subtype = H5Tget_member_type(datatype, i);
    char* field_name = H5Tget_member_name(datatype, i);

    int vtk_type = HDF5TypeToVTKType(subtype);
    if (vtk_type == -1)
      {
      vtkWarningMacro("Unknown type " << vtk_type << " in column " << field_name);
      vtk_type = VTK_DOUBLE;
      }

    vtkSmartPointer<vtkAbstractArray> arr = vtkSmartPointer<vtkAbstractArray>::Take(vtkAbstractArray::CreateArray(vtk_type));
    arr->SetName(field_name);
    delete [] field_name;

    arr->SetNumberOfTuples(num_records);
    output->AddColumn(arr);

    sizes[i] = H5Tget_size(subtype);
    H5Tclose(subtype);
    }

  for (int j = 0; j < num_fields; ++j)
    {
    vtkAbstractArray* arr = output->GetColumn(j);
    if (vtkDataArray::SafeDownCast(arr))
      {
      void* void_data = arr->GetVoidPointer(0);
      switch(arr->GetDataType())
        {
        vtkTemplateMacro(HDF5ReadTableValue(file, name, num_records, j, static_cast<VTK_TT*>(void_data)));
        }
      }
    else if (vtkStringArray::SafeDownCast(arr))
      {
      size_t field_offset = 0;
      size_t field_size = sizes[j];
      char* data = new char[num_records*field_size];
      herr_t err = H5TBread_fields_index(file, name.c_str(), 1, &j, 0, num_records, field_size, &field_offset, &field_size, data);
      for (int i = 0; i < num_records; ++i)
        {
        vtkStdString s(data+field_size*i, field_size);
        vtkStringArray::SafeDownCast(arr)->SetValue(i, trim(s));
        }
      delete [] data;
      }
    }

  delete [] sizes;

  H5Tclose(datatype);
  H5Dclose(dataset);

  H5Fclose(file);
  vtksys::SystemTools::ChangeDirectory(cwd.c_str());
  return 1;
}

int vtkHDF5TableReader::ReadAttribs(vtkInformation* outInf)
{
  vtkTable* output = vtkTable::SafeDownCast(outInf->Get(vtkDataObject::DATA_OBJECT()));

  if (!this->FileName)
    {
    vtkErrorMacro("File name must be defined.");
    return 0;
    }

  // Change directory to where the file is located, since some HDF5
  // files reference other files in the same directory
  std::string cwd = vtksys::SystemTools::GetCurrentWorkingDirectory();
  std::string filename = this->FileName;
  std::string path = vtksys::SystemTools::GetFilenamePath(filename);
  vtksys::SystemTools::ChangeDirectory(path.c_str());

  hid_t file = H5Fopen(this->FileName, H5F_ACC_RDONLY, H5P_DEFAULT);
  if (file < 0)
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Could not open file " << this->FileName << ".");
    return 0;
    }

  std::string name;
  if (!this->DatasetPath)
    {
    hid_t g = H5Gopen(file, "/");
    H5Ovisit(g, H5_INDEX_NAME, H5_ITER_NATIVE, &object_iterator, &name);
    H5Gclose(g);
    }
  else
    {
    name = this->DatasetPath;
    }

  if (name == "")
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Could not find dataset, empty dataset name");
    return 0;
    }

  hid_t dataset = H5Dopen(file, name.c_str());
  hid_t datatype = H5Dget_type(dataset);
  H5T_class_t type_class = H5Tget_class(datatype);
  if (type_class != H5T_COMPOUND)
    {
    vtksys::SystemTools::ChangeDirectory(cwd.c_str());
    vtkErrorMacro("Expected a compound type.");
    return 0;
    }


  int nDataSetAttribs = H5Aget_num_attrs(dataset);
  if (0 < nDataSetAttribs)
    {
    for (int idx = 0; idx < nDataSetAttribs; ++idx)
      {
      hid_t attr = H5Aopen_idx(dataset, idx) ;
      ssize_t nameLen = H5Aget_name(attr, 0, NULL) ;
      char* nameBuff = new char[nameLen+1] ;
      nameLen = H5Aget_name(attr, nameLen+1, nameBuff) ;
      hid_t attrType = H5Aget_type(attr) ;
      hsize_t ssize = H5Aget_storage_size(attr);
      int vtk_type = HDF5TypeToVTKType(attrType);

      vtkSmartPointer<vtkAbstractArray> arr =
        vtkSmartPointer<vtkAbstractArray>::Take(vtkAbstractArray::CreateArray(vtk_type));
      arr->SetName(nameBuff);
      arr->SetNumberOfTuples(1);
      output->AddColumn(arr);

      if (vtkDataArray::SafeDownCast(arr))
        {
        hid_t native_type = H5Tget_native_type(attrType, H5T_DIR_ASCEND);
        void* void_data = arr->GetVoidPointer(0);
        herr_t err = H5Aread(attr, native_type, void_data);
        }
      else if (vtkStringArray::SafeDownCast(arr))
        {
        size_t field_size = ssize;
        char* data = new char[field_size];
        herr_t err = H5Aread(attr, attrType, data);

        vtkStdString s(data, field_size);
        vtkStringArray::SafeDownCast(arr)->SetValue(0, trim(s));

        delete [] data;
        }

      delete [] nameBuff ;
      H5Fclose(attr) ;
      }
    }

  H5Tclose(datatype);
  H5Dclose(dataset);

  H5Fclose(file);
  vtksys::SystemTools::ChangeDirectory(cwd.c_str());
  return 1;
}


void vtkHDF5TableReader::PrintSelf(ostream & os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
