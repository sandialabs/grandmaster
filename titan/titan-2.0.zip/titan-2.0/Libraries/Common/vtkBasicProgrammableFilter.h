/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkBasicProgrammableFilter_h
#define __vtkBasicProgrammableFilter_h

#include "titanCommon.h"
#include <vtkAlgorithm.h>
#include <boost/tr1/functional.hpp>

class vtkStdString;

/**
\class vtkBasicProgrammableFilter
\brief Filter whose behavior can be specified at runtime.

vtkBasicProgrammableFilter is a filter that can be programmed by the user.  To
use the filter you define a callback function that is executed by the filter
when it needs to execute.  Using
this filter avoids the need for subclassing - and the function can be
defined in an interpreter wrapper language such as Python.

The trickiest part of using this filter is that the input and output
methods are unusual and cannot be compile-time type checked. Instead, as a
user of this filter it is your responsibility to set and get the correct
number and type inputs and outputs.

\sa vtkProgrammableSource and vtkProgrammableFilter
*/

class TITAN_COMMON_EXPORT vtkBasicProgrammableFilter : public vtkAlgorithm
{
public:
  static vtkBasicProgrammableFilter *New();
  vtkTypeMacro(vtkBasicProgrammableFilter, vtkAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  /// Called to specify how many inputs this filter should have.  You should
  /// call SetInputDataType for each input you specify here.
  void SetNumberOfInputPorts(int n);
  /// Called to specify how many outputs this filter will produce.  You should
  /// call SetOutputDataType for each output you specify here.
  void SetNumberOfOutputPorts(int n);

  /// Called to specify the data type for a specific input port, using the
  /// name of the input data structure.
  void SetInputDataType(int port, const vtkStdString& type);
  /// Called to specify the data type for a specific output port, using the
  /// name of the output data structure.
  void SetOutputDataType(int port, const vtkStdString& type);

//BTX
  /// Called to specify the callback function to be executed when this filter
  /// needs to be updated.  Note that you can use std::tr1::bind() to bind
  /// arbitrary parameters to the callback function.
  ///
  /// Typically, you will need to bind a pointer to this filter to the callback,
  /// so the callback can obtain the filter's inputs and outputs.
  void SetCallback(const std::tr1::function<void()>& callback);
//ETX

  /// Provided for use with generated language bindings.  C++ developers should
  /// not need to use this.
  void SetCallback(void(*f)(void*), void* argument);
  /// Provided for use with generated language bindings.  C++ developers should
  /// not need to use this.
  void SetCallbackArgDelete(void(*f)(void*));

//BTX
protected:
  vtkBasicProgrammableFilter();
  ~vtkBasicProgrammableFilter();

  virtual int FillInputPortInformation(int port, vtkInformation* info);
  virtual int FillOutputPortInformation(int port, vtkInformation* info);
  virtual int ProcessRequest(vtkInformation*, vtkInformationVector**, vtkInformationVector*);

private:
  vtkBasicProgrammableFilter(const vtkBasicProgrammableFilter&);  // Not implemented.
  void operator=(const vtkBasicProgrammableFilter&);  // Not implemented.

  class Implementation;
  Implementation* const Internal;
//ETX
};

#endif
