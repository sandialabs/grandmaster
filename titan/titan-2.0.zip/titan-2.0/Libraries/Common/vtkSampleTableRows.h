/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkSampleTableRows.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkSampleTableRows vtkSampleTableRows.h <Common/vtkSampleTableRows.h>
/// \brief This filter samples the rows of the input table, producing an
/// output table containing only the sample rows.

#ifndef __vtkSampleTableRows_h
#define __vtkSampleTableRows_h

#include "titanCommon.h"
#include <vtkTableAlgorithm.h>

#include <titanSampleTableRows.h>

#include <boost/random.hpp>

class vtkAbstractArray;
class vtkTable;

class TITAN_COMMON_EXPORT vtkSampleTableRows : public vtkTableAlgorithm
{
public:
  static vtkSampleTableRows* New();
  vtkTypeMacro(vtkSampleTableRows, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  enum
  {
    SAMPLE_OFF,
    SAMPLE_ABSOLUTE,
    SAMPLE_LOGISTIC,
    SAMPLE_PROBABILITY,
    SAMPLE_RATIO
  } SamplingMethodType;

  enum
  {
    MODE_SAMPLE,
    MODE_PROJECT,
    MODE_PROJECT_DIFF
  } ModeType;

  void UnsetRandomGeneratorSeed();

  ///@{
  /// This sets the mode of the filter, from options in ModeType
  /// "MODE_SAMPLE" is the default mode, which samples rows from the input table.
  ///
  /// "MODE_PROJECT" uses the row map previously generated and stored within this filter to
  /// return the appropriate rows.
  ///
  /// "MODE_PROJECT_DIFF" uses the row map previously generated and stored within this filter
  /// to return the appropriate rows, returning the difference. So if the filter
  /// is used to generate a sampling, the same filter can be used with
  /// this option set to true to return everything that was not selected
  /// previously, the two resultant sets being mutually exclusive.
  vtkSetMacro(Mode,unsigned int);
  ///@}
  vtkGetMacro(Mode,unsigned int);

  ///@{
  /// Sets the SamplingMethod to use from:
  /// SAMPLE_ABSOLUTE: An exact number of rows <br>
  /// SAMPLE_LOGISTIC: A log ratio (base=SamplingParameter, power=total number of rows) <br>
  /// SAMPLE_PROBABILITY: A probability of selection <br>
  /// SAMPLE_RATIO: A ratio of rows [0.0,1.0]. Similar to SAMPLE_PROBABILITY
  /// except that it guarantees a minimum amount if available. <br>
  ///
  /// This is set to SAMPLE_ABSOLUTE by default.
  vtkSetMacro(SamplingMethod,vtkIdType);
  ///@}
  vtkGetMacro(SamplingMethod,vtkIdType);

  ///@{
  /// Sampling of the table will be done agnostic to the values. If this is false,
  /// then the Sampling will assume that the numeric columns represent
  /// different classes, and will treat the selection as the satisfaction of a
  /// computational knapsack, allowing overflow.
  ///
  /// This is set to true by default.
  vtkSetMacro(AgnosticSampling,bool);
  ///@}
  vtkGetMacro(AgnosticSampling,bool);

  ///@{
  /// Sets the sampling to be done with or without replacement.
  ///
  /// This is set to false by default.
  vtkSetMacro(SampleWithReplacement,bool);
  ///@}
  vtkGetMacro(SampleWithReplacement,bool);


  ///@{
  /// If true, negative values will be treated as zeroes.
  /// This is set to true by default.
  vtkSetMacro(IgnoreClassNegatives,bool);
  ///@}
  vtkGetMacro(IgnoreClassNegatives,bool);

  ///@{
  /// Sets the sampling parameter. This number will represent either the
  /// absolute number of samples, the probability of selection, or the log
  /// probability of selection, depending on the SamplingMethod.
  vtkSetMacro(SamplingParameter,double);
  ///@}
  vtkGetMacro(SamplingParameter,double);


  ///@{
  /// Sets the sampling parameter. This number will represent either the
  /// absolute number of samples, the probability of selection, or the log
  /// probability of selection, depending on the SamplingMethod.
  void SetRandomGeneratorSeed(unsigned int seed);

  ///@{
  /// Sets the minimum number of selected rows when using purely probabilistic,
  /// agnostic sampling (SAMPLE_PROBABILITY and AgnosticSampling(true)).
  ///
  /// Purely probabilistic, class-aware sampling is the same as probabilistic
  /// class-agnostic sampling unless the probabilities are class-dependent,
  /// which this filter does not currently support.
  ///
  /// This is set to 1 by default.
  vtkSetMacro(MinSelections,double);
  ///@}
  vtkGetMacro(MinSelections,double);

  ///@{
  /// Add Truth columns, call this for each column that is to be
  /// included as a class column
  void AddTruthColumn(const char* column);
  ///@}

protected:
  vtkSampleTableRows();
  ~vtkSampleTableRows();

  int FillInputPortInformation(int port, vtkInformation* info);
  int FillOutputPortInformation( int port, vtkInformation* info );

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkSampleTableRows(const vtkSampleTableRows&); // Not implemented
  void operator=(const vtkSampleTableRows&);   // Not implemented

  bool SampleRows(vtkTable* input, std::vector<vtkDataArray*> truth_arrays, vtkTable* input_indices_table,
      vtkTable* output, vtkTable* output_indices_table);


  unsigned int Mode;

  vtkIdType SamplingMethod;

  double SamplingParameter;
  unsigned int RandomGeneratorSeed;

  bool AgnosticSampling;
  bool SampleWithReplacement;
  bool IgnoreClassNegatives;

  double  MinSelections;

  std::vector<std::string> TruthColumns;

  int SetupTruthArrays(
      vtkTable *observation_truth_table,
      std::vector<vtkDataArray*>& observation_truth_arrays);

  titanSampleTableRows  TableSampler;
};

#endif
