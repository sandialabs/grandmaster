/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanNormalizeVectors titanNormalizeVectors.h <Clustering/titanNormalizeVector.h>
/// \brief ...
///
///  titanNormalizeVectors normalizes each vector. Note that the number
///  of vectors never changes using this method.
#ifndef __titanNormalizeVector_h
#define __titanNormalizeVector_h

#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <iostream>

using namespace std;
class titanNormalizeVectors
{
public:
  titanNormalizeVectors() : Power(1)
  {
  }

  titanNormalizeVectors(double power) : Power(power)
  {
  }

  void SetPower(double power)
  {
    Power=power;
  }

  template<typename VectorIteratorT>
  void operator()(
     VectorIteratorT begin,  VectorIteratorT end
    )
  {

    typedef typename VectorIteratorT::value_type observation_type;

    for(VectorIteratorT observation = begin; observation != end; ++observation)
    {
      normalize(*observation,this->Power);
    }
  }
private:
  double Power;

};


#endif
