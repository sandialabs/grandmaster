/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkMatrixVectorIterator_h
#define __vtkMatrixVectorIterator_h

#include <vtkArrayCoordinates.h>
#include <iterator>
#include <vector>

#include <iostream>


/// Model of RandomAccessIterator that makes a matrix (2D vtkArray) look like a 1D collection of vectors, suitable for clustering.
template<typename ArrayT, typename ElementTypeT>
class vtkMatrixVectorIterator
{
  class vtkMatrixVector
  {
  public:
    typedef ElementTypeT value_type;
    value_type * Start;
    size_t Stride;
    size_t NumberOfElements;

    std::vector<size_t> ElementIndices;

    size_t size() const
    {
      return NumberOfElements;
    }

    void resize(const size_t& new_size)
    {
      return;
    }

    value_type operator[](size_t i) const
    {
      return Start[i*Stride];
    }

    value_type& operator[](size_t i)
    {
      return Start[i*Stride];
    }

    template<typename VectorT>
    vtkMatrixVector& operator=(const VectorT& b)
    {
      for(size_t i = 0; i != this->size(); ++i)
      {
        (*this)[i] = b[i];
      }
      return *this;
    }

    vtkMatrixVector& operator=(const vtkMatrixVector& b)
    {
      for(size_t i = 0; i != this->size(); ++i)
      {
        (*this)[i] = b[i];
      }
      return *this;
    }
  };

public:
  typedef std::random_access_iterator_tag iterator_category;
  typedef vtkIdType difference_type;

  typedef vtkMatrixVector  value_type;
  typedef value_type* pointer;
  typedef value_type& reference;


  /// Specifies the array for iteration, plus the dimension (0 or 1) that stores observations, plus the current observation number.
  vtkMatrixVectorIterator(ArrayT* array, vtkIdType observation_dimension, size_t observation) :
    Array(array),
    ObservationDimension(observation_dimension),
    ElementDimension(1 - observation_dimension),
    ElementBegin(array->GetExtent(ElementDimension).GetBegin()),
    ElementEnd(array->GetExtent(ElementDimension).GetEnd())
  {
    this->CurrentCoordinates.SetDimensions(2);
    this->CurrentCoordinates[this->ObservationDimension] = static_cast<vtkIdType>(observation);
    this->CurrentCoordinates[this->ElementDimension] = 0;

    if (ObservationDimension==0)
    {
      this->ObservationStride=1;
      this->CurrentValue.Stride = array->GetExtent(0).GetSize();
    }
    else
    {
      this->ObservationStride=array->GetExtent(0).GetSize();
      this->CurrentValue.Stride = 1;
    }

    this->CurrentValue.NumberOfElements = ElementEnd - ElementBegin;
  }

  ~vtkMatrixVectorIterator()
  {
  }

  vtkIdType operator-(const vtkMatrixVectorIterator& other) const
  {
    return this->CurrentCoordinates[this->ObservationDimension] - other.CurrentCoordinates[other.ObservationDimension];
  }

  bool operator!=(const vtkMatrixVectorIterator& other) const
  {
    return this->CurrentCoordinates[this->ObservationDimension] != other.CurrentCoordinates[other.ObservationDimension];
  }

  bool operator<(const vtkMatrixVectorIterator& other) const
  {
    return this->CurrentCoordinates[this->ObservationDimension] < other.CurrentCoordinates[other.ObservationDimension];
  }

  vtkMatrixVectorIterator& operator++()
  {
    ++this->CurrentCoordinates[this->ObservationDimension];
    return *this;
  }

  vtkMatrixVectorIterator operator+(const size_t offset) const
  {
    return vtkMatrixVectorIterator(this->Array, this->ObservationDimension, static_cast<vtkIdType>(this->CurrentCoordinates[this->ObservationDimension] + offset));
  }

  value_type operator*() const
  {
    this->CurrentValue.Start =
      this->Array->GetStorage() +
      this->CurrentCoordinates[this->ObservationDimension]*this->ObservationStride;
    return this->CurrentValue;
  }

  value_type& operator*()
  {
    this->CurrentValue.Start =
      this->Array->GetStorage() +
      this->CurrentCoordinates[this->ObservationDimension]*this->ObservationStride;
    return this->CurrentValue;
  }

  vtkIdType observation() const
  {
    return this->CurrentCoordinates[this->ObservationDimension];
  }

  mutable vtkArrayCoordinates CurrentCoordinates;

private:
  ArrayT* Array;
  vtkIdType ObservationDimension;
  vtkIdType ElementDimension;
  vtkIdType ElementBegin;
  vtkIdType ElementEnd;
  vtkIdType ObservationStride;

  mutable value_type CurrentValue;
};

#endif
