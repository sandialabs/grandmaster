/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkAssignPedigreeIds.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkAssignPedigreeIds vtkAssignPedigreeIds.h <Common/vtkAssignPedigreeIds.h>
/// \brief Apply colors to a data set.
///

#ifndef __vtkAssignPedigreeIds_h
#define __vtkAssignPedigreeIds_h

#include "titanCommon.h"
#include <vtkPassInputTypeAlgorithm.h>

class TITAN_COMMON_EXPORT vtkAssignPedigreeIds : public vtkPassInputTypeAlgorithm
{
public:
  static vtkAssignPedigreeIds *New();
  vtkTypeMacro(vtkAssignPedigreeIds, vtkPassInputTypeAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
  /// Always keep NUM_ATTRIBUTE_LOCS as the last entry
  enum FieldType
  {
    POINT_DATA=0,
    CELL_DATA=1,
    VERTEX_DATA=2,
    EDGE_DATA=3,
    ROW_DATA=4,
    NUM_ATTRIBUTE_LOCS
  };
//ETX

  ///@{
  /// Set/Get where the data is located that is being mapped.
  /// See FieldType enumeration for possible values.
  /// Default is POINT_DATA.
  vtkSetMacro(FieldType, int);
  vtkGetMacro(FieldType, int);
  ///@}

  ///@{
  /// Set/Get the name of the input array. This must be set prior to execution.
  vtkSetStringMacro(ArrayName);
  vtkGetStringMacro(ArrayName);
  ///@}

protected:
  vtkAssignPedigreeIds();
  ~vtkAssignPedigreeIds();

  /// Convert the vtkGraph into vtkPolyData.
  int RequestData(
    vtkInformation *, vtkInformationVector **, vtkInformationVector *);

  int FillInputPortInformation(int, vtkInformation *);

  char* ArrayName;
  int FieldType;

private:
  vtkAssignPedigreeIds(const vtkAssignPedigreeIds&);  // Not implemented.
  void operator=(const vtkAssignPedigreeIds&);  // Not implemented.
};

#endif
