/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkJoinTables.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/
//
// .NAME vtkJoinTables - This filter 'JOINS' (in database vernacular)
// two tables based upon a join column.
//
// .SECTION Description
// This description is based on an e-mail posted by Craig Courtney on
// 6/21/2003 to the drupal-devel mailing list: http://drupal.org/node/view/322.
//
// There are 3 kinds of join: INNER, LEFT OUTER, and RIGHT OUTER. Each requires
// an ON clause to let the RDBMS know what fields to use joining the tables.
// For each join there are two tables: the left table and the right table.
// The syntax is as follows:
//
// {left table} {INNER | LEFT | RIGHT} JOIN {right table} ON {join criteria}
//
// An INNER JOIN returns only those rows from the left table having a matching
// row in the right table based on the join criteria.
//
// A LEFT JOIN returns ALL rows from the left table even if no matching rows
// where found in the right table. Any values selected out of the right table
// will be null for those rows where no matching row is found in the right table.
//
// A RIGHT JOIN works exactly the same as a left join but reversing the direction.
// So it would return all rows in the right table regardless of matching rows in
// the left table.
//
// It is recommended that you not use right joins, as a query can
// always be rewritten to use left joins which tend to be more
// portable and easier to read.  All you need to do is swap the
// inputs.  Foo RIGHT OUTER JOIN Bar is equivalent to Bar LEFT OUTER
// JOIN Foo.
//
// So this filter only has options for INNER and LEFT JOINS.
//
// Also this filter has a very limited join criteria. The only option is
// equivalence between values in the 'join' columns of the tables.
//
// The API warrants some discussion:
//
// SetLeftTableInputConnection(vtkAlgorithmOutput *conn) is just syntactic sugar
// for vtkJoinTables->SetInputConnection(0, conn).
//
// SetRightTableInputConnection(vtkAlgorithmOutput *conn)is just syntactic sugar
// for vtkJoinTables->SetInputConnection(1, conn).
//
// SetLeftJoinColumn("column_name") sets the left join column
// SetRightJoinColumn("column_name") sets the right join column
// SetJoinType(int join_type) defaults to INNER_JOIN but can be set
// to LEFT_JOIN if you want all the fields in your left table to
// be reflection in your output (with NULLS) for those entries
// which have to matching entry in the right table.
//
// .SECTION Notes
// This filter checks the left table for pedigree ids and will
// forward those through. There is no support for passing through
// pedigree ids on the right table.
//
// .SECTION Caveats
//
// Since vtkAbstractArray has no way to indicate which of its elements
// are valid and which are not, it is not sufficient to rely on just
// the values in the output table to determine which elements are
// supposed to be NULL and which are not.  In particular, any column
// that is a subclass of vtkDataArray will contain 0 instead of NULL
// values.  vtkStringArray columns will contain empty strings instead
// of NULL values.  The vtkVariant type is capable of storing a NULL
// value explicitly and will do so.
//
// However, since vtkTable uses the field data for its array storage,
// we have nowhere to put auxiliary arrays that would indicate which
// rows/columns contain nulls.  You're on your own.
//
// .SECTION Thanks
//
// Thanks to Brian Wylie and Andy Wilson of Sandia National Labs for
// writing this class.

#ifndef __vtkJoinTables_h
#define __vtkJoinTables_h

#include "titanCommon.h"
#include "vtkTableAlgorithm.h"

class  TITAN_COMMON_EXPORT vtkJoinTables : public vtkTableAlgorithm
{
public:
  static vtkJoinTables* New();
  vtkTypeMacro(vtkJoinTables,vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  // Set the input for the left table
  void SetLeftTableInputConnection(vtkAlgorithmOutput *conn);
  void SetLeftTableInputData(vtkTable *conn);

  // Description:
  // Set the input for the right table
  void SetRightTableInputConnection(vtkAlgorithmOutput *conn);
  void SetRightTableInputData(vtkTable *conn);

  // Description:
  // Set/Get the join column name for the left table
  vtkSetStringMacro(LeftJoinColumnName);
  vtkGetStringMacro(LeftJoinColumnName);

  // Description:
  // Set/Get the join column name for the right table
  vtkSetStringMacro(RightJoinColumnName);
  vtkGetStringMacro(RightJoinColumnName);

  //BTX
  enum join_type {
    INNER_JOIN = 0,
    LEFT_JOIN = 1
  };
  //ETX

  // Description:
  // Set/Get the join type (INNER_JOIN or LEFT_JOIN)
  vtkSetMacro(JoinType, int);
  vtkGetMacro(JoinType, int);

  // Description:
  // If a column in the right table already exists in the left table,
  // it must be renamed before being added to the output table.  This
  // suffix will be appended to its name to accomplish that.  The
  // caller is responsible for ensuring that this does not cause a new
  // conflict. The default value is "_2".
  vtkSetStringMacro(NameConflictSuffix);
  vtkGetStringMacro(NameConflictSuffix);

protected:
  vtkJoinTables();
  ~vtkJoinTables();

  char* LeftJoinColumnName;
  char* RightJoinColumnName;
  char* NameConflictSuffix;

  int JoinType;

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkJoinTables(const vtkJoinTables&); // Not implemented
  void operator=(const vtkJoinTables&);   // Not implemented
};

#endif
