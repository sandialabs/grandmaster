/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkPalantirXMLWriter.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2009 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/

#include "vtkPalantirXMLWriter.h"

#include "vtkAbstractArray.h"
#include "vtkBitArray.h"
#include "vtkDataSetAttributes.h"
#include "vtkEdgeListIterator.h"
#include "vtkErrorCode.h"
#include "vtkGraph.h"
#include "vtkInformation.h"
#include "vtkIdTypeArray.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"
#include "vtkGraph.h"

#include <vtksys/ios/sstream>


vtkStandardNewMacro(vtkPalantirXMLWriter);

vtkPalantirXMLWriter::vtkPalantirXMLWriter()
{
}

vtkPalantirXMLWriter::~vtkPalantirXMLWriter()
{
}

void vtkPalantirXMLWriter::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

//----------------------------------------------------------------------------
int vtkPalantirXMLWriter::WriteData()
{
  ostream& os = *(this->Stream);

  os << "<?xml version=\"1.0\"?>\n";

  // Open the document-level element.  This will contain the rest of
  // the elements.
  os << "<palantir xmlns=\"http://www.palantirtech.com/pg/schema/import/\">\n";
  os << "<graph>\n";

  os.flush();
  if (os.fail())
    {
    this->SetErrorCode(vtkErrorCode::GetLastSystemError());
    return 0;
    }

  this->WriteObjectSet();
  this->WriteLinkSet();

  // Close the document-level element.
  os << "</graph>\n";
  os << "</palantir>\n";

  os.flush();
  if (os.fail())
    {
    this->SetErrorCode(vtkErrorCode::GetLastSystemError());
    return 0;
    }

  return 1;
}

//----------------------------------------------------------------------------
void vtkPalantirXMLWriter::WriteObjectSet()
{
  vtkIndent indent = vtkIndent().GetNextIndent();

  vtkGraph* graph = vtkGraph::SafeDownCast(this->GetInput());
  vtkDataSetAttributes* dsa = graph->GetVertexData();

  ostream& os = *(this->Stream);

  os << indent << "<objectSet>\n";

  indent = indent.GetNextIndent();

  vtkAbstractArray *labelArray = dsa->GetAbstractArray("label");
  vtkAbstractArray *typeArray = dsa->GetAbstractArray("type");
  vtkAbstractArray *idArray = dsa->GetAbstractArray("ids");
  for(vtkIdType i=0; i < labelArray->GetNumberOfTuples(); ++i)
    {
    os << indent << "<object id='" << idArray->GetVariantValue(i).ToString() << "' ";
    os << "type='" << typeArray->GetVariantValue(i).ToString() << "'>\n";
    vtkIndent tempIndent = indent.GetNextIndent();
    os << tempIndent << "<propertySet>\n";
    tempIndent = tempIndent.GetNextIndent();
    os << tempIndent << "<property type='com.palantir.property.IntrinsicTitle'>\n";
    tempIndent = tempIndent.GetNextIndent();
    os << tempIndent << "<propertyValue>\n";
    tempIndent = tempIndent.GetNextIndent();
    os << tempIndent << "<propertyComponent type='TITLE'>\n";
    tempIndent = tempIndent.GetNextIndent();
    os << tempIndent << "<propertyData>";
    os << labelArray->GetVariantValue(i).ToString();
    os << "</propertyData>\n";
    os << tempIndent << "</propertyComponent>\n";
    os << tempIndent << "</propertyValue>\n";
    os << tempIndent << "</property>\n";
    os << tempIndent << "</propertySet>\n";
    os << tempIndent << "</object>\n";
    }

  os << indent << "</objectSet>\n";
  os.flush();
  if (os.fail())
    {
    this->SetErrorCode(vtkErrorCode::GetLastSystemError());
    return;
    }
}

//----------------------------------------------------------------------------
void vtkPalantirXMLWriter::WriteLinkSet()
{
  vtkIndent indent = vtkIndent().GetNextIndent();

  vtkGraph* graph = vtkGraph::SafeDownCast(this->GetInput());

  ostream& os = *(this->Stream);

  os << indent << "<linkSet>\n";

  indent = indent.GetNextIndent();

  vtkAbstractArray *vertexIdArray = graph->GetVertexData()->GetAbstractArray("ids");
  vtkAbstractArray *typeArray = graph->GetEdgeData()->GetAbstractArray("type");
  vtkAbstractArray *edgeIdArray = graph->GetEdgeData()->GetAbstractArray("edge");
  vtkSmartPointer<vtkEdgeListIterator> edges = vtkSmartPointer<vtkEdgeListIterator>::New();
  graph->GetEdges(edges);
  while (edges->HasNext())
    {
    vtkEdgeType e = edges->Next();
    vtkIdType sourceIndex = e.Source;
    vtkIdType targetIndex = e.Target;
    vtkStdString sourceId = vertexIdArray->GetVariantValue(sourceIndex).ToString();
    vtkStdString targetId = vertexIdArray->GetVariantValue(targetIndex).ToString();

    os << indent.GetNextIndent() << "<link id='" << edgeIdArray->GetVariantValue(e.Id).ToString() << "' ";
    os << "parentRef='" << sourceId << "' ";
    os << "childRef='" << targetId << "' ";
    os << "type='com.palantir.link." << typeArray->GetVariantValue(e.Id).ToString() << "'/>\n";
    }

  os << indent << "</linkSet>\n";
  os.flush();
  if (os.fail())
    {
    this->SetErrorCode(vtkErrorCode::GetLastSystemError());
    return;
    }
}
