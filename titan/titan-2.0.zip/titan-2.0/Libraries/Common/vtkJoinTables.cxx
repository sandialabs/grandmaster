/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkJoinTables.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/

#include "vtkJoinTables.h"

#include "vtkAbstractArray.h"
#include "vtkBitArray.h"
#include "vtkDataSetAttributes.h"
#include "vtkFieldData.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkStreamingDemandDrivenPipeline.h"
#include "vtkStringArray.h"
#include "vtkTable.h"
#include "vtkVariantArray.h"

#include <cassert>
#include <map>


vtkStandardNewMacro(vtkJoinTables);
//---------------------------------------------------------------------------
vtkJoinTables::vtkJoinTables()
{
  this->LeftJoinColumnName = 0;
  this->RightJoinColumnName = 0;
  this->SetJoinType(INNER_JOIN);
  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(1);
  this->NameConflictSuffix = NULL;
  this->SetNameConflictSuffix("_2");
}

//---------------------------------------------------------------------------
vtkJoinTables::~vtkJoinTables()
{
  this->SetLeftJoinColumnName(0);
  this->SetRightJoinColumnName(0);
  this->SetNameConflictSuffix(0);
}

// Just some syntactic sugar
void vtkJoinTables::SetLeftTableInputConnection(vtkAlgorithmOutput *conn)
{
  this->SetInputConnection(0, conn);
}

// Just some syntactic sugar
void vtkJoinTables::SetLeftTableInputData(vtkTable *conn)
{
  this->SetInputData(0, conn);
}

// Just some syntactic sugar
void vtkJoinTables::SetRightTableInputConnection(vtkAlgorithmOutput *conn)
{
  this->SetInputConnection(1, conn);
}

// Just some syntactic sugar
void vtkJoinTables::SetRightTableInputData(vtkTable *conn)
{
  this->SetInputData(1, conn);
}

//---------------------------------------------------------------------------
int vtkJoinTables::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // Get input tables
  vtkInformation* leftTableInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* leftTable = vtkTable::SafeDownCast(
    leftTableInfo->Get(vtkDataObject::DATA_OBJECT()));
  vtkInformation* rightTableInfo = inputVector[1]->GetInformationObject(0);
  vtkTable* rightTable = vtkTable::SafeDownCast(
    rightTableInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get output table
  vtkInformation* outInfo = outputVector->GetInformationObject(0);
  vtkTable* outputTable = vtkTable::SafeDownCast(
    outInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get the left join column
  vtkAbstractArray* leftJoinColumn =
    leftTable->GetColumnByName(this->LeftJoinColumnName);
  if (leftJoinColumn == NULL)
    {
    if (this->LeftJoinColumnName == NULL)
      {
      vtkErrorMacro(<< "Left join column name is NULL!");
      }
    else
      {
      if( leftTable->GetNumberOfRows() == 0 )
        {
        // Nothing to do, so return...
        return 1;
        }
      else
        {
        vtkErrorMacro(<< "Could not find left join column: " << this->LeftJoinColumnName);
        }
      }
      return 0;
    }

  // Get the right join column
  vtkAbstractArray* rightJoinColumn =
    rightTable->GetColumnByName(this->RightJoinColumnName);
  if (rightJoinColumn == NULL)
    {
    if (this->RightJoinColumnName == NULL)
      {
      vtkErrorMacro(<< "Right join column name is NULL!");
      }
    else
      {
      vtkErrorMacro(<< "Could not find right join column: " << this->RightJoinColumnName);
      }
      return 0;
    }

  // Add all the columns in the left input to the output.
  int row, col;
  for (col = 0; col < leftTable->GetNumberOfColumns(); ++col)
    {
    vtkAbstractArray *column = leftTable->GetColumn(col);
    vtkAbstractArray *newColumn = vtkAbstractArray::CreateArray(column->GetDataType());
    newColumn->SetName(column->GetName());
    newColumn->SetNumberOfComponents(column->GetNumberOfComponents());
    outputTable->AddColumn(newColumn);
    newColumn->Delete();

    // Check for pedigree ids
    if(leftTable->GetRowData()->GetPedigreeIds() == column)
      {
      outputTable->GetRowData()->SetPedigreeIds(newColumn);
      }
    }

  // Add all the columns from the right table to the output.  If there
  // are duplicated names then we'll have to rename some of the new
  // columns.
  std::map<vtkStdString, vtkStdString> rightColumnNameMap;
  for (col = 0; col < rightTable->GetNumberOfColumns(); ++col)
    {
    vtkAbstractArray *column = rightTable->GetColumn(col);
    vtkStdString oldName(column->GetName());
    vtkStdString newName = oldName;
    if (leftTable->GetColumnByName(oldName.c_str()) != NULL)
      {
      newName += this->NameConflictSuffix;
      }
    rightColumnNameMap[oldName] = newName;
    vtkAbstractArray *newColumn = vtkAbstractArray::CreateArray(column->GetDataType());
    newColumn->SetNumberOfComponents(column->GetNumberOfComponents());
    newColumn->SetName(newName.c_str());
    outputTable->AddColumn(newColumn);
    newColumn->Delete();
    }

  // Make a map from the values in the right join column to the row
  // indices in which those values occur.  This is the lookup table
  // that will let us do the actual join.  We use a multimap instead
  // of a regular map because values in the join column (both left and
  // right) are not guaranteed to be unique.
  typedef std::multimap<vtkVariant,vtkIdType,vtkVariantLessThan> variantMap;
  variantMap joinValueToIndex;
  for (row = 0; row < rightJoinColumn->GetNumberOfTuples(); ++row)
    {
    std::pair< vtkVariant, int > mapEntry;
    mapEntry.first = rightJoinColumn->GetVariantValue(row);
    mapEntry.second = row;
    joinValueToIndex.insert(mapEntry);
    }

  vtkDebugMacro(<<"joinValueToIndex map contains "
                << joinValueToIndex.size() << " entries");

  // Now we're ready to do the actual join.
  for (row = 0; row < leftJoinColumn->GetNumberOfTuples(); ++row)
    {
    vtkVariant leftJoinValue = leftJoinColumn->GetVariantValue(row);
    variantMap::const_iterator joinRowIter;

    // The rows added in a left outer join are a superset of the rows
    // added in an inner join.  That means that we always run the
    // logic for an inner join -- we'll do that first.

    // Add exactly those rows from the right table that match the
    // join condition.
    if (joinValueToIndex.find(leftJoinValue) != joinValueToIndex.end())
      {
      vtkDebugMacro(<<"Executing inner join on index value "
                    <<leftJoinValue.ToString().c_str());
      }
    else
      {
      vtkDebugMacro(<<"Index value "
                    << leftJoinValue.ToString().c_str()
                    << " not found for inner join");
      }

    for (joinRowIter = joinValueToIndex.lower_bound(leftJoinValue);
         joinRowIter != joinValueToIndex.upper_bound(leftJoinValue);
         ++joinRowIter)
      {
      vtkIdType newRowIndex = outputTable->InsertNextBlankRow();
      int rightRowIndex = (*joinRowIter).second;
      vtkDebugMacro(<<"Joining left row " << row << " to right row "
                    << rightRowIndex);
      // columns from left table first
      for (col = 0; col < leftTable->GetNumberOfColumns(); ++col)
        {
        vtkAbstractArray *oldColumn = leftTable->GetColumn(col);
        vtkAbstractArray *newColumn = outputTable->GetColumnByName(oldColumn->GetName());
        assert(newColumn != NULL);
        newColumn->SetTuple(newRowIndex, row, oldColumn);
        }
      // now columns from the right table.  Be careful about
      // possible renamings.
      for (col = 0; col < rightTable->GetNumberOfColumns(); ++col)
        {
        vtkAbstractArray *oldColumn = rightTable->GetColumn(col);
        vtkStdString oldName(oldColumn->GetName());
        assert(rightColumnNameMap.find(oldName) != rightColumnNameMap.end());
        vtkStdString newName = rightColumnNameMap[oldName];
        vtkAbstractArray *newColumn = outputTable->GetColumnByName(newName.c_str());
        assert(newColumn != NULL);
        newColumn->SetTuple(newRowIndex, rightRowIndex, oldColumn);
        vtkDebugMacro(<<"Right column " << col << " has "
                      << newColumn->GetNumberOfTuples() << " tuple(s)");
        }
      } // Done adding rows that match the inner join

    // The difference between inner and outer joins is that we'll add
    // columns from the left table and pad the right columns with nulls
    // if there's no match.  We handle that here.
    if (joinValueToIndex.find(leftJoinValue) == joinValueToIndex.end() &&
        this->JoinType == vtkJoinTables::LEFT_JOIN)
      {
      vtkDebugMacro(<<"Executing outer join (right columns null) on value "
                    << leftJoinValue.ToString().c_str());
      vtkIdType newRowIndex = outputTable->InsertNextBlankRow();

      // Copy in the values from the left table
      for (col = 0; col < leftTable->GetNumberOfColumns(); ++col)
        {
        vtkAbstractArray *oldColumn = leftTable->GetColumn(col);
        vtkAbstractArray *newColumn = outputTable->GetColumnByName(oldColumn->GetName());
        assert(newColumn != NULL);
        newColumn->SetTuple(newRowIndex, row, oldColumn);
        }

      // Leave the columns for the right table blank.
      } // Done handling outer join logic
    } // Done iterating over rows in left table


  return 1;
}

//---------------------------------------------------------------------------
void vtkJoinTables::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "LeftJoinColumnName: "
     << (this->LeftJoinColumnName ? this->LeftJoinColumnName : "(null)") << endl;
  os << indent << "RightJoinColumnName: "
     << (this->RightJoinColumnName ? this->RightJoinColumnName : "(null)") << endl;
  os << indent << "JoinType: "
     << ((this->JoinType == vtkJoinTables::INNER_JOIN) ? "INNER_JOIN" : "LEFT_JOIN") << endl;
}


// Storage
#if 0
  if (!this->FirstTablePrefix || !this->SecondTablePrefix)
    {
    vtkErrorMacro("FirstTablePrefix and/or SecondTablePrefix must be non-null.");
    return 0;
    }
  if (!strcmp(this->FirstTablePrefix, this->SecondTablePrefix))
    {
    vtkErrorMacro("FirstTablePrefix and SecondTablePrefix must be different.");
    return 0;
    }

  // Add columns from table 1
  for (int c = 0; c < table1->GetNumberOfColumns(); c++)
    {
    vtkAbstractArray* col = table1->GetColumn(c);
    char* name = col->GetName();
    char* newName = name;
    if (this->PrefixAllButMerged)
      {
      int len = static_cast<int>(strlen(name));
      int prefixLen = static_cast<int>(strlen(this->FirstTablePrefix));
      newName = new char[prefixLen + len + 1];
      strcpy(newName, this->FirstTablePrefix);
      strcat(newName, name);
      }
    vtkAbstractArray* newCol = vtkAbstractArray::CreateArray(col->GetDataType());
    newCol->DeepCopy(col);
    newCol->SetName(newName);
    //vtkWarningMacro("adding column " << newCol->GetName() << " of size " << newCol->GetNumberOfTuples());
    output->AddColumn(newCol);
    newCol->Delete();
    }

  // Add empty values
  for (int r = 0; r < table2->GetNumberOfRows(); r++)
    {
    output->InsertNextBlankRow();
    }

  // Add columns from table 2
  vtkStringArray* toMerge = vtkStringArray::New();
  vtkTable* tempTable = vtkTable::New();
  for (int c = 0; c < table2->GetNumberOfColumns(); c++)
    {
    vtkAbstractArray* col = table2->GetColumn(c);
    char* name = col->GetName();
    vtkAbstractArray* newCol = vtkAbstractArray::CreateArray(col->GetDataType());
    if (table1->GetColumnByName(name) != 0)
      {
      // We have a naming conflict.
      // Rename both columns using the prefixes.
      int len = static_cast<int>(strlen(name));
      char* newName1 = new char[len + strlen(this->FirstTablePrefix) + 1];
      strcpy(newName1, this->FirstTablePrefix);
      strcat(newName1, name);
      if (!this->PrefixAllButMerged)
        {
        vtkAbstractArray* col1 = output->GetColumnByName(name);
        col1->SetName(newName1);
        }
      char* newName2 = new char[len + strlen(this->SecondTablePrefix) + 1];
      strcpy(newName2, this->SecondTablePrefix);
      strcat(newName2, name);
      newCol->SetName(newName2);
      toMerge->InsertNextValue(newName1);
      toMerge->InsertNextValue(newName2);
      toMerge->InsertNextValue(name);
      }
    else
      {
      char* newName = name;
      if (this->PrefixAllButMerged)
        {
        int len = static_cast<int>(strlen(name));
        int prefixLen = static_cast<int>(strlen(this->SecondTablePrefix));
        newName = new char[prefixLen + len + 1];
        strcpy(newName, this->SecondTablePrefix);
        strcat(newName, name);
        }
      newCol->SetName(newName);
      }
    tempTable->AddColumn(newCol);
    newCol->Delete();
    }

  // Add empty values
  for (int r = 0; r < table1->GetNumberOfRows(); r++)
    {
    tempTable->InsertNextBlankRow();
    }

  // Add values from table 2
  for (int r = 0; r < table2->GetNumberOfRows(); r++)
    {
    for (int c = 0; c < tempTable->GetNumberOfColumns(); c++)
      {
      vtkAbstractArray* tempCol = tempTable->GetColumn(c);
      vtkAbstractArray* col = table2->GetColumn(c);
      tempCol->InsertNextTuple(r, col);
      }
    }

  // Move the columns from the temp table to the output table
  for (int c = 0; c < tempTable->GetNumberOfColumns(); c++)
    {
    vtkAbstractArray* col = tempTable->GetColumn(c);
    //vtkWarningMacro("adding column " << col->GetName() << " of size " << col->GetNumberOfTuples());
    output->AddColumn(col);
    }
  tempTable->Delete();

  // Merge any arrays that have the same name
  vtkMergeColumns* mergeColumns = vtkMergeColumns::New();
  vtkTable* temp = vtkTable::New();
  temp->ShallowCopy(output);
  mergeColumns->SetInput(temp);
  if (this->MergeColumnsByName)
    {
    for (vtkIdType i = 0; i < toMerge->GetNumberOfValues(); i += 3)
      {
      mergeColumns->SetInputArrayToProcess(
        0, 0, 0, vtkDataObject::FIELD_ASSOCIATION_ROWS,
        toMerge->GetValue(i).c_str());
      mergeColumns->SetInputArrayToProcess(
        1, 0, 0, vtkDataObject::FIELD_ASSOCIATION_ROWS,
        toMerge->GetValue(i+1).c_str());
      mergeColumns->SetMergedColumnName(toMerge->GetValue(i+2).c_str());
      mergeColumns->Update();
      temp->ShallowCopy(mergeColumns->GetOutput());
      }
    }
  mergeColumns->Delete();
  toMerge->Delete();

  output->ShallowCopy(temp);
  temp->Delete();

  // Clean up pipeline information
  int piece = -1;
  int npieces = -1;
  if (outInfo->Has(
        vtkStreamingDemandDrivenPipeline::UPDATE_PIECE_NUMBER()))
    {
    piece = outInfo->Get(
      vtkStreamingDemandDrivenPipeline::UPDATE_PIECE_NUMBER());
    npieces = outInfo->Get(
      vtkStreamingDemandDrivenPipeline::UPDATE_NUMBER_OF_PIECES());
    }
  output->GetInformation()->Set(vtkDataObject::DATA_NUMBER_OF_PIECES(), npieces);
  output->GetInformation()->Set(vtkDataObject::DATA_PIECE_NUMBER(), piece);

  return 1;

#endif
