
#include <vtkFieldData.h>
#include <vtkIntArray.h>
#include <vtkMultiStringToCategory.h>
#include <vtkNew.h>
#include <vtkStringArray.h>
#include <vtkTable.h>

#include <sstream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

int main(int, char*[])
{
  std::cerr << "Running the filter ..." << std::endl;
  vtkNew<vtkMultiStringToCategory> f;
  vtkNew<vtkTable> t;
  f->AddInputArray("an invalid input array name");
  f->ResetInputArrays();
  for (int i = 0; i < 10; ++i)
    {
    vtkNew<vtkStringArray> s;
    s->SetName(vtkVariant(i).ToString());
    for (int j = 0; j < 10; ++j)
      {
      s->InsertNextValue(vtkVariant(j%(i+1)).ToString());
      }
    t->AddColumn(s.GetPointer());
    f->AddInputArray(vtkVariant(i).ToString());
    }
  f->SetInputData(t.GetPointer());
  f->Update();

  std::cerr << "Testing the output ..." << std::endl;
  vtkTable* out = vtkTable::SafeDownCast(f->GetOutput(0));
  test_expression(out);
  for (int i = 0; i < 10; ++i)
    {
    vtkIntArray* arr = vtkIntArray::SafeDownCast(out->GetColumnByName((vtkVariant(i).ToString()+"_category").c_str()));
    test_expression(arr);
    for (int j = 0; j < 10; ++j)
      {
      test_expression(arr->GetValue(j) == j%(i+1));
      }
    }

  std::cerr << "Testing maps of numbers back to strings ..." << std::endl;
  vtkFieldData* outMaps = out->GetFieldData();
  for (int i = 0; i < 10; ++i)
    {
    vtkStringArray* arr = vtkStringArray::SafeDownCast(outMaps->GetAbstractArray(vtkVariant(i).ToString()));
    test_expression(arr);
    test_expression(arr->GetNumberOfTuples() == (i+1));
    for (int j = 0; j < arr->GetNumberOfTuples(); ++j)
      {
      test_expression(arr->GetValue(j) == vtkVariant(j).ToString());
      }
    }

  std::cerr << "... Done" << std::endl;
  return 0;
}
