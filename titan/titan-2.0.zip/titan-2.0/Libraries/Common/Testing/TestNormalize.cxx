/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <iostream>
#include <iterator>
#include <stdexcept>

#include <titanNormalizeVectors.h>
#include <titanNormalizeFeatures.h>

using namespace std;

int main(int argc, char *argv[])
{
  try
  {

    /* Data initialization */
    std::vector<std::vector<double> > observations, observations_copy;

    // Create observation vectors.

    std::vector<double> ob0, ob1, ob2, ob3, ob4;

    ob0.resize(4,.9);
    ob1.resize(4,.1);
    ob2.resize(4,.8);

    ob3.push_back(.1);
    ob3.push_back(-.4);
    ob3.push_back(.2);
    ob3.push_back(.3);

    ob4.push_back(-.30);
    ob4.push_back(1);
    ob4.push_back(0);
    ob4.push_back(.50);

    observations.push_back(ob0);
    observations.push_back(ob1);
    observations.push_back(ob2);
    observations.push_back(ob3);
    observations.push_back(ob4);

    observations_copy = observations;

    cout << "Before L1 normalization:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;

    titanNormalizeVectors()(observations.begin(), observations.end());

    cout << "After L1 normalization:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;

    observations = observations_copy;

    titanNormalizeVectors(2)(observations.begin(), observations.end());

    cout << "After L2 normalization:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;

    titanNormalizeFeatures  feature_normalize;
    feature_normalize.SetNormalizedMinMax(0,1);

    observations=observations_copy;
    feature_normalize.GenerateModel(observations.begin(),observations.end(),false);
    feature_normalize(observations.begin(),observations.end());

    cout << "After [0,1] feature normalization:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;

    feature_normalize.SetNormalizedMinMax(-1,1);

    observations=observations_copy;
    feature_normalize.GenerateModel(observations.begin(),observations.end(),false);
    feature_normalize(observations.begin(),observations.end());

    cout << "After [-1,1] feature normalization:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;


    /****/

    feature_normalize.SetNormalizedMinMax(0,1);

    observations=observations_copy;
    feature_normalize.GenerateModel(observations.begin(),observations.end(),true);
    feature_normalize(observations.begin(),observations.end());

    cout << "After [0,1] global feature normalization:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;


    /****/

    feature_normalize.SetNormalizedMinMax(0,1);

    observations=observations_copy;
    feature_normalize.SetGlobalMinMax(-.5,.5);
    feature_normalize.GenerateModel(observations.begin(),observations.end(),true);
    feature_normalize(observations.begin(),observations.end());

    cout << "After [0,1] global feature normalization, setting the global min and max to -.5 and .5:" << endl;
    for (size_t i=0; i != observations.size(); ++i)
    {
      cout << observations[i] << endl;
    }
    cout << endl;

    return 0;
  }
  catch(std::exception& e)
  {
    cerr << e.what() << endl;
    return 1;
  }

  return 0;
}
