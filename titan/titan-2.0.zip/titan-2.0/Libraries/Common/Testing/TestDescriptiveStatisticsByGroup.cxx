#include "vtkDescriptiveStatisticsByGroup.h"
#include "vtkDoubleArray.h"
#include "vtkIntArray.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"

int main(int, char*[])
{
  vtkSmartPointer<vtkTable> table = vtkSmartPointer<vtkTable>::New();
  vtkSmartPointer<vtkDoubleArray> da = vtkSmartPointer<vtkDoubleArray>::New();
  vtkSmartPointer<vtkIntArray> ga = vtkSmartPointer<vtkIntArray>::New();
  da->SetName("data");
  ga->SetName("group");
  for (int i = 0; i < 100; ++i)
    {
    da->InsertNextValue(i);
    ga->InsertNextValue(i/10);
    }
  table->AddColumn(da);
  table->AddColumn(ga);

  vtkSmartPointer<vtkDescriptiveStatisticsByGroup> group =
    vtkSmartPointer<vtkDescriptiveStatisticsByGroup>::New();
  group->SetInputData(table);
  group->SetArrayName("data");
  group->SetGroupArrayName("group");
  group->Update();
  vtkTable* output = group->GetOutput();
  output->Dump(3);

  // sanity check that sums are right
  for (vtkIdType r = 0; r < output->GetNumberOfRows(); ++r)
    {
    double group = output->GetValueByName(r, "Group").ToDouble();
    if (output->GetValueByName(r, "Sum").ToDouble() != group*100+45)
      {
      cerr << "invalid sum" << endl;
      return 1;
      }
    }

  return 0;
}
