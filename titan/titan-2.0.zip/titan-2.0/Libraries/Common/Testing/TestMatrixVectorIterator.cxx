/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/
#include <iostream>

#include "vtkTable.h"
#include "vtkDoubleArray.h"
#include "vtkDataArray.h"
#include "vtkDenseArray.h"

#include "vtkSmartPointer.h"
#include "vtkMatrixVectorIterator.h"
#include "vtkMatrixVectorAdaptor.h"

#include "titanVectorTraits.h"

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace std;

int main(int argc, char* argv[])
{
  VTK_CREATE(vtkDenseArray<double>, array);

  size_t k=0;
  array->Resize(4,4);
  array->Fill(0);

  vtkMatrixVectorIterator<vtkDenseArray<double>,double> observation_begin(array,0,0);
  vtkMatrixVectorIterator<vtkDenseArray<double>,double> observation_end(array,0,4);

  typedef vtkMatrixVectorIterator<vtkDenseArray<double>,double> iterator;

  vtkMatrixVectorAdaptor<vtkDenseArray<double>,double> adaptor(array,0);

  adaptor.dump();

  for (iterator observation = observation_begin; observation != observation_end; ++observation)
  {
    vector_traits<iterator::value_type>::put(*observation,k,4.0);
  }

  adaptor.dump();

  k++;

  for (size_t i = 0; i != 4; ++i)
  {
    vector_traits<iterator::value_type>::put(*(adaptor.begin()+i),k,4.0);
  }

  adaptor.dump();

 return 0;
}
