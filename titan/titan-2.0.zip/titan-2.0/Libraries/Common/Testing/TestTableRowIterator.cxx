/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/
#include <iostream>

#include "vtkTable.h"
#include "vtkDoubleArray.h"
//#include "vtkDataArray.h"

#include "vtkSmartPointer.h"
#include "vtkTableRowIterator.h"

#include "titanVectorTraits.h"
#include <titanNormalizeVectors.h>


#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace std;

int main(int argc, char* argv[])
{
  VTK_CREATE(vtkDoubleArray, Col1);
  VTK_CREATE(vtkDoubleArray, Col2);
  VTK_CREATE(vtkDoubleArray, Col3);

  Col1->SetName("Col1");
  Col2->SetName("Col2");
  Col3->SetName("Col3");

  Col1->InsertNextTuple1(1.0);
  Col1->InsertNextTuple1(2.0);
  Col1->InsertNextTuple1(3.0);
  Col1->InsertNextTuple1(4.0);

  Col2->InsertNextTuple1(3.14159);
  Col2->InsertNextTuple1(3.112);
  Col2->InsertNextTuple1(2.7);
  Col2->InsertNextTuple1(99.21);

  Col3->InsertNextTuple1(11);
  Col3->InsertNextTuple1(12);
  Col3->InsertNextTuple1(13);
  Col3->InsertNextTuple1(14);

  VTK_CREATE(vtkTable, TestTable);
  TestTable->AddColumn(Col1);
  TestTable->AddColumn(Col2);
  TestTable->AddColumn(Col3);

  std::vector<vtkDoubleArray*> feature_arrays;

  feature_arrays.push_back(Col1);
  feature_arrays.push_back(Col2);
  feature_arrays.push_back(Col3);

  TestTable->Dump(7);

  typedef vtkTableRowIterator<vtkDoubleArray,double> iterator;
  typedef iterator::value_type iterator_value_type;

  size_t  k=0;

  iterator  observation_begin(feature_arrays.begin(), feature_arrays.end(), 0);
  iterator  observation_end(feature_arrays.begin(), feature_arrays.end(), 4);

  for (iterator observation = observation_begin; observation != observation_end; ++observation)
  {
    vector_traits<iterator::value_type>::put(*observation,k,4.0);
  }

  for (vtkIdType i=0; i != TestTable->GetNumberOfRows(); ++i)
  {
    if (feature_arrays[0]->GetTuple1(0) != 4.0)
      {
      cerr << "Iterator put() did not work!" << endl;
      return 1;
      }
  }

  TestTable->Dump(7);

  for (vtkIdType i=0; i != 3; ++i)
  {
    feature_arrays[i]->SetTuple1(0,4.0);
  }

  double * val = feature_arrays[0]->GetTuple(0);

  TestTable->Dump(7);



 return 0;
}
