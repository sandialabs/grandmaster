#include "vtkOrderStatisticsByGroup.h"
#include "vtkDoubleArray.h"
#include "vtkIntArray.h"
#include "vtkSmartPointer.h"
#include "vtkTable.h"

int main(int, char*[])
{
  vtkSmartPointer<vtkTable> table = vtkSmartPointer<vtkTable>::New();
  vtkSmartPointer<vtkDoubleArray> da = vtkSmartPointer<vtkDoubleArray>::New();
  vtkSmartPointer<vtkIntArray> ga = vtkSmartPointer<vtkIntArray>::New();
  da->SetName("data");
  ga->SetName("group");
  for (int i = 0; i < 100; ++i)
    {
    da->InsertNextValue(i);
    ga->InsertNextValue(i%10);
    }
  table->AddColumn(da);
  table->AddColumn(ga);

  vtkSmartPointer<vtkOrderStatisticsByGroup> group =
    vtkSmartPointer<vtkOrderStatisticsByGroup>::New();
  group->SetInputData(table);
  group->SetArrayName("data");
  group->SetGroupArrayName("group");
  group->Update();
  vtkTable* output = group->GetOutput();
  output->Dump(20);

  // sanity check that first quartiles are right
  for (vtkIdType r = 0; r < output->GetNumberOfRows(); ++r)
    {
    double group = output->GetValueByName(r, "Group").ToDouble();
    if (output->GetValueByName(r, "Cardinality").ToDouble() != 10)
      {
      cerr << "invalid cardinality" << endl;
      return 1;
      }
    if (output->GetValueByName(r, "Minimum").ToDouble() != group)
      {
      cerr << "invalid minimum" << endl;
      return 1;
      }
    if (output->GetValueByName(r, "First Quartile").ToDouble() != 20 + group)
      {
      cerr << "invalid first quartile" << endl;
      return 1;
      }
    if (output->GetValueByName(r, "Median").ToDouble() != 45 + group)
      {
      cerr << "invalid minimum" << endl;
      return 1;
      }
    if (output->GetValueByName(r, "Third Quartile").ToDouble() != 70 + group)
      {
      cerr << "invalid third quartile" << endl;
      return 1;
      }
    if (output->GetValueByName(r, "Maximum").ToDouble() != 90 + group)
      {
      cerr << "invalid maximum" << endl;
      return 1;
      }
    }

  return 0;
}
