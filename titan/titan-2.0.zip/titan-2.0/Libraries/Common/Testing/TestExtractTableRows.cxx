/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/
#include <iostream>

#include "vtkExtractTableRows.h"
#include "vtkStdString.h"
#include "vtkTable.h"
#include "vtkIdTypeArray.h"
#include "vtkFloatArray.h"
#include "vtkStringArray.h"

#include "vtkSmartPointer.h"
#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

#define DUMP_TABLES 1

using namespace std;

int main(int argc, char* argv[])
{
  int retVal = 0;

  // BUILD A TABLE TO DO SOME SEARCHING AGAINST.
  VTK_CREATE(vtkStringArray, ColString);
  VTK_CREATE(vtkIdTypeArray, ColIntNum);
  VTK_CREATE(vtkFloatArray, ColFloatNum);

  ColString->SetName("ColString");
  ColIntNum->SetName("ColIntNum");
  ColFloatNum->SetName("ColFloatNum");

  ColString->InsertNextValue("Alpha");
  ColString->InsertNextValue("Bravo");
  ColString->InsertNextValue("Charlie");
  ColString->InsertNextValue("Delta");
  ColString->InsertNextValue("Echo");
  ColString->InsertNextValue("Foxtrot");
  ColString->InsertNextValue("Alpha");

  ColIntNum->InsertNextValue(23);
  ColIntNum->InsertNextValue(12);
  ColIntNum->InsertNextValue(77);
  ColIntNum->InsertNextValue(17);
  ColIntNum->InsertNextValue(22);
  ColIntNum->InsertNextValue(12);
  ColIntNum->InsertNextValue(92);

  ColFloatNum->InsertNextValue(3.14159);
  ColFloatNum->InsertNextValue(3.112);
  ColFloatNum->InsertNextValue(2.7);
  ColFloatNum->InsertNextValue(99.21);
  ColFloatNum->InsertNextValue(2.7);
  ColFloatNum->InsertNextValue(1.1);
  ColFloatNum->InsertNextValue(4.23);

  VTK_CREATE(vtkTable, ConditionTable);
  ConditionTable->AddColumn(ColString);
  ConditionTable->AddColumn(ColIntNum);
  ConditionTable->AddColumn(ColFloatNum);

#if DUMP_TABLES
  cout << "Table:" << endl;
  ConditionTable->Dump(10);
#endif

  // TEST 1 -- Just get the strings that match "Alpha" from ColString
  cout << endl << "Test 1" << endl;
  {
  VTK_CREATE(vtkExtractTableRows, test);
  test->SetInputData(0, ConditionTable);
  test->AddMatch("ColString","Alpha");
  test->Update();
#if DUMP_TABLES
  test->GetOutput()->Dump(10);
  cout << "*\tOutput should be strings matching \"Alpha\" from the \"ColString\" column."
            << endl;
#endif

  if(2 != test->GetOutput()->GetNumberOfRows())
    {
    cerr << "FAILED Test 1 (Strings): I found "
         << test->GetOutput()->GetNumberOfRows()
         << " rows but expected only 2" << endl;
    retVal = 1;
    }
  }

  // TEST 2 -- Get rows that match 12 from ColIntNum
  cout << endl << "Test 2" << endl;
  {
  VTK_CREATE(vtkExtractTableRows, test);
  test->SetInputData(0, ConditionTable);
  test->AddMatch("ColIntNum","12");
  test->Update();

#if DUMP_TABLES
  test->GetOutput()->Dump(10);
  cout << "*\tOutput should be strings matching \"12\" from the \"ColIntNum\" column."
            << endl;
#endif

  if(2 != test->GetOutput()->GetNumberOfRows())
    {
    cerr << "FAILED Test 2 (IdType): I found "
         << test->GetOutput()->GetNumberOfRows()
         << " rows but expected 2" << endl;
    retVal = 1;
    }
  }

  // TEST 3 -- Get rows that match 2.7 from ColFloatNum (maybe just print warning on this one)
  cout << endl << "Test 3" << endl;
  {
  VTK_CREATE(vtkExtractTableRows, test);
  test->SetInputData(0, ConditionTable);
  test->AddMatch("ColFloatNum","2.7");
  test->Update();
#if DUMP_TABLES
  test->GetOutput()->Dump(10);
  cout << "*\tOutput should be strings matching \"2.7\" from the \"ColFloatNum\" column."
            << endl;
#endif

  if(2 != test->GetOutput()->GetNumberOfRows())
    {
    cerr << "WARNING Test 3 (Floats): I found "
         << test->GetOutput()->GetNumberOfRows()
         << " rows but expected 2" << endl;
    cerr << "\tNote: Float matching isn't exact, "
         << "might add an epsilon function in the future" << endl;
    }
  }

  // TEST 4 -- Get rows that match 'Alpha' from ColString and 12 from ColIntNum
  cout << endl << "Test 4" << endl;
  {
  VTK_CREATE(vtkExtractTableRows, test);
  test->SetInputData(0, ConditionTable);
  test->AddMatch("ColString","Alpha");
  test->AddMatch("ColIntNum","12");
  test->Update();

#if DUMP_TABLES
  test->GetOutput()->Dump(10);
  cout << "*\tOutput should be strings matching \"Alpha\" from the \"ColString\" column"
            << endl
            << "\tor \"12\" from the \"ColIntNum\" column."
            << endl;
#endif

  if(4 != test->GetOutput()->GetNumberOfRows())
    {
    cerr << "FAILED Test 4 (IdType & Strings) I found "
         << test->GetOutput()->GetNumberOfRows()
         << " rows but expected 4" << endl << endl;
    retVal = 1;
    }
  }

 return retVal;
}
