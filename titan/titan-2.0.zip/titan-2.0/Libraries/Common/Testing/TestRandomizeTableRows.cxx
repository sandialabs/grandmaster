/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <iostream>
#include <iterator>
#include <stdexcept>

#include <vtkUnsignedIntArray.h>
#include <vtkDoubleArray.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkSmartPointer.h>

#include <vtkRandomizeTableRows.h>

#include <vtksys/ios/sstream>

#define VTK_CREATE(type, name)                                  \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace std;

int main(int argc, char *argv[])
{
  try
  {
    vtkIdType num_rows = 10;
    std::stringstream ss;


    VTK_CREATE(vtkTable,test_table);

    VTK_CREATE(vtkUnsignedIntArray,col0);
    VTK_CREATE(vtkDoubleArray,col1);
    VTK_CREATE(vtkStringArray,col2);

    col0->SetName("foo");
    col1->SetName("bar");
    col2->SetName("baz");

    test_table->AddColumn(col0);
    test_table->AddColumn(col1);
    test_table->AddColumn(col2);

    test_table->SetNumberOfRows(num_rows);

    for (vtkIdType i = 0; i != num_rows; ++i)
    {
      col0->SetValue(i,i);
      col1->SetValue(i,i*2);

      ss.str("");
      ss << (char)(97+i);
      col2->SetValue(i,ss.str());
    }

    cout << "Before Randomization" << endl;
    test_table->Dump();
    cout << endl;

    VTK_CREATE(vtkRandomizeTableRows,table_randomizer);
    table_randomizer->SetInputData(test_table);

    table_randomizer->SetRandomGeneratorSeed(0);
    table_randomizer->Update();

    cout << "After Randomization with seed 0" << endl;
    table_randomizer->GetOutput()->Dump();
    cout << endl;

    table_randomizer->SetRandomGeneratorSeed(1);
    table_randomizer->Update();

    cout << "After Randomization with seed 1" << endl;
    table_randomizer->GetOutput()->Dump();
    cout << endl;


    table_randomizer->SetRandomGeneratorSeed(2);
    table_randomizer->SetUsePreviousRowMap(true);
    table_randomizer->Update();

    cout << "After Randomization 2 (Using previous map, should be identical to 1)" << endl;
    table_randomizer->GetOutput()->Dump();

    table_randomizer->SetUsePreviousRowMap(false);

    table_randomizer->UnsetRandomGeneratorSeed();
    table_randomizer->Update();

    cout << "After Randomization with no seed set" << endl;
    table_randomizer->GetOutput()->Dump();
    cout << endl;

    table_randomizer->Modified();
    table_randomizer->Update();

    cout << "After Randomization with no seed set again" << endl;
    table_randomizer->GetOutput()->Dump();
    cout << endl;

    return 0;
  }
  catch(std::exception& e)
  {
    cerr << e.what() << endl;
    return 1;
  }

  return 0;
}
