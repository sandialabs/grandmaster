/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <iostream>
#include <iterator>
#include <stdexcept>

#include <vtkUnsignedIntArray.h>
#include <vtkDoubleArray.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkSmartPointer.h>

#include <vtkSampleTableRows.h>

#include <vtksys/ios/sstream>

#define VTK_CREATE(type, name)                                  \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace std;

int main(int argc, char *argv[])
{
  try
  {
    vtkIdType num_rows = 10;
    std::stringstream ss;


    VTK_CREATE(vtkTable,test_table);

    VTK_CREATE(vtkUnsignedIntArray,col0);
    VTK_CREATE(vtkDoubleArray,col1);
    VTK_CREATE(vtkStringArray,col2);

    col0->SetName("foo");
    col1->SetName("bar");
    col2->SetName("baz");

    test_table->AddColumn(col0);
    test_table->AddColumn(col1);
    test_table->AddColumn(col2);

    test_table->SetNumberOfRows(num_rows);

    for (vtkIdType i = 0; i != num_rows; ++i)
    {
      col0->SetValue(i,i);
      col1->SetValue(i,i*2);

      ss.str("");
      ss << (char)(97+i);
      col2->SetValue(i,ss.str());
    }

    cout << "Before Sampling" << endl;
    test_table->Dump();
    cout << endl;

    VTK_CREATE(vtkSampleTableRows,table_sampler);
    table_sampler->SetSamplingMethod(vtkSampleTableRows::SAMPLE_PROBABILITY);
    table_sampler->SetSamplingParameter(.3);
    table_sampler->UnsetRandomGeneratorSeed();

    table_sampler->SetInputData(test_table);

    table_sampler->Update();

    cout << "After Sampling" << endl;
    table_sampler->GetOutput()->Dump();
    cout << endl;

    table_sampler->SetMode(vtkSampleTableRows::MODE_PROJECT_DIFF);
    table_sampler->Update();

    cout << "Sampling Diff" << endl;
    table_sampler->GetOutput()->Dump();
    cout << endl;


    return 0;
  }
  catch(std::exception& e)
  {
    cerr << e.what() << endl;
    return 1;
  }

  return 0;
}
