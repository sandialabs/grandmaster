/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkPalantirXMLReader.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2009 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/
// .NAME vtkPalantirXMLReader - reads a Palantir XML file into a vtkGraph
//
// .SECTION Description
// vtkPalantirXMLReader parses a Palantir XML file and uses the objectSet and
// the linkSet to construct and vtkGraph. The graph is directed, the
// direction of the edge is determined by the parentRef, childRef pair
// in the linkSet:link items.
//
// Current Schema mappings (all other entities/values currently ignored)
// vtkGraph vertex attribute arrays (all vtkStringArray):
//      id = Palantir object id (e.g. PT_OBJECT2)
//      label = com.palantir.property.IntrinsicTitle:propertyData:propertyValue:
//              propertyComponent type="TITLE":propertyData (e.g. John Doe)
//      type = Palantir object type (e.g. com.palantir.object.person)
//
// vtkGraph edge attribute arrays (all vtkStringArray):
//      edge id = 0 to N-1 based edge pedigree ids. The name can be changed
//                by using EdgePedigreeIdArrayName.
//      label = The last part of the type (e.g. "SiblingOf" for "com.palantir.link.SiblingOf"
//      type = Palantir link type (e.g. com.palantir.link.SiblingOf)
//      text = Palantir option text field (often this is blank unless user filled in)
//
#ifndef __vtkPalantirXMLReader_h
#define __vtkPalantirXMLReader_h

#include "titanCommon.h"
#include "vtkDirectedGraphAlgorithm.h"

class TITAN_COMMON_EXPORT vtkPalantirXMLReader : public vtkDirectedGraphAlgorithm
{
public:
  static vtkPalantirXMLReader* New();
  vtkTypeMacro(vtkPalantirXMLReader,vtkDirectedGraphAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  // Description:
  // If set, reads in the XML file specified.
  vtkGetStringMacro(FileName);
  vtkSetStringMacro(FileName);

  // Description:
  // If set, and FileName is not set, reads in the XML string.
  vtkGetStringMacro(XMLString);
  vtkSetStringMacro(XMLString);

  // Description:
  // The name of the edge pedigree ids. Default is "edge id".
  vtkGetStringMacro(EdgePedigreeIdArrayName);
  vtkSetStringMacro(EdgePedigreeIdArrayName);


protected:
  vtkPalantirXMLReader();
  ~vtkPalantirXMLReader();
  char* FileName;
  char* XMLString;
  char* EdgePedigreeIdArrayName;

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:
  vtkPalantirXMLReader(const vtkPalantirXMLReader&); // Not implemented
  void operator=(const vtkPalantirXMLReader&);   // Not implemented
};

#endif
