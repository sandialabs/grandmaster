// -*- c++ -*-
/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkTemporalRanges.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

// .NAME vtkStringUtilities - A collection of methods that work on strings.
//
// .SECTION Description
//
// vtkStringUtilities simply acts as a namespace for a collection of methods
// that work on strings.  The strings that these methods work on are expected to
// implement the same basic methods as the standard template library string.
//
// Implementation note: I'm not sure if this is a "proper" way to use templates.
// Rather than having templated static methods, should there be defined static
// methods that call inline templated functions like examples in vtkMath?  Or
// should this be a namespace instead?  Or is it fine the way it is?
//

#ifndef __vtkStringUtilities_h
#define __vtkStringUtilities_h

#include <ctype.h>       // For inline functions

//BTX
class vtkStringUtilities
{
public:
  template<class T>
  static T TrimCopy(const T &value)
  {
    typename T::size_type begin, end;
    begin = 0;  end = value.size();
    while ((begin < end) && isspace(value[begin])) begin++;
    while ((begin < end) && isspace(value[end-1])) end--;
    return value.substr(begin, end);
  }

  template<class T>
  static void Trim(T &value)
  {
    value = vtkStringUtilities::TrimCopy(value);
  }
private:
  vtkStringUtilities();         // Not implemented.
};
//ETX

#endif //__vtkStringUtilities_h
