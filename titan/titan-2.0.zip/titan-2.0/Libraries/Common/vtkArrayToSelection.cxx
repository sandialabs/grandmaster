/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile$

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

#include "vtkArrayToSelection.h"

#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkObjectFactory.h"
#include "vtkSelection.h"
#include "vtkSelectionNode.h"
#include "vtkSelectionSource.h"
#include "vtkSmartPointer.h"


vtkStandardNewMacro(vtkArrayToSelection);

vtkArrayToSelection::vtkArrayToSelection() :
  FieldType(vtkSelectionNode::CELL)
{
  this->SetNumberOfInputPorts(1);
}

vtkArrayToSelection::~vtkArrayToSelection()
{
}

void vtkArrayToSelection::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "FieldType: " << this->FieldType << endl;
}

int vtkArrayToSelection::FillInputPortInformation(int port, vtkInformation* info)
{
  switch(port)
    {
    case 0:
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkDataObject");
      return 1;
    }

  return 0;
}

int vtkArrayToSelection::RequestData(
  vtkInformation* vtkNotUsed(request),
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  vtkSmartPointer<vtkSelectionSource> source = vtkSmartPointer<vtkSelectionSource>::New();
  source->SetContentType(vtkSelectionNode::INDICES);
  source->SetFieldType(this->FieldType);

  if(vtkIdTypeArray* const array = vtkIdTypeArray::SafeDownCast(this->GetInputAbstractArrayToProcess(0, inputVector)))
    {
    for(vtkIdType i = 0; i < array->GetNumberOfTuples(); ++i)
      {
      source->AddID(-1, array->GetValue(i));
      }
    }
  else
    {
    vtkErrorMacro(<< "missing input array, or array not the correct type.")
    }
  source->Update();

  vtkSelection* const output = vtkSelection::GetData(outputVector);
  output->ShallowCopy(source->GetOutput());

  return 1;
}
