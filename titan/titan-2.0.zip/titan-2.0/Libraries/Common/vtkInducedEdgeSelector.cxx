/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkInducedEdgeSelector.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
#include "vtkInducedEdgeSelector.h"

#include "vtkCellData.h"
#include "vtkConvertSelection.h"
#include "vtkEdgeListIterator.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"
#include "vtkInEdgeIterator.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkOutEdgeIterator.h"
#include "vtkSelection.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"

#include <vtksys/stl/set>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkInducedEdgeSelector);
//----------------------------------------------------------------------------
vtkInducedEdgeSelector::vtkInducedEdgeSelector()
{
  this->SetNumberOfInputPorts(2);
}

//----------------------------------------------------------------------------
vtkInducedEdgeSelector::~vtkInducedEdgeSelector()
{
}

//----------------------------------------------------------------------------
int vtkInducedEdgeSelector::RequestData(
  vtkInformation *vtkNotUsed(request),
  vtkInformationVector **inputVector,
  vtkInformationVector *outputVector)
{
  vtkInformation *inInfo = inputVector[0]->GetInformationObject(0);
  vtkSelection *input = vtkSelection::SafeDownCast(
    inInfo->Get(vtkDataObject::DATA_OBJECT()));

  vtkInformation *dataInfo = inputVector[1]->GetInformationObject(0);
  vtkGraph *data = vtkGraph::SafeDownCast(
    dataInfo->Get(vtkDataObject::DATA_OBJECT()));

  vtkInformation *outInfo = outputVector->GetInformationObject(0);
  vtkSelection *output = vtkSelection::SafeDownCast(
    outInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get the selected vertices
  VTK_CREATE(vtkIdTypeArray, vertexIds);
  vtkConvertSelection::GetSelectedVertices(input, data, vertexIds);

  // Get the selected edge
  VTK_CREATE(vtkIdTypeArray, edgeIds);
  vtkConvertSelection::GetSelectedEdges(input, data, edgeIds);

  // Add edges between selected vertices
  vtkSmartPointer<vtkEdgeListIterator> edges = vtkSmartPointer<vtkEdgeListIterator>::New();
  data->GetEdges(edges);
  while (edges->HasNext())
    {
    vtkEdgeType e = edges->Next();
    if (vertexIds->LookupValue(e.Source) != -1 &&
        vertexIds->LookupValue(e.Target) != -1)
      {
      edgeIds->InsertNextValue(e.Id);
      }
    }

  // Vertex selection node
  VTK_CREATE(vtkSelectionNode, vertexIndexNode);
  vertexIndexNode->SetContentType(vtkSelectionNode::INDICES);
  vertexIndexNode->SetFieldType(vtkSelectionNode::VERTEX);
  vertexIndexNode->SetSelectionList(vertexIds);

  // Edge selection node
  VTK_CREATE(vtkSelectionNode, edgeIndexNode);
  edgeIndexNode->SetContentType(vtkSelectionNode::INDICES);
  edgeIndexNode->SetFieldType(vtkSelectionNode::EDGE);
  edgeIndexNode->SetSelectionList(edgeIds);

  output->AddNode(vertexIndexNode);
  output->AddNode(edgeIndexNode);

  return 1;
}

//----------------------------------------------------------------------------
int vtkInducedEdgeSelector::FillInputPortInformation(
  int port, vtkInformation* info)
{
  // now add our info
  if (port == 0)
    {
    info->Set(vtkInducedEdgeSelector::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    }
  else if (port == 1)
    {
    info->Set(vtkInducedEdgeSelector::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    }
  return 1;
}

//----------------------------------------------------------------------------
void vtkInducedEdgeSelector::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
