/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkAddEdges.cxx,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/*-------------------------------------------------------------------------
  Copyright 2008 Sandia Corporation.
  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
  the U.S. Government retains certain rights in this software.
-------------------------------------------------------------------------*/

#include "vtkAddEdges.h"

#include "vtkAnnotation.h"
#include "vtkAnnotationLayers.h"
#include "vtkBitArray.h"
#include "vtkCellData.h"
#include "vtkCommand.h"
#include "vtkDataArray.h"
#include "vtkDataObjectToTable.h"
#include "vtkDoubleArray.h"
#include "vtkEdgeListIterator.h"
#include "vtkExecutive.h"
#include "vtkExtractSelectedGraph.h"
#include "vtkGraph.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkInformationIntegerKey.h"
#include "vtkInformationDataObjectKey.h"
#include "vtkIntArray.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkMutableUndirectedGraph.h"
#include "vtkObjectFactory.h"
#include "vtkPointData.h"
#include "vtkSelection.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"
#include "vtkStringArray.h"
#include "vtkStringTokenizer.h"
#include "vtkStringUtilities.h"
#include "vtkTable.h"
#include "vtkVariant.h"
#include "vtkVariantArray.h"

#include <vtksys/stl/algorithm>
#include <vtksys/stl/map>
#include <vtksys/stl/set>
#include <vtksys/stl/vector>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()


vtkStandardNewMacro(vtkAddEdges);
vtkCxxSetObjectMacro(vtkAddEdges, LinkGraph, vtkMutableDirectedGraph);
//---------------------------------------------------------------------------
vtkAddEdges::vtkAddEdges()
{
  this->Directed = 0;
  this->LinkGraph = 0;
  this->SetNumberOfInputPorts(2);
  this->SetNumberOfOutputPorts(1);
}

//---------------------------------------------------------------------------
vtkAddEdges::~vtkAddEdges()
{
  this->SetLinkGraph(0);
}

//---------------------------------------------------------------------------
int vtkAddEdges::ValidateLinkGraph()
{
  if (!this->LinkGraph)
    {
    this->LinkGraph = vtkMutableDirectedGraph::New();
    }
  if (!vtkStringArray::SafeDownCast(
      this->LinkGraph->GetVertexData()->GetAbstractArray("column")))
    {
    if (this->LinkGraph->GetNumberOfVertices() == 0)
      {
      vtkStringArray* column = vtkStringArray::New();
      column->SetName("column");
      this->LinkGraph->GetVertexData()->AddArray(column);
      column->Delete();
      this->Modified();
      }
    else
      {
      vtkErrorMacro("The link graph must contain a string array named \"column\".");
      return 0;
      }
    }
  if (!vtkStringArray::SafeDownCast(
      this->LinkGraph->GetVertexData()->GetAbstractArray("delimiter")))
    {
    vtkStringArray* delim = vtkStringArray::New();
    delim->SetName("delimiter");
    delim->SetNumberOfTuples(this->LinkGraph->GetNumberOfVertices());
    for (vtkIdType i = 0; i < this->LinkGraph->GetNumberOfVertices(); i++)
      {
      delim->SetValue(i, "");
      }
    this->LinkGraph->GetVertexData()->AddArray(delim);
    delim->Delete();
    this->Modified();
    }
  if (!vtkStringArray::SafeDownCast(
      this->LinkGraph->GetEdgeData()->GetAbstractArray("domain")))
    {
    vtkStringArray* domain = vtkStringArray::New();
    domain->SetName("domain");
    domain->SetNumberOfTuples(this->LinkGraph->GetNumberOfEdges());
    for (vtkIdType i = 0; i < this->LinkGraph->GetNumberOfEdges(); i++)
      {
      domain->SetValue(i, "");
      }
    this->LinkGraph->GetEdgeData()->AddArray(domain);
    domain->Delete();
    this->Modified();
    }
  return 1;
}

//---------------------------------------------------------------------------
void vtkAddEdges::AddLinkVertex(const char* column, const char* delim)
{
  if (!column)
    {
    vtkErrorMacro("Column name cannot be null");
    }

  vtkStdString delimStr = "";
  if (delim)
    {
    delimStr = delim;
    }

  if (!this->ValidateLinkGraph())
    {
    return;
    }

  vtkStringArray* columnArr = vtkStringArray::SafeDownCast(
      this->LinkGraph->GetVertexData()->GetAbstractArray("column"));
  vtkStringArray* delimArr = vtkStringArray::SafeDownCast(
      this->LinkGraph->GetVertexData()->GetAbstractArray("delimiter"));

  vtkIdType index = -1;
  for (vtkIdType i = 0; i < this->LinkGraph->GetNumberOfVertices(); i++)
    {
    if (!strcmp(column, columnArr->GetValue(i)))
      {
      index = i;
      break;
      }
    }
  if (index >= 0)
    {
    delimArr->SetValue(index, delimStr);
    }
  else
    {
    this->LinkGraph->AddVertex();
    columnArr->InsertNextValue(column);
    delimArr->InsertNextValue(delimStr);
    }
  this->Modified();
}

//---------------------------------------------------------------------------
void vtkAddEdges::ClearLinkVertices()
{
  this->ValidateLinkGraph();
  this->Modified();
}

//---------------------------------------------------------------------------
void vtkAddEdges::AddLinkEdge(const char* column1, const char* column2, const char* domain)
{
  if (!column1 || !column2 || !domain)
    {
    vtkErrorMacro("Column names may not be null.");
    }
  this->ValidateLinkGraph();
  vtkStringArray* columnArr = vtkStringArray::SafeDownCast(
      this->LinkGraph->GetVertexData()->GetAbstractArray("column"));
  vtkIdType source = -1;
  vtkIdType target = -1;
  for (vtkIdType i = 0; i < this->LinkGraph->GetNumberOfVertices(); i++)
    {
    if (!strcmp(column1, columnArr->GetValue(i)))
      {
      source = i;
      }
    if (!strcmp(column2, columnArr->GetValue(i)))
      {
      target = i;
      }
    }
  if (source < 0)
    {
    this->AddLinkVertex(column1,"");
    source = this->LinkGraph->GetNumberOfVertices() - 1;
    }
  if (target < 0)
    {
    this->AddLinkVertex(column2,"");
    target = this->LinkGraph->GetNumberOfVertices() - 1;
    }
  this->LinkGraph->AddEdge(source, target);
  vtkStringArray* domainArr = vtkStringArray::SafeDownCast(
      this->LinkGraph->GetEdgeData()->GetAbstractArray("domain"));
  domainArr->InsertNextValue(domain);

  this->Modified();
}

//---------------------------------------------------------------------------
void vtkAddEdges::ClearLinkEdges()
{
  VTK_CREATE(vtkMutableDirectedGraph, newLinkGraph);
  for (vtkIdType i = 0; i < this->LinkGraph->GetNumberOfVertices(); ++i)
    {
    newLinkGraph->AddVertex();
    }
  newLinkGraph->GetVertexData()->ShallowCopy(this->LinkGraph->GetVertexData());
  this->SetLinkGraph(newLinkGraph);
}

//---------------------------------------------------------------------------
int vtkAddEdges::FillInputPortInformation(int port, vtkInformation* info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  else if (port == 1)
    {
    info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(),1);
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkAnnotationLayers");
    return 1;
    }

  return 0;
}

//---------------------------------------------------------------------------
template <typename T>
vtkVariant vtkAddEdgesGetValue(T* arr, vtkIdType index)
{
  return vtkVariant(arr[index]);
}


//---------------------------------------------------------------------------
bool vtkAddEdgesCompare(//vtksys_stl::multimap<vtkStdString, vtkStdString>::iterator iter1,
                        //vtksys_stl::multimap<vtkStdString, vtkStdString>::iterator iter2)
    const vtksys_stl::pair<vtksys_stl::multimap<vtkStdString, vtkStdString >::iterator, vtksys_stl::multimap<vtkStdString, vtkStdString >::iterator>& p1,
    const vtksys_stl::pair<vtksys_stl::multimap<vtkStdString, vtkStdString >::iterator, vtksys_stl::multimap<vtkStdString, vtkStdString >::iterator>& p2)
{
/*
  vtkStdString valueSource = iter1->first;
  vtkStdString valueTarget = iter2->first;
  while(*iter1 && iter1->first && iter1->first == valueSource)
    {
    while(*iter2 && iter2-first && iter2->first == valueTarget)
      {
      if(iter1->second == iter2->second)
        return true;
      iter2++;
      }
    iter1++;
    }
*/
  vtksys_stl::multimap<vtkStdString, vtkStdString >::iterator iter1;
  for(iter1 = p1.first; iter1 != p1.second; ++iter1)
    {
    vtksys_stl::multimap<vtkStdString, vtkStdString >::iterator iter2;
    for(iter2 = p2.first; iter2 != p2.second; ++iter2)
      {
      if((*iter1).second == (*iter2).second)
        return true;
      }
    }

  return false;
}

//---------------------------------------------------------------------------
int vtkAddEdges::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // get the info objects
  vtkInformation *inInfo = inputVector[0]->GetInformationObject(0);
  vtkInformation *outInfo = outputVector->GetInformationObject(0);

  // get the input and output
  vtkGraph *input = vtkGraph::SafeDownCast(
    inInfo->Get(vtkDataObject::DATA_OBJECT()));
  vtkAnnotationLayers* inputAnnotations = vtkAnnotationLayers::GetData(inputVector[1]);
  vtkGraph *output = vtkGraph::SafeDownCast(
    outInfo->Get(vtkDataObject::DATA_OBJECT()));

  if(!inputAnnotations)
    {
    output->ShallowCopy(input);
    return 1;
    }

  // Extract edge table
  vtkSmartPointer<vtkDataObjectToTable> dToEdgeTable = vtkSmartPointer<vtkDataObjectToTable>::New();
  dToEdgeTable->SetInputData(0, input);
  dToEdgeTable->SetFieldType(vtkDataObjectToTable::EDGE_DATA);
  dToEdgeTable->Update();
  vtkTable* edgeTable = vtkTable::SafeDownCast(dToEdgeTable->GetOutput());

  // Extract vertex table
  vtkSmartPointer<vtkDataObjectToTable> dToVertexTable = vtkSmartPointer<vtkDataObjectToTable>::New();
  dToVertexTable->SetInputData(0, input);
  dToVertexTable->SetFieldType(vtkDataObjectToTable::VERTEX_DATA);
  dToVertexTable->Update();
  vtkTable* vertexTable = vtkTable::SafeDownCast(dToVertexTable->GetOutput());

  if(!this->LinkGraph)
    {
    for(unsigned int i=0; i<inputAnnotations->GetNumberOfAnnotations(); ++i)
      {
      vtkAnnotation* a = inputAnnotations->GetAnnotation(i);
      if (a->GetInformation()->Has(vtkAnnotation::ENABLE()) &&
          a->GetInformation()->Get(vtkAnnotation::ENABLE())==1 &&
          a->GetInformation()->Has(vtkAnnotation::DATA()))
        {
        vtkGraph* aLinkGraph = vtkGraph::SafeDownCast(a->GetInformation()->Get(vtkAnnotation::DATA()));
        if(!aLinkGraph)
          {
          continue;
          }

        vtkStringArray* linkColumn = vtkStringArray::SafeDownCast(
          aLinkGraph->GetVertexData()->GetAbstractArray("column"));

        if (!linkColumn)
          {
          continue;
          }

        vtkStringArray* linkDomain = vtkStringArray::SafeDownCast(
          aLinkGraph->GetEdgeData()->GetAbstractArray("domain"));

        if (!linkDomain)
          {
          continue;
          }

        vtkStringArray* linkDelimiter = vtkStringArray::SafeDownCast(
          aLinkGraph->GetVertexData()->GetAbstractArray("delimiter"));

        for(int j=0; j<linkColumn->GetNumberOfTuples(); ++j)
          {
          this->AddLinkVertex(linkColumn->GetValue(j), linkDelimiter->GetValue(j));
          }

        VTK_CREATE(vtkEdgeListIterator, edges);
        aLinkGraph->GetEdges(edges);
        while (edges->HasNext())
          {
          vtkEdgeType e = edges->Next();
          vtkStdString edgeDomain;
          edgeDomain = linkDomain->GetValue(e.Id);
          this->AddLinkEdge(linkColumn->GetValue(e.Source), linkColumn->GetValue(e.Target), edgeDomain);
          }
        }
      }

    // Check that the link graph is valid
    if (!this->LinkGraph)
      {
      output->ShallowCopy(input);
      return 1;
      }
    }

  vtkStringArray* linkColumn = vtkStringArray::SafeDownCast(
    this->LinkGraph->GetVertexData()->GetAbstractArray("column"));

  if (!linkColumn)
    {
    vtkErrorMacro("The link graph must have a string array named \"column\".");
    return 0;
    }

  vtkStringArray* linkDomain = vtkStringArray::SafeDownCast(
    this->LinkGraph->GetEdgeData()->GetAbstractArray("domain"));

  if (!linkDomain)
    {
    vtkErrorMacro("The link graph must have a string array named \"domain\".");
    return 0;
    }

  vtkStringArray* linkDelimiter = vtkStringArray::SafeDownCast(
    this->LinkGraph->GetVertexData()->GetAbstractArray("delimiter"));

  // Calculate the percent time based on whether there are hidden types
  double createVertexTime = 0.25;
  double createEdgeTime = 0.75;

  // Create builder for the graph
  VTK_CREATE(vtkMutableDirectedGraph, dirBuilder);
  VTK_CREATE(vtkMutableUndirectedGraph, undirBuilder);
  vtkGraph *builder = 0;
  if (this->Directed)
    {
    builder = dirBuilder;
    }
  else
    {
    builder = undirBuilder;
    }

  builder->DeepCopy(input);

  VTK_CREATE(vtkTable, outputEdgeTable);
  outputEdgeTable->DeepCopy(edgeTable);

  // Check to see if the output edge table contains a domain array.
  // If none, add one and initialize with a default string.
  vtkAbstractArray *domainValuesArr = outputEdgeTable->GetColumnByName("domain");
  vtkAbstractArray *edgePedigreeIds = input->GetEdgeData()->GetPedigreeIds();
  if (!domainValuesArr)
    {
    VTK_CREATE(vtkStringArray, newDomainValuesArr);
    newDomainValuesArr->SetName("domain");
    newDomainValuesArr->SetNumberOfTuples(outputEdgeTable->GetNumberOfRows());
    for (vtkIdType r = 0; r < outputEdgeTable->GetNumberOfRows(); ++r)
      {
      newDomainValuesArr->SetValue(r, edgePedigreeIds->GetName());
      }
    outputEdgeTable->AddColumn(newDomainValuesArr);
    }

  //VTK_CREATE(vtkDoubleArray, edgeWeightsArr);
  //edgeWeightsArr->SetName("added_edge_weights");
  //edgeWeightsArr->SetNumberOfTuples(outputEdgeTable->GetNumberOfRows());
  //edgeWeightsArr->FillComponent(0,0);
  //outputEdgeTable->AddColumn(edgeWeightsArr);

  // Add columns to the edge table corresponding to the new edge domain names
  VTK_CREATE(vtkEdgeListIterator, edges);
  this->LinkGraph->GetEdges(edges);
  while (edges->HasNext())
    {
    vtkEdgeType e = edges->Next();
    vtkStdString edgeDomain;
    edgeDomain = linkDomain->GetValue(e.Id);
    VTK_CREATE(vtkStringArray, edgeDomainValues);
    edgeDomainValues->SetName(edgeDomain.c_str());
    edgeDomainValues->SetNumberOfValues(outputEdgeTable->GetNumberOfRows());
    outputEdgeTable->AddColumn(edgeDomainValues);
    }

  // Now go through the vertex table, adding edges.
  // For each row in the vertex table, add one edge to the
  // output graph for each edge in the link graph.
  vtksys_stl::multimap<vtkStdString, vtkStdString> tokenMap;

  this->LinkGraph->GetEdges(edges);
  while (edges->HasNext())
    {
    vtkEdgeType e = edges->Next();
    vtkIdType linkSource = e.Source;
    vtkIdType linkTarget = e.Target;
    vtkStdString columnNameSource = linkColumn->GetValue(linkSource);
    vtkStdString columnNameTarget = linkColumn->GetValue(linkTarget);
    vtkStdString sourceDelimiter = linkDelimiter->GetValue(linkSource);
    vtkStdString targetDelimiter = linkDelimiter->GetValue(linkTarget);
    vtkStdString edgeDomain = linkDomain->GetValue(e.Id);

    vtkAbstractArray* columnSource = vertexTable->GetColumnByName(columnNameSource);
    vtkAbstractArray* columnTarget = vertexTable->GetColumnByName(columnNameTarget);
    if (!columnSource)
      {
      vtkErrorMacro( "vtkAddEdges cannot find array: " << columnNameSource.c_str());
      return 0;
      }
    if (!columnTarget)
      {
      vtkErrorMacro( "vtkAddEdges cannot find array: " << columnNameTarget.c_str());
      return 0;
      }

    for (vtkIdType srcRow = 0; srcRow < vertexTable->GetNumberOfRows(); srcRow++)
      {
      vtkVariant v;
      switch(columnSource->GetDataType())
        {
        vtkExtendedTemplateMacro(v = vtkAddEdgesGetValue(
          static_cast<VTK_TT*>(columnSource->GetVoidPointer(0)), srcRow));
        }

      vtkStdString valueSource = v.ToString();

      if(tokenMap.count(valueSource) == 0)
        {
        if(sourceDelimiter)
          {
          vtkStringTokenizer<vtkStdString> tokenizer(valueSource,
                                                     sourceDelimiter);
          for (vtkStringTokenizer<vtkStdString>::iterator token = tokenizer.begin();
               token != tokenizer.end(); token++)
            {
            tokenMap.insert(vtksys_stl::make_pair(valueSource,
                                         vtkStringUtilities::TrimCopy(*token)));
            }
          }
        else
          {
          tokenMap.insert(vtksys_stl::make_pair<vtkStdString, vtkStdString>(valueSource,valueSource));
          }
        }

      // For this pair of source/target columns, scan through vertex table for any matches
      for (vtkIdType targRow = 0; targRow < vertexTable->GetNumberOfRows(); targRow++)
        {
        if(srcRow == targRow)
          continue;

        switch(columnTarget->GetDataType())
          {
          vtkExtendedTemplateMacro(v = vtkAddEdgesGetValue(
            static_cast<VTK_TT*>(columnTarget->GetVoidPointer(0)), targRow));
          }

        vtkStdString valueTarget = v.ToString();

        if(tokenMap.count(valueTarget) == 0)
          {
          if(targetDelimiter)
            {
            vtkStringTokenizer<vtkStdString> tokenizer(valueTarget,
                                                       targetDelimiter);
            for (vtkStringTokenizer<vtkStdString>::iterator token = tokenizer.begin();
                 token != tokenizer.end(); token++)
              {
              tokenMap.insert(vtksys_stl::make_pair(valueTarget,
                                         vtkStringUtilities::TrimCopy(*token)));
              }
            }
          else
            {
            tokenMap.insert(vtksys_stl::make_pair<vtkStdString, vtkStdString>(valueTarget,valueTarget));
            }
          }

        //vtksys_stl::multimap<vtkStdString, vtkStdString>::iterator srcIter = tokenMap.find(valueSource);
        //vtksys_stl::multimap<vtkStdString, vtkStdString>::iterator tarIter = tokenMap.find(valueTarget);
        //if(srcIter == tokenMap.end() || tarIter == tokenMap.end())
         // continue;

        if(vtkAddEdgesCompare(tokenMap.equal_range(valueSource), tokenMap.equal_range(valueTarget)))
          {
          vtkEdgeType newEdge;
          if (this->Directed)
            {
            newEdge = dirBuilder->AddEdge(srcRow, targRow);
            }
          else
            {
            newEdge = undirBuilder->AddEdge(srcRow, targRow);
            }
          vtkIdType row = outputEdgeTable->InsertNextBlankRow();
          outputEdgeTable->SetValueByName(row, "domain", edgeDomain);
          //outputEdgeTable->SetValueByName(row, "added_edge_weights", 0.8);
          outputEdgeTable->SetValueByName(row, edgeDomain.c_str(), valueSource);
          }
        }
      if (srcRow % 100 == 0)
        {
        double progress = createVertexTime + createEdgeTime * srcRow / vertexTable->GetNumberOfRows();
        this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
        }
      }
    }

  // Copy the edge table that we've modified to the output
  builder->GetEdgeData()->ShallowCopy(outputEdgeTable->GetRowData());

  // Copy structure into output graph.
  if (!output->CheckedShallowCopy(builder))
    {
    vtkErrorMacro(<<"Invalid graph structure");
    return 0;
    }

  return 1;
}

//----------------------------------------------------------------------------
int vtkAddEdges::RequestDataObject(
  vtkInformation*,
  vtkInformationVector**,
  vtkInformationVector* )
{
  vtkGraph *output = 0;
  if (this->Directed)
    {
    output = vtkDirectedGraph::New();
    }
  else
    {
    output = vtkUndirectedGraph::New();
    }
  this->GetExecutive()->SetOutputData(0, output);
  output->Delete();

  return 1;
}

//---------------------------------------------------------------------------
unsigned long vtkAddEdges::GetMTime()
{
  unsigned long time = this->Superclass::GetMTime();
  if(this->LinkGraph)
    {
    unsigned long linkGraphTime = this->LinkGraph->GetMTime();
    time = (linkGraphTime > time ? linkGraphTime : time);
    }
  return time;
}


//---------------------------------------------------------------------------
void vtkAddEdges::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Directed: " << this->Directed << endl;
  os << indent << "LinkGraph: " << (this->LinkGraph ? "" : "(null)") << endl;
  if (this->LinkGraph)
    {
    this->LinkGraph->PrintSelf(os, indent.GetNextIndent());
    }
}
