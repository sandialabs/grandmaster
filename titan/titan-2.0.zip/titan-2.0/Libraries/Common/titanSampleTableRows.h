/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class titanSampleTableRows titanSampleTableRows.h <Clustering/titanSampleTableRows.h>
/// \brief ...
///
///  titanSampleTableRows normalizes the features of each vector. Note that the number
///  of vectors never changes using this method.
#ifndef __titanSampleTableRows_h
#define __titanSampleTableRows_h

#include <Common/titanVectorOperations.h>
#include <Common/titanVectorTraits.h>

#include <boost/random.hpp>
#include <boost/date_time/posix_time/posix_time.hpp>

#include <iostream>
#include <limits>
#include <cmath>

using namespace std;
class titanSampleTableRows
{

private:
  std::vector<size_t> RandomRowIndices;
  std::vector<size_t> DiffIndices;

  bool UsePreviousRowMap;

  unsigned int SamplingMethod;
  unsigned int Mode;

  double SamplingParameter;

  bool AgnosticSampling;
  bool SampleWithReplacement;
  bool IgnoreClassNegatives;

  double  MinSelections;

  boost::mt19937 RandomGenerator;

public:

  enum
  {
    SAMPLE_OFF,
    SAMPLE_ABSOLUTE,
    SAMPLE_LOGISTIC,
    SAMPLE_PROBABILITY,
    SAMPLE_RATIO
  } SamplingMethodType;

  enum
  {
    MODE_SAMPLE,
    MODE_PROJECT,
    MODE_PROJECT_DIFF
  } ModeType;

  titanSampleTableRows()
  {
    this->SetMode(MODE_SAMPLE);
    this->SetSamplingMethod(SAMPLE_ABSOLUTE);
    this->SetAgnosticSampling(true);
    this->SetMinSelections(1);
    this->SetSamplingParameter(1);
    this->SetIgnoreClassNegatives(true);
    this->SetSampleWithReplacement(false);
    this->UnsetRandomGeneratorSeed();
  }

  void SetRandomGeneratorSeed(unsigned int seed)
  {
    this->RandomGenerator.seed(seed);
  }

  void UnsetRandomGeneratorSeed()
  {
    unsigned int random_seed;
    boost::posix_time::ptime now = boost::posix_time::microsec_clock::local_time();
    random_seed =
        static_cast<unsigned int>(now.time_of_day().total_microseconds());

    this->RandomGenerator.seed(random_seed);
  }


  ///@{
  /// Sets the SamplingMethod to use from:
  /// SAMPLE_ABSOLUTE: An exact number of rows <br>
  /// SAMPLE_LOGISTIC: A log ratio (base=SamplingParameter, power=total number of rows) <br>
  /// SAMPLE_PROBABILITY: A probability of selection <br>
  /// SAMPLE_RATIO: A ratio of rows [0.0,1.0]. Similar to SAMPLE_PROBABILITY
  /// except that it guarantees a minimum amount if available. <br>
  ///
  /// This is set to SAMPLE_ABSOLUTE by default.
  void SetSamplingMethod(unsigned int sampling_method)
  {
    this->SamplingMethod = sampling_method;
  }

  void SetMode(unsigned int mode)
  {
    this->Mode = mode;
  }

  ///@{
  /// Sets the sampling parameter. This number will represent either the
  /// absolute number of samples, the probability of selection, or the log
  /// probability of selection, depending on the SamplingMethod.
  void SetSamplingParameter(double sampling_parameter)
  {
    this->SamplingParameter = sampling_parameter;
  }
  ///@}

  ///@{
  /// Sampling of the table will be done agnostic to the values. If this is false,
  /// then the Sampling will assume that the numeric columns represent
  /// different classes, and will treat the selection as the satisfaction of a
  /// computational knapsack, allowing overflow.
  ///
  /// This is set to true by default.
  void SetAgnosticSampling(unsigned int agnostic)
  {
    this->AgnosticSampling = agnostic;
  }
  ///@}

  ///@{
  /// Sets the sampling to be done with or without replacement.
  ///
  /// This is set to false by default.
  void SetSampleWithReplacement(unsigned int replacement)
  {
    this->SampleWithReplacement = replacement;
  }
  ///@}


  ///@{
  /// Sets the Proximity from the enumerated ProximityType. Some of these
  /// proximities (such as ProximityKL) will require a numeric parameter, set
  /// with SetProximityNumericParameter1().
  ///
  /// This is set to false by default.
  void SetUsePreviousRowMap(bool use_previous_map)
  {
    this->UsePreviousRowMap = use_previous_map;
  }
  ///@}

  ///@{
  /// Sets the minimum number of selected rows when using purely probabilistic,
  /// agnostic sampling (SAMPLE_PROBABILITY and AgnosticSampling(true)).
  ///
  /// Purely probabilistic, class-aware sampling is the same as probabilistic
  /// class-agnostic sampling unless the probabilities are class-dependent,
  /// which this filter does not currently support.
  ///
  /// This is set to 1 by default.
  void SetMinSelections(double min_selections)
  {
    this->MinSelections = min_selections;
  }
  ///@}


  ///@{
  /// If true, negative values in class-aware sampling will be ignored.
  /// This is set to true by default.
  void SetIgnoreClassNegatives(bool ignore)
  {
    this->IgnoreClassNegatives = ignore;
  }
  ///@}


  void CalculateDiffIndices(size_t num_total_rows)
  {
    // making a copy, just in case this the row indices are guaranteeing a random ordering
    std::vector<size_t> temp_indices = RandomRowIndices;

    DiffIndices.clear();
    std::sort(temp_indices.begin(),temp_indices.end());

    for (size_t i = 0; i != num_total_rows; ++i)
    {
      if (std::binary_search(temp_indices.begin(),temp_indices.end(),i))
        continue;
      else
      {
        DiffIndices.push_back(i);
      }
    }
  }

  template<typename VectorIteratorT>
  std::vector<size_t> * Project(
     VectorIteratorT begin,  VectorIteratorT end
    )
  {
    if ((end-begin) < 0)
      return NULL;

    return &RandomRowIndices;
  }

  template<typename VectorIteratorT>
  std::vector<size_t> * ProjectDiff(
     VectorIteratorT begin,  VectorIteratorT end
    )
  {
    if ((end-begin) < 0)
      return NULL;

    return &DiffIndices;
  }

  template<typename VectorIteratorT>
  std::vector<size_t> * SampleAware(
     VectorIteratorT begin,  VectorIteratorT end
    )
  {
    RandomRowIndices.clear();

    size_t num_rows = end - begin;
    size_t num_cols = vector_traits<typename VectorIteratorT::value_type>::size(*begin);

    double probability;

    // Total sum of values for each numeric column.
    std::vector<double> class_totals;
    std::vector<double> target_class_totals;
    std::vector<double> selected_class_totals;
    std::vector<double> remaining_class_totals;

    class_totals.resize(num_cols,0.0);
    target_class_totals.resize(num_cols);
    selected_class_totals.resize(num_cols,0);

    // Calculate the class totals and target class totals by making a pass
    // through the table
    double class_total;
    double class_value;
    double leeway;
    for (size_t numeric_col_index=0; numeric_col_index != num_cols; ++numeric_col_index)
    {
      class_total=0;
      for (unsigned int row_index=0; row_index != num_rows; ++row_index)
      {
        class_value = (*(begin + row_index))[numeric_col_index];
        if (this->IgnoreClassNegatives)
          class_value = std::max(class_value,0.0);
        class_total += class_value;
      }

      class_totals[numeric_col_index] = class_total;

      if (this->SamplingMethod == this->SAMPLE_ABSOLUTE)
        target_class_totals[numeric_col_index]=this->SamplingParameter;
      else if (this->SamplingMethod == this->SAMPLE_RATIO)
        target_class_totals[numeric_col_index]=this->SamplingParameter*class_total;
      else if (this->SamplingMethod == this->SAMPLE_LOGISTIC)
        target_class_totals[numeric_col_index]=std::log10(class_total)/std::log10(this->SamplingParameter);

      target_class_totals[numeric_col_index]=std::max(this->MinSelections,target_class_totals[numeric_col_index]);
    }

    remaining_class_totals = class_totals;

    for (unsigned int row_index = 0; row_index != num_rows; ++row_index)
    {

      probability = 0;
      for (size_t numeric_col_index=0; numeric_col_index != num_cols; ++numeric_col_index)
      {
        // If we have enough of this class, then skip it
        if ((target_class_totals[numeric_col_index]-selected_class_totals[numeric_col_index]) <= 0)
        {
          continue;
        }

        class_value = (*(begin + row_index))[numeric_col_index];

        // Consider adding this row for this column only if it can possibly
        // help satisfy the target
        if (class_value > 0)
        {
          leeway = remaining_class_totals[numeric_col_index] - target_class_totals[numeric_col_index]
          + selected_class_totals[numeric_col_index];

          leeway = std::max(leeway,0.0);

          if ((selected_class_totals[numeric_col_index] < target_class_totals[numeric_col_index]) && !leeway)
          {
            probability=1;
          }
          else
          probability = std::max(probability,(target_class_totals[numeric_col_index]-selected_class_totals[numeric_col_index])/remaining_class_totals[numeric_col_index]);
        }
      }


      // At this point, "probability" is equal to the maximum probability over
      // all the classes.

      // As an alternative, this selection could be done inside the previous
      // loop. As this is a greedy heuristic, it's not so clear that being
      // picky in this regard will really help. Please feel free to modify
      // this if there is a better way.
      boost::uniform_real<> random_01_map(0, 1.0);

      boost::variate_generator<boost::mt19937&, boost::uniform_real<> > random_probability(
          RandomGenerator, random_01_map);

      bool added_row=false;

      if (random_probability() < probability)
      {
        RandomRowIndices.push_back(row_index);
        added_row=true;
      }

      for (size_t numeric_col_index=0; numeric_col_index != num_cols; ++numeric_col_index)
      {
        class_value = (*(begin + row_index))[numeric_col_index];

        if (this->IgnoreClassNegatives)
          class_value = std::max(class_value,0.0);

        if (added_row)
          selected_class_totals[numeric_col_index] += class_value;

        remaining_class_totals[numeric_col_index] -= class_value;
      }

    }

    this->CalculateDiffIndices(num_rows);

    return &RandomRowIndices;
  }

  template<typename VectorIteratorT>
  std::vector<size_t> * SampleAgnostic(
     VectorIteratorT begin,  VectorIteratorT end
    )
  {
    RandomRowIndices.clear();

    size_t num_rows = end - begin;

    double probability;
    double target_total = 0;

    // For some sampling methods, there is a target total which depends on the
    // number of selected rows. This section calculates that total.
    if (this->SamplingMethod == this->SAMPLE_ABSOLUTE)
    {
      target_total = this->SamplingParameter;
    }
    else if (this->SamplingMethod == this->SAMPLE_RATIO)
    {
      target_total = this->SamplingParameter * num_rows;
    }
    else if (this->SamplingMethod == this->SAMPLE_LOGISTIC)
    {
      target_total = std::log10(static_cast<double>(num_rows))
          / std::log10(this->SamplingParameter);
    }
    else if (this->SamplingMethod == this->SAMPLE_PROBABILITY)
    {
      target_total = this->MinSelections;
    }

    // Loop through the data, selecting row_indices
    if (this->SampleWithReplacement)
    {
      while (RandomRowIndices.size() != target_total)
      {
        boost::uniform_int<> random_map(0,
            static_cast<unsigned int>(num_rows - 1));

        boost::variate_generator<boost::mt19937&, boost::uniform_int<> >random_selection_pool_index(RandomGenerator, random_map);

        RandomRowIndices.push_back(random_selection_pool_index());
      }
    }
    else // Loop through the data, selecting unique row_indices
    {
      double leeway, random_prob;

      for (unsigned int row_index = 0; row_index != num_rows; ++row_index)
      {
        if (this->SamplingMethod == this->SAMPLE_PROBABILITY)
        {
          probability = this->SamplingParameter;
          leeway=num_rows;
        }
        else
        {
          if (target_total <= RandomRowIndices.size())
            break;

          leeway = num_rows - row_index - this->MinSelections
          + RandomRowIndices.size();

          leeway = std::max(0.0,leeway);

          probability = (target_total - (double) RandomRowIndices.size())
          / (num_rows - row_index);
        }

        // If we haven't reached the minimum number of selections, and we have
        // no more leeway, then select all remaining rows
        if (this->MinSelections
            && (RandomRowIndices.size() < this->MinSelections) && !leeway)
        {
          while (row_index != num_rows)
          {
            RandomRowIndices.push_back(row_index);
            ++row_index;
          }
          break;
        }

        boost::uniform_real<> random_01_map(0, 1.0);

        boost::variate_generator<boost::mt19937&, boost::uniform_real<> > random_probability(
            RandomGenerator, random_01_map);

        random_prob = random_probability();

        if (random_probability() < probability)
        {
          RandomRowIndices.push_back(row_index);
        }
      }
    }

    this->CalculateDiffIndices(num_rows);

    return &RandomRowIndices;
  }

};


#endif
