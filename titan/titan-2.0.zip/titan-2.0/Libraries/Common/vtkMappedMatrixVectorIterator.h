/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkMappedMatrixVectorIterator_h
#define __vtkMappedMatrixVectorIterator_h

#include <vtkArrayCoordinates.h>
#include <iterator>
#include <vector>

/// Model of RandomAccessIterator that makes a matrix (2D vtkArray) look like a 1D collection of vectors, suitable for clustering.
template<typename ObservationContainerT, typename ArrayT>
class vtkMappedMatrixVectorIterator
{
public:
  typedef std::random_access_iterator_tag iterator_category;
  typedef ObservationContainerT value_type;
  typedef ObservationContainerT& reference;
  typedef ObservationContainerT* pointer;
  typedef vtkIdType difference_type;

  /// Specifies the array for iteration, the dimension (0 or 1) that stores observations, the current observation index in the range (0, n],
  /// and a map from observation indices to vector indices.
  template<typename MapIteratorT>
  vtkMappedMatrixVectorIterator(ArrayT* array, vtkIdType observation_dimension, vtkIdType observation_index, MapIteratorT map_begin, MapIteratorT map_end) :
    Array(array),
    ObservationDimension(observation_dimension),
    ElementDimension(1 - observation_dimension),
    ElementBegin(array->GetExtent(ElementDimension).GetBegin()),
    ElementEnd(array->GetExtent(ElementDimension).GetEnd()),
    CurrentObservation(observation_index),
    Map(map_begin, map_end),
    CurrentValue(array->GetExtent(ElementDimension).GetSize())
  {
    this->CurrentCoordinates.SetDimensions(2);
  }

  vtkIdType operator-(const vtkMappedMatrixVectorIterator& other) const
  {
    return this->CurrentObservation - other.CurrentObservation;
  }

  bool operator!=(const vtkMappedMatrixVectorIterator& other) const
  {
    return this->CurrentObservation != other.CurrentObservation;
  }

  bool operator<(const vtkMappedMatrixVectorIterator& other) const
  {
    return this->CurrentObservation < other.CurrentObservation;
  }

  vtkMappedMatrixVectorIterator& operator++()
  {
    ++this->CurrentObservation;
    return *this;
  }

  vtkMappedMatrixVectorIterator operator+(const vtkIdType offset) const
  {
    return vtkMappedMatrixVectorIterator(this->Array, this->ObservationDimension, this->CurrentObservation + offset, Map.begin(), Map.end());
  }

  reference operator*() const
  {
    this->CurrentCoordinates[this->ObservationDimension] = this->Map[this->CurrentObservation];
    vtkIdType& element = this->CurrentCoordinates[this->ElementDimension];
    for(element = this->ElementBegin; element != this->ElementEnd; ++element)
    {
      this->CurrentValue[element] = this->Array->GetValue(this->CurrentCoordinates);
    }
    return this->CurrentValue;
  }

private:
  ArrayT* Array;
  vtkIdType ObservationDimension;
  vtkIdType ElementDimension;
  vtkIdType ElementBegin;
  vtkIdType ElementEnd;
  vtkIdType CurrentObservation;
  std::vector<vtkIdType> Map;
  mutable vtkArrayCoordinates CurrentCoordinates;
  mutable value_type CurrentValue;
};

#endif
