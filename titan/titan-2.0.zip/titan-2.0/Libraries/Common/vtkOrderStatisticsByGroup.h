/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkOrderStatisticsByGroup.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkOrderStatisticsByGroup vtkOrderStatisticsByGroup.h <Common/vtkOrderStatisticsByGroup.h>
/// \brief Apply order statistics to a column of a table, grouping rows
/// by distinct values in another column.
///
/// The output is a table with several columns. The "Group" column is the
/// same type as the input group column and contains the distinct group
/// value that the row represents. "Variable", "Cardinality", "Minimum",
/// "First Quartile", "Median", "Third Quartile", "Maximum", are the results
/// from the primary output of vtkOrderStatistics.
///
/// \sa vtkOrderStatistics
///

#ifndef __vtkOrderStatisticsByGroup_h
#define __vtkOrderStatisticsByGroup_h

#include "titanCommon.h"
#include "vtkTableAlgorithm.h"

class TITAN_COMMON_EXPORT vtkOrderStatisticsByGroup : public vtkTableAlgorithm
{
public:
  static vtkOrderStatisticsByGroup *New();
  vtkTypeMacro(vtkOrderStatisticsByGroup, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Set/Get the name of the input array to run statistics on.
  vtkSetStringMacro(ArrayName);
  vtkGetStringMacro(ArrayName);
  ///@}

  ///@{
  /// Set/Get the name of the array to group by.
  vtkSetStringMacro(GroupArrayName);
  vtkGetStringMacro(GroupArrayName);
  ///@}

protected:
  vtkOrderStatisticsByGroup();
  ~vtkOrderStatisticsByGroup();

  int RequestData(
    vtkInformation *vtkNotUsed(request),
    vtkInformationVector **inputVector,
    vtkInformationVector *outputVector);

  char* ArrayName;
  char* GroupArrayName;

private:
  vtkOrderStatisticsByGroup(const vtkOrderStatisticsByGroup&);  // Not implemented.
  void operator=(const vtkOrderStatisticsByGroup&);  // Not implemented.
};

#endif
