/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkBitVectorToCategory.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkBitVectorToCategory vtkBitVectorToCategory.h <Common/vtkBitVectorToCategory.h>
/// \brief Extracts a set of rows from a table based on matching.
///
/// Given a table and a set of ColumnName,Value pairs
/// return a table containing only rows that contain a value match in its
/// specified column.
///

#ifndef __vtkBitVectorToCategory_h
#define __vtkBitVectorToCategory_h

#include "titanCommon.h"
#include <vtkTableAlgorithm.h>

#include <string>
#include <vector>

class vtkTable;

class TITAN_COMMON_EXPORT vtkBitVectorToCategory : public vtkTableAlgorithm
{
public:
  static vtkBitVectorToCategory* New();
  vtkTypeMacro(vtkBitVectorToCategory, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Add Truth columns, call this for each column to be
  /// included as an output for the perceptron
  void AddBitColumn(const char* column);
  ///@}

  vtkGetMacro(HasPrefix, bool);
  vtkSetMacro(HasPrefix, bool);


protected:
  vtkBitVectorToCategory();
  ~vtkBitVectorToCategory();

  int RequestData(vtkInformation*, vtkInformationVector**, vtkInformationVector*);

private:
  vtkBitVectorToCategory(const vtkBitVectorToCategory&); // Not implemented
  void operator=(const vtkBitVectorToCategory&);   // Not implemented

  std::vector<std::string> BitColumns;
  bool  HasPrefix;

};

#endif
