/*=========================================================================

  Program:   Visualization Toolkit
  Module:    $RCSfile: vtkExtractTableRows.h,v $

  Copyright (c) Ken Martin, Will Schroeder, Bill Lorensen
  All rights reserved.
  See Copyright.txt or http://www.kitware.com/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/

/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkExtractTableRows vtkExtractTableRows.h <Common/vtkExtractTableRows.h>
/// \brief Extracts a set of rows from a table based on matching.
///
/// Given a table and a set of ColumnName,Value pairs
/// return a table containing only rows that contain a value match in its
/// specified column.
///

#ifndef __vtkExtractTableRows_h
#define __vtkExtractTableRows_h

#include "titanCommon.h"
#include <vtkTableAlgorithm.h>

class vtkTable;

class TITAN_COMMON_EXPORT vtkExtractTableRows : public vtkTableAlgorithm
{
public:
  static vtkExtractTableRows* New();
  vtkTypeMacro(vtkExtractTableRows, vtkTableAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// Specifies a column by its name and a value from that column that
  /// we wish to match against.
  void AddMatch(const char *ColumnName, const char *Value);
  void ClearMatches();
  ///@}

protected:
  vtkExtractTableRows();
  ~vtkExtractTableRows();

  int RequestData(vtkInformation*, vtkInformationVector**, vtkInformationVector*);

private:
  vtkExtractTableRows(const vtkExtractTableRows&); // Not implemented
  void operator=(const vtkExtractTableRows&);   // Not implemented

//BTX
  vtkTable * ConditionTable;
//ETX
};

#endif
