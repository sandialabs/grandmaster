#ifdef LAPACK_SURROUND_UNDERSCORE
#  define LAPACK_LEADING_UNDERSCORE
#  define LAPACK_TRAILING_UNDERSCORE
#endif

#ifdef LAPACK_LEADING_UNDERSCORE
#  define LAPACK_PREFIX _
#else
#  define LAPACK_PREFIX
#endif
#ifdef LAPACK_TRAILING_UNDERSCORE
#  define LAPACK_SUFFIX _
#else
#  define LAPACK_SUFFIX
#endif

#ifdef LAPACK_UPPERCASE_NAMES
#  define LAPACK_NAME DGEEV
#else
#  define LAPACK_NAME dgeev
#endif

#define LAPACK_DGEEVXX(a,b,c) a ## b ## c
#define LAPACK_DGEEVX(a,b,c) LAPACK_DGEEVXX(a,b,c)

int main()
{
  char cdummy = 'T';
  int idummy=1;
  double ddummy = 1.;

  LAPACK_DGEEVX(LAPACK_PREFIX,LAPACK_NAME,LAPACK_SUFFIX)
  (
  &cdummy, &cdummy, &cdummy, &cdummy, &idummy, &ddummy, &idummy, &ddummy,
  &ddummy, &ddummy, &idummy, &ddummy, &idummy, &idummy, &idummy, &ddummy,
  &ddummy, &ddummy, &ddummy, &ddummy , &idummy, &idummy, &idummy
  );
  return 0;
}
