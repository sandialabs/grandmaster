/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkSimilarityMatrix vtkSimilarityMatrix.h <DataAnalysis/vtkSimilarityMatrix.h>
/// \brief Given an N x M input matrix, compute an N x N similarity matrix containing a similarity score for all pairs in the input.
///
///
///  Text analysis algorithms like LSA and LDA often produce a vector
///  for each document under analysis.  One common postprocessing step
///  is to compute similarities (or distances) between all pairs of
///  documents for later use in some clustering scheme.  This filter
///  computes that matrix.  There is no default distance measure: you
///  must subclass this and implement the ComputePairwiseScore() method.
///  There are likewise no constraints on what the numbers actually
///  mean.  You are free to choose whether lower numbers mean higher or
///  lower similarity -- you need only make sure that the rest of your
///  code uses the same convention.
///
/// \warning
///
///  This is a very simple filter.  It only operates in serial and
///  insists upon a vtkDenseArray<double> as its input.  It produces a
///  vtkDenseArray<double> as its output.
///
/// \par To Do :
///
///  Add on-the-fly thresholding: when set, the filter will generate a
///  vtkSparseArray instead of a vtkDenseArray and will only add scores
///  that pass a threshold value (above or below).
///
///  Add parallel capability (probably in a different filter) where each
///  process owns some set of rows from the input matrix and the
///  corresponding rows from the output matrix.
///
/// \par Thanks :
///
///  Andy Wilson (atwilso@sandia.gov) perpetrated this class.

#ifndef __vtkSimilarityMatrix_h
#define __vtkSimilarityMatrix_h

#include "titanDataAnalysis.h"
#include "vtkArrayDataAlgorithm.h"

class vtkDoubleArray;
class vtkInformation;
class vtkInformationVector;

class TITAN_DATA_ANALYSIS_EXPORT vtkSimilarityMatrix : public vtkArrayDataAlgorithm
{
public:
  vtkTypeMacro(vtkSimilarityMatrix, vtkArrayDataAlgorithm);
  void PrintSelf(ostream &os, vtkIndent indent);

protected: // methods
  vtkSimilarityMatrix();
  ~vtkSimilarityMatrix();

  int RequestData(vtkInformation *, vtkInformationVector **, vtkInformationVector *);

  virtual double ComputePairwiseScore(vtkDoubleArray *A, vtkDoubleArray *B) = 0;

protected: // ivars
  // nothing here just yet

private:
  vtkSimilarityMatrix(const vtkSimilarityMatrix &);
  void operator=(const vtkSimilarityMatrix &);

};

#endif
