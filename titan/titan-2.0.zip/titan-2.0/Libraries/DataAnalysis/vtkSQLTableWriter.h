/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkSQLTableWriter vtkSQLTableWriter.h <DataAnalysis/vtkSQLTableWriter.h>
/// \brief Write columns in a table back to an SQL database
///
///
///  This filter is the opposite of vtkRowQueryToTable.  Give it a
///  pointer to a vtkSQLQuery object, a table name, and a vtkTable for
///  input and it will write the contents of that table to the database
///  behind the vtkSQLQuery.
///
///  If you only want to set some of the columns, supply a list of their
///  names using SetIncludedColumns().  If you want to rename the columns
///  as they're inserted, supply a list of the new names using
///  SetColumnNames().  By default, all columns in the table will be
///  inserted and the column names in the database will be taken from
///  the array names in the table.
///
///  By default the filter will use prepared statements and bound
///  parameters to make execution go more quickly.  If you need to
///  disable this for whatever reason use UsePreparedStatementsOff().
///
///  Note: This writer will not create the table that it writes into --
///  you must do that yourself.

#ifndef __vtkSQLTableWriter_h
#define __vtkSQLTableWriter_h

#include <titanDataAnalysis.h>
#include <vtkWriter.h>

class vtkInformation;
class vtkStringArray;
class vtkSQLQuery;

class TITAN_DATA_ANALYSIS_EXPORT vtkSQLTableWriter : public vtkWriter
{
public:
  vtkTypeMacro(vtkSQLTableWriter, vtkWriter);
  static vtkSQLTableWriter *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  ///@{
  /// If set, this array specifies the columns that will be written
  /// into the database.
  void SetIncludedColumns(vtkStringArray *list);
  vtkGetObjectMacro(IncludedColumns, vtkStringArray);
  ///@}

  ///@{
  /// If set, this array specifies new names for the columns that will
  /// be written into the database.  If both IncludedColumns and
  /// ColumnNames are set, they must have the same length.
  void SetColumnNames(vtkStringArray *list);
  vtkGetObjectMacro(ColumnNames, vtkStringArray);
  ///@}

  ///@{
  /// Set the query object that will be used to write to the database.
  /// You do not need to set up the actual SQL query -- the filter will
  /// do that during execution.
  void SetQuery(vtkSQLQuery *query);
  vtkGetObjectMacro(Query, vtkSQLQuery);
  ///@}

  ///@{
  /// By default this filter will use bound parameters and prepared
  /// statements for efficiency.  However, not all database drivers
  /// support this yet.  If you need to fall back to writing everything
  /// out in full, turn UsePreparedStatements off.
  vtkSetMacro(UsePreparedStatements, bool);
  vtkGetMacro(UsePreparedStatements, bool);
  vtkBooleanMacro(UsePreparedStatements, bool);
  ///@}

  ///@{
  /// Set/get the name of the database table where the results will be stored
  vtkSetStringMacro(TableName);
  vtkGetStringMacro(TableName);
  ///@}

protected:
  vtkSQLTableWriter();
  ~vtkSQLTableWriter();

  bool UsePreparedStatements;
  vtkSQLQuery *Query;
  vtkStringArray *IncludedColumns;
  vtkStringArray *ColumnNames;
  char *TableName;

  void WriteData();

  int FillInputPortInformation(int port, vtkInformation* info);

private:
  vtkSQLTableWriter(const vtkSQLTableWriter &);
  void operator=(const vtkSQLTableWriter &);

};

#endif
