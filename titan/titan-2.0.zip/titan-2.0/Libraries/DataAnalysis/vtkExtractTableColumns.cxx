/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkDataSetAttributes.h"
#include "vtkExtractTableColumns.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkStdString.h"
#include "vtkStringArray.h"
#include "vtkTable.h"

#include <vector>
#include <algorithm>

class vtkExtractTableColumns::vtkVector : public std::vector<vtkStdString>
{
};


vtkStandardNewMacro(vtkExtractTableColumns);

vtkExtractTableColumns::vtkExtractTableColumns()
{
  this->Columns = new vtkExtractTableColumns::vtkVector();
}

vtkExtractTableColumns::~vtkExtractTableColumns()
{
  delete this->Columns;
}


//----------------------------------------------------------------------------
void vtkExtractTableColumns::AddColumn(const char *column)
{
  this->Columns->push_back(column);
  this->Modified();
}

//----------------------------------------------------------------------------
void vtkExtractTableColumns::RemoveColumn(const char *column)
{
  this->Columns->erase(std::remove(this->Columns->begin(), this->Columns->end(), column), this->Columns->end());
  this->Modified();
}

// ----------------------------------------------------------------------
void vtkExtractTableColumns::SetColumnStatus( const char* column, int status )
{
  if( status )
    {
    this->AddColumn( column );
    }
  else
    {
    this->RemoveColumn( column );
    }
}

//----------------------------------------------------------------------------
void vtkExtractTableColumns::RemoveAllColumns()
{
  this->Columns->clear();
  this->Modified();
}

int vtkExtractTableColumns::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  // Get input table
  vtkInformation* inputInfo = inputVector[0]->GetInformationObject(0);
  vtkTable* input = vtkTable::SafeDownCast(
    inputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // Get output tables
  vtkInformation* outputInfo = outputVector->GetInformationObject(0);
  vtkTable* output = vtkTable::SafeDownCast(
    outputInfo->Get(vtkDataObject::DATA_OBJECT()));

  // This will copy only the meta data and not the row data
  output->vtkDataObject::ShallowCopy(input);

  std::vector<vtkStdString>::iterator I;
  for(I = this->Columns->begin(); I != this->Columns->end(); ++I)
    {
    const vtkStdString name = *I;
    vtkAbstractArray* const column = input->GetColumnByName(name.c_str());
    if(column == 0)
      {
      vtkErrorMacro(<< "Could not find column: " << name << " in input table");
      }
    else
      {
      output->AddColumn(column);
      if(input->GetRowData()->GetPedigreeIds() == column)
        output->GetRowData()->SetPedigreeIds(column);
      }
    }

  return 1;
}

void vtkExtractTableColumns::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}
