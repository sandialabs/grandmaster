/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkJensenShannonSimilarityMatrix vtkJensenShannonSimilarityMatrix.h <DataAnalysis/vtkJensenShannonSimilarityMatrix.h>
/// \brief Similarity matrix using symmetrized Jensen-Shannon divergence
///
///
///  Jensen-Shannon divergence is a difference-of-information metric
///  applicable to probability distributions.  It will never take on
///  negative values.  JS(a,b) == 0 if and only if a == b.  It may be
///  loosely (/very/ loosely) interpreted as a distance measure.
///
///  Since the JS divergence increases as two vectors grow less similar
///  this should properly be considered a distance matrix instead of a
///  similarity matrix.  You may choose your favorite way to remap these
///  values into the interval [0, 1] so that 0 == minimum similarity and
///  1 == identity.  I do not have a good intuition for how to do that
///  in an information-theoretically-sound manner.

#ifndef __vtkJensenShannonSimilarityMatrix_h
#define __vtkJensenShannonSimilarityMatrix_h

#include "titanDataAnalysis.h"

#include "vtkSimilarityMatrix.h"
#include "vtkSmartPointer.h" // for smart pointer ivar

class vtkDoubleArray;

class TITAN_DATA_ANALYSIS_EXPORT vtkJensenShannonSimilarityMatrix : public vtkSimilarityMatrix
{
public:
  vtkTypeMacro(vtkJensenShannonSimilarityMatrix, vtkSimilarityMatrix);
  static vtkJensenShannonSimilarityMatrix *New();
  void PrintSelf(ostream &os, vtkIndent indent);

protected:
  vtkJensenShannonSimilarityMatrix();
  ~vtkJensenShannonSimilarityMatrix();

  double ComputePairwiseScore(vtkDoubleArray *left, vtkDoubleArray *right);

  // This is to hold the midpoint between Left and Right while we're
  // computing the distance.  Since it will almost never change length
  // after the first call to ComputePairwiseScore we allocate it once
  // and re-use the memory forever after.
//BTX
  vtkSmartPointer<vtkDoubleArray> Middle;
//ETX

private:
  vtkJensenShannonSimilarityMatrix(const vtkJensenShannonSimilarityMatrix &);
  void operator=(const vtkJensenShannonSimilarityMatrix &);

};

#endif
