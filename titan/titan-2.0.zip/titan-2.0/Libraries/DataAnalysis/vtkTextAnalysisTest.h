/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef _vtkTextAnalysisTest_h
#define _vtkTextAnalysisTest_h

#include "titanDataAnalysis.h"

#include <vtkMultiProcessController.h>
#include <vtkObject.h>

#include <map>
#include <string>

/// \class vtkTextAnalysisTest vtkTextAnalysisTest.h <DataAnalysis/vtkTextAnalysisTest.h>
/// \brief ...
///
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_DATA_ANALYSIS_EXPORT vtkTextAnalysisTest
{
public:
  ///@{
  /// Helper class that simplifies timekeeping.
  class TITAN_DATA_ANALYSIS_EXPORT CPUTimer
  {
  public:
    CPUTimer();
    const double Elapsed() const;
    void Reset();
  ///@}

  private:
    double StartTime;
  };

  ///@{
  /// Helper class that simplifies timekeeping.
  class TITAN_DATA_ANALYSIS_EXPORT WallclockTimer
  {
  public:
    WallclockTimer();
    const double Elapsed() const;
    void Reset();
  ///@}

  private:
    double StartTime;
  };

  ///@{
  /// Set the stream to use for output (default: std::cout)
  static void SetOutputStream(std::ostream& stream);
  static std::ostream& GetOutputStream();
  ///@}

  ///@{
  /// Set the current run number (default: 0)
  static void SetCurrentRun(int run);
  static int GetCurrentRun();
  ///@}

  /// Print column headings for CSV scalability output ...
  static void PrintColumnHeadings();

  /// Print a message to the output stream ...
  static void PrintMessage(const std::string& message);

  /// Print runtime metrics for CSV scalability output ...

  template<typename T>
  static void PrintMetric(vtkMultiProcessController* controller, const std::string& component, const std::string& metric, const T& value, const std::string& units)
  {
    ComponentIndices.insert(std::make_pair(component, ComponentIndices.size()));
    MetricIndices.insert(std::make_pair(component, std::map<std::string, int>()));
    MetricIndices[component].insert(std::make_pair(metric, MetricIndices[component].size()));

    *OutputStream << CurrentRun;
    *OutputStream << ", " << controller->GetLocalProcessId();
    *OutputStream << ", " << controller->GetNumberOfProcesses();
    *OutputStream << ", " << ComponentIndices[component];
    *OutputStream << ", " << MetricIndices[component][metric];
    *OutputStream << ", " << value;
    *OutputStream << ", " << component;
    *OutputStream << ", " << metric;
    *OutputStream << ", " << units;
    *OutputStream << std::endl;
  }

  template<typename T>
  static void PrintMetric(vtkMultiProcessController* controller, vtkObject* component, const std::string& metric, const T& value, const std::string& units)
  {
    PrintMetric(controller, component->GetClassName(), metric, value, units);
  }

  static void PrintMetric(vtkMultiProcessController* controller, vtkObject* component, const std::string& metric, const CPUTimer& timer);
  static void PrintMetric(vtkMultiProcessController* controller, const std::string& component, const std::string& metric, const CPUTimer& timer);
  static void PrintMetric(vtkMultiProcessController* controller, const std::string& component, const std::string& metric, const WallclockTimer& timer);

  template<typename FunctorT>
  static void Serialize(vtkMultiProcessController* controller, FunctorT functor)
  {
    for(int i = 0; i != controller->GetNumberOfProcesses(); ++i)
      {
      if(i == controller->GetLocalProcessId())
        {
        functor(i);
        }
      controller->Barrier();
      }
  }

private:
  static std::ostream* OutputStream;
  static int CurrentRun;
  static std::map<std::string, int> ComponentIndices;
  static std::map<std::string, std::map<std::string, int> > MetricIndices;
};

#endif // !_vtkTextAnalysisTest_h
