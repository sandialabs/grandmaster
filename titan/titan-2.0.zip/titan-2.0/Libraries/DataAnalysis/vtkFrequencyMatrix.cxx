/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkCommand.h"
#include "vtkTextAnalysisTest.h"
#include "vtkDenseArray.h"
#include "vtkIdTypeArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"
#include "vtkSparseArray.h"
#include "vtkFrequencyMatrix.h"
#include "vtkUnicodeStringArray.h"

#include <boost/lambda/lambda.hpp>
using namespace boost::lambda;

#include <iterator>
#include <map>
#include <set>
#include <stdexcept>

///////////////////////////////////////////////////////////////////////////////
// GlobalLookup

static void GlobalLookup(const int IgnoreUnknownFeatures, vtkMultiProcessController* const controller, vtkFrequencyMatrix* const self, vtkIdTypeArray* const local_documents, vtkUnicodeStringArray* const local_features, vtkDataArray* const local_count, vtkUnicodeStringArray* const global_features, vtkSparseArray<double>* output_array)
{
  vtkTextAnalysisTest::CPUTimer cpu_timer;

  const vtkIdType local_feature_count = local_features->GetNumberOfTuples();
  const vtkIdType global_feature_count = global_features->GetNumberOfTuples();

  // Create a mapping of global features ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  std::map<vtkUnicodeString, vtkIdType> global_feature_map;
  for(vtkIdType i = 0; i != global_feature_count; ++i)
    global_feature_map.insert(std::make_pair(global_features->GetValue(i), i));

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "create global feature map", cpu_timer);

  // Get the set of unique documents from our input ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  std::set<vtkIdType> unique_documents;
  for(vtkIdType i = 0; i != local_feature_count; ++i)
    unique_documents.insert(local_documents->GetValue(i));

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "collect unique documents", cpu_timer);

  // For each distinct document ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  int counter = 0, total_count = unique_documents.size();
  std::vector<double> global_feature_frequencies(global_feature_count);
  for(std::set<vtkIdType>::const_iterator document = unique_documents.begin(); document != unique_documents.end(); ++document)
    {
    ++counter;
    std::fill(global_feature_frequencies.begin(), global_feature_frequencies.end(), 0);

    for(vtkIdType i = 0; i != local_feature_count; ++i)
      {
      if(local_documents->GetValue(i) != *document)
        continue;

      std::map<vtkUnicodeString, vtkIdType>::const_iterator lookup = global_feature_map.find(local_features->GetValue(i));
      if(lookup == global_feature_map.end())
        {
        if(!IgnoreUnknownFeatures)
          vtkErrorWithObjectMacro(self, << "Local feature [" << local_features->GetValue(i).utf8_str() << "] does not appear in global feature dictionary!");
        continue;
        }

      if(local_count)
        global_feature_frequencies[lookup->second] += local_count->GetTuple1(i);
      else
        ++global_feature_frequencies[lookup->second];
      }

    for(vtkIdType i = 0; i != global_feature_count; ++i)
      {
      if(!global_feature_frequencies[i])
        continue;

      output_array->AddValue(i, *document, global_feature_frequencies[i]);
      }

    if( counter % 10 == 0 )
      {
      //emit progress...
      double progress = static_cast<double>(counter) / static_cast<double>(total_count);
      self->InvokeEvent(vtkCommand::ProgressEvent, &progress);
      }
    }

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "global feature lookup", cpu_timer);
}

static void GlobalPresortedLookup(const int IgnoreUnknownFeatures, vtkMultiProcessController* const controller, vtkFrequencyMatrix* const self, vtkIdTypeArray* const local_documents, vtkUnicodeStringArray* const local_features, vtkDataArray* const local_count, vtkUnicodeStringArray* const global_features, vtkSparseArray<double>* output_array)
{
  vtkTextAnalysisTest::CPUTimer cpu_timer;

  const vtkIdType local_feature_count = local_features->GetNumberOfTuples();
  const vtkIdType global_feature_count = global_features->GetNumberOfTuples();

  // Create a mapping of global features ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  std::map<vtkUnicodeString, vtkIdType> global_feature_map;
  for(vtkIdType i = 0; i != global_feature_count; ++i)
    global_feature_map.insert(std::make_pair(global_features->GetValue(i), i));

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "create global feature map", cpu_timer);

  // Get the set of unique documents from our input ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  std::set<vtkIdType> unique_documents;
  for(vtkIdType i = 0; i != local_feature_count; ++i)
    unique_documents.insert(local_documents->GetValue(i));

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "collect unique documents", cpu_timer);

  // For each distinct document ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  int counter = 0, total_count = unique_documents.size();
  std::vector<double> global_feature_frequencies(global_feature_count);
  vtkIdType previous_document = 0;
  for( vtkIdType m = 0; m < local_feature_count; )
    {
    ++counter;
    std::fill(global_feature_frequencies.begin(), global_feature_frequencies.end(), 0);

    vtkIdType current_document = local_documents->GetValue(m);
    if( current_document < previous_document )
      {
      vtkErrorWithObjectMacro(self, << "Document order should be monotonically increasing for the vtkFrequencyMatrix - GlobalPresorted strategy to work correctly." << endl );
      continue;
      }

    while( local_documents->GetValue(m) == current_document )
      {
      std::map<vtkUnicodeString, vtkIdType>::const_iterator lookup = global_feature_map.find(local_features->GetValue(m));
      if(lookup == global_feature_map.end())
        {
        if(!IgnoreUnknownFeatures)
          vtkErrorWithObjectMacro(self, << "Local feature [" << local_features->GetValue(m).utf8_str() << "] does not appear in global feature dictionary!");
        continue;
        }

      if(local_count)
        global_feature_frequencies[lookup->second] += local_count->GetTuple1(m);
      else
        ++global_feature_frequencies[lookup->second];
      ++m;
      }
    previous_document = current_document;

    for(vtkIdType i = 0; i != global_feature_count; ++i)
      {
      if(!global_feature_frequencies[i])
        continue;

      output_array->AddValue(i, current_document, global_feature_frequencies[i]);
      }

    if( counter % 10 == 0 )
      {
      //emit progress...
      double progress = static_cast<double>(counter) / static_cast<double>(total_count);
      self->InvokeEvent(vtkCommand::ProgressEvent, &progress);
      }
    }

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "global feature lookup", cpu_timer);
}

///////////////////////////////////////////////////////////////////////////////
// GlobalPlusLocalLookup

static void GlobalPlusLocalLookup(const int IgnoreUnknownFeatures, vtkMultiProcessController* const controller, vtkFrequencyMatrix* const self, vtkIdTypeArray* const local_documents, vtkUnicodeStringArray* const local_features, vtkDataArray* const local_count, vtkUnicodeStringArray* const global_features, vtkSparseArray<double>* output_array)
{
  vtkTextAnalysisTest::CPUTimer cpu_timer;

  const vtkIdType local_feature_count = local_features->GetNumberOfTuples();
  const vtkIdType global_feature_count = global_features->GetNumberOfTuples();

  // Create a mapping of global features ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  std::map<vtkUnicodeString, vtkIdType> global_feature_map;
  for(vtkIdType i = 0; i != global_feature_count; ++i)
    global_feature_map.insert(std::make_pair(global_features->GetValue(i), i));

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "create global features map", cpu_timer);

  // Get the set of unique documents from our input ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  std::set<vtkIdType> unique_documents;
  for(vtkIdType i = 0; i != local_feature_count; ++i)
    unique_documents.insert(local_documents->GetValue(i));

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "collect unique documents", cpu_timer);

  // For each distinct document ...
  if(controller)
    controller->GetCommunicator()->Barrier();
  cpu_timer.Reset();

  int counter = 0, total_count = unique_documents.size();
  for(std::set<vtkIdType>::const_iterator document = unique_documents.begin(); document != unique_documents.end(); ++document)
    {
    ++counter;
    std::map<vtkUnicodeString, double> local_feature_frequencies;
    for(vtkIdType i = 0; i != local_feature_count; ++i)
      {
      if(local_documents->GetValue(i) != *document)
        continue;

      std::map<vtkUnicodeString, double>::iterator lookup = local_feature_frequencies.find(local_features->GetValue(i));
      if(lookup == local_feature_frequencies.end())
        lookup = local_feature_frequencies.insert(std::make_pair(local_features->GetValue(i), 0)).first;

      if(local_count)
        lookup->second += local_count->GetTuple1(i);
      else
        ++lookup->second;
      }

    for(std::map<vtkUnicodeString, double>::const_iterator local_feature = local_feature_frequencies.begin(); local_feature != local_feature_frequencies.end(); ++local_feature)
      {
      std::map<vtkUnicodeString, vtkIdType>::const_iterator lookup = global_feature_map.find(local_feature->first);
      if(lookup == global_feature_map.end())
        {
        if(!IgnoreUnknownFeatures)
          vtkErrorWithObjectMacro(self, << "Local features [" << local_feature->first.utf8_str() << "] does not appear in global features dictionary!");
        continue;
        }

      output_array->AddValue(global_feature_map[local_feature->first], *document, local_feature->second);
      }

    if( counter % 10 == 0 )
      {
      //emit progress...
      double progress = static_cast<double>(counter) / static_cast<double>(total_count);
      self->InvokeEvent(vtkCommand::ProgressEvent, &progress);
      }
    }

  if(controller)
    vtkTextAnalysisTest::PrintMetric(controller, self, "global+local features lookup", cpu_timer);
}

///////////////////////////////////////////////////////////////////////////////
// vtkFrequencyMatrix


vtkStandardNewMacro(vtkFrequencyMatrix);

vtkFrequencyMatrix::vtkFrequencyMatrix() :
  Lookup(GLOBAL_PLUS_LOCAL),
  IgnoreUnknownFeatures(false),
  Controller(0)
{
  this->SetInputArrayToProcess(0, 0, 0, 6, "document");
  this->SetInputArrayToProcess(1, 0, 0, 6, "text");
  this->SetInputArrayToProcess(2, 1, 0, 6, "text");
  this->SetInputArrayToProcess(3, 2, 0, 6, "document");
  this->SetInputArrayToProcess(4, 0, 0, 6, "count");

  this->SetNumberOfInputPorts(3);
  this->SetNumberOfOutputPorts(1);
}

vtkFrequencyMatrix::~vtkFrequencyMatrix()
{
  this->SetController(0);
}

void vtkFrequencyMatrix::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Lookup: " << this->Lookup << "\n";
  os << indent << "IgnoreUnknownFeatures: " << this->IgnoreUnknownFeatures << "\n";
}

int vtkFrequencyMatrix::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
    {
    case 0:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;

    case 1:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;

    case 2:
      information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
      return 1;
    }

    return 0;
}

int vtkFrequencyMatrix::RequestData(
  vtkInformation*,
  vtkInformationVector** inputVector,
  vtkInformationVector* outputVector)
{
  try
    {
    vtkTextAnalysisTest::CPUTimer cpu_timer;

    // Setup input data ...
    vtkIdTypeArray* const local_documents = vtkIdTypeArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(0, 0, inputVector));
    if(!local_documents)
      throw std::runtime_error("Missing feature table document id array.");

    vtkUnicodeStringArray* const local_features = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(1, 0, inputVector));
    if(!local_features)
      throw std::runtime_error("Missing feature table features array.");

    vtkDataArray* const local_count = vtkDataArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(4, 0, inputVector));

    vtkUnicodeStringArray* const global_features = vtkUnicodeStringArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(2, 0, inputVector));
    if(!global_features)
      throw std::runtime_error("Missing feature dictionary features array.");
    const vtkIdType global_feature_count = global_features->GetNumberOfTuples();

    vtkIdTypeArray* const document_id_array = vtkIdTypeArray::SafeDownCast(
      this->GetInputAbstractArrayToProcess(3, 0, inputVector));
    if(!document_id_array)
      throw std::runtime_error("Missing document dictionary document id array.");

    // Get the range of document ids in the document dictionary ...
    std::set<vtkIdType> document_ids;
    for(vtkIdType i = 0; i != document_id_array->GetNumberOfTuples(); ++i)
      document_ids.insert(document_id_array->GetValue(i));

    // Setup the output frequency matrix ...
    vtkSparseArray<double>* const output_array = vtkSparseArray<double>::New();
    output_array->Resize(vtkArrayRange(0, global_feature_count), document_ids.size() ? vtkArrayRange(*document_ids.begin(), *document_ids.rbegin() + 1) : vtkArrayRange(0, 0));
    output_array->SetName("frequency-matrix");
    output_array->SetDimensionLabel(0, "feature");
    output_array->SetDimensionLabel(1, "document");
    output_array->SetNullValue(0.0);

    // Do the actual work ...
    switch(this->Lookup)
      {
      case GLOBAL_PLUS_LOCAL:
        {
        GlobalPlusLocalLookup(this->IgnoreUnknownFeatures, this->Controller, this, local_documents, local_features, local_count, global_features, output_array);
        break;
        }
      case GLOBAL_PRESORTED:
        {
        GlobalPresortedLookup(this->IgnoreUnknownFeatures, this->Controller, this, local_documents, local_features, local_count, global_features, output_array);
        break;
        }
      case GLOBAL:
        {
        GlobalLookup(this->IgnoreUnknownFeatures, this->Controller, this, local_documents, local_features, local_count, global_features, output_array);
        break;
        }
      }

    // Configure our output ...
    vtkArrayData* const output = vtkArrayData::GetData(outputVector, 0);
    output->ClearArrays();
    output->AddArray(output_array);
    output_array->Delete();

    return 1;
    }
  catch(std::exception& e)
    {
    vtkErrorMacro(<< "caught exception: " << e.what() << endl);
    }
  catch(...)
    {
    vtkErrorMacro(<< "caught unknown exception." << endl);
    }

  return 0;
}
