/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkCosineSimilarityTable_h
#define __vtkCosineSimilarityTable_h

#include <vtkSimilarityTable.h>
#include "titanDataAnalysis.h"

class vtkInformation;

/// \class vtkCosineSimilarityTable vtkCosineSimilarityTable.h <DataAnalysis/vtkCosineSimilarityTable.h>
/// \brief compute cosine similarity metrics.
///
///  Treats matrices as collections of vectors and computes cosine similarity
///  metrics between vectors.
///
///  The results are returned as an edge-table that lists the index of each vector
///  and their computed similarity.  The output edge-table is typically used with
///  vtkTableToGraph to create a similarity graph.
///
///  This filter can be used with one or two input matrices.  If you provide a
///  single matrix as input, every vector in the matrix is compared with every
///  other vector. If you provide two matrices, every vector in the first matrix
///  is compared with every vector in the second matrix.
///
///  You may optionally provide a weighting vector that will be applied to each
///  pair of input vectors before computing their similarity.  This would
///  typically be used for power-weighting of LSA similarities by singular values.
///
///  You may also optionally use a vtkArrayRange object to define a "window" of
///  vector elements to be compared.  This would typically be used when computing
///  truncated LSA similarities.
///
///  Inputs:
///    Input port 0: (required) A vtkDenseArray<double> with two dimensions.
///    Input port 1: (optional) A vtkDenseArray<double> with two dimensions.
///    Input port 2: (optional) Weighting vector - a vtkDenseArray<double> with
///      one dimension.
///
///  Outputs:
///    Output port 0: A vtkTable containing "source", "target", and "similarity"
///      columns.
///
/// \warning
///  Note that the complexity of this filter is quadratic!  It also requires dense
///  arrays as input, in the future it should be generalized to accept sparse
///  arrays.
///
/// \par Thanks :
///  Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

class TITAN_DATA_ANALYSIS_EXPORT vtkCosineSimilarityTable : public vtkSimilarityTable
{
public:
  vtkTypeMacro(vtkCosineSimilarityTable, vtkSimilarityTable);
  static vtkCosineSimilarityTable *New();
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
protected:
  vtkCosineSimilarityTable();
  ~vtkCosineSimilarityTable();

  int FillInputPortInformation(int, vtkInformation*);

private:
  vtkCosineSimilarityTable(const vtkCosineSimilarityTable&); // Not implemented
  void operator=(const vtkCosineSimilarityTable&);   // Not implemented

  virtual void StartIteration(const Context& context);
  virtual double ComputePairwiseScore(const Context& context, vtkIdType vector_a, vtkIdType vector_b);
  virtual void FinishIteration(const Context& context);

  vtkTypedArray<double>* WeightingVector;
//ETX
};

#endif
