#include <vtkArray.h>
#include <vtkArrayData.h>
#include <vtkArrayWriter.h>
#include <vtkDoubleArray.h>
#include <vtkFrequencyMatrix.h>
#include <vtkIdTypeArray.h>
#include <vtkNew.h>
#include <vtkTable.h>
#include <vtkUnicodeStringArray.h>

#include <sstream>
#include <stdexcept>

#define test_expression(expression) \
{ \
  if(!(expression)) \
    { \
    std::ostringstream buffer; \
    buffer << "Expression failed at line " << __LINE__ << ": " << #expression; \
    throw std::runtime_error(buffer.str()); \
    } \
}

void check_freq_matrix(vtkTable* feature_table)
{
  vtkNew<vtkTable> feature_dict;
  vtkNew<vtkUnicodeStringArray> feature_dict_text;
  feature_dict_text->SetName("text");
  feature_dict_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_dict_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_dict->AddColumn(feature_dict_text.GetPointer());

  vtkNew<vtkTable> document_dict;
  vtkNew<vtkIdTypeArray> document_dict_doc;
  document_dict_doc->SetName("document");
  document_dict_doc->InsertNextValue(0);
  document_dict_doc->InsertNextValue(1);
  document_dict->AddColumn(document_dict_doc.GetPointer());

  vtkNew<vtkFrequencyMatrix> freq;
  freq->SetInput(0, feature_table);
  freq->SetInput(1, feature_dict.GetPointer());
  freq->SetInput(2, document_dict.GetPointer());
  for (int lookup = 0; lookup != 3; ++lookup)
    {
    freq->SetLookup(lookup);
    freq->Update();
    vtkArray* a = freq->GetOutput()->GetArray(0);
    //cerr << vtkArrayWriter::Write(a);
    test_expression(a->GetVariantValue(0, 0).ToDouble() == 2);
    test_expression(a->GetVariantValue(0, 1).ToDouble() == 1);
    test_expression(a->GetVariantValue(1, 0).ToDouble() == 1);
    test_expression(a->GetVariantValue(1, 1).ToDouble() == 2);
    }
}

void FrequencyMatrixWithoutCountColumn()
{
  vtkNew<vtkTable> feature_table;
  vtkNew<vtkIdTypeArray> feature_table_doc;
  feature_table_doc->SetName("document");
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(1);
  feature_table_doc->InsertNextValue(1);
  feature_table_doc->InsertNextValue(1);
  feature_table->AddColumn(feature_table_doc.GetPointer());
  vtkNew<vtkUnicodeStringArray> feature_table_text;
  feature_table_text->SetName("text");
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table->AddColumn(feature_table_text.GetPointer());

  check_freq_matrix(feature_table.GetPointer());
}

void FrequencyMatrixWithCountColumn()
{
  vtkNew<vtkTable> feature_table;
  vtkNew<vtkIdTypeArray> feature_table_doc;
  feature_table_doc->SetName("document");
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(1);
  feature_table_doc->InsertNextValue(1);
  feature_table->AddColumn(feature_table_doc.GetPointer());
  vtkNew<vtkUnicodeStringArray> feature_table_text;
  feature_table_text->SetName("text");
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table->AddColumn(feature_table_text.GetPointer());
  vtkNew<vtkDoubleArray> feature_table_count;
  feature_table_count->SetName("count");
  feature_table_count->InsertNextValue(2);
  feature_table_count->InsertNextValue(1);
  feature_table_count->InsertNextValue(1);
  feature_table_count->InsertNextValue(2);
  feature_table->AddColumn(feature_table_count.GetPointer());

  check_freq_matrix(feature_table.GetPointer());
}

void FrequencyMatrixWithMultipleCounts()
{
  vtkNew<vtkTable> feature_table;
  vtkNew<vtkIdTypeArray> feature_table_doc;
  feature_table_doc->SetName("document");
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(0);
  feature_table_doc->InsertNextValue(1);
  feature_table_doc->InsertNextValue(1);
  feature_table->AddColumn(feature_table_doc.GetPointer());
  vtkNew<vtkUnicodeStringArray> feature_table_text;
  feature_table_text->SetName("text");
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("a"));
  feature_table_text->InsertNextValue(vtkUnicodeString::from_utf8("b"));
  feature_table->AddColumn(feature_table_text.GetPointer());
  vtkNew<vtkDoubleArray> feature_table_count;
  feature_table_count->SetName("count");
  feature_table_count->InsertNextValue(1.5);
  feature_table_count->InsertNextValue(0.5);
  feature_table_count->InsertNextValue(1);
  feature_table_count->InsertNextValue(1);
  feature_table_count->InsertNextValue(2);
  feature_table->AddColumn(feature_table_count.GetPointer());

  check_freq_matrix(feature_table.GetPointer());
}

int main()
{
  try
    {
    FrequencyMatrixWithoutCountColumn();
    FrequencyMatrixWithCountColumn();
    FrequencyMatrixWithMultipleCounts();
    return 0;
    }
  catch (std::exception& e)
    {
    std::cerr << e.what() << std::endl;
    return 1;
    }
}
