/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkTestSimilarityTable_h
#define __vtkTestSimilarityTable_h

#include <vtkSimilarityTable.h>
#include "titanDataAnalysis.h"

class vtkInformation;

/// Helper class that implements a dirt-simple similarity metric
/// for testing the vtkSimilarityTable implementation.
class vtkTestSimilarityTable :
  public vtkSimilarityTable
{
public:
  vtkTypeMacro(vtkTestSimilarityTable, vtkSimilarityTable);
  static vtkTestSimilarityTable *New();
  void PrintSelf(ostream& os, vtkIndent indent);

//BTX
protected:
  vtkTestSimilarityTable();
  ~vtkTestSimilarityTable();

  int FillInputPortInformation(int, vtkInformation*);

private:
  vtkTestSimilarityTable(const vtkTestSimilarityTable&); // Not implemented
  void operator=(const vtkTestSimilarityTable&);   // Not implemented

  virtual void StartIteration(const Context& context);
  virtual double ComputePairwiseScore(const Context& context, vtkIdType vector_a, vtkIdType vector_b);
  virtual void FinishIteration(const Context& context);
//ETX
};

#endif
