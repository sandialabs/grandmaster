/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkTestSimilarityTable.h"
#include "vtkInformation.h"
#include "vtkObjectFactory.h"

#include <cmath>

// ----------------------------------------------------------------------


vtkStandardNewMacro(vtkTestSimilarityTable);

// ----------------------------------------------------------------------

vtkTestSimilarityTable::vtkTestSimilarityTable()
{
  // Override the number of input ports specified by the base class ...
  this->SetNumberOfInputPorts(3);
}

// ----------------------------------------------------------------------

vtkTestSimilarityTable::~vtkTestSimilarityTable()
{
}

// ----------------------------------------------------------------------

void vtkTestSimilarityTable::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

int vtkTestSimilarityTable::FillInputPortInformation(int port, vtkInformation* info)
{
  // Provide information for our input port, defer to the base class for
  // everything else ...
  switch(port)
    {
    case 2:
      info->Set(vtkAlgorithm::INPUT_IS_OPTIONAL(), 1);
      info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
      return 1;

    default:
      return this->Superclass::FillInputPortInformation(port, info);
    }

  return 0;
}

void vtkTestSimilarityTable::StartIteration(const Context& context)
{
}

double vtkTestSimilarityTable::ComputePairwiseScore(const Context& context, vtkIdType vector_a, vtkIdType vector_b)
{
  /// We return a score that is equal to the distance between vector indices.
  /// Yes, this is dumb, but it should be useful for writing tests.
  return std::abs(static_cast<double>(vector_a - vector_b));
}

void vtkTestSimilarityTable::FinishIteration(const Context& context)
{
}
