/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkArrayData.h"
#include "vtkJensenShannonSimilarityTable.h"
#include "vtkDenseArray.h"
#include "vtkInformation.h"
#include "vtkObjectFactory.h"

#include <cmath>
#include <stdexcept>

#ifndef log2
  inline double log2(double n)
  {
    return std::log(n) / std::log(2.0);
  }
#endif

// ----------------------------------------------------------------------


vtkStandardNewMacro(vtkJensenShannonSimilarityTable);

// ----------------------------------------------------------------------

vtkJensenShannonSimilarityTable::vtkJensenShannonSimilarityTable()
{
}

// ----------------------------------------------------------------------

vtkJensenShannonSimilarityTable::~vtkJensenShannonSimilarityTable()
{
}

// ----------------------------------------------------------------------

void vtkJensenShannonSimilarityTable::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

// ----------------------------------------------------------------------

double vtkJensenShannonSimilarityTable::ComputePairwiseScore(const Context& context, vtkIdType vector_a, vtkIdType vector_b)
{
  vtkArrayCoordinates coordinates_a(0, 0);
  coordinates_a[context.VectorDimensionA] = vector_a;

  vtkArrayCoordinates coordinates_b(0, 0);
  coordinates_b[context.VectorDimensionB] = vector_b;

  // Compute the dot-product of a & b, norm a, and norm b ...
  double divergence = 0;
  double similarity = 0;
  double a_to_middle = 0;
  double b_to_middle = 0;

  for(vtkIdType element = context.ElementBegin; element != context.ElementEnd; ++element)
    {
    coordinates_a[context.ElementDimensionA] = element;
    coordinates_b[context.ElementDimensionB] = element;
    double a = context.ArrayA->GetValue(coordinates_a);
    double b = context.ArrayB->GetValue(coordinates_b);
    double middle = 0.5 * (a+b);

#if 0
    if (vector_a == 0 && vector_b == 8)
      {
      cerr << "element = " << element
           << ", A coords ("
           << coordinates_a[0] << " " << coordinates_a[1] << ")"
           << ", a = "
           << a
           << ", B coords ("
           << coordinates_b[0] << " " << coordinates_b[1] << ")"
           << ", b = " << b << ", middle = " << middle << "\n";
      }
#endif

    // guard against zeros -- these are possible but hopefully rare
    if (middle == 0) middle = 1e-10;
    if (a == 0) a = 1e-10;
    if (b == 0) b = 1e-10;
    a_to_middle += a * log2(a / middle);
    b_to_middle += b * log2(b / middle);
    }


  divergence = a_to_middle + b_to_middle;
  similarity = pow(2, -1. * divergence);

  return similarity;
}

// ----------------------------------------------------------------------

void vtkJensenShannonSimilarityTable::StartIteration(const Context& context)
{
  if(!vtkDenseArray<double>::SafeDownCast(context.ArrayA))
    throw std::runtime_error("First input must be vtkDenseArray<double>.");
  if(!vtkDenseArray<double>::SafeDownCast(context.ArrayB))
    throw std::runtime_error("Second input must be vtkDenseArray<double>.");
}

// ----------------------------------------------------------------------

void vtkJensenShannonSimilarityTable::FinishIteration(const Context& context)
{
}
