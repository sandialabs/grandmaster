/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkMapArrayToUnstructuredGrid vtkMapArrayToUnstructuredGrid.h <DataAnalysis/vtkMapArrayToUnstructuredGrid.h>
/// \brief maps CCA results to node variables in an unstructured grid.
///
///
///  Inputs:
///    Input port 0: (required) Mesh - a vtkUnstructuredGrid.
///    Input port 1: (required) CCA result matrix - vtkArrayData
///      with a vtkDenseArray<double> in two dimensions.
///    Input port 2: (optional) Node map - vtkArrayData
///      with a vtkDenseArray<int> with one dimension.
///
///  Outputs:
///    Output port 0: A vtkUnstructuredGrid combining the CCA results with
///      the mesh topology.
///
/// \par Thanks :
///  Developed by Patricia Crossno(pjcross@sandia.gov) at Sandia National Laboratories.

#ifndef __vtkMapArrayToUnstructuredGrid_h
#define __vtkMapArrayToUnstructuredGrid_h

#include "titanDataAnalysis.h"
#include <vtkUnstructuredGridAlgorithm.h>

class TITAN_DATA_ANALYSIS_EXPORT vtkMapArrayToUnstructuredGrid :
  public vtkUnstructuredGridAlgorithm
{
public:
  static vtkMapArrayToUnstructuredGrid* New();
  vtkTypeMacro(vtkMapArrayToUnstructuredGrid, vtkUnstructuredGridAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

protected:
  vtkMapArrayToUnstructuredGrid();
  ~vtkMapArrayToUnstructuredGrid();

  // Description:
  // This is called by the superclass.
  // This is the method you should override.
  virtual int RequestData(vtkInformation* request,
                          vtkInformationVector** inputVector,
                          vtkInformationVector* outputVector);

  virtual int FillInputPortInformation(int port, vtkInformation* info);

private:
  vtkMapArrayToUnstructuredGrid(const vtkMapArrayToUnstructuredGrid&); // Not implemented
  void operator=(const vtkMapArrayToUnstructuredGrid&); // Not implemented
};

#endif
