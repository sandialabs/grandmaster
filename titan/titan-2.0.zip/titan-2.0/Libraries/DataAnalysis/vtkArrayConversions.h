/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#ifndef __vtkArrayConversions_h
#define __vtkArrayConversions_h

#include "vtkSparseArray.h"

// .SECTION Thanks
// Developed by Timothy M. Shead (tshead@sandia.gov) at Sandia National Laboratories.

///@{
/// Converts a vtkArray to a matrix in Compressed Column Storage (CCS) format
template<typename T, typename ColumnsT, typename RowsT, typename ValuesT>
void vtkConvertToCCS(vtkTypedArray<T>* matrix, ColumnsT& columns, RowsT& rows, ValuesT& values);
///@}

///@{
/// Converts a matrix in Compressed Column Storage (CCS) format to a vtkArray
template<typename T1, typename T2>
void vtkConvertFromCCS(const std::vector<int>& columns, const std::vector<int>& rows, const std::vector<T1>& values, vtkSparseArray<T2>* matrix);
///@}

#include "vtkArrayConversions.txx"

#endif
