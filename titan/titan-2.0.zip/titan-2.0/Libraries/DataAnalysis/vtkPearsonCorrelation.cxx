/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkPearsonCorrelation.h"

#include "vtkArrayData.h"
#include "vtkDenseArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"

#include <stdexcept>


vtkStandardNewMacro(vtkPearsonCorrelation);

// ----------------------------------------------------------------------

vtkPearsonCorrelation::vtkPearsonCorrelation() :
UnbiasedVariance(true)
{
}

// ----------------------------------------------------------------------

vtkPearsonCorrelation::~vtkPearsonCorrelation()
{
}

// ----------------------------------------------------------------------

void
vtkPearsonCorrelation::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

// ----------------------------------------------------------------------

int vtkPearsonCorrelation::FillInputPortInformation(int port, vtkInformation* information)
{
  switch(port)
  {
  case 0:
    information->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkArrayData");
    return 1;
  }

  return 0;
}

// ----------------------------------------------------------------------

int vtkPearsonCorrelation::FillOutputPortInformation(int port, vtkInformation* information)
{
  switch(port)
  {
  case 0:
    information->Set(vtkDataObject::DATA_TYPE_NAME(), "vtkArrayData");
    return 1;
  }

  return 0;
}


// ----------------------------------------------------------------------

int vtkPearsonCorrelation::RequestData(vtkInformation*        request,
                                       vtkInformationVector** inputVector,
                                       vtkInformationVector*  outputVector)
{
  try
  {
    // Validate inputs ...
    vtkArrayData* const input_array_data = vtkArrayData::GetData(inputVector[0]);
    if(!input_array_data)
      throw std::runtime_error("Missing input vtkArrayData.");
    if(input_array_data->GetNumberOfArrays() != 2)
      throw std::runtime_error("PearsonCorrelation Input vtkArrayData must contain two vtkArrays.");

    vtkDenseArray<double>* const X = vtkDenseArray<double>::SafeDownCast(input_array_data->GetArray(0));
    if(!X)
      throw std::runtime_error("First Pearson Input vtkArray must be a vtkDenseArray<double>.");
    if(X->GetDimensions() != 2)
      throw std::runtime_error("First Pearson Input vtkArray must have two dimensions.");
    if(!X->GetExtents().ZeroBased())
      throw std::runtime_error("First Pearson Input vtkArray must use zero-based indices.");
    if(X->GetExtents()[1].GetSize() < 1)
      throw std::runtime_error("First Pearson Input vtkArray must have at least one column.");

    vtkDenseArray<double>* const Y = vtkDenseArray<double>::SafeDownCast(input_array_data->GetArray(1));
    if(!Y)
      throw std::runtime_error("Second Pearson Input vtkArray must be a vtkDenseArray<double>.");
    if(Y->GetDimensions() != 2)
      throw std::runtime_error("Second Pearson Input vtkArray must have two dimensions.");
    if(!Y->GetExtents().ZeroBased())
      throw std::runtime_error("Second Pearson Input vtkArray must use zero-based indices.");
    if(Y->GetExtents()[1].GetSize() < 1)
      throw std::runtime_error("Second Pearson Input vtkArray must have at least one column.");

    int numRows = X->GetExtents()[0].GetSize();
    if(numRows != Y->GetExtents()[0].GetSize())
      throw std::runtime_error("Pearson input arrays must have the same number of rows.");
    if(numRows < 2) //if numRows == 1, could get a divide by zero with UnbiasedVariance
      throw std::runtime_error("Pearson input arrays must contain at least 2 rows.");


    //setup the output array
    vtkDenseArray<double>* const coefficients = vtkDenseArray<double>::New();
    coefficients->Resize(0,0);
    vtkArrayData* const output = vtkArrayData::GetData(outputVector);
    output->ClearArrays();
    output->AddArray(coefficients);
    coefficients->Delete();

    // If the input is empty just return
    if(0 == X->GetSize() || 0 == Y->GetSize())
    {
      return 1;
    }


    //Temp vectors for statistics
    vtkSmartPointer<vtkDenseArray<double> > Xmeans = vtkSmartPointer<vtkDenseArray<double> >::New();
    Xmeans->Resize( X->GetExtents()[1].GetSize() );
    vtkSmartPointer<vtkDenseArray<double> > Xdeviations = vtkSmartPointer<vtkDenseArray<double> >::New();
    Xdeviations->Resize( X->GetExtents()[1].GetSize() );
    vtkSmartPointer<vtkDenseArray<double> > Ymeans = vtkSmartPointer<vtkDenseArray<double> >::New();
    Ymeans->Resize( Y->GetExtents()[1].GetSize() );
    vtkSmartPointer<vtkDenseArray<double> > Ydeviations = vtkSmartPointer<vtkDenseArray<double> >::New();
    Ydeviations->Resize( Y->GetExtents()[1].GetSize() );

    coefficients->Resize(X->GetExtents()[1].GetSize(), Y->GetExtents()[1].GetSize());

    //calc mean and stddev
    this->calcStats(X, Xmeans, Xdeviations);
    this->calcStats(Y, Ymeans, Ydeviations);

    //Do the Pearson calculation
    for(int r=0; r<X->GetExtents()[1].GetSize(); r++)
    {
      for(int c=0; c<Y->GetExtents()[1].GetSize(); c++)
      {
        if(Xdeviations->GetValue(r) == 0.0 || Ydeviations->GetValue(c) == 0.0)
        {
          coefficients->SetValue(r, c, 0.0 );
        }
        else
        {
          //covarience is an inner product of variances using the r-th col of X and the c-th col of Y
          double covar = 0.0;
          for(int ii=0; ii<numRows; ii++)
          {
            covar += (X->GetValue(ii, r) - Xmeans->GetValue(r)) * (Y->GetValue(ii, c) - Ymeans->GetValue(c)); // 1/n performed on line below
          }
          coefficients->SetValue(r, c, covar / ((numRows-1) * Xdeviations->GetValue(r) * Ydeviations->GetValue(c)) );
        }
      }
    }


  }
  catch(std::exception& e)
  {
    vtkErrorMacro(<< "unhandled exception: " << e.what());
    return 0;
  }
  catch(...)
  {
    vtkErrorMacro(<< "unknown exception");
    return 0;
  }

  return 1;
}


void vtkPearsonCorrelation::calcStats(vtkDenseArray<double>* A, vtkDenseArray<double>* means, vtkDenseArray<double>* stddevs)
{
  int numRows = A->GetExtents()[0].GetSize();
  int numCols = A->GetExtents()[1].GetSize();
  int numSamples;

  if( this->UnbiasedVariance )
  {
    numSamples = numRows - 1;  //use an unbiased (sample) n
  }
  else
  {
    numSamples = numRows;      //use a biased (population) n
  }

  for(int col=0; col<numCols; col++)
  {
    double mean = 0.0;
    double moment2 = 0.0;
    double n, val, delta;

    //run down each col to find mean and 2nd moment
    for (int row=0; row<numRows; row++)
    {
      n = row + 1.0;
      val = A->GetValue(row,col);
      delta = val - mean;
      mean += delta / n;
      moment2 += delta * (val - mean);
    }

    //standard deviation:  variance = moment2/numSamples,  sigma = sqrt(variance)
    stddevs->SetValue(col, sqrt(moment2/numSamples) );
    means->SetValue(col, mean);
  }

}
