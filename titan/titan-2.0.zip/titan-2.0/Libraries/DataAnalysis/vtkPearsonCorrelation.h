/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


/// \class vtkPearsonCorrelation vtkPearsonCorrelation.h <DataAnalysis/vtkPearsonCorrelation.h>
/// \brief This filter computes a measure of correlation between two given arrays.
///
///
///  The Pearson Correlation Coefficient (sometimes known as "Pearson's R" or an
///  "r-squared value" or Pearson Product-Moment Correlation Coefficient) is a
///  measure of the correlation between two variables.
///  This is a serial implementation that takes two arrays and computes the
///  correlation between all combinations of the column vectors.
///  For input arrays of X and Y, the output coefficient pcc(i,j) is the correlation
///  between the i-th column of X and the j-th column of Y.
///
/// \Requirements:
///
///  Input:
///  This filter requires a vtkArrayData as input containing 2 arrays typed vtkDenseArray<double>:
///    port 0, input array X, dimension r1xc1
///    port 1, input array Y, dimension r2xc2
///
///  Output:
///  vtkArrayData containing 1 vtkDenseArray<double> as the resultant coefficients
///    port 0, output array of correlation coefficients, dimension c1xc2
///
/// \par Math notes:
///
///  This filter computes: pcc(x,y) = cov(x,y) / sigma_x * sigma_y
///    where x and y are column vectors from the 2 input arrays.
///  The filter defaults to sample or unbiased variance for standard deviation.
///  You may select a population or biased variance if desired.
///
/// \par Thanks :
///
///  Warren Hunt (wlhunt@sandia.gov) authored this class.

#ifndef __vtkPearsonCorrelation_h
#define __vtkPearsonCorrelation_h

#include "titanDataAnalysis.h"
#include "vtkArrayDataAlgorithm.h"

#include <vtkDenseArray.h>

class vtkInformation;
class vtkInformationVector;

class TITAN_DATA_ANALYSIS_EXPORT vtkPearsonCorrelation : public vtkArrayDataAlgorithm
{
public:
  vtkTypeMacro(vtkPearsonCorrelation, vtkArrayDataAlgorithm);
  static vtkPearsonCorrelation *New();
  void PrintSelf(ostream &os, vtkIndent indent);

  ///@{
  /// Sets the estimator to use in calculating variance.
  /// Default is true, unbiased variance (which is "sample" or "n-1"). Set to false for biased "population" variance.
  vtkSetMacro(UnbiasedVariance, bool);
  vtkGetMacro(UnbiasedVariance, bool);
  ///@}


//BTX
protected: // methods
  vtkPearsonCorrelation();
  ~vtkPearsonCorrelation();

  virtual int FillInputPortInformation(int, vtkInformation*);
  virtual int FillOutputPortInformation(int, vtkInformation*);

  int RequestData(vtkInformation *, vtkInformationVector **, vtkInformationVector *);

protected: // ivars

  bool UnbiasedVariance;


private:
  vtkPearsonCorrelation(const vtkPearsonCorrelation &);
  void operator=(const vtkPearsonCorrelation &);

  void calcStats(vtkDenseArray<double>* A, vtkDenseArray<double>* means, vtkDenseArray<double>* stddevs);
//ETX

};

#endif
