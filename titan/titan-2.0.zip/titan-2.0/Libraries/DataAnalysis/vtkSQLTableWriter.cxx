/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkSQLTableWriter.h"

#include <vtkInformation.h>
#include <vtkObjectFactory.h>
#include <vtkSmartPointer.h>
#include <vtkSQLDatabase.h>
#include <vtkSQLQuery.h>
#include <vtkStringArray.h>
#include <vtkTable.h>
#include <vtkVariantArray.h>

#include <vtksys/ios/sstream>


vtkCxxSetObjectMacro(vtkSQLTableWriter, IncludedColumns, vtkStringArray);
vtkCxxSetObjectMacro(vtkSQLTableWriter, ColumnNames, vtkStringArray);
vtkCxxSetObjectMacro(vtkSQLTableWriter, Query, vtkSQLQuery);
vtkStandardNewMacro(vtkSQLTableWriter);

// ----------------------------------------------------------------------

vtkSQLTableWriter::vtkSQLTableWriter()
  : UsePreparedStatements(true),
    Query(NULL),
    IncludedColumns(NULL),
    ColumnNames(NULL),
    TableName(NULL)
{
  this->SetNumberOfInputPorts(1);
}

// ----------------------------------------------------------------------

vtkSQLTableWriter::~vtkSQLTableWriter()
{
  this->SetQuery(NULL);
  this->SetIncludedColumns(NULL);
  this->SetColumnNames(NULL);
  this->SetTableName(NULL);
}

// ----------------------------------------------------------------------

void
vtkSQLTableWriter::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "Table name: " << (this->TableName ? this->TableName : "(null)") << "\n";
  os << indent << "Included columns: ";
  if (this->IncludedColumns)
    {
    os << "\n";
    this->IncludedColumns->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)\n";
    }

  os << indent << "Column names: ";
  if (this->ColumnNames)
    {
    os << "\n";
    this->ColumnNames->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)\n";
    }

  os << indent << "Query: ";
  if (this->Query)
    {
    os << "\n";
    this->Query->PrintSelf(os, indent.GetNextIndent());
    }
  else
    {
    os << "(null)\n";
    }
}

// ----------------------------------------------------------------------

int
vtkSQLTableWriter::FillInputPortInformation(int vtkNotUsed(port),
                                            vtkInformation *info)
{
  info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkTable");
  return 1;
}

// ----------------------------------------------------------------------

void
vtkSQLTableWriter::WriteData()
{
  vtkTable *input = vtkTable::SafeDownCast(this->GetInput());
  if (!input)
    {
    vtkErrorMacro(<<"Cannot write data: no input!");
    return;
    }

  if (input->GetNumberOfColumns() == 0)
    {
    vtkWarningMacro(<<"Table has no columns.");
    return;
    }

  if (input->GetNumberOfRows() == 0)
    {
    vtkWarningMacro(<<"Table has no rows.");
    return;
    }

  if (this->IncludedColumns && this->IncludedColumns->GetNumberOfTuples() == 0)
    {
    vtkWarningMacro(<<"IncludedColumns array set but does not list any columns to write.");
    return;
    }

  if (this->IncludedColumns && this->ColumnNames &&
      this->IncludedColumns->GetNumberOfTuples() != this->ColumnNames->GetNumberOfTuples())
    {
    vtkWarningMacro(<<"IncludedColumns and ColumnNames arrays have different lengths.");
    return;
    }


  if (!this->Query)
    {
    vtkErrorMacro(<<"Cannot write data: no Query ivar set!");
    return;
    }

  vtkTable *writeTable;
  // First, subset the table if necessary.
  if (this->IncludedColumns)
    {
    writeTable = vtkTable::New();
    for (int i = 0; i < this->IncludedColumns->GetNumberOfTuples(); ++i)
      {
      vtkAbstractArray *col = input->GetColumnByName(this->IncludedColumns->GetValue(i).c_str());
      if (!col)
        {
        vtkErrorMacro(<<"Fatal error: could not locate column '"
                      << this->IncludedColumns->GetValue(i).c_str()
                      << "' in input table.");
        writeTable->Delete();
        return;
        }
      else
        {
        writeTable->AddColumn(col);
        }
      }
    }
  else
    {
    writeTable = input;
    writeTable->Register(this);
    }

  // One more round of sanity checks
  if (writeTable->GetNumberOfColumns() == 0)
    {
    vtkErrorMacro(<<"No columns are left after table subsetting.");
    writeTable->Delete();
    return;
    }

  if (this->ColumnNames &&
      this->ColumnNames->GetNumberOfTuples() != writeTable->GetNumberOfColumns())
    {
    vtkErrorMacro(<<"ColumnNames is set but does not match the number of fields to be written.");
    writeTable->Delete();
    return;
    }

  vtksys_ios::ostringstream preamble;
  preamble << "INSERT INTO " << this->TableName << " ( ";
  if (this->ColumnNames)
    {
    for (int col = 0; col < this->ColumnNames->GetNumberOfTuples(); ++col)
      {
      if (col > 0)
        {
        preamble << ", ";
        }
      preamble << this->ColumnNames->GetValue(col);
      }
    }
  else
    {
    for (int col = 0; col < writeTable->GetNumberOfColumns(); ++col)
      {
      if (col > 0)
        {
        preamble << ", ";
        }
      preamble << writeTable->GetColumnName(col);
      }
    }
  // terminate the Names list and set up for Values
  preamble << " ) VALUES ( ";

  if (this->UsePreparedStatements)
    {
    vtksys_ios::ostringstream querybuf;
    querybuf << preamble.str();
    for (int col = 0; col < writeTable->GetNumberOfColumns(); ++col)
      {
      if (col > 0)
        {
        querybuf << ", ";
        }
      querybuf << "?";
      }
    querybuf << " )";

    this->Query->SetQuery(querybuf.str().c_str());
    vtkDebugMacro(<< "Prepared query text: "
                  << querybuf.str().c_str());
    }

  // Now we can iterate over the rows and write them one by one
  for (int row = 0; row < writeTable->GetNumberOfRows(); ++row)
    {
    if (this->UsePreparedStatements)
      {
      for (int col = 0; col < writeTable->GetNumberOfColumns(); ++col)
        {
        this->Query->BindParameter(col, writeTable->GetValue(row, col));
        vtkDebugMacro(<<"Row " << row << ", col " << col
                      <<": binding parameter value "
                      << writeTable->GetValue(row, col).ToString().c_str());
        }
      }
    else
      {
      vtksys_ios::ostringstream querybuf;
      querybuf << preamble.str();
      for (int col = 0; col < writeTable->GetNumberOfColumns(); ++col)
        {
        if (col > 0)
          {
          querybuf << ", ";
          }
        vtkVariant value = writeTable->GetValue(row, col);
        if (!value.IsValid())
          {
          querybuf << "NULL";
          }
        else if (value.GetType() == VTK_OBJECT)
          {
          vtkWarningMacro(<<"Cannot insert variants of type VTK_OBJECT into a database.  Trying to insert NULL instead.");
          querybuf << "NULL";
          }
        else if (value.GetType() == VTK_STRING)
          {
          querybuf << this->Query->EscapeString(value.ToString());
          }
        else
          {
          querybuf << value.ToString();
          }
        }
      querybuf << " )";
      vtkDebugMacro(<<"Raw text SQL query: "
                    << querybuf.str().c_str());
      this->Query->SetQuery(querybuf.str().c_str());
      }

    bool insertStatus = this->Query->Execute();
    if (!insertStatus)
      {
      vtkErrorMacro(<< "Error inserting row " << row << " of "
                    << writeTable->GetNumberOfRows() << ": "
                    << this->Query->GetLastErrorText());
      }
    }

  writeTable->Delete();
}
