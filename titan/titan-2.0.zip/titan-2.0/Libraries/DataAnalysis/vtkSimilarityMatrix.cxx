/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkSimilarityMatrix.h"

#include "vtkArrayData.h"
#include "vtkDenseArray.h"
#include "vtkDoubleArray.h"
#include "vtkInformation.h"
#include "vtkInformationVector.h"
#include "vtkObjectFactory.h"
#include "vtkSmartPointer.h"

#include <vtksys/ios/sstream>
#include <vtksys/stl/stdexcept>
#include <vtksys/stl/vector>



// ----------------------------------------------------------------------

vtkSimilarityMatrix::vtkSimilarityMatrix()
{
  // nothing to do yet
}

// ----------------------------------------------------------------------

vtkSimilarityMatrix::~vtkSimilarityMatrix()
{
  // still nothing to do
}

// ----------------------------------------------------------------------

void
vtkSimilarityMatrix::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

// ----------------------------------------------------------------------

int
vtkSimilarityMatrix::RequestData(vtkInformation *vtkNotUsed(request),
                                 vtkInformationVector **inVector,
                                 vtkInformationVector *vtkNotUsed(outVector))
{
  vtkArrayData *input = vtkArrayData::GetData(inVector[0], 0);

  try
    {
    if (input->GetNumberOfArrays() == 0)
      {
      throw vtksys_stl::runtime_error("There are no arrays in vtkArrayData input 0.");
      }

    typedef vtkDenseArray<double> vtkDenseDoubleArray;
    vtkDenseDoubleArray *matrix =
      vtkDenseDoubleArray::SafeDownCast(input->GetArray(0));

    if (matrix == 0)
      {
      vtksys_ios::ostringstream errbuf;
      errbuf << "Array 0 is not a vtkDenseArray<double> as is currently required.  Its class name is "
             << input->GetArray(0)->GetClassName() << ".";
      throw vtksys_stl::runtime_error(errbuf.str());
      }

    if(!matrix->GetExtents().ZeroBased())
      throw vtksys_stl::runtime_error("Input array must use zero-based indices.");

    // Since I'm not gigantically concerned about memory consumption
    // right now I'm going to go ahead and pull out all the rows at
    // once into vtkDoubleArrays.  It is somewhat inefficient to copy
    // the entire input matrix but it makes implementation of the
    // pairwise score function much simpler.  Also, we're going to
    // need a dense row representation like this anyway when we move
    // on to sparse arrays.  Let's just get used to it now.
    typedef vtkSmartPointer<vtkDoubleArray> vtkDoubleArraySmartPointer;
    vtksys_stl::vector<vtkDoubleArraySmartPointer> rows_as_arrays;

    vtkArrayExtents extents = matrix->GetExtents();
    int num_rows = extents[0].GetSize();
    int num_columns = extents[1].GetSize();
    for (int row = 0; row < num_rows; ++row)
      {
      rows_as_arrays.push_back(vtkDoubleArraySmartPointer::New());
      rows_as_arrays[row]->SetNumberOfTuples(num_columns);

      for (int col = 0; col < num_columns; ++col)
        {
        rows_as_arrays[row]->SetValue(col, matrix->GetValue(row,col));
        }
      }

    vtkSmartPointer<vtkDenseDoubleArray> output_matrix =
      vtkSmartPointer<vtkDenseDoubleArray>::New();
    output_matrix->Resize(num_rows, num_rows);

    for (int left_entry = 0; left_entry < num_rows; ++left_entry)
      {
      for (int right_entry = 0; right_entry < num_rows; ++right_entry)
        {
        output_matrix->SetValue(
          left_entry, right_entry,
          this->ComputePairwiseScore(rows_as_arrays[left_entry],
                                     rows_as_arrays[right_entry])
          );
        }
      }

    vtkArrayData *output = this->GetOutput();
    output->AddArray(output_matrix);
    }
  catch (const vtksys_stl::runtime_error &e)
    {
    vtkErrorMacro(<< "ERROR: " << e.what());
    return 0;
    }

  return 1;
}
