/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/


#include "vtkJensenShannonSimilarityMatrix.h"

#include "vtkDoubleArray.h"
#include "vtkObjectFactory.h"

#include <vtksys/stl/vector>
#include <math.h>

#if defined(_MSC_VER)
# include <float.h> // needed for _isnan
#endif


vtkStandardNewMacro(vtkJensenShannonSimilarityMatrix);

namespace
{
  inline double Log2(double x)
  {
#if defined(_MSC_VER)
    return (log(x) / log(2.0));
#else
    return log2(x);
#endif
  }

#if defined(_MSC_VER)
  inline int IsNAN(double x)
  {
    return _isnan(x);
  }

  inline int IsNAN(float x)
  {
    return _isnan(x);
  }
#else
  inline int IsNAN(double x)
  {
    return isnan(x);
  }

  inline int IsNAN(float x)
  {
    return isnan(x);
  }
#endif

// ----------------------------------------------------------------------

double
OneSidedDistance(vtkDoubleArray *v1,
                 vtkDoubleArray *v2)
{
  double dist = 0;
  double *data1 = v1->GetPointer(0);
  double *data2 = v2->GetPointer(0);

  for (int i = 0; i < v1->GetNumberOfTuples(); ++i)
    {
    double p_i = data1[i];
    double q_i = data2[i];

    if (q_i == 0)
      {
      q_i = 1e-20; // guard against division by zero
      }

    if (p_i == 0)
      {
      p_i = 1e-20; // guard against taking the log of zero
      }

    double value = p_i * Log2(p_i / q_i);

    // We can remove this later if it turns out to be a performance
    // problem
    if (IsNAN(value))
      {
      vtkGenericWarningMacro(<<"ERROR computing KL divergence, entry "
                             << i << ": p "
                             << p_i << ", q " << q_i << ", p/q "
                             << p_i / q_i << ", log(p/q) "
                             << Log2(p_i/q_i) << ", final value "
                             << value);
      }
    dist += value;
    }
  return dist;
}

}

// ----------------------------------------------------------------------

vtkJensenShannonSimilarityMatrix::vtkJensenShannonSimilarityMatrix()
{
  this->Middle = vtkSmartPointer<vtkDoubleArray>::New();
}

// ----------------------------------------------------------------------

vtkJensenShannonSimilarityMatrix::~vtkJensenShannonSimilarityMatrix()
{
  // still nothing to do
}

// ----------------------------------------------------------------------

void
vtkJensenShannonSimilarityMatrix::PrintSelf(ostream &os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
}

// ----------------------------------------------------------------------

double
vtkJensenShannonSimilarityMatrix::ComputePairwiseScore(vtkDoubleArray *A,
                                                       vtkDoubleArray *B)
{
  this->Middle->SetNumberOfTuples(A->GetNumberOfTuples());

  for (int i = 0; i < A->GetNumberOfTuples(); ++i)
    {
    this->Middle->SetValue(i, 0.5 * (A->GetValue(i) + B->GetValue(i)));
    }
  double distance =
    0.5 * (::OneSidedDistance(A, this->Middle) +
           ::OneSidedDistance(B, this->Middle));
  return distance;

}
