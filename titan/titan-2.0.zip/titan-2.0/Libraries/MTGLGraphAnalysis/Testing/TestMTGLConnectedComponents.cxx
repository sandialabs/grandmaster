/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ostream>
#include <iostream>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSelectionSource.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"

#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLConnectedComponents.h"
#include "vtkBoostConnectedComponents.h"

#include <stdexcept>
#include <map>   // for comparison of boost cc with mtgl cc

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;



void print_vtk_graph(vtkGraph * the_graph)
{
  for(int i=0; i<the_graph->GetNumberOfVertices(); i++)
    {
    printf("%5lu (%2lu) { ", (long unsigned int)i,
                             (long unsigned int)the_graph->GetOutDegree(i));
    VTK_CREATE(vtkOutEdgeIterator, outEdgeIter);
    the_graph->GetOutEdges( i, outEdgeIter );
    while(outEdgeIter->HasNext())
      {
      vtkOutEdgeType outEdge = outEdgeIter->Next();
      printf("%lu ", (long unsigned int)outEdge.Target);
      }
    printf("}\n");
    }
}


////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLConnectedComponents(int, char** const)
int main(int /*argc*/, char * /*argv*/ [])
{
try {
  cout << "start" << endl; fflush(stdout);
  int testFailed = false;

  // Create a random graph with edge weights
  // (will be an undirected graph)
  VTK_CREATE(vtkRandomGraphSource, graph_source);
  graph_source->SetNumberOfVertices(30);
  graph_source->SetEdgeProbability(0.05);
  graph_source->UseEdgeProbabilityOn();
  graph_source->AllowParallelEdgesOn();
  graph_source->AllowSelfLoopsOn();
  graph_source->SetIncludeEdgeWeights(true);
  graph_source->SetStartWithTree(false);
  graph_source->Update();

  vtkGraph * the_graph = graph_source->GetOutput();

  if(the_graph)
    {
    cout << "graph created successfully." << endl;
    cout << endl;
    }
  else
    {
    cout << "ERROR: graph was not created successfully." << endl;
    fflush(stdout);
    testFailed = true;
    return(testFailed);
    }

  // Nothing special currently for validation -- just call PrintSelf.
  // For now, if we don't segfault we're probably doing ok.
  cout << endl
       << "==========================================================" << endl
       << "==========[ Print Information of Source Graph" << endl
       << "==========================================================" << endl
       << endl;

  print_vtk_graph(the_graph);
  //the_graph->PrintSelf(cout, vtkIndent(0));

  VTK_CREATE(vtkBoostConnectedComponents, boost_ccomp);
  boost_ccomp->SetInputConnection(graph_source->GetOutputPort());
  boost_ccomp->Update();

  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST MTGL Connected Components Algorithm" << endl
       << "==========================================================" << endl
       << endl;

  VTK_CREATE(vtkMTGLConnectedComponents, ccomp);
  ccomp->SetGraphConnection(graph_source->GetOutputPort());
  ccomp->Update();
  //ccomp->GetOutput()->PrintSelf(cout, vtkIndent(0));

  map<vtkIdType, vtkIdType> cc_map;
  map<vtkIdType, vtkIdType>::iterator cc_map_iter;

  for(vtkIdType i=0; i<ccomp->GetOutput()->GetNumberOfVertices(); i++)
    {
    vtkIdType boost_ccid = boost_ccomp->GetOutput()->GetVertexData()->GetArray("component")->GetVariantValue(i).ToUnsignedInt();
    vtkIdType mtgl_ccid  = ccomp->GetOutput()->GetVertexData()->GetArray("component")->GetVariantValue(i).ToUnsignedInt();

    cout << "Check:  BoostCC=" << boost_ccid << " :: MtglCC=" << mtgl_ccid << "\t";

    cc_map_iter = cc_map.find(boost_ccid);
    if(cc_map_iter == cc_map.end())
      {
      cc_map[boost_ccid] = mtgl_ccid;
      cout << "(ADD TO MAP)";
      }
    else if( cc_map_iter->second == mtgl_ccid )
      {
      cout << "(OK)";
      }
    else
      {
      cout << "(FAIL)";
      testFailed = true;
      }
    cout << endl;
#if 0
    cout << i;
    cout << "\tboost CC: " << boost_ccid;
    cout << "\tmtgl CC: " << mtgl_ccid;
    cout << endl;
#endif
    }

  // Create a MTGL graph adapter and link the source graph to it.
  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
