/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <iostream>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSmartPointer.h"
#include "vtkMTGLGraphAdapter.h"

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;


////////////////////////////////////////////////////////////////////////////////
///
///
void print_vtk_graph(vtkGraph * the_graph)
{
  for(int i=0; i<the_graph->GetNumberOfVertices(); i++)
    {
    printf("%5lu (%2lu) { ", (long unsigned int)i,
                             (long unsigned int)the_graph->GetOutDegree(i));
    VTK_CREATE(vtkOutEdgeIterator, outEdgeIter);
    the_graph->GetOutEdges( i, outEdgeIter );
    while(outEdgeIter->HasNext())
      {
      vtkOutEdgeType outEdge = outEdgeIter->Next();
      printf("%lu ", (long unsigned int)outEdge.Target);
      }
    printf("}\n");
    }
}



////////////////////////////////////////////////////////////////////////////////
///
///
template<typename graph_adapter>
bool test_graph_direction(graph_adapter &ga)
{
  bool testFailed = false;

  cout << "==========[ TEST graph direction" << endl;
  cout << "\tis_directed      = " << is_directed(ga) << endl;
  cout << "\tis_undirected    = " << is_undirected(ga) << endl;
  cout << "\tis_bidirectional = " << is_bidirectional(ga) << endl;

  return testFailed;
}



////////////////////////////////////////////////////////////////////////////////
///
///
template<typename graph_adapter>
bool test_graph_sizes(graph_adapter &ga,
                      vtkGraph &the_graph)
{
  typedef typename graph_adapter::size_type size_type;

  bool testFailed = false;
  cout << "==========[ TEST graph sizes" << endl;

  size_type numVerts = num_vertices(ga);
  size_type numEdges = num_edges(ga);

  if(numVerts != the_graph.GetNumberOfVertices())
    {
    cout << "FAIL\tnum_vertices()" << endl;
    cout << "\tgraph_adapter reports " << numVerts << endl;
    cout << "\tvtkGraph reports " << the_graph.GetNumberOfVertices() << endl;
    testFailed = true;
    }
  else
    {
    cout << "PASS\tnum_vertices()" << endl;
    }

  if(numEdges != the_graph.GetNumberOfEdges())
    {
    cout << "FAIL\tnum_edges()" << endl;
    cout << "\tgraph_adapter reports " << numEdges << endl;
    cout << "\tvtkGraph reports " << the_graph.GetNumberOfEdges() << endl;
    testFailed = true;
    }
  else
    {
    cout << "PASS\tnum_edges()" << endl;
    }
  return testFailed;
}



////////////////////////////////////////////////////////////////////////////////
///
///
template<typename graph_adapter>
bool test_vertex_iterator(graph_adapter &ga,
                          vtkGraph &the_graph)
{
  typedef typename graph_adapter::size_type          size_type;
  typedef typename graph_adapter::vertex_iterator    vertex_iterator;
  typedef typename graph_adapter::vertex_descriptor  vertex_descriptor;
  typedef typename graph_adapter::adjacency_iterator adjacency_iterator;

  bool testFailed = false;
  vertex_id_map<graph_adapter> vid_map = get(_vertex_id_map, ga);

  cout << "==========[ TEST vertex_iterator, adjacency_iterator" << endl;

  size_type numVerts = num_vertices(ga);
  size_type numEdges = num_edges(ga);

  // Iterate over vertices
  size_type i, j, k;
  vertex_iterator viter = vertices(ga);
  for (i=0; i<numVerts; i++)
    {
    vertex_descriptor u = viter[i];
    size_type uid       = get(vid_map, u);
    size_type out_deg   = out_degree(u, ga);

    printf("%5lu %5lu (%2lu) { ", (long unsigned int) i,
                                  (long unsigned int) uid,
                                  (long unsigned int) out_deg);
    if(out_deg != the_graph.GetOutDegree(i))
      {
      cout << "FAIL\tout_degree(u, g) failed" << endl;
      testFailed = true;
      }

    adjacency_iterator adjs = adjacent_vertices(u, ga);
    for(j=0; j<out_deg; j++)
      {
      vertex_descriptor v = adjs[j];
      size_type vid = get(vid_map, v);
      printf("%lu ", (long unsigned int) vid);
      }
    printf("}\n");
    }

  // Check results of vertices() & resulting vertex_iterator
  if(i != the_graph.GetNumberOfVertices())
    {
    testFailed = true;
    cout << "FAIL\tvertices() produced vertex_iterator failure." << endl;
    cout << "    \tIterator visitied " << i << " vertices." << endl
         << "    \tShould have seen " << the_graph.GetNumberOfVertices()
         << " vertices" << endl;
    }
  else
    {
    cout << "PASS\tvertices()" << endl;
    }

  return testFailed;
}



////////////////////////////////////////////////////////////////////////////////
///
///
template<typename graph_adapter>
bool test_out_edge_iterator(graph_adapter &ga,
                            vtkGraph &the_graph)
{
  typedef typename graph_adapter::size_type         size_type;
  typedef typename graph_adapter::vertex_descriptor vertex_descriptor;
  typedef typename graph_adapter::edge_descriptor   edge_descriptor;
  typedef typename graph_adapter::out_edge_iterator out_edge_iterator;

  bool testFailed = false;

  cout << "==========[ TEST out_edge_iterator" << endl;
  size_type i, j, k;

  for(vertex_descriptor v=0; v<2; v++)
    {
    //vertex_descriptor v = 0;
    cout << "iterate out-edges of vertex " << v << endl;
    out_edge_iterator out_eiter = out_edges(v, ga);
    for(j=0; j<out_degree(v, ga); j++)
      {
      edge_descriptor e = out_eiter[j];
      cout << "\t"
           << source(e, ga) << "->"
           << target(e, ga) << " ";
      if(other(e, source(e,ga), ga) == target(e,ga) &&
         other(e, target(e,ga), ga) == source(e,ga)  )
        {
        cout << "\tPASS";
        }
      else
        {
        cout << "\tFAIL";
        }
      cout << endl;
      }
    }
  return testFailed;
}



////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLGraphAdapter(int, char** const)
int
main(int /*argc*/, char * /*argv*/[])
{
try
  {
  int testFailed = false;

  // Create a random graph with edge weights
  // (defaults to undirected)
  VTK_CREATE(vtkRandomGraphSource, graph_source);
  graph_source->SetNumberOfVertices(15);
  graph_source->SetEdgeProbability(0.1);
  graph_source->UseEdgeProbabilityOn();
  graph_source->AllowParallelEdgesOn();
  graph_source->AllowSelfLoopsOn();
  graph_source->SetIncludeEdgeWeights(true);
  graph_source->SetStartWithTree(true);
  graph_source->Update();

  vtkGraph * the_graph = graph_source->GetOutput();

  // ---------------------------------------
  // Print out the VTK graph natively.
  // ---------------------------------------
  cout << "==========[ PRINT the VTK graph using native iterators." << endl;
  print_vtk_graph(the_graph);

  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST vtkGraph f/m RandomGraphSource"            << endl
       << "==========================================================" << endl
       << endl;

  // ---------------------------------------
  // Set some MTGL typedefs
  // ---------------------------------------
  typedef vtkIdType size_type;
#if 0
  typedef vtkMTGLGraphAdapter<undirectedS>          mtgl_graph_adapter;
  typedef mtgl_graph_adapter::size_type             size_type;
  typedef mtgl_graph_adapter::vertex_descriptor     vertex_descriptor;
  typedef mtgl_graph_adapter::edge_descriptor       edge_descriptor;
  typedef mtgl_graph_adapter::vertex_iterator       vertex_iterator;
  typedef mtgl_graph_adapter::adjacency_iterator    adjacency_iterator;
  typedef mtgl_graph_adapter::out_edge_iterator     out_edge_iterator;
  typedef mtgl_graph_adapter::in_edge_iterator      in_edge_iterator;
  typedef mtgl_graph_adapter::in_adjacency_iterator in_adjacency_iterator;
#endif

  // ---------------------------------------
  // Set up the MTGL graph adapter
  // ---------------------------------------
  vtkMTGLGraphAdapter<undirectedS> vtk_ga(*the_graph);

  // ---------------------------------------
  // Test graph directedness
  // ---------------------------------------
  testFailed = test_graph_direction(vtk_ga);

  // ---------------------------------------
  // Get the number of vertices and edges
  // ---------------------------------------
  testFailed = test_graph_sizes(vtk_ga, *the_graph);

  // ---------------------------------------
  // Test the vertex iterator
  // ---------------------------------------
  testFailed = test_vertex_iterator(vtk_ga, *the_graph);

  // ----------------------------------
  // Test the out_edge_iterator
  // ----------------------------------
  testFailed = test_out_edge_iterator(vtk_ga, *the_graph);


  ///
  /// Test init() function -- create a vtkGraph using MTGL init() call
  ///
  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST init() on Mutable Directed Graph"          << endl
       << "==========================================================" << endl
       << endl;

  VTK_CREATE(vtkMutableDirectedGraph, mutableDirectedGraph);

  vtkMTGLGraphAdapter<directedS> vtk_mdga(*mutableDirectedGraph);

  size_type n = 6;
  size_type m = 8;
  size_type srcs[8] = {0,1,2,2,3,3,4,4};
  size_type trgs[8] = {1,2,3,4,4,5,3,5};

  init(n,m,srcs,trgs,vtk_mdga);

  // Run some tests on this graph
  testFailed = test_graph_direction(vtk_mdga);
  testFailed = test_graph_sizes(vtk_mdga, *mutableDirectedGraph);
  testFailed = test_vertex_iterator(vtk_mdga, *mutableDirectedGraph);
  testFailed = test_out_edge_iterator(vtk_mdga, *mutableDirectedGraph);


  // Create a MTGL graph adapter and link the source graph to it.
  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std::cerr << e.what() << std::endl;
  return 1;
  }
}
