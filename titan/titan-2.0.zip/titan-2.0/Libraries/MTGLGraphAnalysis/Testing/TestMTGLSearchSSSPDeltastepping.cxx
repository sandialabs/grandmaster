/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ostream>
#include <iostream>

#include "vtkGraph.h"
#include "vtkMutableDirectedGraph.h"
#include "vtkIndent.h"
#include "vtkIdTypeArray.h"
#include "vtkPointData.h"
#include "vtkRandomGraphSource.h"
#include "vtkSelectionSource.h"
#include "vtkSelectionNode.h"
#include "vtkSmartPointer.h"
#include "vtkMTGLGraphAdapter.h"
#include "vtkMTGLSearchSSSPDeltastepping.h"

#define VTK_CREATE(type, name) vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using namespace mtgl;
using namespace std;


// ---------------------------------------
// Set some MTGL typedefs
// ---------------------------------------
typedef vtkMTGLGraphAdapter<directedS> mtgl_graph_adapter;
typedef mtgl_graph_adapter::size_type          size_type;
typedef mtgl_graph_adapter::vertex_descriptor  vertex_descriptor;
typedef mtgl_graph_adapter::edge_descriptor    edge_descriptor;
typedef mtgl_graph_adapter::vertex_iterator    vertex_iterator;
typedef mtgl_graph_adapter::adjacency_iterator adjacency_iterator;
typedef mtgl_graph_adapter::out_edge_iterator  out_edge_iterator;
typedef mtgl_graph_adapter::in_edge_iterator   in_edge_iterator;



////////////////////////////////////////////////////////////////////////////////
///
///
//int TestMTGLSearchSSSPDeltastepping(int, char** const)
int main(int argc, char* argv[])
{
try
  {
  int testFailed = false;

  // Create a random graph with edge weights
  VTK_CREATE(vtkRandomGraphSource, graph_source);
  graph_source->SetNumberOfVertices(15);
  graph_source->SetEdgeProbability(0.1);
  graph_source->UseEdgeProbabilityOn();
  graph_source->AllowParallelEdgesOn();
  graph_source->AllowSelfLoopsOn();
  graph_source->SetIncludeEdgeWeights(true);
  graph_source->SetStartWithTree(true);
  graph_source->Update();

  vtkGraph * the_graph = graph_source->GetOutput();

  cout << endl
       << "==========================================================" << endl
       << "==========[ TEST MTGL SSSP Deltastepping" << endl
       << "==========================================================" << endl
       << endl;

  VTK_CREATE(vtkSelectionSource, selection);
  selection->SetFieldType(3);
  selection->SetContentType(4);
  selection->AddID(0,0);

  VTK_CREATE(vtkMTGLSearchSSSPDeltastepping, sssp_search);
  sssp_search->SetGraphConnection(graph_source->GetOutputPort());
  sssp_search->SetSelectionConnection(selection->GetOutputPort());
  sssp_search->SetInputArrayNameEdgeWeights("edge weight");
  sssp_search->SetOutputArrayNameVertexWeights("sssp weights");
  sssp_search->Update();

  sssp_search->GetOutput()->PrintSelf(cout, vtkIndent(0));

  // Create a MTGL graph adapter and link the source graph to it.
  cout << "Done" << endl;

  return testFailed;
  }
catch(std::exception& e)
  {
  std:cerr << e.what() << std::endl;
  return 1;
  }
}
