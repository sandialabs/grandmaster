/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/
#include "vtkMTGLSelectionFilterMultiCSG.h"
#include "vtkMTGLSelectionFilterCSG.h"

#include <vtkCellData.h>
#include <vtkCommand.h>
#include <vtkConvertSelection.h>
#include <vtkDataArray.h>
#include <vtkEventForwarderCommand.h>
#include <vtkExtractSelection.h>
#include <vtkGraph.h>
#include <vtkIdTypeArray.h>
#include <vtkInformation.h>
#include <vtkInformationVector.h>
#include <vtkObjectFactory.h>
#include <vtkSelection.h>
#include <vtkSelectionNode.h>
#include <vtkSelectionSource.h>
#include <vtkPointData.h>
#include <vtkSmartPointer.h>
#include <vtkSortDataArray.h>

#include <vtksys/stl/set>

#define VTK_CREATE(type, name) \
  vtkSmartPointer<type> name = vtkSmartPointer<type>::New()

using vtksys_stl::set;
using namespace std;


vtkStandardNewMacro(vtkMTGLSelectionFilterMultiCSG);



vtkMTGLSelectionFilterMultiCSG::vtkMTGLSelectionFilterMultiCSG()
{
  this->SetNumberOfInputPorts(2);
  this->NumberOfIterations = 1;
  this->OutputPedigreeIdSelection = true;
}



vtkMTGLSelectionFilterMultiCSG::~vtkMTGLSelectionFilterMultiCSG()
{
}



int vtkMTGLSelectionFilterMultiCSG::FillInputPortInformation(int port, vtkInformation* info)
{
  if (port == 0)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkSelection");
    return 1;
    }
  else if (port == 1)
    {
    info->Set(vtkAlgorithm::INPUT_REQUIRED_DATA_TYPE(), "vtkGraph");
    return 1;
    }
  return 0;
}



void vtkMTGLSelectionFilterMultiCSG::SetGraphConnection(vtkAlgorithmOutput * in)
{
  this->SetInputConnection(1, in);
}



int vtkMTGLSelectionFilterMultiCSG::RequestData(vtkInformation* vtkNotUsed(request),
                                               vtkInformationVector** inputVector,
                                               vtkInformationVector* outputVector)
{
  vtkSelection * input  = vtkSelection::GetData(inputVector[0]);
  vtkGraph     * graph  = vtkGraph::GetData(inputVector[1]);
  vtkSelection * output = vtkSelection::GetData(outputVector);

  VTK_CREATE(vtkIdTypeArray, indexArray);
  vtkConvertSelection::GetSelectedVertices(input, graph, indexArray);

  vtkIdType indexArraySize = indexArray->GetNumberOfTuples();

  // Do a quick sanity check
  if(indexArraySize < 1)
    {
    return 1;
    }
  else if(indexArraySize==1)
    {
    // If there's only one entity selected, just copy the input to the output.
    output->ShallowCopy(input);
    }
  else if(indexArraySize > 1)
    {
    // If at least 2 nodes are selected, we do pairwise ST searches and merge
    // results.
    double counter = 0;
    for(int i=0; i<indexArraySize; i++)
      {
      for(int j=i+1; j<indexArraySize; j++)
        {
        counter += 1.0;
        vtkIdType srcid = indexArray->GetValue(i);
        vtkIdType trgid = indexArray->GetValue(j);
        //cout << "Finding S-T for pair: " << srcid << "::" << trgid << endl;

        VTK_CREATE(vtkSelectionSource, CurrentPair);
        CurrentPair->SetFieldType(vtkSelectionNode::VERTEX);
        CurrentPair->SetContentType(vtkSelectionNode::INDICES);
        CurrentPair->AddID(0, srcid);
        CurrentPair->AddID(0, trgid);

        // Create search
        VTK_CREATE(vtkMTGLSelectionFilterCSG, search);
        search->SetNumberOfIterations(this->NumberOfIterations);
        search->SetOutputPedigreeIdSelection(this->OutputPedigreeIdSelection);
        search->AddInputConnection( CurrentPair->GetOutputPort() );
        search->SetGraphData( graph );
        search->Update();

        // If we didn't get anything, just add the input points
        if(search->GetOutput()->GetNumberOfNodes()==0)
          {
          output->Union( CurrentPair->GetOutput() );
          }
        else
          {
          output->Union( search->GetOutput() );
          }
        double progress = counter / indexArraySize;
        this->InvokeEvent(vtkCommand::ProgressEvent, &progress);
        }
      }
    }

  return 1;
}



void vtkMTGLSelectionFilterMultiCSG::PrintSelf(ostream& os, vtkIndent indent)
{
  this->Superclass::PrintSelf(os, indent);
  os << indent << "OutputPedigreeIdSelection: "
     << (this->OutputPedigreeIdSelection ? "on" : "off") << endl;
}
