/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

#ifndef __vtkMTGLSearchSSSPDeltastepping_h
#define __vtkMTGLSearchSSSPDeltastepping_h

#include "vtkGraphAlgorithm.h"
#include "titanMTGLGraphAnalysis.h"

// Forward declaration
class vtkFloatArray;

class TITAN_MTGL_EXPORT vtkMTGLSearchSSSPDeltastepping : public vtkGraphAlgorithm
{
public:
  static vtkMTGLSearchSSSPDeltastepping *New();

  vtkTypeMacro(vtkMTGLSearchSSSPDeltastepping, vtkGraphAlgorithm);
  void PrintSelf(ostream & os, vtkIndent indent);
  void SetGraphConnection(vtkAlgorithmOutput *);
  void SetSelectionConnection(vtkAlgorithmOutput * in);

  /// Specify the input port (i.e., the edge-selection)
  int FillInputPortInformation(int, vtkInformation *);

  ///@{
  /// Set the output array name.  If no output array name is
  /// set then name "vertex_time" is used.
  vtkSetStringMacro(OutputArrayNameVertexWeights);
  ///@}

  // set the input array name.  If no input array name is set
  // then uses "edge_time".
  vtkSetStringMacro(InputArrayNameEdgeWeights);

protected:

  vtkMTGLSearchSSSPDeltastepping();
  ~vtkMTGLSearchSSSPDeltastepping();


  int RequestData(vtkInformation *,
                  vtkInformationVector **,
                  vtkInformationVector *);


private:

  char * OutputArrayNameVertexWeights;
  char * InputArrayNameEdgeWeights;

  // not implemented
  vtkMTGLSearchSSSPDeltastepping(const vtkMTGLSearchSSSPDeltastepping&);
  // not implemented
  void operator=(const vtkMTGLSearchSSSPDeltastepping&);

//BTX
  template<typename graph_adapter>
  void mtgl_worker(graph_adapter &, vtkFloatArray*, vtkFloatArray*, int);
//ETX

};

#endif
