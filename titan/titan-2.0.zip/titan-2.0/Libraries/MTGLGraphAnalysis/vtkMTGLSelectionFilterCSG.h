/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

/// \class vtkMTGLSelectionFilterCSG vtkMTGLSelectionFilterCSG.h <MTGLGraphAnalysis/vtkMTGLSelectionFilterCSG.h>
/// \brief computes connection subgraphs
///
///  The first input is a vtkSelection containing the selected vertices
///     (two of them)
///  The second input is a vtkGraph.
///  This filter computes the connection subgraphs algorithm, which is similar
///  to S-T shortest paths except that it uses an electrical-circuit motif
///  that selects paths which tend to meet the following properties:
///  1) Shorter paths are preferred over longer paths
///  2) Paths with high-degree vertices are penalized, tends to avoid them.


#ifndef __vtkMTGLSelectionFilterCSG_h
#define __vtkMTGLSelectionFilterCSG_h

//#include "vtkInfovisWin32Header.h"
#include "titanMTGLGraphAnalysis.h"
#include "vtkSelectionAlgorithm.h"

// Forward Declarations
class vtkGraph;
class vtkIdTypeArray;


class TITAN_MTGL_EXPORT vtkMTGLSelectionFilterCSG : public vtkSelectionAlgorithm
{
public:
  static vtkMTGLSelectionFilterCSG* New();
  vtkTypeMacro(vtkMTGLSelectionFilterCSG,vtkSelectionAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  /// A convenience method for setting the second input (i.e. the graph).
  void SetGraphConnection(vtkAlgorithmOutput* in);
  void SetGraphData(vtkDataObject* in);

  /// Specify the first vtkSelection input and the second vtkGraph input.
  int FillInputPortInformation(int port, vtkInformation* info);

  ///@{
  /// Set/Get IncludeShortestPaths controls whether this filter tries to
  /// 'connect' the vertices in the selection set by computing the
  /// shortest path between the vertices (if such a path exists)
  /// Note: IncludeShortestPaths is currently non-functional
  vtkSetMacro(IncludeShortestPaths, bool);
  vtkGetMacro(IncludeShortestPaths, bool);
  vtkBooleanMacro(IncludeShortestPaths, bool);
  ///@}

  ///@{
  /// Set/Get NumberOfIterations controls the number of iterations the CSG
  /// code performs.  If set to 1, only a single short path is returned.
  /// Each additional iteration adds an additional path, or an additional
  /// spur to an existing path.  There is no guarantee that additional paths
  /// will be found with additional iterations. Default value is 1.
  vtkSetMacro(NumberOfIterations, int);
  vtkGetMacro(NumberOfIterations, int);
  ///@}

  ///@{
  /// Set/Get whether to output a pedigree id selection
  vtkSetMacro(OutputPedigreeIdSelection, bool);
  vtkGetMacro(OutputPedigreeIdSelection, bool);
  ///@}

protected:
  vtkMTGLSelectionFilterCSG();
  ~vtkMTGLSelectionFilterCSG();

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

  int  Distance;
  int  NumberOfIterations;
  bool IncludeShortestPaths;

  bool OutputPedigreeIdSelection;

private:
  vtkMTGLSelectionFilterCSG(const vtkMTGLSelectionFilterCSG&); // Not implemented
  void operator=(const vtkMTGLSelectionFilterCSG&);   // Not implemented

//BTX
  template<typename graph_adapter>
  void mtgl_worker(graph_adapter &, vtkIdTypeArray*, int, int, int, int, double);
//ETX

  void ExecuteCSGSearch(vtkIdTypeArray*, vtkGraph*);
};

#endif
