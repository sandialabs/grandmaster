/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/*----------------------------------------------------------------------------
 Copyright (c) Sandia Corporation
 See Copyright.txt or http://www.paraview.org/HTML/Copyright.html for details.
----------------------------------------------------------------------------*/

/// \class vtkMTGLConnectedComponents vtkMTGLConnectedComponents.h <MTGLGraphAnalysis/vtkMTGLConnectedComponents.h>
/// \brief ...
///
///  Implements the MTGL connected components algorithm using the Shiloach-Vishkin
///  method.
///
#ifndef __vtkMTGLConnectedComponents_h
#define __vtkMTGLConnectedComponents_h

//#include "vtkInfovisWin32Header.h"
#include "titanMTGLGraphAnalysis.h"
#include "vtkGraphAlgorithm.h"



class TITAN_MTGL_EXPORT vtkMTGLConnectedComponents : public vtkGraphAlgorithm
{
public:
  static vtkMTGLConnectedComponents* New();
  vtkTypeMacro(vtkMTGLConnectedComponents,vtkGraphAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  /// A convenience method for setting the graph input
  void SetGraphConnection(vtkAlgorithmOutput* in);

  /// Fill Input ports.  Port 0 is the graph
  int FillInputPortInformation(int port, vtkInformation* info);

  ///@{
  /// Set the output components array name.  Default value is "component".
  vtkSetStringMacro(ComponentArrayName);
  vtkGetStringMacro(ComponentArrayName);
  ///@}

protected:
  vtkMTGLConnectedComponents();
  ~vtkMTGLConnectedComponents();

  int RequestData(
    vtkInformation*,
    vtkInformationVector**,
    vtkInformationVector*);

private:

//BTX
  template<typename graph_adapter>
  void mtgl_worker(graph_adapter &, vtkIdTypeArray*);
//ETX

  vtkMTGLConnectedComponents(const vtkMTGLConnectedComponents&); // Not implemented
  void operator=(const vtkMTGLConnectedComponents&);   // Not implemented

  char * ComponentArrayName;
};

#endif
