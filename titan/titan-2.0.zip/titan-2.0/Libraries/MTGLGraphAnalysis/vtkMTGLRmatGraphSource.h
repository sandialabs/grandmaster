/**********************************************************************
 This source file is part of the Titan Toolkit

 Copyright 2010 Sandia Corporation.  Under the terms of Contract
 DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government
 retains certain rights in this software.

 This source code is released under the New BSD License.
 **********************************************************************/

/// \class vtkMTGLRmatGraphSource vtkMTGLRmatGraphSource.h <MTGLGraphAnalysis/vtkMTGLRmatGraphSource.h>
/// \brief a graph with random edges
///
///  Generates a R-MAT graph which naturally generates power-law
///  degree distributions which model many real-world structures
///  such as social networks, the web graph, etc.
///

#ifndef __vtkMTGLRmatGraphSource_h
#define __vtkMTGLRmatGraphSource_h

#include "vtkGraphAlgorithm.h"
#include "titanMTGLGraphAnalysis.h"
//#include "vtkInfovisWin32Header.h"

class vtkGraph;
class vtkPVXMLElement;

class TITAN_MTGL_EXPORT vtkMTGLRmatGraphSource : public vtkGraphAlgorithm
{
public:
  static vtkMTGLRmatGraphSource* New();
  vtkTypeMacro(vtkMTGLRmatGraphSource,vtkGraphAlgorithm);
  void PrintSelf(ostream& os, vtkIndent indent);

  ///@{
  /// When set, includes edge weights in an array named "edge_weights".
  /// Defaults to off.  Weights are random between 0 and 1.
  /// wcm: currently unused for MTGLRmatGraphSource (!)
  vtkSetMacro(IncludeEdgeWeights, bool);
  vtkGetMacro(IncludeEdgeWeights, bool);
  vtkBooleanMacro(IncludeEdgeWeights, bool);
  ///@}

  ///@{
  /// When set, creates a directed graph, as opposed to an undirected graph.
  /// Default = False (Undirected).
  vtkSetMacro(Directed, bool);
  vtkGetMacro(Directed, bool);
  vtkBooleanMacro(Directed, bool);
  ///@}

  ///@{
  /// Control the seed used for pseudo-random-number generation.
  /// Not sure if this makes it to mtgl, might deprecate this in the future.
  vtkSetMacro(Seed, int);
  vtkGetMacro(Seed, int);
  ///@}

  ///@{
  /// Control the scale factor of the grap (i.e., # of vertices).
  /// 2^(ScaleFactor) vertices will be generated.
  /// Default = 5
  vtkSetMacro(ScaleFactor, int);
  vtkGetMacro(ScaleFactor, int);
  ///@}

  ///@{
  /// Set the edge-factor of the graph.  (Default=8)
  /// This controls the approximate average # of edges / vertex the generator
  /// will try and achieve.   Default = 4
  vtkSetMacro(EdgeFactor, int);
  vtkGetMacro(EdgeFactor, int);
  ///@}

  ///@{
  /// Set/Get the probability on partition A  (Default = 0.57)
  vtkSetMacro(ParamA, double);
  vtkGetMacro(ParamA, double);
  ///@}

  ///@{
  /// Set/Get the probability on partition B  (Default = 0.19)
  vtkSetMacro(ParamB, double);
  vtkGetMacro(ParamB, double);
  ///@}

  ///@{
  /// Set/Get the probability on partition C  (Default = 0.19)
  vtkSetMacro(ParamC, double);
  vtkGetMacro(ParamC, double);
  ///@}

  ///@{
  /// Set/Get the probability on partition D  (Default = 0.05)
  vtkSetMacro(ParamD, double);
  vtkGetMacro(ParamD, double);
  ///@}

protected:

  vtkMTGLRmatGraphSource();
  ~vtkMTGLRmatGraphSource();
  bool Directed;
  bool IncludeEdgeWeights;	// unused for now
  int Seed;

  int ScaleFactor;
  int EdgeFactor;

  double ParamA;
  double ParamB;
  double ParamC;
  double ParamD;

  virtual int RequestData( vtkInformation*,
                           vtkInformationVector**,
                           vtkInformationVector*);

  ///@{
  /// Creates directed or undirected output based on Directed flag.
  virtual int RequestDataObject( vtkInformation*,
                                 vtkInformationVector** inputVector,
                                vtkInformationVector* outputVector);
  ///@}

private:

  vtkMTGLRmatGraphSource(const vtkMTGLRmatGraphSource&); // Not implemented
  void operator=(const vtkMTGLRmatGraphSource&);   // Not implemented
};

#endif
