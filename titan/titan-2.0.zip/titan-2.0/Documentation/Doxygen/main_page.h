/** \mainpage Titan Reference Documentation

\image html titan_mark.png


\par Useful links:
\li Titan Home: http://titan.sandia.gov
\li Titan Users Mailing List: titan-users@public.kitware.com subscribe at http://public.kitware.com/cgi-bin/mailman/listinfo/titan-users
\li Titan Developers Mailing List: titan-developers@public.kitware.com subscribe at http://public.kitware.com/cgi-bin/mailman/listinfo/titan-developers
\li Titan Source Code Repository: git://public.kitware.com/titan.git
\li Titan Software Quality Dashboard: http://www.cdash.org/CDash/index.php?project=Titan

*/
